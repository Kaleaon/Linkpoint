// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import okhttp3.internal.Util;
import okhttp3.internal.cache.CacheRequest;
import okio.ForwardingSink;
import okio.Sink;

// Referenced classes of package okhttp3:
//            Cache

private final class ache.Editor
    implements CacheRequest
{

    private Sink body;
    private Sink cacheOut;
    boolean done;
    private final okhttp3.internal.cache.rt editor;
    final Cache this$0;

    public void abort()
    {
label0:
        {
            synchronized (Cache.this)
            {
                if (done)
                {
                    break label0;
                }
                done = true;
                Cache cache1 = Cache.this;
                cache1.writeAbortCount = cache1.writeAbortCount + 1;
            }
            Util.closeQuietly(cacheOut);
            try
            {
                editor.rt();
                return;
            }
            catch (IOException ioexception)
            {
                return;
            }
        }
        cache;
        JVM INSTR monitorexit ;
        return;
        exception;
        cache;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public Sink body()
    {
        return body;
    }

    public ache.Editor(okhttp3.internal.cache. )
    {
        this$0 = Cache.this;
        super();
        editor = ;
        cacheOut = .Sink(1);
        body = new ForwardingSink() {

            final Cache.CacheRequestImpl this$1;
            final okhttp3.internal.cache.DiskLruCache.Editor val$editor;
            final Cache val$this$0;

            public void close()
                throws IOException
            {
label0:
                {
                    synchronized (Cache.CacheRequestImpl.this.this$0)
                    {
                        if (done)
                        {
                            break label0;
                        }
                        done = true;
                        Cache cache2 = Cache.CacheRequestImpl.this.this$0;
                        cache2.writeSuccessCount = cache2.writeSuccessCount + 1;
                    }
                    super.close();
                    editor.commit();
                    return;
                }
                cache1;
                JVM INSTR monitorexit ;
                return;
                exception;
                cache1;
                JVM INSTR monitorexit ;
                throw exception;
            }

            
            {
                this$1 = Cache.CacheRequestImpl.this;
                this$0 = cache;
                editor = editor1;
                super(final_sink);
            }
        };
    }
}
