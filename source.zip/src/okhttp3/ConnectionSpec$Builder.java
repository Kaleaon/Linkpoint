// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            ConnectionSpec, CipherSuite, TlsVersion

public static final class tls
{

    String cipherSuites[];
    boolean supportsTlsExtensions;
    boolean tls;
    String tlsVersions[];

    public tls allEnabledCipherSuites()
    {
        if (tls)
        {
            cipherSuites = null;
            return this;
        } else
        {
            throw new IllegalStateException("no cipher suites for cleartext connections");
        }
    }

    public  allEnabledTlsVersions()
    {
        if (tls)
        {
            tlsVersions = null;
            return this;
        } else
        {
            throw new IllegalStateException("no TLS versions for cleartext connections");
        }
    }

    public ConnectionSpec build()
    {
        return new ConnectionSpec(this);
    }

    public transient  cipherSuites(String as[])
    {
        if (tls)
        {
            if (as.length != 0)
            {
                cipherSuites = (String[])as.clone();
                return this;
            } else
            {
                throw new IllegalArgumentException("At least one cipher suite is required");
            }
        } else
        {
            throw new IllegalStateException("no cipher suites for cleartext connections");
        }
    }

    public transient  cipherSuites(CipherSuite aciphersuite[])
    {
        int i = 0;
        if (!tls) goto _L2; else goto _L1
_L1:
        String as[] = new String[aciphersuite.length];
_L4:
        if (i >= aciphersuite.length)
        {
            return cipherSuites(as);
        }
        as[i] = aciphersuite[i].javaName;
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("no cipher suites for cleartext connections");
        if (true) goto _L4; else goto _L3
_L3:
    }

    public  supportsTlsExtensions(boolean flag)
    {
        if (tls)
        {
            supportsTlsExtensions = flag;
            return this;
        } else
        {
            throw new IllegalStateException("no TLS extensions for cleartext connections");
        }
    }

    public transient  tlsVersions(String as[])
    {
        if (tls)
        {
            if (as.length != 0)
            {
                tlsVersions = (String[])as.clone();
                return this;
            } else
            {
                throw new IllegalArgumentException("At least one TLS version is required");
            }
        } else
        {
            throw new IllegalStateException("no TLS versions for cleartext connections");
        }
    }

    public transient  tlsVersions(TlsVersion atlsversion[])
    {
        int i = 0;
        if (!tls) goto _L2; else goto _L1
_L1:
        String as[] = new String[atlsversion.length];
_L4:
        if (i >= atlsversion.length)
        {
            return tlsVersions(as);
        }
        as[i] = atlsversion[i].javaName;
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("no TLS versions for cleartext connections");
        if (true) goto _L4; else goto _L3
_L3:
    }

    public ion(ConnectionSpec connectionspec)
    {
        tls = connectionspec.tls;
        cipherSuites = connectionspec.cipherSuites;
        tlsVersions = connectionspec.tlsVersions;
        supportsTlsExtensions = connectionspec.supportsTlsExtensions;
    }

    TlsExtensions(boolean flag)
    {
        tls = flag;
    }
}
