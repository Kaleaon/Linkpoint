// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import okio.ByteString;

// Referenced classes of package okhttp3:
//            Request, WebSocketListener

public interface WebSocket
{
    public static interface Factory
    {

        public abstract WebSocket newWebSocket(Request request1, WebSocketListener websocketlistener);
    }


    public abstract void cancel();

    public abstract boolean close(int i, String s);

    public abstract long queueSize();

    public abstract Request request();

    public abstract boolean send(String s);

    public abstract boolean send(ByteString bytestring);
}
