// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.nio.charset.Charset;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MediaType
{

    private static final Pattern PARAMETER = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");
    private static final String QUOTED = "\"([^\"]*)\"";
    private static final String TOKEN = "([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)";
    private static final Pattern TYPE_SUBTYPE = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");
    private final String charset;
    private final String mediaType;
    private final String subtype;
    private final String type;

    private MediaType(String s, String s1, String s2, String s3)
    {
        mediaType = s;
        type = s1;
        subtype = s2;
        charset = s3;
    }

    public static MediaType parse(String s)
    {
        String s2;
        Matcher matcher1;
        int i;
        Matcher matcher = TYPE_SUBTYPE.matcher(s);
        String s4;
        String s5;
        if (matcher.lookingAt())
        {
            s4 = matcher.group(1).toLowerCase(Locale.US);
            s5 = matcher.group(2).toLowerCase(Locale.US);
            matcher1 = PARAMETER.matcher(s);
            i = matcher.end();
            s2 = null;
            break MISSING_BLOCK_LABEL_58;
        } else
        {
            return null;
        }
_L5:
        if (i >= s.length())
        {
            return new MediaType(s, s4, s5, s2);
        }
        matcher1.region(i, s.length());
        if (!matcher1.lookingAt()) goto _L2; else goto _L1
_L1:
        String s3 = matcher1.group(1);
        if (s3 != null) goto _L4; else goto _L3
_L3:
        String s1 = s2;
_L7:
        i = matcher1.end();
        s2 = s1;
          goto _L5
_L2:
        return null;
_L4:
        s1 = s2;
        if (!s3.equalsIgnoreCase("charset")) goto _L7; else goto _L6
_L6:
        s3 = matcher1.group(2);
        if (s3 != null) goto _L9; else goto _L8
_L8:
        s1 = matcher1.group(3);
          goto _L10
_L9:
        s1 = s3;
        if (!s3.startsWith("'")) goto _L10; else goto _L11
_L11:
        s1 = s3;
        if (!s3.endsWith("'")) goto _L10; else goto _L12
_L12:
        s1 = s3;
        if (s3.length() <= 2) goto _L10; else goto _L13
_L13:
        s1 = s3.substring(1, s3.length() - 1);
_L10:
        if (s2 != null && !s1.equalsIgnoreCase(s2))
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Multiple different charsets: ").append(s).toString());
        }
          goto _L7
    }

    public Charset charset()
    {
        if (charset == null)
        {
            return null;
        } else
        {
            return Charset.forName(charset);
        }
    }

    public Charset charset(Charset charset1)
    {
        if (charset == null)
        {
            return charset1;
        } else
        {
            return Charset.forName(charset);
        }
    }

    public boolean equals(Object obj)
    {
        while (!(obj instanceof MediaType) || !((MediaType)obj).mediaType.equals(mediaType)) 
        {
            return false;
        }
        return true;
    }

    public int hashCode()
    {
        return mediaType.hashCode();
    }

    public String subtype()
    {
        return subtype;
    }

    public String toString()
    {
        return mediaType;
    }

    public String type()
    {
        return type;
    }

}
