// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import okio.BufferedSource;
import okio.ForwardingSource;
import okio.Okio;
import okio.Source;

// Referenced classes of package okhttp3:
//            ResponseBody, Cache, MediaType

private static class che.Snapshot extends ResponseBody
{

    private final BufferedSource bodySource;
    private final String contentLength;
    private final String contentType;
    final okhttp3.internal.cache.ose snapshot;

    public long contentLength()
    {
        if (contentLength == null)
        {
            return -1L;
        }
        long l;
        try
        {
            l = Long.parseLong(contentLength);
        }
        catch (NumberFormatException numberformatexception)
        {
            return -1L;
        }
        return l;
    }

    public MediaType contentType()
    {
        if (contentType == null)
        {
            return null;
        } else
        {
            return MediaType.parse(contentType);
        }
    }

    public BufferedSource source()
    {
        return bodySource;
    }

    public che.Snapshot(okhttp3.internal.cache. , String s, String s1)
    {
        snapshot = ;
        contentType = s;
        contentLength = s1;
        bodySource = Okio.buffer(new ForwardingSource() {

            final Cache.CacheResponseBody this$0;
            final okhttp3.internal.cache.DiskLruCache.Snapshot val$snapshot;

            public void close()
                throws IOException
            {
                snapshot.close();
                super.close();
            }

            
            {
                this$0 = Cache.CacheResponseBody.this;
                snapshot = snapshot1;
                super(final_source1);
            }
        });
    }
}
