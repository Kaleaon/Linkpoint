// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;

// Referenced classes of package okhttp3:
//            Callback, Response, Request

public interface Call
    extends Cloneable
{
    public static interface Factory
    {

        public abstract Call newCall(Request request1);
    }


    public abstract void cancel();

    public abstract Call clone();

    public abstract void enqueue(Callback callback);

    public abstract Response execute()
        throws IOException;

    public abstract boolean isCanceled();

    public abstract boolean isExecuted();

    public abstract Request request();
}
