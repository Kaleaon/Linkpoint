// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.UnknownHostException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.cache.InternalCache;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.RouteDatabase;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.platform.Platform;
import okhttp3.internal.tls.CertificateChainCleaner;
import okhttp3.internal.tls.OkHostnameVerifier;
import okhttp3.internal.ws.RealWebSocket;

// Referenced classes of package okhttp3:
//            Protocol, ConnectionSpec, CertificatePinner, Cache, 
//            RealCall, Authenticator, ConnectionPool, CookieJar, 
//            Dispatcher, Dns, Request, Call, 
//            WebSocketListener, WebSocket, Interceptor, HttpUrl, 
//            Address

public class OkHttpClient
    implements Cloneable, Call.Factory, WebSocket.Factory
{
    public static final class Builder
    {

        Authenticator authenticator;
        Cache cache;
        CertificateChainCleaner certificateChainCleaner;
        CertificatePinner certificatePinner;
        int connectTimeout;
        ConnectionPool connectionPool;
        List connectionSpecs;
        CookieJar cookieJar;
        Dispatcher dispatcher;
        Dns dns;
        boolean followRedirects;
        boolean followSslRedirects;
        HostnameVerifier hostnameVerifier;
        final List interceptors;
        InternalCache internalCache;
        final List networkInterceptors;
        int pingInterval;
        List protocols;
        Proxy proxy;
        Authenticator proxyAuthenticator;
        ProxySelector proxySelector;
        int readTimeout;
        boolean retryOnConnectionFailure;
        SocketFactory socketFactory;
        SSLSocketFactory sslSocketFactory;
        int writeTimeout;

        private static int checkDuration(String s, long l, TimeUnit timeunit)
        {
            boolean flag3 = true;
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append(s).append(" < 0").toString());
            }
            long l1;
            if (timeunit != null)
            {
                l1 = timeunit.toMillis(l);
                boolean flag1;
                if (l1 <= 0x7fffffffL)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                if (!flag1)
                {
                    throw new IllegalArgumentException((new StringBuilder()).append(s).append(" too large.").toString());
                }
            } else
            {
                throw new NullPointerException("unit == null");
            }
            if (l1 == 0L)
            {
                boolean flag2;
                if (l <= 0L)
                {
                    flag2 = flag3;
                } else
                {
                    flag2 = false;
                }
                if (!flag2)
                {
                    throw new IllegalArgumentException((new StringBuilder()).append(s).append(" too small.").toString());
                }
            }
            return (int)l1;
        }

        public Builder addInterceptor(Interceptor interceptor)
        {
            interceptors.add(interceptor);
            return this;
        }

        public Builder addNetworkInterceptor(Interceptor interceptor)
        {
            networkInterceptors.add(interceptor);
            return this;
        }

        public Builder authenticator(Authenticator authenticator1)
        {
            if (authenticator1 != null)
            {
                authenticator = authenticator1;
                return this;
            } else
            {
                throw new NullPointerException("authenticator == null");
            }
        }

        public OkHttpClient build()
        {
            return new OkHttpClient(this);
        }

        public Builder cache(Cache cache1)
        {
            cache = cache1;
            internalCache = null;
            return this;
        }

        public Builder certificatePinner(CertificatePinner certificatepinner)
        {
            if (certificatepinner != null)
            {
                certificatePinner = certificatepinner;
                return this;
            } else
            {
                throw new NullPointerException("certificatePinner == null");
            }
        }

        public Builder connectTimeout(long l, TimeUnit timeunit)
        {
            connectTimeout = checkDuration("timeout", l, timeunit);
            return this;
        }

        public Builder connectionPool(ConnectionPool connectionpool)
        {
            if (connectionpool != null)
            {
                connectionPool = connectionpool;
                return this;
            } else
            {
                throw new NullPointerException("connectionPool == null");
            }
        }

        public Builder connectionSpecs(List list)
        {
            connectionSpecs = Util.immutableList(list);
            return this;
        }

        public Builder cookieJar(CookieJar cookiejar)
        {
            if (cookiejar != null)
            {
                cookieJar = cookiejar;
                return this;
            } else
            {
                throw new NullPointerException("cookieJar == null");
            }
        }

        public Builder dispatcher(Dispatcher dispatcher1)
        {
            if (dispatcher1 != null)
            {
                dispatcher = dispatcher1;
                return this;
            } else
            {
                throw new IllegalArgumentException("dispatcher == null");
            }
        }

        public Builder dns(Dns dns1)
        {
            if (dns1 != null)
            {
                dns = dns1;
                return this;
            } else
            {
                throw new NullPointerException("dns == null");
            }
        }

        public Builder followRedirects(boolean flag)
        {
            followRedirects = flag;
            return this;
        }

        public Builder followSslRedirects(boolean flag)
        {
            followSslRedirects = flag;
            return this;
        }

        public Builder hostnameVerifier(HostnameVerifier hostnameverifier)
        {
            if (hostnameverifier != null)
            {
                hostnameVerifier = hostnameverifier;
                return this;
            } else
            {
                throw new NullPointerException("hostnameVerifier == null");
            }
        }

        public List interceptors()
        {
            return interceptors;
        }

        public List networkInterceptors()
        {
            return networkInterceptors;
        }

        public Builder pingInterval(long l, TimeUnit timeunit)
        {
            pingInterval = checkDuration("interval", l, timeunit);
            return this;
        }

        public Builder protocols(List list)
        {
            list = new ArrayList(list);
            if (list.contains(Protocol.HTTP_1_1))
            {
                if (!list.contains(Protocol.HTTP_1_0))
                {
                    if (!list.contains(null))
                    {
                        if (list.contains(Protocol.SPDY_3))
                        {
                            list.remove(Protocol.SPDY_3);
                        }
                        protocols = Collections.unmodifiableList(list);
                        return this;
                    } else
                    {
                        throw new IllegalArgumentException("protocols must not contain null");
                    }
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("protocols must not contain http/1.0: ").append(list).toString());
                }
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("protocols doesn't contain http/1.1: ").append(list).toString());
            }
        }

        public Builder proxy(Proxy proxy1)
        {
            proxy = proxy1;
            return this;
        }

        public Builder proxyAuthenticator(Authenticator authenticator1)
        {
            if (authenticator1 != null)
            {
                proxyAuthenticator = authenticator1;
                return this;
            } else
            {
                throw new NullPointerException("proxyAuthenticator == null");
            }
        }

        public Builder proxySelector(ProxySelector proxyselector)
        {
            proxySelector = proxyselector;
            return this;
        }

        public Builder readTimeout(long l, TimeUnit timeunit)
        {
            readTimeout = checkDuration("timeout", l, timeunit);
            return this;
        }

        public Builder retryOnConnectionFailure(boolean flag)
        {
            retryOnConnectionFailure = flag;
            return this;
        }

        void setInternalCache(InternalCache internalcache)
        {
            internalCache = internalcache;
            cache = null;
        }

        public Builder socketFactory(SocketFactory socketfactory)
        {
            if (socketfactory != null)
            {
                socketFactory = socketfactory;
                return this;
            } else
            {
                throw new NullPointerException("socketFactory == null");
            }
        }

        public Builder sslSocketFactory(SSLSocketFactory sslsocketfactory)
        {
            if (sslsocketfactory != null)
            {
                X509TrustManager x509trustmanager = Platform.get().trustManager(sslsocketfactory);
                if (x509trustmanager != null)
                {
                    sslSocketFactory = sslsocketfactory;
                    certificateChainCleaner = CertificateChainCleaner.get(x509trustmanager);
                    return this;
                } else
                {
                    throw new IllegalStateException((new StringBuilder()).append("Unable to extract the trust manager on ").append(Platform.get()).append(", sslSocketFactory is ").append(sslsocketfactory.getClass()).toString());
                }
            } else
            {
                throw new NullPointerException("sslSocketFactory == null");
            }
        }

        public Builder sslSocketFactory(SSLSocketFactory sslsocketfactory, X509TrustManager x509trustmanager)
        {
            if (sslsocketfactory != null)
            {
                if (x509trustmanager != null)
                {
                    sslSocketFactory = sslsocketfactory;
                    certificateChainCleaner = CertificateChainCleaner.get(x509trustmanager);
                    return this;
                } else
                {
                    throw new NullPointerException("trustManager == null");
                }
            } else
            {
                throw new NullPointerException("sslSocketFactory == null");
            }
        }

        public Builder writeTimeout(long l, TimeUnit timeunit)
        {
            writeTimeout = checkDuration("timeout", l, timeunit);
            return this;
        }

        public Builder()
        {
            interceptors = new ArrayList();
            networkInterceptors = new ArrayList();
            dispatcher = new Dispatcher();
            protocols = OkHttpClient.DEFAULT_PROTOCOLS;
            connectionSpecs = OkHttpClient.DEFAULT_CONNECTION_SPECS;
            proxySelector = ProxySelector.getDefault();
            cookieJar = CookieJar.NO_COOKIES;
            socketFactory = SocketFactory.getDefault();
            hostnameVerifier = OkHostnameVerifier.INSTANCE;
            certificatePinner = CertificatePinner.DEFAULT;
            proxyAuthenticator = Authenticator.NONE;
            authenticator = Authenticator.NONE;
            connectionPool = new ConnectionPool();
            dns = Dns.SYSTEM;
            followSslRedirects = true;
            followRedirects = true;
            retryOnConnectionFailure = true;
            connectTimeout = 10000;
            readTimeout = 10000;
            writeTimeout = 10000;
            pingInterval = 0;
        }

        Builder(OkHttpClient okhttpclient)
        {
            interceptors = new ArrayList();
            networkInterceptors = new ArrayList();
            dispatcher = okhttpclient.dispatcher;
            proxy = okhttpclient.proxy;
            protocols = okhttpclient.protocols;
            connectionSpecs = okhttpclient.connectionSpecs;
            interceptors.addAll(okhttpclient.interceptors);
            networkInterceptors.addAll(okhttpclient.networkInterceptors);
            proxySelector = okhttpclient.proxySelector;
            cookieJar = okhttpclient.cookieJar;
            internalCache = okhttpclient.internalCache;
            cache = okhttpclient.cache;
            socketFactory = okhttpclient.socketFactory;
            sslSocketFactory = okhttpclient.sslSocketFactory;
            certificateChainCleaner = okhttpclient.certificateChainCleaner;
            hostnameVerifier = okhttpclient.hostnameVerifier;
            certificatePinner = okhttpclient.certificatePinner;
            proxyAuthenticator = okhttpclient.proxyAuthenticator;
            authenticator = okhttpclient.authenticator;
            connectionPool = okhttpclient.connectionPool;
            dns = okhttpclient.dns;
            followSslRedirects = okhttpclient.followSslRedirects;
            followRedirects = okhttpclient.followRedirects;
            retryOnConnectionFailure = okhttpclient.retryOnConnectionFailure;
            connectTimeout = okhttpclient.connectTimeout;
            readTimeout = okhttpclient.readTimeout;
            writeTimeout = okhttpclient.writeTimeout;
            pingInterval = okhttpclient.pingInterval;
        }
    }


    static final List DEFAULT_CONNECTION_SPECS;
    static final List DEFAULT_PROTOCOLS;
    final Authenticator authenticator;
    final Cache cache;
    final CertificateChainCleaner certificateChainCleaner;
    final CertificatePinner certificatePinner;
    final int connectTimeout;
    final ConnectionPool connectionPool;
    final List connectionSpecs;
    final CookieJar cookieJar;
    final Dispatcher dispatcher;
    final Dns dns;
    final boolean followRedirects;
    final boolean followSslRedirects;
    final HostnameVerifier hostnameVerifier;
    final List interceptors;
    final InternalCache internalCache;
    final List networkInterceptors;
    final int pingInterval;
    final List protocols;
    final Proxy proxy;
    final Authenticator proxyAuthenticator;
    final ProxySelector proxySelector;
    final int readTimeout;
    final boolean retryOnConnectionFailure;
    final SocketFactory socketFactory;
    final SSLSocketFactory sslSocketFactory;
    final int writeTimeout;

    public OkHttpClient()
    {
        this(new Builder());
    }

    OkHttpClient(Builder builder)
    {
        dispatcher = builder.dispatcher;
        proxy = builder.proxy;
        protocols = builder.protocols;
        connectionSpecs = builder.connectionSpecs;
        interceptors = Util.immutableList(builder.interceptors);
        networkInterceptors = Util.immutableList(builder.networkInterceptors);
        proxySelector = builder.proxySelector;
        cookieJar = builder.cookieJar;
        cache = builder.cache;
        internalCache = builder.internalCache;
        socketFactory = builder.socketFactory;
        Iterator iterator = connectionSpecs.iterator();
        boolean flag = false;
        do
        {
            if (!iterator.hasNext())
            {
                ConnectionSpec connectionspec;
                if (builder.sslSocketFactory != null || !flag)
                {
                    sslSocketFactory = builder.sslSocketFactory;
                    certificateChainCleaner = builder.certificateChainCleaner;
                } else
                {
                    X509TrustManager x509trustmanager = systemDefaultTrustManager();
                    sslSocketFactory = systemDefaultSslSocketFactory(x509trustmanager);
                    certificateChainCleaner = CertificateChainCleaner.get(x509trustmanager);
                }
                hostnameVerifier = builder.hostnameVerifier;
                certificatePinner = builder.certificatePinner.withCertificateChainCleaner(certificateChainCleaner);
                proxyAuthenticator = builder.proxyAuthenticator;
                authenticator = builder.authenticator;
                connectionPool = builder.connectionPool;
                dns = builder.dns;
                followSslRedirects = builder.followSslRedirects;
                followRedirects = builder.followRedirects;
                retryOnConnectionFailure = builder.retryOnConnectionFailure;
                connectTimeout = builder.connectTimeout;
                readTimeout = builder.readTimeout;
                writeTimeout = builder.writeTimeout;
                pingInterval = builder.pingInterval;
                return;
            }
            connectionspec = (ConnectionSpec)iterator.next();
            if (flag || connectionspec.isTls())
            {
                flag = true;
            } else
            {
                flag = false;
            }
        } while (true);
    }

    private SSLSocketFactory systemDefaultSslSocketFactory(X509TrustManager x509trustmanager)
    {
        try
        {
            SSLContext sslcontext = SSLContext.getInstance("TLS");
            sslcontext.init(null, new TrustManager[] {
                x509trustmanager
            }, null);
            x509trustmanager = sslcontext.getSocketFactory();
        }
        // Misplaced declaration of an exception variable
        catch (X509TrustManager x509trustmanager)
        {
            throw new AssertionError();
        }
        return x509trustmanager;
    }

    private X509TrustManager systemDefaultTrustManager()
    {
        Object obj;
        obj = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        ((TrustManagerFactory) (obj)).init((KeyStore)null);
        obj = ((TrustManagerFactory) (obj)).getTrustManagers();
        if (obj.length == 1) goto _L2; else goto _L1
_L1:
        throw new IllegalStateException((new StringBuilder()).append("Unexpected default trust managers:").append(Arrays.toString(((Object []) (obj)))).toString());
        obj;
        throw new AssertionError();
_L2:
        if (!(obj[0] instanceof X509TrustManager)) goto _L1; else goto _L3
_L3:
        obj = (X509TrustManager)obj[0];
        return ((X509TrustManager) (obj));
    }

    public Authenticator authenticator()
    {
        return authenticator;
    }

    public Cache cache()
    {
        return cache;
    }

    public CertificatePinner certificatePinner()
    {
        return certificatePinner;
    }

    public int connectTimeoutMillis()
    {
        return connectTimeout;
    }

    public ConnectionPool connectionPool()
    {
        return connectionPool;
    }

    public List connectionSpecs()
    {
        return connectionSpecs;
    }

    public CookieJar cookieJar()
    {
        return cookieJar;
    }

    public Dispatcher dispatcher()
    {
        return dispatcher;
    }

    public Dns dns()
    {
        return dns;
    }

    public boolean followRedirects()
    {
        return followRedirects;
    }

    public boolean followSslRedirects()
    {
        return followSslRedirects;
    }

    public HostnameVerifier hostnameVerifier()
    {
        return hostnameVerifier;
    }

    public List interceptors()
    {
        return interceptors;
    }

    InternalCache internalCache()
    {
        if (cache == null)
        {
            return internalCache;
        } else
        {
            return cache.internalCache;
        }
    }

    public List networkInterceptors()
    {
        return networkInterceptors;
    }

    public Builder newBuilder()
    {
        return new Builder(this);
    }

    public Call newCall(Request request)
    {
        return new RealCall(this, request, false);
    }

    public WebSocket newWebSocket(Request request, WebSocketListener websocketlistener)
    {
        request = new RealWebSocket(request, websocketlistener, new SecureRandom());
        request.connect(this);
        return request;
    }

    public int pingIntervalMillis()
    {
        return pingInterval;
    }

    public List protocols()
    {
        return protocols;
    }

    public Proxy proxy()
    {
        return proxy;
    }

    public Authenticator proxyAuthenticator()
    {
        return proxyAuthenticator;
    }

    public ProxySelector proxySelector()
    {
        return proxySelector;
    }

    public int readTimeoutMillis()
    {
        return readTimeout;
    }

    public boolean retryOnConnectionFailure()
    {
        return retryOnConnectionFailure;
    }

    public SocketFactory socketFactory()
    {
        return socketFactory;
    }

    public SSLSocketFactory sslSocketFactory()
    {
        return sslSocketFactory;
    }

    public int writeTimeoutMillis()
    {
        return writeTimeout;
    }

    static 
    {
        DEFAULT_PROTOCOLS = Util.immutableList(new Protocol[] {
            Protocol.HTTP_2, Protocol.HTTP_1_1
        });
        DEFAULT_CONNECTION_SPECS = Util.immutableList(new ConnectionSpec[] {
            ConnectionSpec.MODERN_TLS, ConnectionSpec.COMPATIBLE_TLS, ConnectionSpec.CLEARTEXT
        });
        Internal.instance = new Internal() {

            public void addLenient(Headers.Builder builder, String s)
            {
                builder.addLenient(s);
            }

            public void addLenient(Headers.Builder builder, String s, String s1)
            {
                builder.addLenient(s, s1);
            }

            public void apply(ConnectionSpec connectionspec, SSLSocket sslsocket, boolean flag)
            {
                connectionspec.apply(sslsocket, flag);
            }

            public boolean connectionBecameIdle(ConnectionPool connectionpool, RealConnection realconnection)
            {
                return connectionpool.connectionBecameIdle(realconnection);
            }

            public RealConnection get(ConnectionPool connectionpool, Address address, StreamAllocation streamallocation)
            {
                return connectionpool.get(address, streamallocation);
            }

            public HttpUrl getHttpUrlChecked(String s)
                throws MalformedURLException, UnknownHostException
            {
                return HttpUrl.getChecked(s);
            }

            public Call newWebSocketCall(OkHttpClient okhttpclient, Request request)
            {
                return new RealCall(okhttpclient, request, true);
            }

            public void put(ConnectionPool connectionpool, RealConnection realconnection)
            {
                connectionpool.put(realconnection);
            }

            public RouteDatabase routeDatabase(ConnectionPool connectionpool)
            {
                return connectionpool.routeDatabase;
            }

            public void setCache(Builder builder, InternalCache internalcache)
            {
                builder.setInternalCache(internalcache);
            }

            public StreamAllocation streamAllocation(Call call)
            {
                return ((RealCall)call).streamAllocation();
            }

        };
    }
}
