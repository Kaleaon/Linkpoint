// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

// Referenced classes of package okhttp3:
//            CertificatePinner

public static final class 
{

    private final List pins = new ArrayList();

    public transient  add(String s, String as[])
    {
        if (s == null) goto _L2; else goto _L1
_L1:
        int i;
        int j;
        j = as.length;
        i = 0;
_L4:
        if (i >= j)
        {
            return this;
        }
        String s1 = as[i];
        pins.add(new t>(s, s1));
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new NullPointerException("pattern == null");
        if (true) goto _L4; else goto _L3
_L3:
    }

    public CertificatePinner build()
    {
        return new CertificatePinner(new LinkedHashSet(pins), null);
    }

    public ()
    {
    }
}
