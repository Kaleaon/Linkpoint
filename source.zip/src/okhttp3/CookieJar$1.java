// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.Collections;
import java.util.List;

// Referenced classes of package okhttp3:
//            CookieJar, HttpUrl

static class s
    implements CookieJar
{

    public List loadForRequest(HttpUrl httpurl)
    {
        return Collections.emptyList();
    }

    public void saveFromResponse(HttpUrl httpurl, List list)
    {
    }

    s()
    {
    }
}
