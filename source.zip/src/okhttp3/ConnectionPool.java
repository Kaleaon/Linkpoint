// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.lang.ref.Reference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import okhttp3.internal.Util;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.RouteDatabase;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.platform.Platform;

// Referenced classes of package okhttp3:
//            Route, Address

public final class ConnectionPool
{

    static final boolean $assertionsDisabled;
    private static final Executor executor;
    private final Runnable cleanupRunnable;
    boolean cleanupRunning;
    private final Deque connections;
    private final long keepAliveDurationNs;
    private final int maxIdleConnections;
    final RouteDatabase routeDatabase;

    public ConnectionPool()
    {
        this(5, 5L, TimeUnit.MINUTES);
    }

    public ConnectionPool(int i, long l, TimeUnit timeunit)
    {
        cleanupRunnable = new Runnable() {

            final ConnectionPool this$0;

            public void run()
            {
                do
                {
                    do
                    {
                        long l1 = cleanup(System.nanoTime());
                        if (l1 == -1L)
                        {
                            return;
                        }
                        boolean flag;
                        long l2;
                        if (l1 <= 0L)
                        {
                            flag = true;
                        } else
                        {
                            flag = false;
                        }
                    } while (flag);
                    l2 = l1 / 0xf4240L;
                    synchronized (ConnectionPool.this)
                    {
                        try
                        {
                            wait(l2, (int)(l1 - l2 * 0xf4240L));
                        }
                        // Misplaced declaration of an exception variable
                        catch (InterruptedException interruptedexception) { }
                    }
                } while (true);
                exception;
                connectionpool;
                JVM INSTR monitorexit ;
                InterruptedException interruptedexception;
                throw exception;
            }

            
            {
                this$0 = ConnectionPool.this;
                super();
            }
        };
        connections = new ArrayDeque();
        routeDatabase = new RouteDatabase();
        maxIdleConnections = i;
        keepAliveDurationNs = timeunit.toNanos(l);
        if (l > 0L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("keepAliveDuration <= 0: ").append(l).toString());
        } else
        {
            return;
        }
    }

    private int pruneAndGetAllocationCount(RealConnection realconnection, long l)
    {
        List list = realconnection.allocations;
        int i = 0;
        do
        {
            if (i >= list.size())
            {
                return list.size();
            }
            Object obj = (Reference)list.get(i);
            if (((Reference) (obj)).get() == null)
            {
                obj = (okhttp3.internal.connection.StreamAllocation.StreamAllocationReference)obj;
                String s = (new StringBuilder()).append("A connection to ").append(realconnection.route().address().url()).append(" was leaked. Did you forget to close a response body?").toString();
                Platform.get().logCloseableLeak(s, ((okhttp3.internal.connection.StreamAllocation.StreamAllocationReference) (obj)).callStackTrace);
                list.remove(i);
                realconnection.noNewStreams = true;
                if (list.isEmpty())
                {
                    realconnection.idleAtNanos = l - keepAliveDurationNs;
                    return 0;
                }
            } else
            {
                i++;
            }
        } while (true);
    }

    long cleanup(long l)
    {
        Exception exception = null;
        long l1 = 0x8000000000000000L;
        this;
        JVM INSTR monitorenter ;
        Iterator iterator = connections.iterator();
        int i;
        int j;
        i = 0;
        j = 0;
_L2:
        if (iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_84;
        }
        RealConnection realconnection;
        boolean flag;
        long l2;
        if (l1 >= keepAliveDurationNs)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_129;
        }
        if (j > maxIdleConnections)
        {
            break MISSING_BLOCK_LABEL_129;
        }
        if (j > 0)
        {
            break MISSING_BLOCK_LABEL_151;
        }
        if (i > 0)
        {
            break MISSING_BLOCK_LABEL_163;
        }
        cleanupRunning = false;
        this;
        JVM INSTR monitorexit ;
        return -1L;
        realconnection = (RealConnection)iterator.next();
        if (pruneAndGetAllocationCount(realconnection, l) > 0)
        {
            break MISSING_BLOCK_LABEL_198;
        }
        l2 = l - realconnection.idleAtNanos;
        if (l2 <= l1)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        break MISSING_BLOCK_LABEL_177;
        connections.remove(exception);
        this;
        JVM INSTR monitorexit ;
        Util.closeQuietly(exception.socket());
        return 0L;
        l = keepAliveDurationNs;
        this;
        JVM INSTR monitorexit ;
        return l - l1;
        l = keepAliveDurationNs;
        this;
        JVM INSTR monitorexit ;
        return l;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        if (!flag)
        {
            exception = realconnection;
            l1 = l2;
        }
        j++;
        continue; /* Loop/switch isn't completed */
        i++;
        if (true) goto _L2; else goto _L1
_L1:
    }

    boolean connectionBecameIdle(RealConnection realconnection)
    {
        if ($assertionsDisabled || Thread.holdsLock(this))
        {
            if (realconnection.noNewStreams || maxIdleConnections == 0)
            {
                connections.remove(realconnection);
                return true;
            } else
            {
                notifyAll();
                return false;
            }
        } else
        {
            throw new AssertionError();
        }
    }

    public int connectionCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = connections.size();
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public void evictAll()
    {
        Object obj = new ArrayList();
        this;
        JVM INSTR monitorenter ;
        Iterator iterator = connections.iterator();
_L3:
        if (iterator.hasNext()) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        obj = ((List) (obj)).iterator();
_L4:
        if (!((Iterator) (obj)).hasNext())
        {
            return;
        }
        break MISSING_BLOCK_LABEL_97;
_L2:
        RealConnection realconnection = (RealConnection)iterator.next();
        if (realconnection.allocations.isEmpty())
        {
            realconnection.noNewStreams = true;
            ((List) (obj)).add(realconnection);
            iterator.remove();
        }
          goto _L3
        obj;
        this;
        JVM INSTR monitorexit ;
        throw obj;
        Util.closeQuietly(((RealConnection)((Iterator) (obj)).next()).socket());
          goto _L4
    }

    RealConnection get(Address address, StreamAllocation streamallocation)
    {
_L2:
        Iterator iterator = connections.iterator();
_L3:
        if (!iterator.hasNext())
        {
            return null;
        }
        break MISSING_BLOCK_LABEL_42;
        if ($assertionsDisabled || Thread.holdsLock(this)) goto _L2; else goto _L1
_L1:
        throw new AssertionError();
        RealConnection realconnection = (RealConnection)iterator.next();
        if (realconnection.allocations.size() < realconnection.allocationLimit && address.equals(realconnection.route().address) && !realconnection.noNewStreams)
        {
            streamallocation.acquire(realconnection);
            return realconnection;
        }
          goto _L3
    }

    public int idleConnectionCount()
    {
        int i = 0;
        this;
        JVM INSTR monitorenter ;
        Iterator iterator = connections.iterator();
_L1:
        boolean flag = iterator.hasNext();
        if (flag)
        {
            break MISSING_BLOCK_LABEL_29;
        }
        this;
        JVM INSTR monitorexit ;
        return i;
        flag = ((RealConnection)iterator.next()).allocations.isEmpty();
        if (flag)
        {
            i++;
        }
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    void put(RealConnection realconnection)
    {
        while ($assertionsDisabled || Thread.holdsLock(this)) 
        {
            if (!cleanupRunning)
            {
                cleanupRunning = true;
                executor.execute(cleanupRunnable);
            }
            connections.add(realconnection);
            return;
        }
        throw new AssertionError();
    }

    static 
    {
        boolean flag;
        if (okhttp3/ConnectionPool.desiredAssertionStatus())
        {
            flag = false;
        } else
        {
            flag = true;
        }
        $assertionsDisabled = flag;
        executor = new ThreadPoolExecutor(0, 0x7fffffff, 60L, TimeUnit.SECONDS, new SynchronousQueue(), Util.threadFactory("OkHttp ConnectionPool", true));
    }
}
