// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpDate;

public final class Headers
{
    public static final class Builder
    {

        final List namesAndValues = new ArrayList(20);

        private void checkNameAndValue(String s, String s1)
        {
            if (s == null) goto _L2; else goto _L1
_L1:
            if (s.isEmpty()) goto _L4; else goto _L3
_L3:
            int i;
            int j;
            j = s.length();
            i = 0;
_L6:
            if (i >= j)
            {
                if (s1 != null)
                {
                    j = s1.length();
                    i = 0;
                    break MISSING_BLOCK_LABEL_37;
                } else
                {
                    throw new NullPointerException("value == null");
                }
            } else
            {
                for (char c = s.charAt(i); c <= '\037' || c >= '\177';)
                {
                    throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in header name: %s", new Object[] {
                        Integer.valueOf(c), Integer.valueOf(i), s
                    }));
                }

                i++;
                continue; /* Loop/switch isn't completed */
            }
_L2:
            throw new NullPointerException("name == null");
_L4:
            throw new IllegalArgumentException("name is empty");
            char c1;
            do
            {
                if (i >= j)
                {
                    return;
                }
                c1 = s1.charAt(i);
                if ((c1 > '\037' || c1 == '\t') && c1 < '\177')
                {
                    i++;
                } else
                {
                    break;
                }
            } while (true);
            throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in %s value: %s", new Object[] {
                Integer.valueOf(c1), Integer.valueOf(i), s, s1
            }));
            if (true) goto _L6; else goto _L5
_L5:
        }

        public Builder add(String s)
        {
            int i = s.indexOf(":");
            if (i != -1)
            {
                return add(s.substring(0, i).trim(), s.substring(i + 1));
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("Unexpected header: ").append(s).toString());
            }
        }

        public Builder add(String s, String s1)
        {
            checkNameAndValue(s, s1);
            return addLenient(s, s1);
        }

        Builder addLenient(String s)
        {
            int i = s.indexOf(":", 1);
            if (i == -1)
            {
                if (!s.startsWith(":"))
                {
                    return addLenient("", s);
                } else
                {
                    return addLenient("", s.substring(1));
                }
            } else
            {
                return addLenient(s.substring(0, i), s.substring(i + 1));
            }
        }

        Builder addLenient(String s, String s1)
        {
            namesAndValues.add(s);
            namesAndValues.add(s1.trim());
            return this;
        }

        public Headers build()
        {
            return new Headers(this);
        }

        public String get(String s)
        {
            int i = namesAndValues.size() - 2;
            do
            {
                if (i < 0)
                {
                    return null;
                }
                if (!s.equalsIgnoreCase((String)namesAndValues.get(i)))
                {
                    i -= 2;
                } else
                {
                    return (String)namesAndValues.get(i + 1);
                }
            } while (true);
        }

        public Builder removeAll(String s)
        {
            int i = 0;
            do
            {
                if (i >= namesAndValues.size())
                {
                    return this;
                }
                if (s.equalsIgnoreCase((String)namesAndValues.get(i)))
                {
                    namesAndValues.remove(i);
                    namesAndValues.remove(i);
                    i -= 2;
                }
                i += 2;
            } while (true);
        }

        public Builder set(String s, String s1)
        {
            checkNameAndValue(s, s1);
            removeAll(s);
            addLenient(s, s1);
            return this;
        }

        public Builder()
        {
        }
    }


    private final String namesAndValues[];

    Headers(Builder builder)
    {
        namesAndValues = (String[])builder.namesAndValues.toArray(new String[builder.namesAndValues.size()]);
    }

    private Headers(String as[])
    {
        namesAndValues = as;
    }

    private static String get(String as[], String s)
    {
        int i = as.length;
        int j;
        do
        {
            j = i - 2;
            if (j < 0)
            {
                return null;
            }
            i = j;
        } while (!s.equalsIgnoreCase(as[j]));
        return as[j + 1];
    }

    public static Headers of(Map map)
    {
        if (map == null) goto _L2; else goto _L1
_L1:
        String as[];
        int i;
        as = new String[map.size() * 2];
        map = map.entrySet().iterator();
        i = 0;
_L4:
        if (!map.hasNext())
        {
            return new Headers(as);
        }
        Object obj;
        for (obj = (java.util.Map.Entry)map.next(); ((java.util.Map.Entry) (obj)).getKey() == null || ((java.util.Map.Entry) (obj)).getValue() == null;)
        {
            throw new IllegalArgumentException("Headers cannot be null");
        }

        String s = ((String)((java.util.Map.Entry) (obj)).getKey()).trim();
        for (obj = ((String)((java.util.Map.Entry) (obj)).getValue()).trim(); s.length() == 0 || s.indexOf('\0') != -1 || ((String) (obj)).indexOf('\0') != -1;)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Unexpected header: ").append(s).append(": ").append(((String) (obj))).toString());
        }

        as[i] = s;
        as[i + 1] = ((String) (obj));
        i += 2;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new NullPointerException("headers == null");
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static transient Headers of(String as[])
    {
        if (as == null) goto _L2; else goto _L1
_L1:
        if (as.length % 2 != 0) goto _L4; else goto _L3
_L3:
        int i;
        as = (String[])as.clone();
        i = 0;
_L7:
        if (i < as.length) goto _L6; else goto _L5
_L5:
        i = 0;
_L8:
        if (i >= as.length)
        {
            return new Headers(as);
        }
        break MISSING_BLOCK_LABEL_96;
_L2:
        throw new NullPointerException("namesAndValues == null");
_L4:
        throw new IllegalArgumentException("Expected alternating header names and values");
_L6:
        if (as[i] != null)
        {
            as[i] = as[i].trim();
            i++;
        } else
        {
            throw new IllegalArgumentException("Headers cannot be null");
        }
          goto _L7
        String s = as[i];
        for (String s1 = as[i + 1]; s.length() == 0 || s.indexOf('\0') != -1 || s1.indexOf('\0') != -1;)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Unexpected header: ").append(s).append(": ").append(s1).toString());
        }

        i += 2;
          goto _L8
    }

    public boolean equals(Object obj)
    {
        while (!(obj instanceof Headers) || !Arrays.equals(((Headers)obj).namesAndValues, namesAndValues)) 
        {
            return false;
        }
        return true;
    }

    public String get(String s)
    {
        return get(namesAndValues, s);
    }

    public Date getDate(String s)
    {
        s = get(s);
        if (s == null)
        {
            return null;
        } else
        {
            return HttpDate.parse(s);
        }
    }

    public int hashCode()
    {
        return Arrays.hashCode(namesAndValues);
    }

    public String name(int i)
    {
        return namesAndValues[i * 2];
    }

    public Set names()
    {
        TreeSet treeset = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        int i = 0;
        int j = size();
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableSet(treeset);
            }
            treeset.add(name(i));
            i++;
        } while (true);
    }

    public Builder newBuilder()
    {
        Builder builder = new Builder();
        Collections.addAll(builder.namesAndValues, namesAndValues);
        return builder;
    }

    public int size()
    {
        return namesAndValues.length / 2;
    }

    public Map toMultimap()
    {
        TreeMap treemap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        int j = size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return treemap;
            }
            String s = name(i).toLowerCase(Locale.US);
            Object obj = (List)treemap.get(s);
            if (obj == null)
            {
                obj = new ArrayList(2);
                treemap.put(s, obj);
            }
            ((List) (obj)).add(value(i));
            i++;
        } while (true);
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        int i = 0;
        int j = size();
        do
        {
            if (i >= j)
            {
                return stringbuilder.toString();
            }
            stringbuilder.append(name(i)).append(": ").append(value(i)).append("\n");
            i++;
        } while (true);
    }

    public String value(int i)
    {
        return namesAndValues[i * 2 + 1];
    }

    public List values(String s)
    {
        int j = size();
        ArrayList arraylist = null;
        int i = 0;
        do
        {
            if (i >= j)
            {
                if (arraylist == null)
                {
                    return Collections.emptyList();
                } else
                {
                    return Collections.unmodifiableList(arraylist);
                }
            }
            if (s.equalsIgnoreCase(name(i)))
            {
                if (arraylist == null)
                {
                    arraylist = new ArrayList(2);
                }
                arraylist.add(value(i));
            }
            i++;
        } while (true);
    }
}
