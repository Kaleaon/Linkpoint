// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            HttpUrl

static class eldError
{

    static final int $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[];

    static 
    {
        $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult = new int[ilder.ParseResult.values().length];
        try
        {
            $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[ilder.ParseResult.SUCCESS.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror4) { }
        try
        {
            $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[ilder.ParseResult.INVALID_HOST.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror3) { }
        try
        {
            $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[ilder.ParseResult.UNSUPPORTED_SCHEME.ordinal()] = 3;
        }
        catch (NoSuchFieldError nosuchfielderror2) { }
        try
        {
            $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[ilder.ParseResult.MISSING_SCHEME.ordinal()] = 4;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[ilder.ParseResult.INVALID_PORT.ordinal()] = 5;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
