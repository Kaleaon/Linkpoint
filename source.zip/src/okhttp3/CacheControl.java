// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.concurrent.TimeUnit;
import okhttp3.internal.http.HttpHeaders;

// Referenced classes of package okhttp3:
//            Headers

public final class CacheControl
{
    public static final class Builder
    {

        int maxAgeSeconds;
        int maxStaleSeconds;
        int minFreshSeconds;
        boolean noCache;
        boolean noStore;
        boolean noTransform;
        boolean onlyIfCached;

        public CacheControl build()
        {
            return new CacheControl(this);
        }

        public Builder maxAge(int i, TimeUnit timeunit)
        {
            boolean flag = false;
            if (i >= 0)
            {
                long l = timeunit.toSeconds(i);
                i = ((flag) ? 1 : 0);
                if (l <= 0x7fffffffL)
                {
                    i = 1;
                }
                if (i == 0)
                {
                    i = 0x7fffffff;
                } else
                {
                    i = (int)l;
                }
                maxAgeSeconds = i;
                return this;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("maxAge < 0: ").append(i).toString());
            }
        }

        public Builder maxStale(int i, TimeUnit timeunit)
        {
            boolean flag = false;
            if (i >= 0)
            {
                long l = timeunit.toSeconds(i);
                i = ((flag) ? 1 : 0);
                if (l <= 0x7fffffffL)
                {
                    i = 1;
                }
                if (i == 0)
                {
                    i = 0x7fffffff;
                } else
                {
                    i = (int)l;
                }
                maxStaleSeconds = i;
                return this;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("maxStale < 0: ").append(i).toString());
            }
        }

        public Builder minFresh(int i, TimeUnit timeunit)
        {
            boolean flag = false;
            if (i >= 0)
            {
                long l = timeunit.toSeconds(i);
                i = ((flag) ? 1 : 0);
                if (l <= 0x7fffffffL)
                {
                    i = 1;
                }
                if (i == 0)
                {
                    i = 0x7fffffff;
                } else
                {
                    i = (int)l;
                }
                minFreshSeconds = i;
                return this;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("minFresh < 0: ").append(i).toString());
            }
        }

        public Builder noCache()
        {
            noCache = true;
            return this;
        }

        public Builder noStore()
        {
            noStore = true;
            return this;
        }

        public Builder noTransform()
        {
            noTransform = true;
            return this;
        }

        public Builder onlyIfCached()
        {
            onlyIfCached = true;
            return this;
        }

        public Builder()
        {
            maxAgeSeconds = -1;
            maxStaleSeconds = -1;
            minFreshSeconds = -1;
        }
    }


    public static final CacheControl FORCE_CACHE;
    public static final CacheControl FORCE_NETWORK = (new Builder()).noCache().build();
    String headerValue;
    private final boolean isPrivate;
    private final boolean isPublic;
    private final int maxAgeSeconds;
    private final int maxStaleSeconds;
    private final int minFreshSeconds;
    private final boolean mustRevalidate;
    private final boolean noCache;
    private final boolean noStore;
    private final boolean noTransform;
    private final boolean onlyIfCached;
    private final int sMaxAgeSeconds;

    CacheControl(Builder builder)
    {
        noCache = builder.noCache;
        noStore = builder.noStore;
        maxAgeSeconds = builder.maxAgeSeconds;
        sMaxAgeSeconds = -1;
        isPrivate = false;
        isPublic = false;
        mustRevalidate = false;
        maxStaleSeconds = builder.maxStaleSeconds;
        minFreshSeconds = builder.minFreshSeconds;
        onlyIfCached = builder.onlyIfCached;
        noTransform = builder.noTransform;
    }

    private CacheControl(boolean flag, boolean flag1, int i, int j, boolean flag2, boolean flag3, boolean flag4, 
            int k, int l, boolean flag5, boolean flag6, String s)
    {
        noCache = flag;
        noStore = flag1;
        maxAgeSeconds = i;
        sMaxAgeSeconds = j;
        isPrivate = flag2;
        isPublic = flag3;
        mustRevalidate = flag4;
        maxStaleSeconds = k;
        minFreshSeconds = l;
        onlyIfCached = flag5;
        noTransform = flag6;
        headerValue = s;
    }

    private String headerValue()
    {
        StringBuilder stringbuilder = new StringBuilder();
        if (noCache)
        {
            stringbuilder.append("no-cache, ");
        }
        if (noStore)
        {
            stringbuilder.append("no-store, ");
        }
        if (maxAgeSeconds != -1)
        {
            stringbuilder.append("max-age=").append(maxAgeSeconds).append(", ");
        }
        if (sMaxAgeSeconds != -1)
        {
            stringbuilder.append("s-maxage=").append(sMaxAgeSeconds).append(", ");
        }
        if (isPrivate)
        {
            stringbuilder.append("private, ");
        }
        if (isPublic)
        {
            stringbuilder.append("public, ");
        }
        if (mustRevalidate)
        {
            stringbuilder.append("must-revalidate, ");
        }
        if (maxStaleSeconds != -1)
        {
            stringbuilder.append("max-stale=").append(maxStaleSeconds).append(", ");
        }
        if (minFreshSeconds != -1)
        {
            stringbuilder.append("min-fresh=").append(minFreshSeconds).append(", ");
        }
        if (onlyIfCached)
        {
            stringbuilder.append("only-if-cached, ");
        }
        if (noTransform)
        {
            stringbuilder.append("no-transform, ");
        }
        if (stringbuilder.length() != 0)
        {
            stringbuilder.delete(stringbuilder.length() - 2, stringbuilder.length());
            return stringbuilder.toString();
        } else
        {
            return "";
        }
    }

    public static CacheControl parse(Headers headers)
    {
        String s;
        boolean flag;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int l1;
        boolean flag1;
        boolean flag2;
        boolean flag3;
        boolean flag4;
        boolean flag5;
        boolean flag6;
        boolean flag7;
        flag4 = false;
        i1 = -1;
        l = -1;
        flag5 = false;
        flag6 = false;
        flag3 = false;
        k = -1;
        j = -1;
        flag2 = false;
        flag1 = false;
        flag = true;
        l1 = headers.size();
        j1 = 0;
        s = null;
        flag7 = false;
_L5:
        if (j1 >= l1)
        {
            String s1;
            String s2;
            String s3;
            int i;
            int k1;
            if (!flag)
            {
                s = null;
            }
            return new CacheControl(flag7, flag4, i1, l, flag5, flag6, flag3, k, j, flag2, flag1, s);
        }
        s1 = headers.name(j1);
        s2 = headers.value(j1);
        if (s1.equalsIgnoreCase("Cache-Control")) goto _L2; else goto _L1
_L1:
        if (s1.equalsIgnoreCase("Pragma")) goto _L4; else goto _L3
_L3:
        j1++;
          goto _L5
_L2:
        if (s == null)
        {
            s = s2;
        } else
        {
            flag = false;
        }
_L6:
        k1 = 0;
_L7:
        if (k1 < s2.length())
        {
            break MISSING_BLOCK_LABEL_164;
        }
          goto _L3
_L4:
        flag = false;
          goto _L6
        i = HttpHeaders.skipUntil(s2, k1, "=,;");
        s3 = s2.substring(k1, i).trim();
        if (i == s2.length() || s2.charAt(i) == ',' || s2.charAt(i) == ';')
        {
            i++;
            s1 = null;
        } else
        {
            k1 = HttpHeaders.skipWhitespace(s2, i + 1);
            if (k1 >= s2.length() || s2.charAt(k1) != '"')
            {
                i = HttpHeaders.skipUntil(s2, k1, ",;");
                s1 = s2.substring(k1, i).trim();
            } else
            {
                i = k1 + 1;
                k1 = HttpHeaders.skipUntil(s2, i, "\"");
                s1 = s2.substring(i, k1);
                i = k1 + 1;
            }
        }
        if (!"no-cache".equalsIgnoreCase(s3))
        {
            if (!"no-store".equalsIgnoreCase(s3))
            {
                if (!"max-age".equalsIgnoreCase(s3))
                {
                    if (!"s-maxage".equalsIgnoreCase(s3))
                    {
                        if (!"private".equalsIgnoreCase(s3))
                        {
                            if (!"public".equalsIgnoreCase(s3))
                            {
                                if (!"must-revalidate".equalsIgnoreCase(s3))
                                {
                                    if (!"max-stale".equalsIgnoreCase(s3))
                                    {
                                        if (!"min-fresh".equalsIgnoreCase(s3))
                                        {
                                            if (!"only-if-cached".equalsIgnoreCase(s3))
                                            {
                                                k1 = i;
                                                if ("no-transform".equalsIgnoreCase(s3))
                                                {
                                                    flag1 = true;
                                                    k1 = i;
                                                }
                                            } else
                                            {
                                                flag2 = true;
                                                k1 = i;
                                            }
                                        } else
                                        {
                                            j = HttpHeaders.parseSeconds(s1, -1);
                                            k1 = i;
                                        }
                                    } else
                                    {
                                        k = HttpHeaders.parseSeconds(s1, 0x7fffffff);
                                        k1 = i;
                                    }
                                } else
                                {
                                    flag3 = true;
                                    k1 = i;
                                }
                            } else
                            {
                                flag6 = true;
                                k1 = i;
                            }
                        } else
                        {
                            flag5 = true;
                            k1 = i;
                        }
                    } else
                    {
                        l = HttpHeaders.parseSeconds(s1, -1);
                        k1 = i;
                    }
                } else
                {
                    i1 = HttpHeaders.parseSeconds(s1, -1);
                    k1 = i;
                }
            } else
            {
                flag4 = true;
                k1 = i;
            }
        } else
        {
            flag7 = true;
            k1 = i;
        }
          goto _L7
    }

    public boolean isPrivate()
    {
        return isPrivate;
    }

    public boolean isPublic()
    {
        return isPublic;
    }

    public int maxAgeSeconds()
    {
        return maxAgeSeconds;
    }

    public int maxStaleSeconds()
    {
        return maxStaleSeconds;
    }

    public int minFreshSeconds()
    {
        return minFreshSeconds;
    }

    public boolean mustRevalidate()
    {
        return mustRevalidate;
    }

    public boolean noCache()
    {
        return noCache;
    }

    public boolean noStore()
    {
        return noStore;
    }

    public boolean noTransform()
    {
        return noTransform;
    }

    public boolean onlyIfCached()
    {
        return onlyIfCached;
    }

    public int sMaxAgeSeconds()
    {
        return sMaxAgeSeconds;
    }

    public String toString()
    {
        String s1 = headerValue;
        String s = s1;
        if (s1 == null)
        {
            s = headerValue();
            headerValue = s;
        }
        return s;
    }

    static 
    {
        FORCE_CACHE = (new Builder()).onlyIfCached().maxStale(0x7fffffff, TimeUnit.SECONDS).build();
    }
}
