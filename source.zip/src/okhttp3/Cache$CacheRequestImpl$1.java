// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import okio.ForwardingSink;
import okio.Sink;

// Referenced classes of package okhttp3:
//            Cache

class val.editor extends ForwardingSink
{

    final he.Editor.commit this$1;
    final okhttp3.internal.cache.t val$editor;
    final Cache val$this$0;

    public void close()
        throws IOException
    {
label0:
        {
            synchronized (_fld0)
            {
                if (ne)
                {
                    break label0;
                }
                ne = true;
                Cache cache1 = _fld0;
                cache1.writeSuccessCount = cache1.writeSuccessCount + 1;
            }
            super.close();
            val$editor.t();
            return;
        }
        cache;
        JVM INSTR monitorexit ;
        return;
        exception;
        cache;
        JVM INSTR monitorexit ;
        throw exception;
    }

    he.Editor(okhttp3.internal.cache. )
    {
        this$1 = final_editor1;
        val$this$0 = Cache.this;
        val$editor = ;
        super(final_sink);
    }
}
