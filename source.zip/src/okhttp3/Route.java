// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.InetSocketAddress;
import java.net.Proxy;

// Referenced classes of package okhttp3:
//            Address

public final class Route
{

    final Address address;
    final InetSocketAddress inetSocketAddress;
    final Proxy proxy;

    public Route(Address address1, Proxy proxy1, InetSocketAddress inetsocketaddress)
    {
        if (address1 != null)
        {
            if (proxy1 != null)
            {
                if (inetsocketaddress != null)
                {
                    address = address1;
                    proxy = proxy1;
                    inetSocketAddress = inetsocketaddress;
                    return;
                } else
                {
                    throw new NullPointerException("inetSocketAddress == null");
                }
            } else
            {
                throw new NullPointerException("proxy == null");
            }
        } else
        {
            throw new NullPointerException("address == null");
        }
    }

    public Address address()
    {
        return address;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof Route))
        {
            return false;
        }
        for (obj = (Route)obj; !address.equals(((Route) (obj)).address) || !proxy.equals(((Route) (obj)).proxy) || !inetSocketAddress.equals(((Route) (obj)).inetSocketAddress);)
        {
            return false;
        }

        return true;
    }

    public int hashCode()
    {
        return ((address.hashCode() + 527) * 31 + proxy.hashCode()) * 31 + inetSocketAddress.hashCode();
    }

    public Proxy proxy()
    {
        return proxy;
    }

    public boolean requiresTunnel()
    {
        while (address.sslSocketFactory == null || proxy.type() != java.net.Proxy.Type.HTTP) 
        {
            return false;
        }
        return true;
    }

    public InetSocketAddress socketAddress()
    {
        return inetSocketAddress;
    }
}
