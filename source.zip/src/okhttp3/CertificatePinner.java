// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.security.Principal;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.net.ssl.SSLPeerUnverifiedException;
import okhttp3.internal.Util;
import okhttp3.internal.tls.CertificateChainCleaner;
import okio.ByteString;

// Referenced classes of package okhttp3:
//            HttpUrl

public final class CertificatePinner
{
    public static final class Builder
    {

        private final List pins = new ArrayList();

        public transient Builder add(String s, String as[])
        {
            if (s == null) goto _L2; else goto _L1
_L1:
            int i;
            int j;
            j = as.length;
            i = 0;
_L4:
            if (i >= j)
            {
                return this;
            }
            String s1 = as[i];
            pins.add(new Pin(s, s1));
            i++;
            continue; /* Loop/switch isn't completed */
_L2:
            throw new NullPointerException("pattern == null");
            if (true) goto _L4; else goto _L3
_L3:
        }

        public CertificatePinner build()
        {
            return new CertificatePinner(new LinkedHashSet(pins), null);
        }

        public Builder()
        {
        }
    }

    static final class Pin
    {

        private static final String WILDCARD = "*.";
        final String canonicalHostname;
        final ByteString hash;
        final String hashAlgorithm;
        final String pattern;

        public boolean equals(Object obj)
        {
            while (!(obj instanceof Pin) || !pattern.equals(((Pin)obj).pattern) || !hashAlgorithm.equals(((Pin)obj).hashAlgorithm) || !hash.equals(((Pin)obj).hash)) 
            {
                return false;
            }
            return true;
        }

        public int hashCode()
        {
            return ((pattern.hashCode() + 527) * 31 + hashAlgorithm.hashCode()) * 31 + hash.hashCode();
        }

        boolean matches(String s)
        {
            if (!pattern.startsWith("*."))
            {
                return s.equals(canonicalHostname);
            } else
            {
                return s.regionMatches(false, s.indexOf('.') + 1, canonicalHostname, 0, canonicalHostname.length());
            }
        }

        public String toString()
        {
            return (new StringBuilder()).append(hashAlgorithm).append(hash.base64()).toString();
        }

        Pin(String s, String s1)
        {
            pattern = s;
            if (!s.startsWith("*."))
            {
                s = HttpUrl.parse((new StringBuilder()).append("http://").append(s).toString()).host();
            } else
            {
                s = HttpUrl.parse((new StringBuilder()).append("http://").append(s.substring("*.".length())).toString()).host();
            }
            canonicalHostname = s;
            if (!s1.startsWith("sha1/"))
            {
                if (!s1.startsWith("sha256/"))
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("pins must start with 'sha256/' or 'sha1/': ").append(s1).toString());
                }
                break MISSING_BLOCK_LABEL_161;
            }
            hashAlgorithm = "sha1/";
            hash = ByteString.decodeBase64(s1.substring("sha1/".length()));
_L1:
            if (hash != null)
            {
                return;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("pins must be base64: ").append(s1).toString());
            }
            hashAlgorithm = "sha256/";
            hash = ByteString.decodeBase64(s1.substring("sha256/".length()));
              goto _L1
        }
    }


    public static final CertificatePinner DEFAULT = (new Builder()).build();
    private final CertificateChainCleaner certificateChainCleaner;
    private final Set pins;

    CertificatePinner(Set set, CertificateChainCleaner certificatechaincleaner)
    {
        pins = set;
        certificateChainCleaner = certificatechaincleaner;
    }

    public static String pin(Certificate certificate)
    {
        if (certificate instanceof X509Certificate)
        {
            return (new StringBuilder()).append("sha256/").append(sha256((X509Certificate)certificate).base64()).toString();
        } else
        {
            throw new IllegalArgumentException("Certificate pinning requires X509 certificates");
        }
    }

    static ByteString sha1(X509Certificate x509certificate)
    {
        return ByteString.of(x509certificate.getPublicKey().getEncoded()).sha1();
    }

    static ByteString sha256(X509Certificate x509certificate)
    {
        return ByteString.of(x509certificate.getPublicKey().getEncoded()).sha256();
    }

    public void check(String s, List list)
        throws SSLPeerUnverifiedException
    {
        List list2 = findMatchingPins(s);
        if (list2.isEmpty()) goto _L2; else goto _L1
_L1:
        List list1;
        int i;
        int j;
        int l;
        if (certificateChainCleaner == null)
        {
            list1 = list;
        } else
        {
            list1 = certificateChainCleaner.clean(list, s);
        }
        l = list1.size();
        i = 0;
_L7:
        if (i < l) goto _L4; else goto _L3
_L3:
        list = (new StringBuilder()).append("Certificate pinning failure!").append("\n  Peer certificate chain:");
        j = list1.size();
        i = 0;
_L15:
        if (i < j) goto _L6; else goto _L5
_L5:
        list.append("\n  Pinned certificates for ").append(s).append(":");
        j = list2.size();
        i = 0;
_L16:
        if (i >= j)
        {
            throw new SSLPeerUnverifiedException(list.toString());
        }
        break MISSING_BLOCK_LABEL_362;
_L2:
        return;
_L4:
        ByteString bytestring;
        X509Certificate x509certificate1;
        int k;
        int i1;
        x509certificate1 = (X509Certificate)list1.get(i);
        i1 = list2.size();
        k = 0;
        list = null;
        bytestring = null;
_L12:
label0:
        {
            if (k < i1)
            {
                break label0;
            }
            i++;
        }
          goto _L7
        Pin pin1 = (Pin)list2.get(k);
        if (pin1.hashAlgorithm.equals("sha256/")) goto _L9; else goto _L8
_L9:
        if (list == null)
        {
            list = sha256(x509certificate1);
        }
        if (pin1.hash.equals(list)) goto _L11; else goto _L10
_L10:
        obj = bytestring;
_L14:
        k++;
        bytestring = obj;
          goto _L12
_L11:
        return;
_L8:
        Object obj;
        if (!pin1.hashAlgorithm.equals("sha1/"))
        {
            throw new AssertionError();
        }
        if (bytestring == null)
        {
            bytestring = sha1(x509certificate1);
        }
        obj = bytestring;
        if (!pin1.hash.equals(bytestring)) goto _L14; else goto _L13
_L13:
        return;
_L6:
        X509Certificate x509certificate = (X509Certificate)list1.get(i);
        list.append("\n    ").append(pin(x509certificate)).append(": ").append(x509certificate.getSubjectDN().getName());
        i++;
          goto _L15
        s = (Pin)list2.get(i);
        list.append("\n    ").append(s);
        i++;
          goto _L16
    }

    public transient void check(String s, Certificate acertificate[])
        throws SSLPeerUnverifiedException
    {
        check(s, Arrays.asList(acertificate));
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            return (obj instanceof CertificatePinner) && Util.equal(certificateChainCleaner, ((CertificatePinner)obj).certificateChainCleaner) && pins.equals(((CertificatePinner)obj).pins);
        } else
        {
            return true;
        }
    }

    List findMatchingPins(String s)
    {
        Object obj = Collections.emptyList();
        Iterator iterator = pins.iterator();
        do
        {
            Pin pin1;
            do
            {
                if (!iterator.hasNext())
                {
                    return ((List) (obj));
                }
                pin1 = (Pin)iterator.next();
            } while (!pin1.matches(s));
            if (((List) (obj)).isEmpty())
            {
                obj = new ArrayList();
            }
            ((List) (obj)).add(pin1);
        } while (true);
    }

    public int hashCode()
    {
        int i;
        if (certificateChainCleaner == null)
        {
            i = 0;
        } else
        {
            i = certificateChainCleaner.hashCode();
        }
        return i * 31 + pins.hashCode();
    }

    CertificatePinner withCertificateChainCleaner(CertificateChainCleaner certificatechaincleaner)
    {
        CertificatePinner certificatepinner = this;
        if (!Util.equal(certificateChainCleaner, certificatechaincleaner))
        {
            certificatepinner = new CertificatePinner(pins, certificatechaincleaner);
        }
        return certificatepinner;
    }

}
