// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.Proxy;
import java.net.ProxySelector;
import java.util.List;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            HttpUrl, CertificatePinner, Dns, Authenticator

public final class Address
{

    final CertificatePinner certificatePinner;
    final List connectionSpecs;
    final Dns dns;
    final HostnameVerifier hostnameVerifier;
    final List protocols;
    final Proxy proxy;
    final Authenticator proxyAuthenticator;
    final ProxySelector proxySelector;
    final SocketFactory socketFactory;
    final SSLSocketFactory sslSocketFactory;
    final HttpUrl url;

    public Address(String s, int i, Dns dns1, SocketFactory socketfactory, SSLSocketFactory sslsocketfactory, HostnameVerifier hostnameverifier, CertificatePinner certificatepinner, 
            Authenticator authenticator, Proxy proxy1, List list, List list1, ProxySelector proxyselector)
    {
        HttpUrl.Builder builder = new HttpUrl.Builder();
        String s1;
        if (sslsocketfactory == null)
        {
            s1 = "http";
        } else
        {
            s1 = "https";
        }
        url = builder.scheme(s1).host(s).port(i).build();
        if (dns1 != null)
        {
            dns = dns1;
            if (socketfactory != null)
            {
                socketFactory = socketfactory;
                if (authenticator != null)
                {
                    proxyAuthenticator = authenticator;
                    if (list != null)
                    {
                        protocols = Util.immutableList(list);
                        if (list1 != null)
                        {
                            connectionSpecs = Util.immutableList(list1);
                            if (proxyselector != null)
                            {
                                proxySelector = proxyselector;
                                proxy = proxy1;
                                sslSocketFactory = sslsocketfactory;
                                hostnameVerifier = hostnameverifier;
                                certificatePinner = certificatepinner;
                                return;
                            } else
                            {
                                throw new NullPointerException("proxySelector == null");
                            }
                        } else
                        {
                            throw new NullPointerException("connectionSpecs == null");
                        }
                    } else
                    {
                        throw new NullPointerException("protocols == null");
                    }
                } else
                {
                    throw new NullPointerException("proxyAuthenticator == null");
                }
            } else
            {
                throw new NullPointerException("socketFactory == null");
            }
        } else
        {
            throw new NullPointerException("dns == null");
        }
    }

    public CertificatePinner certificatePinner()
    {
        return certificatePinner;
    }

    public List connectionSpecs()
    {
        return connectionSpecs;
    }

    public Dns dns()
    {
        return dns;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof Address))
        {
            return false;
        }
        for (obj = (Address)obj; !url.equals(((Address) (obj)).url) || !dns.equals(((Address) (obj)).dns) || !proxyAuthenticator.equals(((Address) (obj)).proxyAuthenticator) || !protocols.equals(((Address) (obj)).protocols) || !connectionSpecs.equals(((Address) (obj)).connectionSpecs) || !proxySelector.equals(((Address) (obj)).proxySelector) || !Util.equal(proxy, ((Address) (obj)).proxy) || !Util.equal(sslSocketFactory, ((Address) (obj)).sslSocketFactory) || !Util.equal(hostnameVerifier, ((Address) (obj)).hostnameVerifier) || !Util.equal(certificatePinner, ((Address) (obj)).certificatePinner);)
        {
            return false;
        }

        return true;
    }

    public int hashCode()
    {
        int l = 0;
        int i1 = url.hashCode();
        int j1 = dns.hashCode();
        int k1 = proxyAuthenticator.hashCode();
        int l1 = protocols.hashCode();
        int i2 = connectionSpecs.hashCode();
        int j2 = proxySelector.hashCode();
        int i;
        int j;
        int k;
        if (proxy == null)
        {
            i = 0;
        } else
        {
            i = proxy.hashCode();
        }
        if (sslSocketFactory == null)
        {
            j = 0;
        } else
        {
            j = sslSocketFactory.hashCode();
        }
        if (hostnameVerifier == null)
        {
            k = 0;
        } else
        {
            k = hostnameVerifier.hashCode();
        }
        if (certificatePinner != null)
        {
            l = certificatePinner.hashCode();
        }
        return (k + (j + (i + ((((((i1 + 527) * 31 + j1) * 31 + k1) * 31 + l1) * 31 + i2) * 31 + j2) * 31) * 31) * 31) * 31 + l;
    }

    public HostnameVerifier hostnameVerifier()
    {
        return hostnameVerifier;
    }

    public List protocols()
    {
        return protocols;
    }

    public Proxy proxy()
    {
        return proxy;
    }

    public Authenticator proxyAuthenticator()
    {
        return proxyAuthenticator;
    }

    public ProxySelector proxySelector()
    {
        return proxySelector;
    }

    public SocketFactory socketFactory()
    {
        return socketFactory;
    }

    public SSLSocketFactory sslSocketFactory()
    {
        return sslSocketFactory;
    }

    public HttpUrl url()
    {
        return url;
    }
}
