// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.concurrent.TimeUnit;

// Referenced classes of package okhttp3:
//            CacheControl

public static final class minFreshSeconds
{

    int maxAgeSeconds;
    int maxStaleSeconds;
    int minFreshSeconds;
    boolean noCache;
    boolean noStore;
    boolean noTransform;
    boolean onlyIfCached;

    public CacheControl build()
    {
        return new CacheControl(this);
    }

    public  maxAge(int i, TimeUnit timeunit)
    {
        boolean flag = false;
        if (i >= 0)
        {
            long l = timeunit.toSeconds(i);
            i = ((flag) ? 1 : 0);
            if (l <= 0x7fffffffL)
            {
                i = 1;
            }
            if (i == 0)
            {
                i = 0x7fffffff;
            } else
            {
                i = (int)l;
            }
            maxAgeSeconds = i;
            return this;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("maxAge < 0: ").append(i).toString());
        }
    }

    public  maxStale(int i, TimeUnit timeunit)
    {
        boolean flag = false;
        if (i >= 0)
        {
            long l = timeunit.toSeconds(i);
            i = ((flag) ? 1 : 0);
            if (l <= 0x7fffffffL)
            {
                i = 1;
            }
            if (i == 0)
            {
                i = 0x7fffffff;
            } else
            {
                i = (int)l;
            }
            maxStaleSeconds = i;
            return this;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("maxStale < 0: ").append(i).toString());
        }
    }

    public  minFresh(int i, TimeUnit timeunit)
    {
        boolean flag = false;
        if (i >= 0)
        {
            long l = timeunit.toSeconds(i);
            i = ((flag) ? 1 : 0);
            if (l <= 0x7fffffffL)
            {
                i = 1;
            }
            if (i == 0)
            {
                i = 0x7fffffff;
            } else
            {
                i = (int)l;
            }
            minFreshSeconds = i;
            return this;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("minFresh < 0: ").append(i).toString());
        }
    }

    public ing noCache()
    {
        noCache = true;
        return this;
    }

    public noCache noStore()
    {
        noStore = true;
        return this;
    }

    public noStore noTransform()
    {
        noTransform = true;
        return this;
    }

    public noTransform onlyIfCached()
    {
        onlyIfCached = true;
        return this;
    }

    public ()
    {
        maxAgeSeconds = -1;
        maxStaleSeconds = -1;
        minFreshSeconds = -1;
    }
}
