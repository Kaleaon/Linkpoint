// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import okio.ByteString;

// Referenced classes of package okhttp3:
//            MultipartBody, MediaType, RequestBody, Headers

public static final class boundary
{

    private final ByteString boundary;
    private final List parts;
    private MediaType type;

    public boundary addFormDataPart(String s, String s1)
    {
        return addPart(ateFormData(s, s1));
    }

    public ateFormData addFormDataPart(String s, String s1, RequestBody requestbody)
    {
        return addPart(ateFormData(s, s1, requestbody));
    }

    public ateFormData addPart(Headers headers, RequestBody requestbody)
    {
        return addPart(ate(headers, requestbody));
    }

    public ate addPart(ate ate)
    {
        if (ate != null)
        {
            parts.add(ate);
            return this;
        } else
        {
            throw new NullPointerException("part == null");
        }
    }

    public  addPart(RequestBody requestbody)
    {
        return addPart(ate(requestbody));
    }

    public MultipartBody build()
    {
        if (!parts.isEmpty())
        {
            return new MultipartBody(boundary, type, parts);
        } else
        {
            throw new IllegalStateException("Multipart body must have at least one part.");
        }
    }

    public n setType(MediaType mediatype)
    {
        if (mediatype != null)
        {
            if (mediatype.type().equals("multipart"))
            {
                type = mediatype;
                return this;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("multipart != ").append(mediatype).toString());
            }
        } else
        {
            throw new NullPointerException("type == null");
        }
    }

    public tion()
    {
        this(UUID.randomUUID().toString());
    }

    public <init>(String s)
    {
        type = MultipartBody.MIXED;
        parts = new ArrayList();
        boundary = ByteString.encodeUtf8(s);
    }
}
