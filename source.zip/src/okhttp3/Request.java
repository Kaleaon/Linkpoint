// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.URL;
import java.util.List;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpMethod;

// Referenced classes of package okhttp3:
//            CacheControl, Headers, HttpUrl, RequestBody

public final class Request
{
    public static class Builder
    {

        RequestBody body;
        Headers.Builder headers;
        String method;
        Object tag;
        HttpUrl url;

        public Builder addHeader(String s, String s1)
        {
            headers.add(s, s1);
            return this;
        }

        public Request build()
        {
            if (url != null)
            {
                return new Request(this);
            } else
            {
                throw new IllegalStateException("url == null");
            }
        }

        public Builder cacheControl(CacheControl cachecontrol)
        {
            cachecontrol = cachecontrol.toString();
            if (!cachecontrol.isEmpty())
            {
                return header("Cache-Control", cachecontrol);
            } else
            {
                return removeHeader("Cache-Control");
            }
        }

        public Builder delete()
        {
            return delete(Util.EMPTY_REQUEST);
        }

        public Builder delete(RequestBody requestbody)
        {
            return method("DELETE", requestbody);
        }

        public Builder get()
        {
            return method("GET", null);
        }

        public Builder head()
        {
            return method("HEAD", null);
        }

        public Builder header(String s, String s1)
        {
            headers.set(s, s1);
            return this;
        }

        public Builder headers(Headers headers1)
        {
            headers = headers1.newBuilder();
            return this;
        }

        public Builder method(String s, RequestBody requestbody)
        {
            if (s != null)
            {
                if (s.length() != 0)
                {
                    if (requestbody == null || HttpMethod.permitsRequestBody(s))
                    {
                        if (requestbody != null || !HttpMethod.requiresRequestBody(s))
                        {
                            method = s;
                            body = requestbody;
                            return this;
                        } else
                        {
                            throw new IllegalArgumentException((new StringBuilder()).append("method ").append(s).append(" must have a request body.").toString());
                        }
                    } else
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("method ").append(s).append(" must not have a request body.").toString());
                    }
                } else
                {
                    throw new IllegalArgumentException("method.length() == 0");
                }
            } else
            {
                throw new NullPointerException("method == null");
            }
        }

        public Builder patch(RequestBody requestbody)
        {
            return method("PATCH", requestbody);
        }

        public Builder post(RequestBody requestbody)
        {
            return method("POST", requestbody);
        }

        public Builder put(RequestBody requestbody)
        {
            return method("PUT", requestbody);
        }

        public Builder removeHeader(String s)
        {
            headers.removeAll(s);
            return this;
        }

        public Builder tag(Object obj)
        {
            tag = obj;
            return this;
        }

        public Builder url(String s)
        {
            if (s != null)
            {
                HttpUrl httpurl;
                if (!s.regionMatches(true, 0, "ws:", 0, 3))
                {
                    if (s.regionMatches(true, 0, "wss:", 0, 4))
                    {
                        s = (new StringBuilder()).append("https:").append(s.substring(4)).toString();
                    }
                } else
                {
                    s = (new StringBuilder()).append("http:").append(s.substring(3)).toString();
                }
                httpurl = HttpUrl.parse(s);
                if (httpurl != null)
                {
                    return url(httpurl);
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("unexpected url: ").append(s).toString());
                }
            } else
            {
                throw new NullPointerException("url == null");
            }
        }

        public Builder url(URL url1)
        {
            if (url1 != null)
            {
                HttpUrl httpurl = HttpUrl.get(url1);
                if (httpurl != null)
                {
                    return url(httpurl);
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("unexpected url: ").append(url1).toString());
                }
            } else
            {
                throw new NullPointerException("url == null");
            }
        }

        public Builder url(HttpUrl httpurl)
        {
            if (httpurl != null)
            {
                url = httpurl;
                return this;
            } else
            {
                throw new NullPointerException("url == null");
            }
        }

        public Builder()
        {
            method = "GET";
            headers = new Headers.Builder();
        }

        Builder(Request request)
        {
            url = request.url;
            method = request.method;
            body = request.body;
            tag = request.tag;
            headers = request.headers.newBuilder();
        }
    }


    final RequestBody body;
    private volatile CacheControl cacheControl;
    final Headers headers;
    final String method;
    final Object tag;
    final HttpUrl url;

    Request(Builder builder)
    {
        url = builder.url;
        method = builder.method;
        headers = builder.headers.build();
        body = builder.body;
        if (builder.tag == null)
        {
            builder = this;
        } else
        {
            builder = ((Builder) (builder.tag));
        }
        tag = builder;
    }

    public RequestBody body()
    {
        return body;
    }

    public CacheControl cacheControl()
    {
        CacheControl cachecontrol1 = cacheControl;
        CacheControl cachecontrol = cachecontrol1;
        if (cachecontrol1 == null)
        {
            cachecontrol = CacheControl.parse(headers);
            cacheControl = cachecontrol;
        }
        return cachecontrol;
    }

    public String header(String s)
    {
        return headers.get(s);
    }

    public List headers(String s)
    {
        return headers.values(s);
    }

    public Headers headers()
    {
        return headers;
    }

    public boolean isHttps()
    {
        return url.isHttps();
    }

    public String method()
    {
        return method;
    }

    public Builder newBuilder()
    {
        return new Builder(this);
    }

    public Object tag()
    {
        return tag;
    }

    public String toString()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append("Request{method=").append(method).append(", url=").append(url).append(", tag=");
        Object obj;
        if (tag == this)
        {
            obj = null;
        } else
        {
            obj = tag;
        }
        return stringbuilder.append(obj).append('}').toString();
    }

    public HttpUrl url()
    {
        return url;
    }
}
