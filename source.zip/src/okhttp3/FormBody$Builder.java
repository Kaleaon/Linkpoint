// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package okhttp3:
//            FormBody, HttpUrl

public static final class 
{

    private final List names = new ArrayList();
    private final List values = new ArrayList();

    public  add(String s, String s1)
    {
        names.add(HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
        values.add(HttpUrl.canonicalize(s1, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
        return this;
    }

    public ize addEncoded(String s, String s1)
    {
        names.add(HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
        values.add(HttpUrl.canonicalize(s1, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
        return this;
    }

    public FormBody build()
    {
        return new FormBody(names, values);
    }

    public ()
    {
    }
}
