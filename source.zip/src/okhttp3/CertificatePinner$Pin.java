// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import okio.ByteString;

// Referenced classes of package okhttp3:
//            CertificatePinner, HttpUrl

static final class hash
{

    private static final String WILDCARD = "*.";
    final String canonicalHostname;
    final ByteString hash;
    final String hashAlgorithm;
    final String pattern;

    public boolean equals(Object obj)
    {
        while (!(obj instanceof hash) || !pattern.equals(((pattern)obj).pattern) || !hashAlgorithm.equals(((hashAlgorithm)obj).hashAlgorithm) || !hash.equals(((hash)obj).hash)) 
        {
            return false;
        }
        return true;
    }

    public int hashCode()
    {
        return ((pattern.hashCode() + 527) * 31 + hashAlgorithm.hashCode()) * 31 + hash.hashCode();
    }

    boolean matches(String s)
    {
        if (!pattern.startsWith("*."))
        {
            return s.equals(canonicalHostname);
        } else
        {
            return s.regionMatches(false, s.indexOf('.') + 1, canonicalHostname, 0, canonicalHostname.length());
        }
    }

    public String toString()
    {
        return (new StringBuilder()).append(hashAlgorithm).append(hash.base64()).toString();
    }

    tion(String s, String s1)
    {
        pattern = s;
        if (!s.startsWith("*."))
        {
            s = HttpUrl.parse((new StringBuilder()).append("http://").append(s).toString()).host();
        } else
        {
            s = HttpUrl.parse((new StringBuilder()).append("http://").append(s.substring("*.".length())).toString()).host();
        }
        canonicalHostname = s;
        if (!s1.startsWith("sha1/"))
        {
            if (!s1.startsWith("sha256/"))
            {
                throw new IllegalArgumentException((new StringBuilder()).append("pins must start with 'sha256/' or 'sha1/': ").append(s1).toString());
            }
            break MISSING_BLOCK_LABEL_161;
        }
        hashAlgorithm = "sha1/";
        hash = ByteString.decodeBase64(s1.substring("sha1/".length()));
_L1:
        if (hash != null)
        {
            return;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("pins must be base64: ").append(s1).toString());
        }
        hashAlgorithm = "sha256/";
        hash = ByteString.decodeBase64(s1.substring("sha256/".length()));
          goto _L1
    }
}
