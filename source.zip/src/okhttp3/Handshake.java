// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.security.Principal;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            CipherSuite, TlsVersion

public final class Handshake
{

    private final CipherSuite cipherSuite;
    private final List localCertificates;
    private final List peerCertificates;
    private final TlsVersion tlsVersion;

    private Handshake(TlsVersion tlsversion, CipherSuite ciphersuite, List list, List list1)
    {
        tlsVersion = tlsversion;
        cipherSuite = ciphersuite;
        peerCertificates = list;
        localCertificates = list1;
    }

    public static Handshake get(SSLSession sslsession)
    {
        Object obj;
        String s;
        obj = null;
        s = sslsession.getCipherSuite();
        if (s == null) goto _L2; else goto _L1
_L1:
        CipherSuite ciphersuite;
        ciphersuite = CipherSuite.forJavaName(s);
        s = sslsession.getProtocol();
        if (s == null) goto _L4; else goto _L3
_L3:
        TlsVersion tlsversion = TlsVersion.forJavaName(s);
        java.security.cert.Certificate acertificate[] = sslsession.getPeerCertificates();
        obj = acertificate;
_L5:
        SSLPeerUnverifiedException sslpeerunverifiedexception;
        if (obj == null)
        {
            obj = Collections.emptyList();
        } else
        {
            obj = Util.immutableList(((Object []) (obj)));
        }
        sslsession = sslsession.getLocalCertificates();
        if (sslsession == null)
        {
            sslsession = Collections.emptyList();
        } else
        {
            sslsession = Util.immutableList(sslsession);
        }
        return new Handshake(tlsversion, ciphersuite, ((List) (obj)), sslsession);
_L2:
        throw new IllegalStateException("cipherSuite == null");
_L4:
        throw new IllegalStateException("tlsVersion == null");
        sslpeerunverifiedexception;
          goto _L5
    }

    public static Handshake get(TlsVersion tlsversion, CipherSuite ciphersuite, List list, List list1)
    {
        if (ciphersuite != null)
        {
            return new Handshake(tlsversion, ciphersuite, Util.immutableList(list), Util.immutableList(list1));
        } else
        {
            throw new NullPointerException("cipherSuite == null");
        }
    }

    public CipherSuite cipherSuite()
    {
        return cipherSuite;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof Handshake)
        {
            obj = (Handshake)obj;
            break MISSING_BLOCK_LABEL_12;
        } else
        {
            return false;
        }
        return Util.equal(cipherSuite, ((Handshake) (obj)).cipherSuite) && cipherSuite.equals(((Handshake) (obj)).cipherSuite) && peerCertificates.equals(((Handshake) (obj)).peerCertificates) && localCertificates.equals(((Handshake) (obj)).localCertificates);
    }

    public int hashCode()
    {
        int i;
        if (tlsVersion == null)
        {
            i = 0;
        } else
        {
            i = tlsVersion.hashCode();
        }
        return (((i + 527) * 31 + cipherSuite.hashCode()) * 31 + peerCertificates.hashCode()) * 31 + localCertificates.hashCode();
    }

    public List localCertificates()
    {
        return localCertificates;
    }

    public Principal localPrincipal()
    {
        if (localCertificates.isEmpty())
        {
            return null;
        } else
        {
            return ((X509Certificate)localCertificates.get(0)).getSubjectX500Principal();
        }
    }

    public List peerCertificates()
    {
        return peerCertificates;
    }

    public Principal peerPrincipal()
    {
        if (peerCertificates.isEmpty())
        {
            return null;
        } else
        {
            return ((X509Certificate)peerCertificates.get(0)).getSubjectX500Principal();
        }
    }

    public TlsVersion tlsVersion()
    {
        return tlsVersion;
    }
}
