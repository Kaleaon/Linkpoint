// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import okio.ForwardingSource;
import okio.Source;

// Referenced classes of package okhttp3:
//            Cache

class val.snapshot extends ForwardingSource
{

    final e.Snapshot.close this$0;
    final okhttp3.internal.cache.e val$snapshot;

    public void close()
        throws IOException
    {
        val$snapshot.e();
        super.close();
    }

    e.Snapshot(okhttp3.internal.cache. )
    {
        this$0 = final_snapshot1;
        val$snapshot = ;
        super(Source.this);
    }
}
