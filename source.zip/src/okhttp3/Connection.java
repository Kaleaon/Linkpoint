// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.Socket;

// Referenced classes of package okhttp3:
//            Handshake, Protocol, Route

public interface Connection
{

    public abstract Handshake handshake();

    public abstract Protocol protocol();

    public abstract Route route();

    public abstract Socket socket();
}
