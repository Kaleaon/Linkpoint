// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.Collections;
import java.util.List;

// Referenced classes of package okhttp3:
//            HttpUrl

public interface CookieJar
{

    public static final CookieJar NO_COOKIES = new CookieJar() {

        public List loadForRequest(HttpUrl httpurl)
        {
            return Collections.emptyList();
        }

        public void saveFromResponse(HttpUrl httpurl, List list)
        {
        }

    };

    public abstract List loadForRequest(HttpUrl httpurl);

    public abstract void saveFromResponse(HttpUrl httpurl, List list);

}
