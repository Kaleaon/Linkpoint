// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            ConnectionPool

class this._cls0
    implements Runnable
{

    final ConnectionPool this$0;

    public void run()
    {
        do
        {
            do
            {
                long l = cleanup(System.nanoTime());
                if (l == -1L)
                {
                    return;
                }
                boolean flag;
                long l1;
                if (l <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            } while (flag);
            l1 = l / 0xf4240L;
            synchronized (ConnectionPool.this)
            {
                try
                {
                    wait(l1, (int)(l - l1 * 0xf4240L));
                }
                // Misplaced declaration of an exception variable
                catch (InterruptedException interruptedexception) { }
            }
        } while (true);
        exception;
        connectionpool;
        JVM INSTR monitorexit ;
        InterruptedException interruptedexception;
        throw exception;
    }

    ption()
    {
        this$0 = ConnectionPool.this;
        super();
    }
}
