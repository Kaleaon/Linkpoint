// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            RealCall

public final class Dispatcher
{

    private ExecutorService executorService;
    private Runnable idleCallback;
    private int maxRequests;
    private int maxRequestsPerHost;
    private final Deque readyAsyncCalls;
    private final Deque runningAsyncCalls;
    private final Deque runningSyncCalls;

    public Dispatcher()
    {
        maxRequests = 64;
        maxRequestsPerHost = 5;
        readyAsyncCalls = new ArrayDeque();
        runningAsyncCalls = new ArrayDeque();
        runningSyncCalls = new ArrayDeque();
    }

    public Dispatcher(ExecutorService executorservice)
    {
        maxRequests = 64;
        maxRequestsPerHost = 5;
        readyAsyncCalls = new ArrayDeque();
        runningAsyncCalls = new ArrayDeque();
        runningSyncCalls = new ArrayDeque();
        executorService = executorservice;
    }

    private void finished(Deque deque, Object obj, boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        if (!deque.remove(obj)) goto _L2; else goto _L1
_L1:
        if (flag) goto _L4; else goto _L3
_L3:
        int i;
        i = runningCallsCount();
        deque = idleCallback;
        this;
        JVM INSTR monitorexit ;
        if (i != 0)
        {
            return;
        }
        break; /* Loop/switch isn't completed */
_L2:
        throw new AssertionError("Call wasn't in-flight!");
        deque;
        this;
        JVM INSTR monitorexit ;
        throw deque;
_L4:
        promoteCalls();
        if (true) goto _L3; else goto _L5
_L5:
        if (deque != null)
        {
            deque.run();
        }
        return;
    }

    private void promoteCalls()
    {
        Iterator iterator;
        if (runningAsyncCalls.size() < maxRequests)
        {
            if (!readyAsyncCalls.isEmpty())
            {
                iterator = readyAsyncCalls.iterator();
                break MISSING_BLOCK_LABEL_38;
            } else
            {
                return;
            }
        } else
        {
            return;
        }
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            RealCall.AsyncCall asynccall = (RealCall.AsyncCall)iterator.next();
            if (runningCallsForHost(asynccall) < maxRequestsPerHost)
            {
                iterator.remove();
                runningAsyncCalls.add(asynccall);
                executorService().execute(asynccall);
            }
            if (runningAsyncCalls.size() >= maxRequests)
            {
                return;
            }
        } while (true);
    }

    private int runningCallsForHost(RealCall.AsyncCall asynccall)
    {
        Iterator iterator = runningAsyncCalls.iterator();
        int i = 0;
        do
        {
            do
            {
                if (!iterator.hasNext())
                {
                    return i;
                }
            } while (!((RealCall.AsyncCall)iterator.next()).host().equals(asynccall.host()));
            i++;
        } while (true);
    }

    public void cancelAll()
    {
        this;
        JVM INSTR monitorenter ;
        Object obj = readyAsyncCalls.iterator();
_L5:
        if (((Iterator) (obj)).hasNext()) goto _L2; else goto _L1
_L1:
        obj = runningAsyncCalls.iterator();
_L6:
        if (((Iterator) (obj)).hasNext()) goto _L4; else goto _L3
_L3:
        obj = runningSyncCalls.iterator();
_L7:
        boolean flag = ((Iterator) (obj)).hasNext();
        if (flag)
        {
            break MISSING_BLOCK_LABEL_105;
        }
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        ((RealCall.AsyncCall)((Iterator) (obj)).next()).get().cancel();
          goto _L5
        obj;
        throw obj;
_L4:
        ((RealCall.AsyncCall)((Iterator) (obj)).next()).get().cancel();
          goto _L6
        ((RealCall)((Iterator) (obj)).next()).cancel();
          goto _L7
    }

    void enqueue(RealCall.AsyncCall asynccall)
    {
        this;
        JVM INSTR monitorenter ;
        if (runningAsyncCalls.size() < maxRequests) goto _L2; else goto _L1
_L1:
        readyAsyncCalls.add(asynccall);
_L4:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (runningCallsForHost(asynccall) >= maxRequestsPerHost)
        {
            break; /* Loop/switch isn't completed */
        }
        runningAsyncCalls.add(asynccall);
        executorService().execute(asynccall);
        if (true) goto _L4; else goto _L3
_L3:
        if (true) goto _L1; else goto _L5
_L5:
        asynccall;
        throw asynccall;
    }

    void executed(RealCall realcall)
    {
        this;
        JVM INSTR monitorenter ;
        runningSyncCalls.add(realcall);
        this;
        JVM INSTR monitorexit ;
        return;
        realcall;
        throw realcall;
    }

    public ExecutorService executorService()
    {
        this;
        JVM INSTR monitorenter ;
        if (executorService == null)
        {
            break MISSING_BLOCK_LABEL_18;
        }
_L1:
        ExecutorService executorservice = executorService;
        this;
        JVM INSTR monitorexit ;
        return executorservice;
        executorService = new ThreadPoolExecutor(0, 0x7fffffff, 60L, TimeUnit.SECONDS, new SynchronousQueue(), Util.threadFactory("OkHttp Dispatcher", false));
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    void finished(RealCall.AsyncCall asynccall)
    {
        finished(runningAsyncCalls, asynccall, true);
    }

    void finished(RealCall realcall)
    {
        finished(runningSyncCalls, realcall, false);
    }

    public int getMaxRequests()
    {
        this;
        JVM INSTR monitorenter ;
        int i = maxRequests;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public int getMaxRequestsPerHost()
    {
        this;
        JVM INSTR monitorenter ;
        int i = maxRequestsPerHost;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public List queuedCalls()
    {
        this;
        JVM INSTR monitorenter ;
        Object obj;
        Iterator iterator;
        obj = new ArrayList();
        iterator = readyAsyncCalls.iterator();
_L1:
        if (iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_38;
        }
        obj = Collections.unmodifiableList(((List) (obj)));
        this;
        JVM INSTR monitorexit ;
        return ((List) (obj));
        ((List) (obj)).add(((RealCall.AsyncCall)iterator.next()).get());
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    public int queuedCallsCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = readyAsyncCalls.size();
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public List runningCalls()
    {
        this;
        JVM INSTR monitorenter ;
        Object obj;
        Iterator iterator;
        obj = new ArrayList();
        ((List) (obj)).addAll(runningSyncCalls);
        iterator = runningAsyncCalls.iterator();
_L1:
        if (iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_49;
        }
        obj = Collections.unmodifiableList(((List) (obj)));
        this;
        JVM INSTR monitorexit ;
        return ((List) (obj));
        ((List) (obj)).add(((RealCall.AsyncCall)iterator.next()).get());
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    public int runningCallsCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i;
        int j;
        i = runningAsyncCalls.size();
        j = runningSyncCalls.size();
        this;
        JVM INSTR monitorexit ;
        return i + j;
        Exception exception;
        exception;
        throw exception;
    }

    public void setIdleCallback(Runnable runnable)
    {
        this;
        JVM INSTR monitorenter ;
        idleCallback = runnable;
        this;
        JVM INSTR monitorexit ;
        return;
        runnable;
        throw runnable;
    }

    public void setMaxRequests(int i)
    {
        this;
        JVM INSTR monitorenter ;
        if (i < 1)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        maxRequests = i;
        promoteCalls();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IllegalArgumentException((new StringBuilder()).append("max < 1: ").append(i).toString());
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void setMaxRequestsPerHost(int i)
    {
        this;
        JVM INSTR monitorenter ;
        if (i < 1)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        maxRequestsPerHost = i;
        promoteCalls();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IllegalArgumentException((new StringBuilder()).append("max < 1: ").append(i).toString());
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }
}
