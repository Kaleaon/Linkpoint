// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.internal.NamedRunnable;
import okhttp3.internal.cache.CacheInterceptor;
import okhttp3.internal.connection.ConnectInterceptor;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.http.BridgeInterceptor;
import okhttp3.internal.http.CallServerInterceptor;
import okhttp3.internal.http.RealInterceptorChain;
import okhttp3.internal.http.RetryAndFollowUpInterceptor;
import okhttp3.internal.platform.Platform;

// Referenced classes of package okhttp3:
//            Call, OkHttpClient, Dispatcher, Request, 
//            HttpUrl, Callback, Response

final class RealCall
    implements Call
{
    final class AsyncCall extends NamedRunnable
    {

        private final Callback responseCallback;
        final RealCall this$0;

        protected void execute()
        {
            boolean flag = true;
            Response response;
            boolean flag1;
            response = getResponseWithInterceptorChain();
            flag1 = retryAndFollowUpInterceptor.isCanceled();
            if (flag1) goto _L2; else goto _L1
_L1:
            responseCallback.onResponse(RealCall.this, response);
_L4:
            client.dispatcher().finished(this);
            return;
_L2:
            responseCallback.onFailure(RealCall.this, new IOException("Canceled"));
            if (true) goto _L4; else goto _L3
_L3:
            Object obj;
            obj;
_L10:
            if (flag) goto _L6; else goto _L5
_L5:
            responseCallback.onFailure(RealCall.this, ((IOException) (obj)));
_L8:
            client.dispatcher().finished(this);
            return;
_L6:
            Platform.get().log(4, (new StringBuilder()).append("Callback failure for ").append(toLoggableString()).toString(), ((Throwable) (obj)));
            if (true) goto _L8; else goto _L7
_L7:
            obj;
            client.dispatcher().finished(this);
            throw obj;
            obj;
            flag = false;
            if (true) goto _L10; else goto _L9
_L9:
        }

        RealCall get()
        {
            return RealCall.this;
        }

        String host()
        {
            return originalRequest.url().host();
        }

        Request request()
        {
            return originalRequest;
        }

        AsyncCall(Callback callback)
        {
            this$0 = RealCall.this;
            super("OkHttp %s", new Object[] {
                redactedUrl()
            });
            responseCallback = callback;
        }
    }


    final OkHttpClient client;
    private boolean executed;
    final boolean forWebSocket;
    final Request originalRequest;
    final RetryAndFollowUpInterceptor retryAndFollowUpInterceptor;

    RealCall(OkHttpClient okhttpclient, Request request1, boolean flag)
    {
        client = okhttpclient;
        originalRequest = request1;
        forWebSocket = flag;
        retryAndFollowUpInterceptor = new RetryAndFollowUpInterceptor(okhttpclient, flag);
    }

    private void captureCallStackTrace()
    {
        Object obj = Platform.get().getStackTraceForCloseable("response.body().close()");
        retryAndFollowUpInterceptor.setCallStackTrace(obj);
    }

    public void cancel()
    {
        retryAndFollowUpInterceptor.cancel();
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public volatile Call clone()
    {
        return clone();
    }

    public RealCall clone()
    {
        return new RealCall(client, originalRequest, forWebSocket);
    }

    public void enqueue(Callback callback)
    {
        this;
        JVM INSTR monitorenter ;
        if (executed)
        {
            break MISSING_BLOCK_LABEL_40;
        }
        executed = true;
        this;
        JVM INSTR monitorexit ;
        captureCallStackTrace();
        client.dispatcher().enqueue(new AsyncCall(callback));
        return;
        throw new IllegalStateException("Already Executed");
        callback;
        this;
        JVM INSTR monitorexit ;
        throw callback;
    }

    public Response execute()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (executed)
        {
            break MISSING_BLOCK_LABEL_53;
        }
        executed = true;
        this;
        JVM INSTR monitorexit ;
        captureCallStackTrace();
        Response response;
        client.dispatcher().executed(this);
        response = getResponseWithInterceptorChain();
        if (response != null)
        {
            client.dispatcher().finished(this);
            return response;
        }
        break MISSING_BLOCK_LABEL_68;
        throw new IllegalStateException("Already Executed");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        throw new IOException("Canceled");
        exception;
        client.dispatcher().finished(this);
        throw exception;
    }

    Response getResponseWithInterceptorChain()
        throws IOException
    {
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(client.interceptors());
        arraylist.add(retryAndFollowUpInterceptor);
        arraylist.add(new BridgeInterceptor(client.cookieJar()));
        arraylist.add(new CacheInterceptor(client.internalCache()));
        arraylist.add(new ConnectInterceptor(client));
        if (!forWebSocket)
        {
            arraylist.addAll(client.networkInterceptors());
        }
        arraylist.add(new CallServerInterceptor(forWebSocket));
        return (new RealInterceptorChain(arraylist, null, null, null, 0, originalRequest)).proceed(originalRequest);
    }

    public boolean isCanceled()
    {
        return retryAndFollowUpInterceptor.isCanceled();
    }

    public boolean isExecuted()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = executed;
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    String redactedUrl()
    {
        return originalRequest.url().redact();
    }

    public Request request()
    {
        return originalRequest;
    }

    StreamAllocation streamAllocation()
    {
        return retryAndFollowUpInterceptor.streamAllocation();
    }

    String toLoggableString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        String s;
        if (!isCanceled())
        {
            s = "";
        } else
        {
            s = "canceled ";
        }
        stringbuilder = stringbuilder.append(s);
        if (!forWebSocket)
        {
            s = "call";
        } else
        {
            s = "web socket";
        }
        return stringbuilder.append(s).append(" to ").append(redactedUrl()).toString();
    }
}
