// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import okhttp3.internal.Util;

public final class Challenge
{

    private final String realm;
    private final String scheme;

    public Challenge(String s, String s1)
    {
        scheme = s;
        realm = s1;
    }

    public boolean equals(Object obj)
    {
        while (!(obj instanceof Challenge) || !Util.equal(scheme, ((Challenge)obj).scheme) || !Util.equal(realm, ((Challenge)obj).realm)) 
        {
            return false;
        }
        return true;
    }

    public int hashCode()
    {
        int j = 0;
        int i;
        if (realm == null)
        {
            i = 0;
        } else
        {
            i = realm.hashCode();
        }
        if (scheme != null)
        {
            j = scheme.hashCode();
        }
        return (i + 899) * 31 + j;
    }

    public String realm()
    {
        return realm;
    }

    public String scheme()
    {
        return scheme;
    }

    public String toString()
    {
        return (new StringBuilder()).append(scheme).append(" realm=\"").append(realm).append("\"").toString();
    }
}
