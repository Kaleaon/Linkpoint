// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import okhttp3.internal.NamedRunnable;
import okhttp3.internal.http.RetryAndFollowUpInterceptor;
import okhttp3.internal.platform.Platform;

// Referenced classes of package okhttp3:
//            RealCall, Callback, OkHttpClient, Dispatcher, 
//            Request, HttpUrl

final class responseCallback extends NamedRunnable
{

    private final Callback responseCallback;
    final RealCall this$0;

    protected void execute()
    {
        boolean flag = true;
        Response response;
        boolean flag1;
        response = getResponseWithInterceptorChain();
        flag1 = retryAndFollowUpInterceptor.isCanceled();
        if (flag1) goto _L2; else goto _L1
_L1:
        responseCallback.onResponse(RealCall.this, response);
_L4:
        client.dispatcher().finished(this);
        return;
_L2:
        responseCallback.onFailure(RealCall.this, new IOException("Canceled"));
        if (true) goto _L4; else goto _L3
_L3:
        Object obj;
        obj;
_L10:
        if (flag) goto _L6; else goto _L5
_L5:
        responseCallback.onFailure(RealCall.this, ((IOException) (obj)));
_L8:
        client.dispatcher().finished(this);
        return;
_L6:
        Platform.get().log(4, (new StringBuilder()).append("Callback failure for ").append(toLoggableString()).toString(), ((Throwable) (obj)));
        if (true) goto _L8; else goto _L7
_L7:
        obj;
        client.dispatcher().finished(this);
        throw obj;
        obj;
        flag = false;
        if (true) goto _L10; else goto _L9
_L9:
    }

    RealCall get()
    {
        return RealCall.this;
    }

    String host()
    {
        return originalRequest.url().host();
    }

    Request request()
    {
        return originalRequest;
    }

    latform(Callback callback)
    {
        this$0 = RealCall.this;
        super("OkHttp %s", new Object[] {
            redactedUrl()
        });
        responseCallback = callback;
    }
}
