// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;

// Referenced classes of package okhttp3:
//            Call, Response

public interface Callback
{

    public abstract void onFailure(Call call, IOException ioexception);

    public abstract void onResponse(Call call, Response response)
        throws IOException;
}
