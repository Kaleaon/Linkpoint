// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSource;

// Referenced classes of package okhttp3:
//            MediaType

public abstract class ResponseBody
    implements Closeable
{
    static final class BomAwareReader extends Reader
    {

        private final Charset charset;
        private boolean closed;
        private Reader _flddelegate;
        private final BufferedSource source;

        public void close()
            throws IOException
        {
            closed = true;
            if (_flddelegate == null)
            {
                source.close();
                return;
            } else
            {
                _flddelegate.close();
                return;
            }
        }

        public int read(char ac[], int i, int j)
            throws IOException
        {
            if (!closed)
            {
                Object obj = _flddelegate;
                if (obj == null)
                {
                    obj = Util.bomAwareCharset(source, charset);
                    obj = new InputStreamReader(source.inputStream(), ((Charset) (obj)));
                    _flddelegate = ((Reader) (obj));
                }
                return ((Reader) (obj)).read(ac, i, j);
            } else
            {
                throw new IOException("Stream closed");
            }
        }

        BomAwareReader(BufferedSource bufferedsource, Charset charset1)
        {
            source = bufferedsource;
            charset = charset1;
        }
    }


    private Reader reader;

    public ResponseBody()
    {
    }

    private Charset charset()
    {
        MediaType mediatype = contentType();
        if (mediatype == null)
        {
            return Util.UTF_8;
        } else
        {
            return mediatype.charset(Util.UTF_8);
        }
    }

    public static ResponseBody create(MediaType mediatype, long l, BufferedSource bufferedsource)
    {
        if (bufferedsource != null)
        {
            return new ResponseBody(mediatype, l, bufferedsource) {

                final BufferedSource val$content;
                final long val$contentLength;
                final MediaType val$contentType;

                public long contentLength()
                {
                    return contentLength;
                }

                public MediaType contentType()
                {
                    return contentType;
                }

                public BufferedSource source()
                {
                    return content;
                }

            
            {
                contentType = mediatype;
                contentLength = l;
                content = bufferedsource;
                super();
            }
            };
        } else
        {
            throw new NullPointerException("source == null");
        }
    }

    public static ResponseBody create(MediaType mediatype, String s)
    {
        Charset charset1 = Util.UTF_8;
        if (mediatype != null) goto _L2; else goto _L1
_L1:
        MediaType mediatype1 = mediatype;
_L4:
        mediatype = (new Buffer()).writeString(s, charset1);
        return create(mediatype1, mediatype.size(), ((BufferedSource) (mediatype)));
_L2:
        Charset charset2 = mediatype.charset();
        charset1 = charset2;
        mediatype1 = mediatype;
        if (charset2 == null)
        {
            charset1 = Util.UTF_8;
            mediatype1 = MediaType.parse((new StringBuilder()).append(mediatype).append("; charset=utf-8").toString());
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static ResponseBody create(MediaType mediatype, byte abyte0[])
    {
        Buffer buffer = (new Buffer()).write(abyte0);
        return create(mediatype, abyte0.length, ((BufferedSource) (buffer)));
    }

    public final InputStream byteStream()
    {
        return source().inputStream();
    }

    public final byte[] bytes()
        throws IOException
    {
        BufferedSource bufferedsource;
        long l;
        l = contentLength();
        boolean flag;
        if (l <= 0x7fffffffL)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IOException((new StringBuilder()).append("Cannot buffer entire body for content length: ").append(l).toString());
        }
        bufferedsource = source();
        Object obj = bufferedsource.readByteArray();
        Util.closeQuietly(bufferedsource);
        if (l != -1L && l != (long)obj.length)
        {
            throw new IOException((new StringBuilder()).append("Content-Length (").append(l).append(") and stream length (").append(obj.length).append(") disagree").toString());
        } else
        {
            return ((byte []) (obj));
        }
        obj;
        Util.closeQuietly(bufferedsource);
        throw obj;
    }

    public final Reader charStream()
    {
        Reader reader1 = reader;
        Object obj = reader1;
        if (reader1 == null)
        {
            obj = new BomAwareReader(source(), charset());
            reader = ((Reader) (obj));
        }
        return ((Reader) (obj));
    }

    public void close()
    {
        Util.closeQuietly(source());
    }

    public abstract long contentLength();

    public abstract MediaType contentType();

    public abstract BufferedSource source();

    public final String string()
        throws IOException
    {
        BufferedSource bufferedsource = source();
        String s = bufferedsource.readString(Util.bomAwareCharset(bufferedsource, charset()));
        Util.closeQuietly(bufferedsource);
        return s;
        Exception exception;
        exception;
        Util.closeQuietly(bufferedsource);
        throw exception;
    }
}
