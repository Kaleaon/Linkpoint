// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            HttpUrl

static final class  extends Enum
{

    private static final INVALID_HOST $VALUES[];
    public static final INVALID_HOST INVALID_HOST;
    public static final INVALID_HOST INVALID_PORT;
    public static final INVALID_HOST MISSING_SCHEME;
    public static final INVALID_HOST SUCCESS;
    public static final INVALID_HOST UNSUPPORTED_SCHEME;

    public static  valueOf(String s)
    {
        return ()Enum.valueOf(okhttp3/HttpUrl$Builder$ParseResult, s);
    }

    public static [] values()
    {
        return ([])$VALUES.clone();
    }

    static 
    {
        SUCCESS = new <init>("SUCCESS", 0);
        MISSING_SCHEME = new <init>("MISSING_SCHEME", 1);
        UNSUPPORTED_SCHEME = new <init>("UNSUPPORTED_SCHEME", 2);
        INVALID_PORT = new <init>("INVALID_PORT", 3);
        INVALID_HOST = new <init>("INVALID_HOST", 4);
        $VALUES = (new .VALUES[] {
            SUCCESS, MISSING_SCHEME, UNSUPPORTED_SCHEME, INVALID_PORT, INVALID_HOST
        });
    }

    private (String s, int i)
    {
        super(s, i);
    }
}
