// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.net.ssl.SSLSocket;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            CipherSuite, TlsVersion

public final class ConnectionSpec
{
    public static final class Builder
    {

        String cipherSuites[];
        boolean supportsTlsExtensions;
        boolean tls;
        String tlsVersions[];

        public Builder allEnabledCipherSuites()
        {
            if (tls)
            {
                cipherSuites = null;
                return this;
            } else
            {
                throw new IllegalStateException("no cipher suites for cleartext connections");
            }
        }

        public Builder allEnabledTlsVersions()
        {
            if (tls)
            {
                tlsVersions = null;
                return this;
            } else
            {
                throw new IllegalStateException("no TLS versions for cleartext connections");
            }
        }

        public ConnectionSpec build()
        {
            return new ConnectionSpec(this);
        }

        public transient Builder cipherSuites(String as[])
        {
            if (tls)
            {
                if (as.length != 0)
                {
                    cipherSuites = (String[])as.clone();
                    return this;
                } else
                {
                    throw new IllegalArgumentException("At least one cipher suite is required");
                }
            } else
            {
                throw new IllegalStateException("no cipher suites for cleartext connections");
            }
        }

        public transient Builder cipherSuites(CipherSuite aciphersuite[])
        {
            int i = 0;
            if (!tls) goto _L2; else goto _L1
_L1:
            String as[] = new String[aciphersuite.length];
_L4:
            if (i >= aciphersuite.length)
            {
                return cipherSuites(as);
            }
            as[i] = aciphersuite[i].javaName;
            i++;
            continue; /* Loop/switch isn't completed */
_L2:
            throw new IllegalStateException("no cipher suites for cleartext connections");
            if (true) goto _L4; else goto _L3
_L3:
        }

        public Builder supportsTlsExtensions(boolean flag)
        {
            if (tls)
            {
                supportsTlsExtensions = flag;
                return this;
            } else
            {
                throw new IllegalStateException("no TLS extensions for cleartext connections");
            }
        }

        public transient Builder tlsVersions(String as[])
        {
            if (tls)
            {
                if (as.length != 0)
                {
                    tlsVersions = (String[])as.clone();
                    return this;
                } else
                {
                    throw new IllegalArgumentException("At least one TLS version is required");
                }
            } else
            {
                throw new IllegalStateException("no TLS versions for cleartext connections");
            }
        }

        public transient Builder tlsVersions(TlsVersion atlsversion[])
        {
            int i = 0;
            if (!tls) goto _L2; else goto _L1
_L1:
            String as[] = new String[atlsversion.length];
_L4:
            if (i >= atlsversion.length)
            {
                return tlsVersions(as);
            }
            as[i] = atlsversion[i].javaName;
            i++;
            continue; /* Loop/switch isn't completed */
_L2:
            throw new IllegalStateException("no TLS versions for cleartext connections");
            if (true) goto _L4; else goto _L3
_L3:
        }

        public Builder(ConnectionSpec connectionspec)
        {
            tls = connectionspec.tls;
            cipherSuites = connectionspec.cipherSuites;
            tlsVersions = connectionspec.tlsVersions;
            supportsTlsExtensions = connectionspec.supportsTlsExtensions;
        }

        Builder(boolean flag)
        {
            tls = flag;
        }
    }


    private static final CipherSuite APPROVED_CIPHER_SUITES[];
    public static final ConnectionSpec CLEARTEXT = (new Builder(false)).build();
    public static final ConnectionSpec COMPATIBLE_TLS;
    public static final ConnectionSpec MODERN_TLS;
    final String cipherSuites[];
    final boolean supportsTlsExtensions;
    final boolean tls;
    final String tlsVersions[];

    ConnectionSpec(Builder builder)
    {
        tls = builder.tls;
        cipherSuites = builder.cipherSuites;
        tlsVersions = builder.tlsVersions;
        supportsTlsExtensions = builder.supportsTlsExtensions;
    }

    private static boolean nonEmptyIntersection(String as[], String as1[])
    {
        while (as == null || as1 == null || as.length == 0 || as1.length == 0) 
        {
            return false;
        }
        int j = as.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return false;
            }
            if (Util.indexOf(as1, as[i]) == -1)
            {
                i++;
            } else
            {
                return true;
            }
        } while (true);
    }

    private ConnectionSpec supportedSpec(SSLSocket sslsocket, boolean flag)
    {
        String as[];
        String as2[];
        String as1[];
        if (cipherSuites == null)
        {
            as = sslsocket.getEnabledCipherSuites();
        } else
        {
            as = (String[])Util.intersect(java/lang/String, cipherSuites, sslsocket.getEnabledCipherSuites());
        }
        if (tlsVersions == null)
        {
            as1 = sslsocket.getEnabledProtocols();
        } else
        {
            as1 = (String[])Util.intersect(java/lang/String, tlsVersions, sslsocket.getEnabledProtocols());
        }
        if (flag) goto _L2; else goto _L1
_L1:
        as2 = as;
_L4:
        return (new Builder(this)).cipherSuites(as2).tlsVersions(as1).build();
_L2:
        as2 = as;
        if (Util.indexOf(sslsocket.getSupportedCipherSuites(), "TLS_FALLBACK_SCSV") != -1)
        {
            as2 = Util.concat(as, "TLS_FALLBACK_SCSV");
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    void apply(SSLSocket sslsocket, boolean flag)
    {
        ConnectionSpec connectionspec = supportedSpec(sslsocket, flag);
        if (connectionspec.tlsVersions != null)
        {
            sslsocket.setEnabledProtocols(connectionspec.tlsVersions);
        }
        if (connectionspec.cipherSuites == null)
        {
            return;
        } else
        {
            sslsocket.setEnabledCipherSuites(connectionspec.cipherSuites);
            return;
        }
    }

    public List cipherSuites()
    {
        ArrayList arraylist;
        String as[];
        int i;
        int j;
        if (cipherSuites != null)
        {
            arraylist = new ArrayList(cipherSuites.length);
            as = cipherSuites;
            j = as.length;
            i = 0;
            break MISSING_BLOCK_LABEL_31;
        } else
        {
            return null;
        }
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableList(arraylist);
            }
            arraylist.add(CipherSuite.forJavaName(as[i]));
            i++;
        } while (true);
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof ConnectionSpec)
        {
            if (obj != this)
            {
                obj = (ConnectionSpec)obj;
                if (tls == ((ConnectionSpec) (obj)).tls)
                {
                    if (tls)
                    {
                        if (Arrays.equals(cipherSuites, ((ConnectionSpec) (obj)).cipherSuites))
                        {
                            if (Arrays.equals(tlsVersions, ((ConnectionSpec) (obj)).tlsVersions))
                            {
                                if (supportsTlsExtensions != ((ConnectionSpec) (obj)).supportsTlsExtensions)
                                {
                                    return false;
                                }
                            } else
                            {
                                return false;
                            }
                        } else
                        {
                            return false;
                        }
                    }
                    return true;
                } else
                {
                    return false;
                }
            } else
            {
                return true;
            }
        } else
        {
            return false;
        }
    }

    public int hashCode()
    {
        int i = 0;
        if (!tls)
        {
            return 17;
        }
        int j = Arrays.hashCode(cipherSuites);
        int k = Arrays.hashCode(tlsVersions);
        if (!supportsTlsExtensions)
        {
            i = 1;
        }
        return i + ((j + 527) * 31 + k) * 31;
    }

    public boolean isCompatible(SSLSocket sslsocket)
    {
        if (tls)
        {
            if (tlsVersions == null || nonEmptyIntersection(tlsVersions, sslsocket.getEnabledProtocols()))
            {
                return cipherSuites == null || nonEmptyIntersection(cipherSuites, sslsocket.getEnabledCipherSuites());
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
    }

    public boolean isTls()
    {
        return tls;
    }

    public boolean supportsTlsExtensions()
    {
        return supportsTlsExtensions;
    }

    public List tlsVersions()
    {
        ArrayList arraylist;
        String as[];
        int i;
        int j;
        if (tlsVersions != null)
        {
            arraylist = new ArrayList(tlsVersions.length);
            as = tlsVersions;
            j = as.length;
            i = 0;
            break MISSING_BLOCK_LABEL_31;
        } else
        {
            return null;
        }
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableList(arraylist);
            }
            arraylist.add(TlsVersion.forJavaName(as[i]));
            i++;
        } while (true);
    }

    public String toString()
    {
        if (tls)
        {
            String s;
            String s1;
            if (cipherSuites == null)
            {
                s = "[all enabled]";
            } else
            {
                s = cipherSuites().toString();
            }
            if (tlsVersions == null)
            {
                s1 = "[all enabled]";
            } else
            {
                s1 = tlsVersions().toString();
            }
            return (new StringBuilder()).append("ConnectionSpec(cipherSuites=").append(s).append(", tlsVersions=").append(s1).append(", supportsTlsExtensions=").append(supportsTlsExtensions).append(")").toString();
        } else
        {
            return "ConnectionSpec()";
        }
    }

    static 
    {
        APPROVED_CIPHER_SUITES = (new CipherSuite[] {
            CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA, 
            CipherSuite.TLS_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_RSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_RSA_WITH_3DES_EDE_CBC_SHA
        });
        MODERN_TLS = (new Builder(true)).cipherSuites(APPROVED_CIPHER_SUITES).tlsVersions(new TlsVersion[] {
            TlsVersion.TLS_1_3, TlsVersion.TLS_1_2, TlsVersion.TLS_1_1, TlsVersion.TLS_1_0
        }).supportsTlsExtensions(true).build();
        COMPATIBLE_TLS = (new Builder(MODERN_TLS)).tlsVersions(new TlsVersion[] {
            TlsVersion.TLS_1_0
        }).supportsTlsExtensions(true).build();
    }
}
