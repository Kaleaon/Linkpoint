// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpDate;

// Referenced classes of package okhttp3:
//            HttpUrl, Headers

public final class Cookie
{
    public static final class Builder
    {

        String domain;
        long expiresAt;
        boolean hostOnly;
        boolean httpOnly;
        String name;
        String path;
        boolean persistent;
        boolean secure;
        String value;

        private Builder domain(String s, boolean flag)
        {
            if (s != null)
            {
                String s1 = Util.domainToAscii(s);
                if (s1 != null)
                {
                    domain = s1;
                    hostOnly = flag;
                    return this;
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("unexpected domain: ").append(s).toString());
                }
            } else
            {
                throw new NullPointerException("domain == null");
            }
        }

        public Cookie build()
        {
            return new Cookie(this);
        }

        public Builder domain(String s)
        {
            return domain(s, false);
        }

        public Builder expiresAt(long l)
        {
            long l1 = 0xe677d21fdbffL;
            boolean flag1 = false;
            boolean flag;
            if (l > 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                l = 0x8000000000000000L;
            }
            flag = flag1;
            if (l <= 0xe677d21fdbffL)
            {
                flag = true;
            }
            if (!flag)
            {
                l = l1;
            }
            expiresAt = l;
            persistent = true;
            return this;
        }

        public Builder hostOnlyDomain(String s)
        {
            return domain(s, true);
        }

        public Builder httpOnly()
        {
            httpOnly = true;
            return this;
        }

        public Builder name(String s)
        {
            if (s != null)
            {
                if (s.trim().equals(s))
                {
                    name = s;
                    return this;
                } else
                {
                    throw new IllegalArgumentException("name is not trimmed");
                }
            } else
            {
                throw new NullPointerException("name == null");
            }
        }

        public Builder path(String s)
        {
            if (s.startsWith("/"))
            {
                path = s;
                return this;
            } else
            {
                throw new IllegalArgumentException("path must start with '/'");
            }
        }

        public Builder secure()
        {
            secure = true;
            return this;
        }

        public Builder value(String s)
        {
            if (s != null)
            {
                if (s.trim().equals(s))
                {
                    value = s;
                    return this;
                } else
                {
                    throw new IllegalArgumentException("value is not trimmed");
                }
            } else
            {
                throw new NullPointerException("value == null");
            }
        }

        public Builder()
        {
            expiresAt = 0xe677d21fdbffL;
            path = "/";
        }
    }


    private static final Pattern DAY_OF_MONTH_PATTERN = Pattern.compile("(\\d{1,2})[^\\d]*");
    private static final Pattern MONTH_PATTERN = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");
    private static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");
    private static final Pattern YEAR_PATTERN = Pattern.compile("(\\d{2,4})[^\\d]*");
    private final String domain;
    private final long expiresAt;
    private final boolean hostOnly;
    private final boolean httpOnly;
    private final String name;
    private final String path;
    private final boolean persistent;
    private final boolean secure;
    private final String value;

    private Cookie(String s, String s1, long l, String s2, String s3, boolean flag, 
            boolean flag1, boolean flag2, boolean flag3)
    {
        name = s;
        value = s1;
        expiresAt = l;
        domain = s2;
        path = s3;
        secure = flag;
        httpOnly = flag1;
        hostOnly = flag2;
        persistent = flag3;
    }

    Cookie(Builder builder)
    {
        if (builder.name != null)
        {
            if (builder.value != null)
            {
                if (builder.domain != null)
                {
                    name = builder.name;
                    value = builder.value;
                    expiresAt = builder.expiresAt;
                    domain = builder.domain;
                    path = builder.path;
                    secure = builder.secure;
                    httpOnly = builder.httpOnly;
                    persistent = builder.persistent;
                    hostOnly = builder.hostOnly;
                    return;
                } else
                {
                    throw new NullPointerException("builder.domain == null");
                }
            } else
            {
                throw new NullPointerException("builder.value == null");
            }
        } else
        {
            throw new NullPointerException("builder.name == null");
        }
    }

    private static int dateCharacterOffset(String s, int i, int j, boolean flag)
    {
        do
        {
            if (i >= j)
            {
                return j;
            }
            char c = s.charAt(i);
            while (false) 
            {
                int k;
                if (c < ' ' && c != '\t' || (c >= '\177' || c >= '0' && c <= '9') || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == ':')
                {
                    c = '\001';
                } else
                {
                    c = '\0';
                }
                if (flag)
                {
                    k = 0;
                } else
                {
                    k = 1;
                }
                if (c != k)
                {
                    i++;
                } else
                {
                    return i;
                }
            }
        } while (true);
    }

    private static boolean domainMatch(HttpUrl httpurl, String s)
    {
        httpurl = httpurl.host();
        if (!httpurl.equals(s))
        {
            return httpurl.endsWith(s) && httpurl.charAt(httpurl.length() - s.length() - 1) == '.' && !Util.verifyAsIpAddress(httpurl);
        } else
        {
            return true;
        }
    }

    static Cookie parse(long l, HttpUrl httpurl, String s)
    {
        int i;
        int j;
        int k;
        j = s.length();
        i = Util.delimiterOffset(s, 0, j, ';');
        k = Util.delimiterOffset(s, 0, i, '=');
        if (k == i) goto _L2; else goto _L1
_L1:
        String s1 = Util.trimSubstring(s, 0, k);
        if (s1.isEmpty()) goto _L4; else goto _L3
_L3:
        Object obj;
        Object obj1;
        String s2;
        long l1;
        long l2;
        boolean flag;
        boolean flag1;
        boolean flag2;
        boolean flag3;
        s2 = Util.trimSubstring(s, k + 1, i);
        l1 = 0xe677d21fdbffL;
        l2 = -1L;
        obj = null;
        obj1 = null;
        flag3 = false;
        flag2 = false;
        flag1 = true;
        flag = false;
        i++;
_L19:
        if (i < j) goto _L6; else goto _L5
_L5:
        if (l2 != 0x8000000000000000L) goto _L8; else goto _L7
_L7:
        l = 0x8000000000000000L;
_L23:
        if (obj == null) goto _L10; else goto _L9
_L9:
        if (!domainMatch(httpurl, ((String) (obj)))) goto _L12; else goto _L11
_L11:
        if (obj1 == null || !((String) (obj1)).startsWith("/"))
        {
            httpurl = httpurl.encodedPath();
            i = httpurl.lastIndexOf('/');
            Object obj2;
            String s3;
            int i1;
            int j1;
            long l3;
            if (i == 0)
            {
                httpurl = "/";
            } else
            {
                httpurl = httpurl.substring(0, i);
            }
        } else
        {
            httpurl = ((HttpUrl) (obj1));
        }
        return new Cookie(s1, s2, l, ((String) (obj)), httpurl, flag3, flag2, flag1, flag);
_L2:
        return null;
_L4:
        return null;
_L6:
        i1 = Util.delimiterOffset(s, i, j, ';');
        j1 = Util.delimiterOffset(s, i, i1, '=');
        s3 = Util.trimSubstring(s, i, j1);
        if (j1 >= i1)
        {
            obj2 = "";
        } else
        {
            obj2 = Util.trimSubstring(s, j1 + 1, i1);
        }
        if (s3.equalsIgnoreCase("expires")) goto _L14; else goto _L13
_L13:
        if (s3.equalsIgnoreCase("max-age")) goto _L16; else goto _L15
_L15:
        if (s3.equalsIgnoreCase("domain")) goto _L18; else goto _L17
_L17:
        if (!s3.equalsIgnoreCase("path"))
        {
            if (!s3.equalsIgnoreCase("secure"))
            {
                if (!s3.equalsIgnoreCase("httponly"))
                {
                    obj2 = obj1;
                    obj1 = obj;
                    obj = obj2;
                } else
                {
                    flag2 = true;
                    obj2 = obj;
                    obj = obj1;
                    obj1 = obj2;
                }
            } else
            {
                flag3 = true;
                obj2 = obj;
                obj = obj1;
                obj1 = obj2;
            }
        } else
        {
            obj1 = obj;
            obj = obj2;
        }
        i = i1 + 1;
        obj2 = obj1;
        obj1 = obj;
        obj = obj2;
          goto _L19
_L14:
        l3 = parseExpires(((String) (obj2)), 0, ((String) (obj2)).length());
        l1 = l3;
        flag = true;
_L24:
        obj2 = obj;
        obj = obj1;
        obj1 = obj2;
        break MISSING_BLOCK_LABEL_303;
_L16:
        l3 = parseMaxAge(((String) (obj2)));
        l2 = l3;
        flag = true;
_L20:
        obj2 = obj;
        obj = obj1;
        obj1 = obj2;
        break MISSING_BLOCK_LABEL_303;
        obj2;
        if (true) goto _L20; else goto _L18
_L18:
        try
        {
            obj2 = parseDomain(((String) (obj2)));
        }
        // Misplaced declaration of an exception variable
        catch (Object obj2)
        {
            obj2 = obj;
            obj = obj1;
            obj1 = obj2;
            break MISSING_BLOCK_LABEL_303;
        }
        flag1 = false;
        obj = obj1;
        obj1 = obj2;
        break MISSING_BLOCK_LABEL_303;
_L8:
        if (l2 == -1L)
        {
            break MISSING_BLOCK_LABEL_575;
        }
        if (l2 > 0x20c49ba5e353f7L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            l1 = l2 * 1000L;
        } else
        {
            l1 = 0x7fffffffffffffffL;
        }
        l1 += l;
        if (l1 < l)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L22; else goto _L21
_L21:
        if (l1 <= 0xe677d21fdbffL)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        l = l1;
        if (i != 0) goto _L23; else goto _L22
_L22:
        l = 0xe677d21fdbffL;
          goto _L23
        l = l1;
          goto _L23
_L10:
        obj = httpurl.host();
        break MISSING_BLOCK_LABEL_132;
_L12:
        return null;
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
          goto _L24
    }

    public static Cookie parse(HttpUrl httpurl, String s)
    {
        return parse(System.currentTimeMillis(), httpurl, s);
    }

    public static List parseAll(HttpUrl httpurl, Headers headers)
    {
        Object obj = null;
        List list = headers.values("Set-Cookie");
        int j = list.size();
        int i = 0;
        headers = obj;
        do
        {
            Cookie cookie;
            if (i >= j)
            {
                if (headers == null)
                {
                    return Collections.emptyList();
                } else
                {
                    return Collections.unmodifiableList(headers);
                }
            }
            cookie = parse(httpurl, (String)list.get(i));
            if (cookie != null)
            {
                if (headers == null)
                {
                    headers = new ArrayList();
                }
                headers.add(cookie);
            }
            i++;
        } while (true);
    }

    private static String parseDomain(String s)
    {
        if (!s.endsWith("."))
        {
            if (s.startsWith("."))
            {
                s = s.substring(1);
            }
            s = Util.domainToAscii(s);
            if (s != null)
            {
                return s;
            } else
            {
                throw new IllegalArgumentException();
            }
        } else
        {
            throw new IllegalArgumentException();
        }
    }

    private static long parseExpires(String s, int i, int j)
    {
        Matcher matcher;
        byte byte0;
        byte byte1;
        byte byte2;
        byte byte3;
        byte byte4;
        int k;
        k = dateCharacterOffset(s, i, j, false);
        byte0 = -1;
        byte2 = -1;
        byte4 = -1;
        byte1 = -1;
        byte3 = -1;
        i = -1;
        matcher = TIME_PATTERN.matcher(s);
_L2:
        if (k >= j)
        {
            String s1;
            int l;
            int i1;
            int j1;
            int k1;
            int l1;
            if (i < 70)
            {
                j = i;
            } else
            {
                j = i;
                if (i <= 99)
                {
                    j = i + 1900;
                }
            }
            if (j < 0)
            {
                i = j;
            } else
            {
                i = j;
                if (j <= 69)
                {
                    i = j + 2000;
                }
            }
            if (i >= 1601)
            {
                if (byte3 != -1)
                {
                    if (byte1 < 1 || byte1 > 31)
                    {
                        throw new IllegalArgumentException();
                    }
                } else
                {
                    throw new IllegalArgumentException();
                }
            } else
            {
                throw new IllegalArgumentException();
            }
            break MISSING_BLOCK_LABEL_462;
        }
        l1 = dateCharacterOffset(s, k + 1, j, true);
        matcher.region(k, l1);
        break MISSING_BLOCK_LABEL_102;
        if (byte0 != -1 || !matcher.usePattern(TIME_PATTERN).matches())
        {
            if (byte1 != -1 || !matcher.usePattern(DAY_OF_MONTH_PATTERN).matches())
            {
                if (byte3 != -1 || !matcher.usePattern(MONTH_PATTERN).matches())
                {
                    if (i != -1)
                    {
                        k1 = byte0;
                        j1 = byte2;
                        i1 = byte4;
                        l = byte1;
                        k = byte3;
                    } else
                    {
                        k = byte3;
                        l = byte1;
                        i1 = byte4;
                        j1 = byte2;
                        k1 = byte0;
                        if (matcher.usePattern(YEAR_PATTERN).matches())
                        {
                            i = Integer.parseInt(matcher.group(1));
                            k = byte3;
                            l = byte1;
                            i1 = byte4;
                            j1 = byte2;
                            k1 = byte0;
                        }
                    }
                } else
                {
                    s1 = matcher.group(1).toLowerCase(Locale.US);
                    k = MONTH_PATTERN.pattern().indexOf(s1) / 4;
                    l = byte1;
                    i1 = byte4;
                    j1 = byte2;
                    k1 = byte0;
                }
            } else
            {
                l = Integer.parseInt(matcher.group(1));
                k = byte3;
                i1 = byte4;
                j1 = byte2;
                k1 = byte0;
            }
        } else
        {
            k1 = Integer.parseInt(matcher.group(1));
            j1 = Integer.parseInt(matcher.group(2));
            i1 = Integer.parseInt(matcher.group(3));
            k = byte3;
            l = byte1;
        }
        l1 = dateCharacterOffset(s, l1 + 1, j, false);
        byte3 = k;
        byte1 = l;
        byte4 = i1;
        byte2 = j1;
        byte0 = k1;
        k = l1;
        continue; /* Loop/switch isn't completed */
        while (byte0 < 0 || byte0 > 23) 
        {
            throw new IllegalArgumentException();
        }
        while (byte2 < 0 || byte2 > 59) 
        {
            throw new IllegalArgumentException();
        }
        while (byte4 < 0 || byte4 > 59) 
        {
            throw new IllegalArgumentException();
        }
        s = new GregorianCalendar(Util.UTC);
        s.setLenient(false);
        s.set(1, i);
        s.set(2, byte3 - 1);
        s.set(5, byte1);
        s.set(11, byte0);
        s.set(12, byte2);
        s.set(13, byte4);
        s.set(14, 0);
        return s.getTimeInMillis();
        if (true) goto _L2; else goto _L1
_L1:
    }

    private static long parseMaxAge(String s)
    {
        long l = 0x8000000000000000L;
        boolean flag = false;
        long l1;
        try
        {
            l1 = Long.parseLong(s);
        }
        catch (NumberFormatException numberformatexception)
        {
            if (!s.matches("-?\\d+"))
            {
                throw numberformatexception;
            }
            if (!s.startsWith("-"))
            {
                l = 0x7fffffffffffffffL;
            }
            return l;
        }
        if (l1 > 0L)
        {
            flag = true;
        }
        if (!flag)
        {
            return 0x8000000000000000L;
        } else
        {
            return l1;
        }
    }

    private static boolean pathMatch(HttpUrl httpurl, String s)
    {
        httpurl = httpurl.encodedPath();
        if (!httpurl.equals(s))
        {
            if (httpurl.startsWith(s))
            {
                if (!s.endsWith("/"))
                {
                    if (httpurl.charAt(s.length()) == '/')
                    {
                        return true;
                    }
                } else
                {
                    return true;
                }
            }
            return false;
        } else
        {
            return true;
        }
    }

    public String domain()
    {
        return domain;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof Cookie)
        {
            obj = (Cookie)obj;
            break MISSING_BLOCK_LABEL_12;
        } else
        {
            return false;
        }
        return ((Cookie) (obj)).name.equals(name) && ((Cookie) (obj)).value.equals(value) && ((Cookie) (obj)).domain.equals(domain) && ((Cookie) (obj)).path.equals(path) && ((Cookie) (obj)).expiresAt == expiresAt && ((Cookie) (obj)).secure == secure && ((Cookie) (obj)).httpOnly == httpOnly && ((Cookie) (obj)).persistent == persistent && ((Cookie) (obj)).hostOnly == hostOnly;
    }

    public long expiresAt()
    {
        return expiresAt;
    }

    public int hashCode()
    {
        int l = 1;
        int i1 = name.hashCode();
        int j1 = value.hashCode();
        int k1 = domain.hashCode();
        int l1 = path.hashCode();
        int i2 = (int)(expiresAt ^ expiresAt >>> 32);
        int i;
        int j;
        int k;
        if (!secure)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (!httpOnly)
        {
            j = 1;
        } else
        {
            j = 0;
        }
        if (!persistent)
        {
            k = 1;
        } else
        {
            k = 0;
        }
        if (hostOnly)
        {
            l = 0;
        }
        return (k + (j + (i + (((((i1 + 527) * 31 + j1) * 31 + k1) * 31 + l1) * 31 + i2) * 31) * 31) * 31) * 31 + l;
    }

    public boolean hostOnly()
    {
        return hostOnly;
    }

    public boolean httpOnly()
    {
        return httpOnly;
    }

    public boolean matches(HttpUrl httpurl)
    {
        boolean flag;
        if (!hostOnly)
        {
            flag = domainMatch(httpurl, domain);
        } else
        {
            flag = httpurl.host().equals(domain);
        }
        if (flag)
        {
            if (pathMatch(httpurl, path))
            {
                return !secure || httpurl.isHttps();
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
    }

    public String name()
    {
        return name;
    }

    public String path()
    {
        return path;
    }

    public boolean persistent()
    {
        return persistent;
    }

    public boolean secure()
    {
        return secure;
    }

    public String toString()
    {
        return toString(false);
    }

    String toString(boolean flag)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(name);
        stringbuilder.append('=');
        stringbuilder.append(value);
        if (persistent)
        {
            if (expiresAt == 0x8000000000000000L)
            {
                stringbuilder.append("; max-age=0");
            } else
            {
                stringbuilder.append("; expires=").append(HttpDate.format(new Date(expiresAt)));
            }
        }
        if (!hostOnly)
        {
            stringbuilder.append("; domain=");
            if (flag)
            {
                stringbuilder.append(".");
            }
            stringbuilder.append(domain);
        }
        stringbuilder.append("; path=").append(path);
        if (secure)
        {
            stringbuilder.append("; secure");
        }
        if (httpOnly)
        {
            stringbuilder.append("; httponly");
        }
        return stringbuilder.toString();
    }

    public String value()
    {
        return value;
    }

}
