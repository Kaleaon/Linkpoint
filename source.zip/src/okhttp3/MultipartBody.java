// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;
import okio.ByteString;

// Referenced classes of package okhttp3:
//            RequestBody, MediaType, Headers

public final class MultipartBody extends RequestBody
{
    public static final class Builder
    {

        private final ByteString boundary;
        private final List parts;
        private MediaType type;

        public Builder addFormDataPart(String s, String s1)
        {
            return addPart(Part.createFormData(s, s1));
        }

        public Builder addFormDataPart(String s, String s1, RequestBody requestbody)
        {
            return addPart(Part.createFormData(s, s1, requestbody));
        }

        public Builder addPart(Headers headers, RequestBody requestbody)
        {
            return addPart(Part.create(headers, requestbody));
        }

        public Builder addPart(Part part1)
        {
            if (part1 != null)
            {
                parts.add(part1);
                return this;
            } else
            {
                throw new NullPointerException("part == null");
            }
        }

        public Builder addPart(RequestBody requestbody)
        {
            return addPart(Part.create(requestbody));
        }

        public MultipartBody build()
        {
            if (!parts.isEmpty())
            {
                return new MultipartBody(boundary, type, parts);
            } else
            {
                throw new IllegalStateException("Multipart body must have at least one part.");
            }
        }

        public Builder setType(MediaType mediatype)
        {
            if (mediatype != null)
            {
                if (mediatype.type().equals("multipart"))
                {
                    type = mediatype;
                    return this;
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("multipart != ").append(mediatype).toString());
                }
            } else
            {
                throw new NullPointerException("type == null");
            }
        }

        public Builder()
        {
            this(UUID.randomUUID().toString());
        }

        public Builder(String s)
        {
            type = MultipartBody.MIXED;
            parts = new ArrayList();
            boundary = ByteString.encodeUtf8(s);
        }
    }

    public static final class Part
    {

        final RequestBody body;
        final Headers headers;

        public static Part create(Headers headers1, RequestBody requestbody)
        {
            if (requestbody != null)
            {
                if (headers1 == null || headers1.get("Content-Type") == null)
                {
                    if (headers1 == null || headers1.get("Content-Length") == null)
                    {
                        return new Part(headers1, requestbody);
                    } else
                    {
                        throw new IllegalArgumentException("Unexpected header: Content-Length");
                    }
                } else
                {
                    throw new IllegalArgumentException("Unexpected header: Content-Type");
                }
            } else
            {
                throw new NullPointerException("body == null");
            }
        }

        public static Part create(RequestBody requestbody)
        {
            return create(null, requestbody);
        }

        public static Part createFormData(String s, String s1)
        {
            return createFormData(s, null, RequestBody.create(null, s1));
        }

        public static Part createFormData(String s, String s1, RequestBody requestbody)
        {
            if (s != null)
            {
                StringBuilder stringbuilder = new StringBuilder("form-data; name=");
                MultipartBody.appendQuotedString(stringbuilder, s);
                if (s1 != null)
                {
                    stringbuilder.append("; filename=");
                    MultipartBody.appendQuotedString(stringbuilder, s1);
                }
                return create(Headers.of(new String[] {
                    "Content-Disposition", stringbuilder.toString()
                }), requestbody);
            } else
            {
                throw new NullPointerException("name == null");
            }
        }

        public RequestBody body()
        {
            return body;
        }

        public Headers headers()
        {
            return headers;
        }

        private Part(Headers headers1, RequestBody requestbody)
        {
            headers = headers1;
            body = requestbody;
        }
    }


    public static final MediaType ALTERNATIVE = MediaType.parse("multipart/alternative");
    private static final byte COLONSPACE[] = {
        58, 32
    };
    private static final byte CRLF[] = {
        13, 10
    };
    private static final byte DASHDASH[] = {
        45, 45
    };
    public static final MediaType DIGEST = MediaType.parse("multipart/digest");
    public static final MediaType FORM = MediaType.parse("multipart/form-data");
    public static final MediaType MIXED = MediaType.parse("multipart/mixed");
    public static final MediaType PARALLEL = MediaType.parse("multipart/parallel");
    private final ByteString boundary;
    private long contentLength;
    private final MediaType contentType;
    private final MediaType originalType;
    private final List parts;

    MultipartBody(ByteString bytestring, MediaType mediatype, List list)
    {
        contentLength = -1L;
        boundary = bytestring;
        originalType = mediatype;
        contentType = MediaType.parse((new StringBuilder()).append(mediatype).append("; boundary=").append(bytestring.utf8()).toString());
        parts = Util.immutableList(list);
    }

    static StringBuilder appendQuotedString(StringBuilder stringbuilder, String s)
    {
        int i;
        int j;
        stringbuilder.append('"');
        i = 0;
        j = s.length();
_L6:
        char c;
        if (i >= j)
        {
            stringbuilder.append('"');
            return stringbuilder;
        }
        c = s.charAt(i);
        c;
        JVM INSTR lookupswitch 3: default 72
    //                   10: 85
    //                   13: 95
    //                   34: 105;
           goto _L1 _L2 _L3 _L4
_L4:
        break MISSING_BLOCK_LABEL_105;
_L2:
        break; /* Loop/switch isn't completed */
_L1:
        stringbuilder.append(c);
_L7:
        i++;
        if (true) goto _L6; else goto _L5
_L5:
        stringbuilder.append("%0A");
          goto _L7
_L3:
        stringbuilder.append("%0D");
          goto _L7
        stringbuilder.append("%22");
          goto _L7
    }

    private long writeOrCountBytes(BufferedSink bufferedsink, boolean flag)
        throws IOException
    {
        long l1 = 0L;
        Object obj;
        int i;
        int k;
        if (!flag)
        {
            Object obj1 = null;
            obj = bufferedsink;
            bufferedsink = obj1;
        } else
        {
            obj = new Buffer();
            bufferedsink = ((BufferedSink) (obj));
        }
        k = parts.size();
        i = 0;
        do
        {
            if (i >= k)
            {
                ((BufferedSink) (obj)).write(DASHDASH);
                ((BufferedSink) (obj)).write(boundary);
                ((BufferedSink) (obj)).write(DASHDASH);
                ((BufferedSink) (obj)).write(CRLF);
                Object obj2;
                Object obj3;
                int j;
                int l;
                long l2;
                if (!flag)
                {
                    return l1;
                } else
                {
                    long l3 = bufferedsink.size();
                    bufferedsink.clear();
                    return l1 + l3;
                }
            }
            obj3 = (Part)parts.get(i);
            obj2 = ((Part) (obj3)).headers;
            obj3 = ((Part) (obj3)).body;
            ((BufferedSink) (obj)).write(DASHDASH);
            ((BufferedSink) (obj)).write(boundary);
            ((BufferedSink) (obj)).write(CRLF);
            if (obj2 != null)
            {
                j = 0;
                l = ((Headers) (obj2)).size();
                while (j < l) 
                {
                    ((BufferedSink) (obj)).writeUtf8(((Headers) (obj2)).name(j)).write(COLONSPACE).writeUtf8(((Headers) (obj2)).value(j)).write(CRLF);
                    j++;
                }
            }
            obj2 = ((RequestBody) (obj3)).contentType();
            if (obj2 != null)
            {
                ((BufferedSink) (obj)).writeUtf8("Content-Type: ").writeUtf8(((MediaType) (obj2)).toString()).write(CRLF);
            }
            l2 = ((RequestBody) (obj3)).contentLength();
            if (l2 != -1L)
            {
                ((BufferedSink) (obj)).writeUtf8("Content-Length: ").writeDecimalLong(l2).write(CRLF);
            } else
            if (flag)
            {
                bufferedsink.clear();
                return -1L;
            }
            ((BufferedSink) (obj)).write(CRLF);
            if (!flag)
            {
                ((RequestBody) (obj3)).writeTo(((BufferedSink) (obj)));
            } else
            {
                l1 += l2;
            }
            ((BufferedSink) (obj)).write(CRLF);
            i++;
        } while (true);
    }

    public String boundary()
    {
        return boundary.utf8();
    }

    public long contentLength()
        throws IOException
    {
        long l = contentLength;
        if (l != -1L)
        {
            return l;
        } else
        {
            long l1 = writeOrCountBytes(null, true);
            contentLength = l1;
            return l1;
        }
    }

    public MediaType contentType()
    {
        return contentType;
    }

    public Part part(int i)
    {
        return (Part)parts.get(i);
    }

    public List parts()
    {
        return parts;
    }

    public int size()
    {
        return parts.size();
    }

    public MediaType type()
    {
        return originalType;
    }

    public void writeTo(BufferedSink bufferedsink)
        throws IOException
    {
        writeOrCountBytes(bufferedsink, false);
    }

}
