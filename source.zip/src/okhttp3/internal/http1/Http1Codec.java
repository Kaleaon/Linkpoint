// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.Route;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.http.HttpCodec;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http.RealResponseBody;
import okhttp3.internal.http.RequestLine;
import okhttp3.internal.http.StatusLine;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ForwardingTimeout;
import okio.Okio;
import okio.Sink;
import okio.Source;
import okio.Timeout;

public final class Http1Codec
    implements HttpCodec
{
    private abstract class AbstractSource
        implements Source
    {

        protected boolean closed;
        final Http1Codec this$0;
        protected final ForwardingTimeout timeout;

        protected final void endOfInput(boolean flag)
            throws IOException
        {
            boolean flag1 = false;
            if (state != 6)
            {
                if (state == 5)
                {
                    detachTimeout(timeout);
                    state = 6;
                    if (streamAllocation == null)
                    {
                        return;
                    }
                } else
                {
                    throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
                }
            } else
            {
                return;
            }
            StreamAllocation streamallocation = streamAllocation;
            if (flag)
            {
                flag = flag1;
            } else
            {
                flag = true;
            }
            streamallocation.streamFinished(flag, Http1Codec.this);
        }

        public Timeout timeout()
        {
            return timeout;
        }

        private AbstractSource()
        {
            this$0 = Http1Codec.this;
            super();
            timeout = new ForwardingTimeout(source.timeout());
        }

    }

    private final class ChunkedSink
        implements Sink
    {

        private boolean closed;
        final Http1Codec this$0;
        private final ForwardingTimeout timeout;

        public void close()
            throws IOException
        {
            this;
            JVM INSTR monitorenter ;
            if (closed)
            {
                break MISSING_BLOCK_LABEL_51;
            }
            closed = true;
            sink.writeUtf8("0\r\n\r\n");
            detachTimeout(timeout);
            state = 3;
            return;
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public void flush()
            throws IOException
        {
            this;
            JVM INSTR monitorenter ;
            if (closed)
            {
                break MISSING_BLOCK_LABEL_24;
            }
            sink.flush();
            return;
            this;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            throw exception;
        }

        public Timeout timeout()
        {
            return timeout;
        }

        public void write(Buffer buffer, long l)
            throws IOException
        {
            if (!closed)
            {
                if (l == 0L)
                {
                    return;
                } else
                {
                    sink.writeHexadecimalUnsignedLong(l);
                    sink.writeUtf8("\r\n");
                    sink.write(buffer, l);
                    sink.writeUtf8("\r\n");
                    return;
                }
            } else
            {
                throw new IllegalStateException("closed");
            }
        }

        ChunkedSink()
        {
            this$0 = Http1Codec.this;
            super();
            timeout = new ForwardingTimeout(sink.timeout());
        }
    }

    private class ChunkedSource extends AbstractSource
    {

        private static final long NO_CHUNK_YET = -1L;
        private long bytesRemainingInChunk;
        private boolean hasMoreChunks;
        final Http1Codec this$0;
        private final HttpUrl url;

        private void readChunkSize()
            throws IOException
        {
            if (bytesRemainingInChunk != -1L)
            {
                source.readUtf8LineStrict();
            }
            String s;
            bytesRemainingInChunk = source.readHexadecimalUnsignedLong();
            s = source.readUtf8LineStrict().trim();
            boolean flag;
            boolean flag1;
            if (bytesRemainingInChunk < 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag) goto _L2; else goto _L1
_L1:
            try
            {
                flag1 = s.isEmpty();
            }
            catch (NumberFormatException numberformatexception)
            {
                throw new ProtocolException(numberformatexception.getMessage());
            }
            if (!flag1) goto _L4; else goto _L3
_L3:
            if (bytesRemainingInChunk == 0L)
            {
                hasMoreChunks = false;
                HttpHeaders.receiveHeaders(client.cookieJar(), url, readHeaders());
                endOfInput(true);
            }
            return;
_L4:
            if (s.startsWith(";")) goto _L3; else goto _L2
_L2:
            throw new ProtocolException((new StringBuilder()).append("expected chunk size and optional extensions but was \"").append(bytesRemainingInChunk).append(s).append("\"").toString());
        }

        public void close()
            throws IOException
        {
            if (!closed)
            {
                break MISSING_BLOCK_LABEL_7;
            } else
            {
                return;
            }
            if (hasMoreChunks && !Util.discard(this, 100, TimeUnit.MILLISECONDS))
            {
                endOfInput(false);
            }
            closed = true;
            return;
        }

        public long read(Buffer buffer, long l)
            throws IOException
        {
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
            if (!closed)
            {
                if (hasMoreChunks)
                {
                    if (bytesRemainingInChunk == 0L || bytesRemainingInChunk == -1L)
                    {
                        readChunkSize();
                        if (!hasMoreChunks)
                        {
                            break MISSING_BLOCK_LABEL_151;
                        }
                    }
                    l = source.read(buffer, Math.min(l, bytesRemainingInChunk));
                    if (l == -1L)
                    {
                        endOfInput(false);
                        throw new ProtocolException("unexpected end of stream");
                    } else
                    {
                        bytesRemainingInChunk = bytesRemainingInChunk - l;
                        return l;
                    }
                } else
                {
                    return -1L;
                }
            } else
            {
                throw new IllegalStateException("closed");
            }
            return -1L;
        }

        ChunkedSource(HttpUrl httpurl)
        {
            this$0 = Http1Codec.this;
            super();
            bytesRemainingInChunk = -1L;
            hasMoreChunks = true;
            url = httpurl;
        }
    }

    private final class FixedLengthSink
        implements Sink
    {

        private long bytesRemaining;
        private boolean closed;
        final Http1Codec this$0;
        private final ForwardingTimeout timeout;

        public void close()
            throws IOException
        {
            boolean flag = true;
            if (!closed)
            {
                closed = true;
                if (bytesRemaining > 0L)
                {
                    flag = false;
                }
                if (!flag)
                {
                    throw new ProtocolException("unexpected end of stream");
                } else
                {
                    detachTimeout(timeout);
                    state = 3;
                    return;
                }
            } else
            {
                return;
            }
        }

        public void flush()
            throws IOException
        {
            if (!closed)
            {
                sink.flush();
                return;
            } else
            {
                return;
            }
        }

        public Timeout timeout()
        {
            return timeout;
        }

        public void write(Buffer buffer, long l)
            throws IOException
        {
            if (!closed)
            {
                Util.checkOffsetAndCount(buffer.size(), 0L, l);
                boolean flag;
                if (l <= bytesRemaining)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    throw new ProtocolException((new StringBuilder()).append("expected ").append(bytesRemaining).append(" bytes but received ").append(l).toString());
                } else
                {
                    sink.write(buffer, l);
                    bytesRemaining = bytesRemaining - l;
                    return;
                }
            } else
            {
                throw new IllegalStateException("closed");
            }
        }

        FixedLengthSink(long l)
        {
            this$0 = Http1Codec.this;
            super();
            timeout = new ForwardingTimeout(sink.timeout());
            bytesRemaining = l;
        }
    }

    private class FixedLengthSource extends AbstractSource
    {

        private long bytesRemaining;
        final Http1Codec this$0;

        public void close()
            throws IOException
        {
            if (!closed)
            {
                if (bytesRemaining != 0L && !Util.discard(this, 100, TimeUnit.MILLISECONDS))
                {
                    endOfInput(false);
                }
                closed = true;
                return;
            } else
            {
                return;
            }
        }

        public long read(Buffer buffer, long l)
            throws IOException
        {
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
            if (!closed)
            {
                if (bytesRemaining == 0L)
                {
                    return -1L;
                }
            } else
            {
                throw new IllegalStateException("closed");
            }
            l = source.read(buffer, Math.min(bytesRemaining, l));
            if (l == -1L)
            {
                endOfInput(false);
                throw new ProtocolException("unexpected end of stream");
            }
            bytesRemaining = bytesRemaining - l;
            if (bytesRemaining == 0L)
            {
                endOfInput(true);
            }
            return l;
        }

        public FixedLengthSource(long l)
            throws IOException
        {
            this$0 = Http1Codec.this;
            super();
            bytesRemaining = l;
            if (bytesRemaining == 0L)
            {
                endOfInput(true);
            }
        }
    }

    private class UnknownLengthSource extends AbstractSource
    {

        private boolean inputExhausted;
        final Http1Codec this$0;

        public void close()
            throws IOException
        {
            if (!closed)
            {
                if (!inputExhausted)
                {
                    endOfInput(false);
                }
                closed = true;
                return;
            } else
            {
                return;
            }
        }

        public long read(Buffer buffer, long l)
            throws IOException
        {
            boolean flag = false;
            if (l >= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
            if (!closed)
            {
                if (!inputExhausted)
                {
                    l = source.read(buffer, l);
                    if (l == -1L)
                    {
                        inputExhausted = true;
                        endOfInput(true);
                        return -1L;
                    } else
                    {
                        return l;
                    }
                } else
                {
                    return -1L;
                }
            } else
            {
                throw new IllegalStateException("closed");
            }
        }

        UnknownLengthSource()
        {
            this$0 = Http1Codec.this;
            super();
        }
    }


    private static final int STATE_CLOSED = 6;
    private static final int STATE_IDLE = 0;
    private static final int STATE_OPEN_REQUEST_BODY = 1;
    private static final int STATE_OPEN_RESPONSE_BODY = 4;
    private static final int STATE_READING_RESPONSE_BODY = 5;
    private static final int STATE_READ_RESPONSE_HEADERS = 3;
    private static final int STATE_WRITING_REQUEST_BODY = 2;
    final OkHttpClient client;
    final BufferedSink sink;
    final BufferedSource source;
    int state;
    final StreamAllocation streamAllocation;

    public Http1Codec(OkHttpClient okhttpclient, StreamAllocation streamallocation, BufferedSource bufferedsource, BufferedSink bufferedsink)
    {
        state = 0;
        client = okhttpclient;
        streamAllocation = streamallocation;
        source = bufferedsource;
        sink = bufferedsink;
    }

    private Source getTransferStream(Response response)
        throws IOException
    {
        if (HttpHeaders.hasBody(response))
        {
            if (!"chunked".equalsIgnoreCase(response.header("Transfer-Encoding")))
            {
                long l = HttpHeaders.contentLength(response);
                if (l != -1L)
                {
                    return newFixedLengthSource(l);
                } else
                {
                    return newUnknownLengthSource();
                }
            } else
            {
                return newChunkedSource(response.request().url());
            }
        } else
        {
            return newFixedLengthSource(0L);
        }
    }

    public void cancel()
    {
        RealConnection realconnection = streamAllocation.connection();
        if (realconnection == null)
        {
            return;
        } else
        {
            realconnection.cancel();
            return;
        }
    }

    public Sink createRequestBody(Request request, long l)
    {
        if (!"chunked".equalsIgnoreCase(request.header("Transfer-Encoding")))
        {
            if (l != -1L)
            {
                return newFixedLengthSink(l);
            } else
            {
                throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
            }
        } else
        {
            return newChunkedSink();
        }
    }

    void detachTimeout(ForwardingTimeout forwardingtimeout)
    {
        Timeout timeout = forwardingtimeout._mthdelegate();
        forwardingtimeout.setDelegate(Timeout.NONE);
        timeout.clearDeadline();
        timeout.clearTimeout();
    }

    public void finishRequest()
        throws IOException
    {
        sink.flush();
    }

    public boolean isClosed()
    {
        return state == 6;
    }

    public Sink newChunkedSink()
    {
        if (state == 1)
        {
            state = 2;
            return new ChunkedSink();
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        }
    }

    public Source newChunkedSource(HttpUrl httpurl)
        throws IOException
    {
        if (state == 4)
        {
            state = 5;
            return new ChunkedSource(httpurl);
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        }
    }

    public Sink newFixedLengthSink(long l)
    {
        if (state == 1)
        {
            state = 2;
            return new FixedLengthSink(l);
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        }
    }

    public Source newFixedLengthSource(long l)
        throws IOException
    {
        if (state == 4)
        {
            state = 5;
            return new FixedLengthSource(l);
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        }
    }

    public Source newUnknownLengthSource()
        throws IOException
    {
        if (state == 4)
        {
            if (streamAllocation != null)
            {
                state = 5;
                streamAllocation.noNewStreams();
                return new UnknownLengthSource();
            } else
            {
                throw new IllegalStateException("streamAllocation == null");
            }
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        }
    }

    public ResponseBody openResponseBody(Response response)
        throws IOException
    {
        Source source1 = getTransferStream(response);
        return new RealResponseBody(response.headers(), Okio.buffer(source1));
    }

    public Headers readHeaders()
        throws IOException
    {
        okhttp3.Headers.Builder builder = new okhttp3.Headers.Builder();
        do
        {
            String s = source.readUtf8LineStrict();
            if (s.length() == 0)
            {
                return builder.build();
            }
            Internal.instance.addLenient(builder, s);
        } while (true);
    }

    public okhttp3.Response.Builder readResponse()
        throws IOException
    {
        while (state == 1 || state == 3) 
        {
            okhttp3.Response.Builder builder;
            try
            {
                StatusLine statusline;
                do
                {
                    statusline = StatusLine.parse(source.readUtf8LineStrict());
                    builder = (new okhttp3.Response.Builder()).protocol(statusline.protocol).code(statusline.code).message(statusline.message).headers(readHeaders());
                } while (statusline.code == 100);
                state = 4;
            }
            catch (EOFException eofexception)
            {
                IOException ioexception = new IOException((new StringBuilder()).append("unexpected end of stream on ").append(streamAllocation).toString());
                ioexception.initCause(eofexception);
                throw ioexception;
            }
            return builder;
        }
        throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
    }

    public okhttp3.Response.Builder readResponseHeaders()
        throws IOException
    {
        return readResponse();
    }

    public void writeRequest(Headers headers, String s)
        throws IOException
    {
        int i = 0;
        if (state != 0) goto _L2; else goto _L1
_L1:
        int j;
        sink.writeUtf8(s).writeUtf8("\r\n");
        j = headers.size();
_L4:
        if (i >= j)
        {
            sink.writeUtf8("\r\n");
            state = 1;
            return;
        }
        sink.writeUtf8(headers.name(i)).writeUtf8(": ").writeUtf8(headers.value(i)).writeUtf8("\r\n");
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void writeRequestHeaders(Request request)
        throws IOException
    {
        String s = RequestLine.get(request, streamAllocation.connection().route().proxy().type());
        writeRequest(request.headers(), s);
    }
}
