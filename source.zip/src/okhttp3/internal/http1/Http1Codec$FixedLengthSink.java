// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import java.net.ProtocolException;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;
import okio.ForwardingTimeout;
import okio.Sink;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private final class bytesRemaining
    implements Sink
{

    private long bytesRemaining;
    private boolean closed;
    final Http1Codec this$0;
    private final ForwardingTimeout timeout;

    public void close()
        throws IOException
    {
        boolean flag = true;
        if (!closed)
        {
            closed = true;
            if (bytesRemaining > 0L)
            {
                flag = false;
            }
            if (!flag)
            {
                throw new ProtocolException("unexpected end of stream");
            } else
            {
                detachTimeout(timeout);
                state = 3;
                return;
            }
        } else
        {
            return;
        }
    }

    public void flush()
        throws IOException
    {
        if (!closed)
        {
            sink.flush();
            return;
        } else
        {
            return;
        }
    }

    public Timeout timeout()
    {
        return timeout;
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        if (!closed)
        {
            Util.checkOffsetAndCount(buffer.size(), 0L, l);
            boolean flag;
            if (l <= bytesRemaining)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new ProtocolException((new StringBuilder()).append("expected ").append(bytesRemaining).append(" bytes but received ").append(l).toString());
            } else
            {
                sink.write(buffer, l);
                bytesRemaining = bytesRemaining - l;
                return;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    (long l)
    {
        this$0 = Http1Codec.this;
        super();
        timeout = new ForwardingTimeout(sink.timeout());
        bytesRemaining = l;
    }
}
