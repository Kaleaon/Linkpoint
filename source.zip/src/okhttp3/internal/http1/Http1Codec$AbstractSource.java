// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import okhttp3.internal.connection.StreamAllocation;
import okio.BufferedSource;
import okio.ForwardingTimeout;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private abstract class <init>
    implements Source
{

    protected boolean closed;
    final Http1Codec this$0;
    protected final ForwardingTimeout timeout;

    protected final void endOfInput(boolean flag)
        throws IOException
    {
        boolean flag1 = false;
        if (state != 6)
        {
            if (state == 5)
            {
                detachTimeout(timeout);
                state = 6;
                if (streamAllocation == null)
                {
                    return;
                }
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("state: ").append(state).toString());
            }
        } else
        {
            return;
        }
        StreamAllocation streamallocation = streamAllocation;
        if (flag)
        {
            flag = flag1;
        } else
        {
            flag = true;
        }
        streamallocation.streamFinished(flag, Http1Codec.this);
    }

    public Timeout timeout()
    {
        return timeout;
    }

    private ()
    {
        this$0 = Http1Codec.this;
        super();
        timeout = new ForwardingTimeout(source.timeout());
    }

    timeout(timeout timeout1)
    {
        this();
    }
}
