// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import okio.Buffer;
import okio.BufferedSink;
import okio.ForwardingTimeout;
import okio.Sink;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private final class timeout
    implements Sink
{

    private boolean closed;
    final Http1Codec this$0;
    private final ForwardingTimeout timeout;

    public void close()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_51;
        }
        closed = true;
        sink.writeUtf8("0\r\n\r\n");
        detachTimeout(timeout);
        state = 3;
        return;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void flush()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        sink.flush();
        return;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Timeout timeout()
    {
        return timeout;
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        if (!closed)
        {
            if (l == 0L)
            {
                return;
            } else
            {
                sink.writeHexadecimalUnsignedLong(l);
                sink.writeUtf8("\r\n");
                sink.write(buffer, l);
                sink.writeUtf8("\r\n");
                return;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    ()
    {
        this$0 = Http1Codec.this;
        super();
        timeout = new ForwardingTimeout(sink.timeout());
    }
}
