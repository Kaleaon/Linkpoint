// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSource;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private class endOfInput extends endOfInput
{

    private long bytesRemaining;
    final Http1Codec this$0;

    public void close()
        throws IOException
    {
        if (!closed)
        {
            if (bytesRemaining != 0L && !Util.discard(this, 100, TimeUnit.MILLISECONDS))
            {
                endOfInput(false);
            }
            closed = true;
            return;
        } else
        {
            return;
        }
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (!closed)
        {
            if (bytesRemaining == 0L)
            {
                return -1L;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
        l = source.read(buffer, Math.min(bytesRemaining, l));
        if (l == -1L)
        {
            endOfInput(false);
            throw new ProtocolException("unexpected end of stream");
        }
        bytesRemaining = bytesRemaining - l;
        if (bytesRemaining == 0L)
        {
            endOfInput(true);
        }
        return l;
    }

    public _cls9(long l)
        throws IOException
    {
        this$0 = Http1Codec.this;
        super(Http1Codec.this, null);
        bytesRemaining = l;
        if (bytesRemaining == 0L)
        {
            endOfInput(true);
        }
    }
}
