// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpHeaders;
import okio.Buffer;
import okio.BufferedSource;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private class url extends 
{

    private static final long NO_CHUNK_YET = -1L;
    private long bytesRemainingInChunk;
    private boolean hasMoreChunks;
    final Http1Codec this$0;
    private final HttpUrl url;

    private void readChunkSize()
        throws IOException
    {
        if (bytesRemainingInChunk != -1L)
        {
            source.readUtf8LineStrict();
        }
        String s;
        bytesRemainingInChunk = source.readHexadecimalUnsignedLong();
        s = source.readUtf8LineStrict().trim();
        boolean flag;
        boolean flag1;
        if (bytesRemainingInChunk < 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L2; else goto _L1
_L1:
        try
        {
            flag1 = s.isEmpty();
        }
        catch (NumberFormatException numberformatexception)
        {
            throw new ProtocolException(numberformatexception.getMessage());
        }
        if (!flag1) goto _L4; else goto _L3
_L3:
        if (bytesRemainingInChunk == 0L)
        {
            hasMoreChunks = false;
            HttpHeaders.receiveHeaders(client.cookieJar(), url, readHeaders());
            endOfInput(true);
        }
        return;
_L4:
        if (s.startsWith(";")) goto _L3; else goto _L2
_L2:
        throw new ProtocolException((new StringBuilder()).append("expected chunk size and optional extensions but was \"").append(bytesRemainingInChunk).append(s).append("\"").toString());
    }

    public void close()
        throws IOException
    {
        if (!closed)
        {
            break MISSING_BLOCK_LABEL_7;
        } else
        {
            return;
        }
        if (hasMoreChunks && !Util.discard(this, 100, TimeUnit.MILLISECONDS))
        {
            endOfInput(false);
        }
        closed = true;
        return;
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (!closed)
        {
            if (hasMoreChunks)
            {
                if (bytesRemainingInChunk == 0L || bytesRemainingInChunk == -1L)
                {
                    readChunkSize();
                    if (!hasMoreChunks)
                    {
                        break MISSING_BLOCK_LABEL_151;
                    }
                }
                l = source.read(buffer, Math.min(l, bytesRemainingInChunk));
                if (l == -1L)
                {
                    endOfInput(false);
                    throw new ProtocolException("unexpected end of stream");
                } else
                {
                    bytesRemainingInChunk = bytesRemainingInChunk - l;
                    return l;
                }
            } else
            {
                return -1L;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
        return -1L;
    }

    (HttpUrl httpurl)
    {
        this$0 = Http1Codec.this;
        super(Http1Codec.this, null);
        bytesRemainingInChunk = -1L;
        hasMoreChunks = true;
        url = httpurl;
    }
}
