// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http1;

import java.io.IOException;
import okio.Buffer;
import okio.BufferedSource;

// Referenced classes of package okhttp3.internal.http1:
//            Http1Codec

private class > extends >
{

    private boolean inputExhausted;
    final Http1Codec this$0;

    public void close()
        throws IOException
    {
        if (!closed)
        {
            if (!inputExhausted)
            {
                endOfInput(false);
            }
            closed = true;
            return;
        } else
        {
            return;
        }
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag = false;
        if (l >= 0L)
        {
            flag = true;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (!closed)
        {
            if (!inputExhausted)
            {
                l = source.read(buffer, l);
                if (l == -1L)
                {
                    inputExhausted = true;
                    endOfInput(true);
                    return -1L;
                } else
                {
                    return l;
                }
            } else
            {
                return -1L;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    ()
    {
        this$0 = Http1Codec.this;
        super(Http1Codec.this, null);
    }
}
