// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;

// Referenced classes of package okhttp3.internal.http2:
//            ErrorCode

public final class StreamResetException extends IOException
{

    public final ErrorCode errorCode;

    public StreamResetException(ErrorCode errorcode)
    {
        super((new StringBuilder()).append("stream was reset: ").append(errorcode).toString());
        errorCode = errorcode;
    }
}
