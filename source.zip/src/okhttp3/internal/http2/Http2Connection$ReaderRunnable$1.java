// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okhttp3.internal.NamedRunnable;
import okhttp3.internal.platform.Platform;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, ErrorCode, Http2Stream

class val.newStream extends NamedRunnable
{

    final val.newStream this$1;
    final Http2Stream val$newStream;

    public void execute()
    {
        try
        {
            listener.(val$newStream);
            return;
        }
        catch (IOException ioexception)
        {
            Platform.get().log(4, (new StringBuilder()).append("FramedConnection.Listener failure for ").append(hostname).toString(), ioexception);
        }
        try
        {
            val$newStream.close(ErrorCode.PROTOCOL_ERROR);
            return;
        }
        catch (IOException ioexception1)
        {
            return;
        }
    }

    transient (Object aobj[], Http2Stream http2stream)
    {
        this$1 = final_;
        val$newStream = http2stream;
        super(String.this, aobj);
    }
}
