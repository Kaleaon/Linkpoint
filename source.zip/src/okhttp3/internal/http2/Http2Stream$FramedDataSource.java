// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.EOFException;
import java.io.IOException;
import okio.Buffer;
import okio.BufferedSource;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Stream, StreamResetException, Http2Connection, Settings, 
//            ErrorCode

private final class maxByteCount
    implements Source
{

    static final boolean $assertionsDisabled;
    boolean closed;
    boolean finished;
    private final long maxByteCount;
    private final Buffer readBuffer = new Buffer();
    private final Buffer receiveBuffer = new Buffer();
    final Http2Stream this$0;

    private void checkNotClosed()
        throws IOException
    {
        if (!closed)
        {
            if (errorCode == null)
            {
                return;
            } else
            {
                throw new StreamResetException(errorCode);
            }
        } else
        {
            throw new IOException("stream closed");
        }
    }

    private void waitUntilReadable()
        throws IOException
    {
        readTimeout.er();
_L5:
        if (readBuffer.size() != 0L) goto _L2; else goto _L1
_L1:
        boolean flag = finished;
        if (!flag) goto _L3; else goto _L2
_L2:
        readTimeout.tAndThrowIfTimedOut();
        return;
_L3:
        if (closed || errorCode != null) goto _L2; else goto _L4
_L4:
        waitForIo();
          goto _L5
        Exception exception;
        exception;
        readTimeout.tAndThrowIfTimedOut();
        throw exception;
    }

    public void close()
        throws IOException
    {
        synchronized (Http2Stream.this)
        {
            closed = true;
            readBuffer.clear();
            notifyAll();
        }
        cancelStreamIfNecessary();
        return;
        exception;
        http2stream;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag2;
label0:
        {
            flag2 = true;
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
            synchronized (Http2Stream.this)
            {
                waitUntilReadable();
                checkNotClosed();
                if (readBuffer.size() != 0L)
                {
                    break label0;
                }
            }
            return -1L;
        }
        l = readBuffer.read(buffer, Math.min(l, readBuffer.size()));
        buffer = Http2Stream.this;
        buffer.unacknowledgedBytesRead = ((Http2Stream) (buffer)).unacknowledgedBytesRead + l;
        boolean flag1;
        if (unacknowledgedBytesRead < (long)(connection.okHttpSettings.getInitialWindowSize() / 2))
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (flag1)
        {
            break MISSING_BLOCK_LABEL_188;
        }
        connection.writeWindowUpdateLater(id, unacknowledgedBytesRead);
        unacknowledgedBytesRead = 0L;
        obj;
        JVM INSTR monitorexit ;
        buffer = connection;
        buffer;
        JVM INSTR monitorenter ;
        obj = connection;
        obj.unacknowledgedBytesRead = ((Http2Connection) (obj)).unacknowledgedBytesRead + l;
        if (connection.unacknowledgedBytesRead < (long)(connection.okHttpSettings.getInitialWindowSize() / 2))
        {
            flag1 = flag2;
        } else
        {
            flag1 = false;
        }
        if (flag1)
        {
            break MISSING_BLOCK_LABEL_293;
        }
        connection.writeWindowUpdateLater(0, connection.unacknowledgedBytesRead);
        connection.unacknowledgedBytesRead = 0L;
        buffer;
        JVM INSTR monitorexit ;
        return l;
        buffer;
        obj;
        JVM INSTR monitorexit ;
        throw buffer;
        Exception exception;
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
    }

    void receive(BufferedSource bufferedsource, long l)
        throws IOException
    {
_L6:
        Http2Stream http2stream;
        boolean flag;
        boolean flag1;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L2; else goto _L1
_L1:
        http2stream = Http2Stream.this;
        http2stream;
        JVM INSTR monitorenter ;
        flag1 = finished;
        if (readBuffer.size() + l <= maxByteCount)
        {
            flag = true;
        } else
        {
            flag = false;
        }
          goto _L3
_L7:
        http2stream;
        JVM INSTR monitorexit ;
          goto _L4
        if ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) goto _L6; else goto _L5
_L5:
        throw new AssertionError();
_L10:
        flag = false;
          goto _L7
        bufferedsource;
        http2stream;
        JVM INSTR monitorexit ;
        throw bufferedsource;
_L4:
        long l1;
        if (!flag)
        {
            if (!flag1)
            {
                l1 = bufferedsource.read(receiveBuffer, l);
                if (l1 == -1L)
                {
                    throw new EOFException();
                }
            } else
            {
                bufferedsource.skip(l);
                return;
            }
        } else
        {
            bufferedsource.skip(l);
            closeLater(ErrorCode.FLOW_CONTROL_ERROR);
            return;
        }
        l -= l1;
        http2stream = Http2Stream.this;
        http2stream;
        JVM INSTR monitorenter ;
        if (readBuffer.size() == 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        readBuffer.writeAll(receiveBuffer);
        if (flag)
        {
            break MISSING_BLOCK_LABEL_233;
        }
_L8:
        http2stream;
        JVM INSTR monitorexit ;
          goto _L6
        bufferedsource;
        http2stream;
        JVM INSTR monitorexit ;
        throw bufferedsource;
        notifyAll();
          goto _L8
_L2:
        return;
_L3:
        if (flag) goto _L10; else goto _L9
_L9:
        flag = true;
          goto _L7
    }

    public Timeout timeout()
    {
        return readTimeout;
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/http2/Http2Stream.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }

    _cls9(long l)
    {
        this$0 = Http2Stream.this;
        super();
        maxByteCount = l;
    }
}
