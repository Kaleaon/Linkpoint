// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;


// Referenced classes of package okhttp3.internal.http2:
//            Huffman

private static final class terminalBits
{

    final terminalBits children[];
    final int symbol;
    final int terminalBits;

    ()
    {
        children = new children[256];
        symbol = 0;
        terminalBits = 0;
    }

    terminalBits(int i, int j)
    {
        children = null;
        symbol = i;
        i = j & 7;
        if (i == 0)
        {
            i = 8;
        }
        terminalBits = i;
    }
}
