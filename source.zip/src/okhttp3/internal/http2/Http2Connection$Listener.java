// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, Http2Stream, ErrorCode

public static abstract class _cls1
{

    public static final _cls1 REFUSE_INCOMING_STREAMS = new Http2Connection.Listener() {

        public void onStream(Http2Stream http2stream)
            throws IOException
        {
            http2stream.close(ErrorCode.REFUSED_STREAM);
        }

    };

    public void onSettings(Http2Connection http2connection)
    {
    }

    public abstract void onStream(Http2Stream http2stream)
        throws IOException;


    public _cls1()
    {
    }
}
