// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okhttp3.internal.connection.StreamAllocation;
import okio.ForwardingSource;
import okio.Source;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Codec

class this._cls0 extends ForwardingSource
{

    final Http2Codec this$0;

    public void close()
        throws IOException
    {
        streamAllocation.streamFinished(false, Http2Codec.this);
        super.close();
    }

    public (Source source)
    {
        this$0 = Http2Codec.this;
        super(source);
    }
}
