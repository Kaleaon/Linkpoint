// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;
import okio.ByteString;

// Referenced classes of package okhttp3.internal.http2:
//            Http2, Settings, ErrorCode

final class Http2Writer
    implements Closeable
{

    private static final Logger logger = Logger.getLogger(okhttp3/internal/http2/Http2.getName());
    private final boolean client;
    private boolean closed;
    private final Buffer hpackBuffer = new Buffer();
    final Hpack.Writer hpackWriter;
    private int maxFrameSize;
    private final BufferedSink sink;

    public Http2Writer(BufferedSink bufferedsink, boolean flag)
    {
        sink = bufferedsink;
        client = flag;
        hpackWriter = new Hpack.Writer(hpackBuffer);
        maxFrameSize = 16384;
    }

    private void writeContinuationFrames(int i, long l)
        throws IOException
    {
        do
        {
            int j;
            if (l <= 0L)
            {
                j = 1;
            } else
            {
                j = 0;
            }
            if (j == 0)
            {
                j = (int)Math.min(maxFrameSize, l);
                l -= j;
                byte byte0;
                if (l == 0L)
                {
                    byte0 = 4;
                } else
                {
                    byte0 = 0;
                }
                frameHeader(i, j, (byte)9, byte0);
                sink.write(hpackBuffer, j);
            } else
            {
                return;
            }
        } while (true);
    }

    private static void writeMedium(BufferedSink bufferedsink, int i)
        throws IOException
    {
        bufferedsink.writeByte(i >>> 16 & 0xff);
        bufferedsink.writeByte(i >>> 8 & 0xff);
        bufferedsink.writeByte(i & 0xff);
    }

    public void applyAndAckSettings(Settings settings1)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        maxFrameSize = settings1.getMaxFrameSize(maxFrameSize);
        if (settings1.getHeaderTableSize() != -1)
        {
            break MISSING_BLOCK_LABEL_64;
        }
_L3:
        frameHeader(0, 0, (byte)4, (byte)1);
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        throw new IOException("closed");
        settings1;
        this;
        JVM INSTR monitorexit ;
        throw settings1;
        hpackWriter.setHeaderTableSizeSetting(settings1.getHeaderTableSize());
          goto _L3
    }

    public void close()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        closed = true;
        sink.close();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void connectionPreface()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        if (!client) goto _L4; else goto _L3
_L3:
        if (logger.isLoggable(Level.FINE))
        {
            break MISSING_BLOCK_LABEL_74;
        }
_L5:
        sink.write(Http2.CONNECTION_PREFACE.toByteArray());
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        throw new IOException("closed");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
_L4:
        this;
        JVM INSTR monitorexit ;
        return;
        logger.fine(Util.format(">> CONNECTION %s", new Object[] {
            Http2.CONNECTION_PREFACE.hex()
        }));
          goto _L5
    }

    public void data(boolean flag, int i, Buffer buffer, int j)
        throws IOException
    {
        byte byte0 = 0;
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_29;
        }
        if (flag)
        {
            byte0 = (byte)1;
        }
        dataFrame(i, byte0, buffer, j);
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        buffer;
        this;
        JVM INSTR monitorexit ;
        throw buffer;
    }

    void dataFrame(int i, byte byte0, Buffer buffer, int j)
        throws IOException
    {
        frameHeader(i, j, (byte)0, byte0);
        if (j <= 0)
        {
            return;
        } else
        {
            sink.write(buffer, j);
            return;
        }
    }

    public void flush()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_21;
        }
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void frameHeader(int i, int j, byte byte0, byte byte1)
        throws IOException
    {
        if (logger.isLoggable(Level.FINE))
        {
            logger.fine(Http2.frameLog(false, i, j, byte0, byte1));
        }
        if (j <= maxFrameSize)
        {
            if ((0x80000000 & i) == 0)
            {
                writeMedium(sink, j);
                sink.writeByte(byte0 & 0xff);
                sink.writeByte(byte1 & 0xff);
                sink.writeInt(0x7fffffff & i);
                return;
            } else
            {
                throw Http2.illegalArgument("reserved bit set: %s", new Object[] {
                    Integer.valueOf(i)
                });
            }
        } else
        {
            throw Http2.illegalArgument("FRAME_SIZE_ERROR length > %d: %d", new Object[] {
                Integer.valueOf(maxFrameSize), Integer.valueOf(j)
            });
        }
    }

    public void goAway(int i, ErrorCode errorcode, byte abyte0[])
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_72;
        }
        if (errorcode.httpCode == -1)
        {
            break MISSING_BLOCK_LABEL_87;
        }
        frameHeader(0, abyte0.length + 8, (byte)7, (byte)0);
        sink.writeInt(i);
        sink.writeInt(errorcode.httpCode);
        if (abyte0.length > 0)
        {
            sink.write(abyte0);
        }
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        errorcode;
        this;
        JVM INSTR monitorexit ;
        throw errorcode;
        throw Http2.illegalArgument("errorCode.httpCode == -1", new Object[0]);
    }

    public void headers(int i, List list)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        headers(false, i, list);
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    void headers(boolean flag, int i, List list)
        throws IOException
    {
        boolean flag1 = false;
        if (!closed)
        {
            hpackWriter.writeHeaders(list);
            long l = hpackBuffer.size();
            int j = (int)Math.min(maxFrameSize, l);
            byte byte0;
            if (l == (long)j)
            {
                byte0 = 4;
            } else
            {
                byte0 = 0;
            }
            if (flag)
            {
                byte0 |= 1;
            }
            frameHeader(i, j, (byte)1, byte0);
            sink.write(hpackBuffer, j);
            if (l <= (long)j)
            {
                flag1 = true;
            }
            if (!flag1)
            {
                writeContinuationFrames(i, l - (long)j);
            }
            return;
        } else
        {
            throw new IOException("closed");
        }
    }

    public int maxDataLength()
    {
        return maxFrameSize;
    }

    public void ping(boolean flag, int i, int j)
        throws IOException
    {
        byte byte0 = 0;
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_61;
        }
        Exception exception;
        if (flag)
        {
            byte0 = 1;
        }
        frameHeader(0, 8, (byte)6, byte0);
        sink.writeInt(i);
        sink.writeInt(j);
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void pushPromise(int i, int j, List list)
        throws IOException
    {
        boolean flag = false;
        this;
        JVM INSTR monitorenter ;
        int k;
        long l;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_130;
        }
        hpackWriter.writeHeaders(list);
        l = hpackBuffer.size();
        k = (int)Math.min(maxFrameSize - 4, l);
        byte byte0;
        if (l == (long)k)
        {
            byte0 = 4;
        } else
        {
            byte0 = 0;
        }
        frameHeader(i, k + 4, (byte)5, byte0);
        sink.writeInt(0x7fffffff & j);
        sink.write(hpackBuffer, k);
        j = ((flag) ? 1 : 0);
        if (l <= (long)k)
        {
            j = 1;
        }
        if (j != 0)
        {
            break MISSING_BLOCK_LABEL_127;
        }
        writeContinuationFrames(i, l - (long)k);
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    public void rstStream(int i, ErrorCode errorcode)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_51;
        }
        if (errorcode.httpCode == -1)
        {
            break MISSING_BLOCK_LABEL_66;
        }
        frameHeader(i, 4, (byte)3, (byte)0);
        sink.writeInt(errorcode.httpCode);
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        errorcode;
        this;
        JVM INSTR monitorexit ;
        throw errorcode;
        throw new IllegalArgumentException();
    }

    public void settings(Settings settings1)
        throws IOException
    {
        int i = 0;
        this;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        frameHeader(0, settings1.size() * 6, (byte)4, (byte)0);
_L6:
        if (i < 10) goto _L4; else goto _L3
_L3:
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        throw new IOException("closed");
        settings1;
        this;
        JVM INSTR monitorexit ;
        throw settings1;
_L4:
        if (!settings1.isSet(i))
        {
            break MISSING_BLOCK_LABEL_105;
        }
        int j;
        if (i != 4)
        {
            if (i != 7)
            {
                j = i;
            } else
            {
                j = 4;
            }
        } else
        {
            j = 3;
        }
        sink.writeShort(j);
        sink.writeInt(settings1.get(i));
        i++;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public void synReply(boolean flag, int i, List list)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        headers(flag, i, list);
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    public void synStream(boolean flag, int i, int j, List list)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_20;
        }
        headers(flag, i, list);
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IOException("closed");
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    public void windowUpdate(int i, long l)
        throws IOException
    {
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        if (l == 0L) goto _L4; else goto _L3
_L3:
        Exception exception;
        if (l > 0x7fffffffL)
        {
            flag = false;
        }
          goto _L5
_L4:
        throw Http2.illegalArgument("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", new Object[] {
            Long.valueOf(l)
        });
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
_L2:
        throw new IOException("closed");
_L6:
        frameHeader(i, 4, (byte)8, (byte)0);
        sink.writeInt((int)l);
        sink.flush();
        this;
        JVM INSTR monitorexit ;
        return;
_L5:
        if (flag) goto _L6; else goto _L4
    }

}
