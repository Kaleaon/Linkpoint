// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okio.Buffer;
import okio.Sink;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Stream, Http2Connection

final class this._cls0
    implements Sink
{

    static final boolean $assertionsDisabled;
    private static final long EMIT_BUFFER_SIZE = 16384L;
    boolean closed;
    boolean finished;
    private final Buffer sendBuffer = new Buffer();
    final Http2Stream this$0;

    private void emitDataFrame(boolean flag)
        throws IOException
    {
        boolean flag1 = true;
        Object obj = Http2Stream.this;
        obj;
        JVM INSTR monitorenter ;
        writeTimeout.nter();
_L6:
        int i;
        long l;
        boolean flag2;
        if (bytesLeftInWriteWindow > 0L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L2; else goto _L1
_L1:
        flag2 = finished;
        if (!flag2) goto _L3; else goto _L2
_L2:
        writeTimeout.xitAndThrowIfTimedOut();
        checkOutNotClosed();
        l = Math.min(bytesLeftInWriteWindow, sendBuffer.size());
        Http2Stream http2stream = Http2Stream.this;
        http2stream.bytesLeftInWriteWindow = http2stream.bytesLeftInWriteWindow - l;
        obj;
        JVM INSTR monitorexit ;
        writeTimeout.nter();
        obj = connection;
        i = id;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_250;
        }
          goto _L4
_L7:
        ((Http2Connection) (obj)).writeData(i, flag, sendBuffer, l);
        writeTimeout.xitAndThrowIfTimedOut();
        return;
_L3:
        if (closed || errorCode != null) goto _L2; else goto _L5
_L5:
        waitForIo();
          goto _L6
        Exception exception1;
        exception1;
        writeTimeout.xitAndThrowIfTimedOut();
        throw exception1;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        throw exception1;
_L4:
        long l1 = sendBuffer.size();
        if (l != l1)
        {
            break MISSING_BLOCK_LABEL_250;
        }
        flag = flag1;
          goto _L7
        Exception exception;
        exception;
        writeTimeout.xitAndThrowIfTimedOut();
        throw exception;
        flag = false;
          goto _L7
    }

    public void close()
        throws IOException
    {
_L6:
        http2stream = Http2Stream.this;
        http2stream;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        if (!sink.finished) goto _L4; else goto _L3
_L3:
        synchronized (Http2Stream.this)
        {
            closed = true;
        }
        connection.flush();
        cancelStreamIfNecessary();
        return;
        if ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) goto _L6; else goto _L5
_L5:
        throw new AssertionError();
_L2:
        http2stream;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        http2stream;
        JVM INSTR monitorexit ;
        throw exception;
_L4:
        boolean flag;
        if (sendBuffer.size() <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_147;
        }
        if (sendBuffer.size() <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L3; else goto _L7
_L7:
        emitDataFrame(true);
        break MISSING_BLOCK_LABEL_111;
        connection.writeData(id, true, null, 0L);
          goto _L3
        exception1;
        http2stream;
        JVM INSTR monitorexit ;
        throw exception1;
    }

    public void flush()
        throws IOException
    {
        while ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) 
        {
            synchronized (Http2Stream.this)
            {
                checkOutNotClosed();
            }
            do
            {
                boolean flag;
                if (sendBuffer.size() <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    emitDataFrame(false);
                    connection.flush();
                } else
                {
                    return;
                }
            } while (true);
        }
        throw new AssertionError();
        exception;
        http2stream;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public Timeout timeout()
    {
        return writeTimeout;
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        while ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) 
        {
            sendBuffer.write(buffer, l);
            do
            {
                boolean flag;
                if (sendBuffer.size() < 16384L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    emitDataFrame(false);
                } else
                {
                    return;
                }
            } while (true);
        }
        throw new AssertionError();
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/http2/Http2Stream.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }

    ()
    {
        this$0 = Http2Stream.this;
        super();
    }
}
