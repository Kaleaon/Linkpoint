// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.util.Arrays;

public final class Settings
{

    static final int COUNT = 10;
    static final int DEFAULT_INITIAL_WINDOW_SIZE = 65535;
    static final int ENABLE_PUSH = 2;
    static final int HEADER_TABLE_SIZE = 1;
    static final int INITIAL_WINDOW_SIZE = 7;
    static final int MAX_CONCURRENT_STREAMS = 4;
    static final int MAX_FRAME_SIZE = 5;
    static final int MAX_HEADER_LIST_SIZE = 6;
    private int set;
    private final int values[] = new int[10];

    public Settings()
    {
    }

    void clear()
    {
        set = 0;
        Arrays.fill(values, 0);
    }

    int get(int i)
    {
        return values[i];
    }

    boolean getEnablePush(boolean flag)
    {
        int i;
        if ((set & 4) == 0)
        {
            if (!flag)
            {
                i = 0;
            } else
            {
                i = 1;
            }
        } else
        {
            i = values[2];
        }
        return i == true;
    }

    int getHeaderTableSize()
    {
        if ((set & 2) == 0)
        {
            return -1;
        } else
        {
            return values[1];
        }
    }

    int getInitialWindowSize()
    {
        if ((set & 0x80) == 0)
        {
            return 65535;
        } else
        {
            return values[7];
        }
    }

    int getMaxConcurrentStreams(int i)
    {
        if ((set & 0x10) == 0)
        {
            return i;
        } else
        {
            return values[4];
        }
    }

    int getMaxFrameSize(int i)
    {
        if ((set & 0x20) == 0)
        {
            return i;
        } else
        {
            return values[5];
        }
    }

    int getMaxHeaderListSize(int i)
    {
        if ((set & 0x40) == 0)
        {
            return i;
        } else
        {
            return values[6];
        }
    }

    boolean isSet(int i)
    {
        return (1 << i & set) != 0;
    }

    void merge(Settings settings)
    {
        int i = 0;
        do
        {
            if (i >= 10)
            {
                return;
            }
            if (settings.isSet(i))
            {
                set(i, settings.get(i));
            }
            i++;
        } while (true);
    }

    Settings set(int i, int j)
    {
        if (i < values.length)
        {
            set = 1 << i | set;
            values[i] = j;
            return this;
        } else
        {
            return this;
        }
    }

    int size()
    {
        return Integer.bitCount(set);
    }
}
