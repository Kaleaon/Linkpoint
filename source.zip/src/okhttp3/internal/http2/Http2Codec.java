// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.http.HttpCodec;
import okhttp3.internal.http.RealResponseBody;
import okhttp3.internal.http.RequestLine;
import okhttp3.internal.http.StatusLine;
import okio.ByteString;
import okio.ForwardingSource;
import okio.Okio;
import okio.Sink;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Header, ErrorCode, Http2Stream, Http2Connection

public final class Http2Codec
    implements HttpCodec
{
    class StreamFinishingSource extends ForwardingSource
    {

        final Http2Codec this$0;

        public void close()
            throws IOException
        {
            streamAllocation.streamFinished(false, Http2Codec.this);
            super.close();
        }

        public StreamFinishingSource(Source source)
        {
            this$0 = Http2Codec.this;
            super(source);
        }
    }


    private static final ByteString CONNECTION;
    private static final ByteString ENCODING;
    private static final ByteString HOST;
    private static final List HTTP_2_SKIPPED_REQUEST_HEADERS;
    private static final List HTTP_2_SKIPPED_RESPONSE_HEADERS;
    private static final ByteString KEEP_ALIVE;
    private static final ByteString PROXY_CONNECTION;
    private static final ByteString TE;
    private static final ByteString TRANSFER_ENCODING;
    private static final ByteString UPGRADE;
    private final OkHttpClient client;
    private final Http2Connection connection;
    private Http2Stream stream;
    final StreamAllocation streamAllocation;

    public Http2Codec(OkHttpClient okhttpclient, StreamAllocation streamallocation, Http2Connection http2connection)
    {
        client = okhttpclient;
        streamAllocation = streamallocation;
        connection = http2connection;
    }

    public static List http2HeadersList(Request request)
    {
        int i = 0;
        Headers headers = request.headers();
        ArrayList arraylist = new ArrayList(headers.size() + 4);
        arraylist.add(new Header(Header.TARGET_METHOD, request.method()));
        arraylist.add(new Header(Header.TARGET_PATH, RequestLine.requestPath(request.url())));
        arraylist.add(new Header(Header.TARGET_AUTHORITY, Util.hostHeader(request.url(), false)));
        arraylist.add(new Header(Header.TARGET_SCHEME, request.url().scheme()));
        int j = headers.size();
        do
        {
            if (i >= j)
            {
                return arraylist;
            }
            request = ByteString.encodeUtf8(headers.name(i).toLowerCase(Locale.US));
            if (!HTTP_2_SKIPPED_REQUEST_HEADERS.contains(request))
            {
                arraylist.add(new Header(request, headers.value(i)));
            }
            i++;
        } while (true);
    }

    public static okhttp3.Response.Builder readHttp2HeadersList(List list)
        throws IOException
    {
        String s = null;
        okhttp3.Headers.Builder builder = new okhttp3.Headers.Builder();
        int j = list.size();
        int i = 0;
        do
        {
            String s1;
            String s2;
            ByteString bytestring;
            if (i >= j)
            {
                if (s != null)
                {
                    list = StatusLine.parse((new StringBuilder()).append("HTTP/1.1 ").append(s).toString());
                    return (new okhttp3.Response.Builder()).protocol(Protocol.HTTP_2).code(((StatusLine) (list)).code).message(((StatusLine) (list)).message).headers(builder.build());
                } else
                {
                    throw new ProtocolException("Expected ':status' header not present");
                }
            }
            bytestring = ((Header)list.get(i)).name;
            s2 = ((Header)list.get(i)).value.utf8();
            s1 = s2;
            if (!bytestring.equals(Header.RESPONSE_STATUS))
            {
                if (HTTP_2_SKIPPED_RESPONSE_HEADERS.contains(bytestring))
                {
                    s1 = s;
                } else
                {
                    Internal.instance.addLenient(builder, bytestring.utf8(), s2);
                    s1 = s;
                }
            }
            i++;
            s = s1;
        } while (true);
    }

    public void cancel()
    {
        if (stream == null)
        {
            return;
        } else
        {
            stream.closeLater(ErrorCode.CANCEL);
            return;
        }
    }

    public Sink createRequestBody(Request request, long l)
    {
        return stream.getSink();
    }

    public void finishRequest()
        throws IOException
    {
        stream.getSink().close();
    }

    public ResponseBody openResponseBody(Response response)
        throws IOException
    {
        StreamFinishingSource streamfinishingsource = new StreamFinishingSource(stream.getSource());
        return new RealResponseBody(response.headers(), Okio.buffer(streamfinishingsource));
    }

    public okhttp3.Response.Builder readResponseHeaders()
        throws IOException
    {
        return readHttp2HeadersList(stream.getResponseHeaders());
    }

    public void writeRequestHeaders(Request request)
        throws IOException
    {
        if (stream == null)
        {
            boolean flag;
            if (request.body() == null)
            {
                flag = false;
            } else
            {
                flag = true;
            }
            request = http2HeadersList(request);
            stream = connection.newStream(request, flag);
            stream.readTimeout().timeout(client.readTimeoutMillis(), TimeUnit.MILLISECONDS);
            stream.writeTimeout().timeout(client.writeTimeoutMillis(), TimeUnit.MILLISECONDS);
            return;
        } else
        {
            return;
        }
    }

    static 
    {
        CONNECTION = ByteString.encodeUtf8("connection");
        HOST = ByteString.encodeUtf8("host");
        KEEP_ALIVE = ByteString.encodeUtf8("keep-alive");
        PROXY_CONNECTION = ByteString.encodeUtf8("proxy-connection");
        TRANSFER_ENCODING = ByteString.encodeUtf8("transfer-encoding");
        TE = ByteString.encodeUtf8("te");
        ENCODING = ByteString.encodeUtf8("encoding");
        UPGRADE = ByteString.encodeUtf8("upgrade");
        HTTP_2_SKIPPED_REQUEST_HEADERS = Util.immutableList(new ByteString[] {
            CONNECTION, HOST, KEEP_ALIVE, PROXY_CONNECTION, TE, TRANSFER_ENCODING, ENCODING, UPGRADE, Header.TARGET_METHOD, Header.TARGET_PATH, 
            Header.TARGET_SCHEME, Header.TARGET_AUTHORITY
        });
        HTTP_2_SKIPPED_RESPONSE_HEADERS = Util.immutableList(new ByteString[] {
            CONNECTION, HOST, KEEP_ALIVE, PROXY_CONNECTION, TE, TRANSFER_ENCODING, ENCODING, UPGRADE
        });
    }
}
