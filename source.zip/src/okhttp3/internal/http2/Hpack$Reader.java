// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;
import okio.Source;

// Referenced classes of package okhttp3.internal.http2:
//            Hpack, Header, Huffman

static final class <init>
{

    Header dynamicTable[];
    int dynamicTableByteCount;
    int headerCount;
    private final List headerList;
    private final int headerTableSizeSetting;
    private int maxDynamicTableByteCount;
    int nextHeaderIndex;
    private final BufferedSource source;

    private void adjustDynamicTableByteCount()
    {
        if (maxDynamicTableByteCount >= dynamicTableByteCount)
        {
            return;
        }
        if (maxDynamicTableByteCount != 0)
        {
            evictToRecoverBytes(dynamicTableByteCount - maxDynamicTableByteCount);
            return;
        } else
        {
            clearDynamicTable();
            return;
        }
    }

    private void clearDynamicTable()
    {
        Arrays.fill(dynamicTable, null);
        nextHeaderIndex = dynamicTable.length - 1;
        headerCount = 0;
        dynamicTableByteCount = 0;
    }

    private int dynamicTableIndex(int i)
    {
        return nextHeaderIndex + 1 + i;
    }

    private int evictToRecoverBytes(int i)
    {
        boolean flag = false;
        if (i <= 0)
        {
            return 0;
        }
        int k = dynamicTable.length;
        int j = i;
        i = ((flag) ? 1 : 0);
        do
        {
            for (k--; k < nextHeaderIndex || j <= 0;)
            {
                System.arraycopy(dynamicTable, nextHeaderIndex + 1, dynamicTable, nextHeaderIndex + 1 + i, headerCount);
                nextHeaderIndex = nextHeaderIndex + i;
                return i;
            }

            j -= dynamicTable[k].hpackSize;
            dynamicTableByteCount = dynamicTableByteCount - dynamicTable[k].hpackSize;
            headerCount = headerCount - 1;
            i++;
        } while (true);
    }

    private ByteString getName(int i)
    {
        if (!isStaticHeader(i))
        {
            return dynamicTable[dynamicTableIndex(i - Hpack.STATIC_HEADER_TABLE.length)].name;
        } else
        {
            return Hpack.STATIC_HEADER_TABLE[i].name;
        }
    }

    private void insertIntoDynamicTable(int i, Header header)
    {
        headerList.add(header);
        int j = header.hpackSize;
        if (i != -1)
        {
            j -= dynamicTable[dynamicTableIndex(i)].hpackSize;
        }
        if (j <= maxDynamicTableByteCount)
        {
            int k = evictToRecoverBytes((dynamicTableByteCount + j) - maxDynamicTableByteCount);
            if (i != -1)
            {
                int l = dynamicTableIndex(i);
                dynamicTable[k + l + i] = header;
            } else
            {
                if (headerCount + 1 > dynamicTable.length)
                {
                    Header aheader[] = new Header[dynamicTable.length * 2];
                    System.arraycopy(dynamicTable, 0, aheader, dynamicTable.length, dynamicTable.length);
                    nextHeaderIndex = dynamicTable.length - 1;
                    dynamicTable = aheader;
                }
                i = nextHeaderIndex;
                nextHeaderIndex = i - 1;
                dynamicTable[i] = header;
                headerCount = headerCount + 1;
            }
            dynamicTableByteCount = j + dynamicTableByteCount;
            return;
        } else
        {
            clearDynamicTable();
            return;
        }
    }

    private boolean isStaticHeader(int i)
    {
        while (i < 0 || i > Hpack.STATIC_HEADER_TABLE.length - 1) 
        {
            return false;
        }
        return true;
    }

    private int readByte()
        throws IOException
    {
        return source.readByte() & 0xff;
    }

    private void readIndexedHeader(int i)
        throws IOException
    {
        int j;
        if (!isStaticHeader(i))
        {
            j = dynamicTableIndex(i - Hpack.STATIC_HEADER_TABLE.length);
            break MISSING_BLOCK_LABEL_19;
        } else
        {
            Header header = Hpack.STATIC_HEADER_TABLE[i];
            headerList.add(header);
            return;
        }
        if (j < 0 || j > dynamicTable.length - 1)
        {
            throw new IOException((new StringBuilder()).append("Header index too large ").append(i + 1).toString());
        } else
        {
            headerList.add(dynamicTable[j]);
            return;
        }
    }

    private void readLiteralHeaderWithIncrementalIndexingIndexedName(int i)
        throws IOException
    {
        insertIntoDynamicTable(-1, new Header(getName(i), readByteString()));
    }

    private void readLiteralHeaderWithIncrementalIndexingNewName()
        throws IOException
    {
        insertIntoDynamicTable(-1, new Header(Hpack.checkLowercase(readByteString()), readByteString()));
    }

    private void readLiteralHeaderWithoutIndexingIndexedName(int i)
        throws IOException
    {
        ByteString bytestring = getName(i);
        ByteString bytestring1 = readByteString();
        headerList.add(new Header(bytestring, bytestring1));
    }

    private void readLiteralHeaderWithoutIndexingNewName()
        throws IOException
    {
        ByteString bytestring = Hpack.checkLowercase(readByteString());
        ByteString bytestring1 = readByteString();
        headerList.add(new Header(bytestring, bytestring1));
    }

    public List getAndResetHeaderList()
    {
        ArrayList arraylist = new ArrayList(headerList);
        headerList.clear();
        return arraylist;
    }

    int maxDynamicTableByteCount()
    {
        return maxDynamicTableByteCount;
    }

    ByteString readByteString()
        throws IOException
    {
        boolean flag = false;
        int i = readByte();
        if ((i & 0x80) == 128)
        {
            flag = true;
        }
        i = readInt(i, 127);
        if (!flag)
        {
            return source.readByteString(i);
        } else
        {
            return ByteString.of(Huffman.get().decode(source.readByteArray(i)));
        }
    }

    void readHeaders()
        throws IOException
    {
        do
        {
            if (source.exhausted())
            {
                return;
            }
            int i = source.readByte() & 0xff;
            if (i != 128)
            {
                if ((i & 0x80) != 128)
                {
                    if (i != 64)
                    {
                        if ((i & 0x40) != 64)
                        {
                            if ((i & 0x20) != 32)
                            {
                                if (i == 16 || i == 0)
                                {
                                    readLiteralHeaderWithoutIndexingNewName();
                                } else
                                {
                                    readLiteralHeaderWithoutIndexingIndexedName(readInt(i, 15) - 1);
                                }
                            } else
                            {
                                for (maxDynamicTableByteCount = readInt(i, 31); maxDynamicTableByteCount < 0 || maxDynamicTableByteCount > headerTableSizeSetting;)
                                {
                                    throw new IOException((new StringBuilder()).append("Invalid dynamic table size update ").append(maxDynamicTableByteCount).toString());
                                }

                                adjustDynamicTableByteCount();
                            }
                        } else
                        {
                            readLiteralHeaderWithIncrementalIndexingIndexedName(readInt(i, 63) - 1);
                        }
                    } else
                    {
                        readLiteralHeaderWithIncrementalIndexingNewName();
                    }
                } else
                {
                    readIndexedHeader(readInt(i, 127) - 1);
                }
            } else
            {
                throw new IOException("index == 0");
            }
        } while (true);
    }

    int readInt(int i, int j)
        throws IOException
    {
        boolean flag = false;
        i &= j;
        if (i >= j)
        {
            i = ((flag) ? 1 : 0);
            break MISSING_BLOCK_LABEL_13;
        } else
        {
            return i;
        }
        do
        {
            int k = readByte();
            if ((k & 0x80) == 0)
            {
                return (k << i) + j;
            }
            j += (k & 0x7f) << i;
            i += 7;
        } while (true);
    }

    (int i, int j, Source source1)
    {
        headerList = new ArrayList();
        dynamicTable = new Header[8];
        nextHeaderIndex = dynamicTable.length - 1;
        headerCount = 0;
        dynamicTableByteCount = 0;
        headerTableSizeSetting = i;
        maxDynamicTableByteCount = j;
        source = Okio.buffer(source1);
    }

    source(int i, Source source1)
    {
        this(i, i, source1);
    }
}
