// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, PushObserver, ErrorCode, Http2Writer

class val.requestHeaders extends NamedRunnable
{

    final Http2Connection this$0;
    final List val$requestHeaders;
    final int val$streamId;

    public void execute()
    {
        if (!pushObserver.onRequest(val$streamId, val$requestHeaders))
        {
            return;
        }
        writer.rstStream(val$streamId, ErrorCode.CANCEL);
        synchronized (Http2Connection.this)
        {
            currentPushRequests.remove(Integer.valueOf(val$streamId));
        }
        return;
        exception;
        http2connection;
        JVM INSTR monitorexit ;
        try
        {
            throw exception;
        }
        catch (IOException ioexception)
        {
            return;
        }
    }

    transient (int i, List list)
    {
        this$0 = final_http2connection;
        val$streamId = i;
        val$requestHeaders = list;
        super(final_s, _5B_Ljava.lang.Object_3B_.this);
    }
}
