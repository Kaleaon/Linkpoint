// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.util.Set;
import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, PushObserver, ErrorCode

class val.errorCode extends NamedRunnable
{

    final Http2Connection this$0;
    final ErrorCode val$errorCode;
    final int val$streamId;

    public void execute()
    {
        pushObserver.onReset(val$streamId, val$errorCode);
        synchronized (Http2Connection.this)
        {
            currentPushRequests.remove(Integer.valueOf(val$streamId));
        }
        return;
        exception;
        http2connection;
        JVM INSTR monitorexit ;
        throw exception;
    }

    transient (int i, ErrorCode errorcode)
    {
        this$0 = final_http2connection;
        val$streamId = i;
        val$errorCode = errorcode;
        super(final_s, _5B_Ljava.lang.Object_3B_.this);
    }
}
