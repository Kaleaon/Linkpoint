// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import okhttp3.internal.NamedRunnable;
import okhttp3.internal.Util;
import okhttp3.internal.platform.Platform;
import okio.BufferedSource;
import okio.ByteString;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, Http2Stream, ErrorCode, Http2Reader, 
//            Ping, Settings, Http2Writer

class reader extends NamedRunnable
    implements reader
{

    final Http2Reader reader;
    final Http2Connection this$0;

    private void applyAndAckSettings(Settings settings1)
    {
        Http2Connection.executor.execute(new NamedRunnable(new Object[] {
            hostname
        }, settings1) {

            final Http2Connection.ReaderRunnable this$1;
            final Settings val$peerSettings;

            public void execute()
            {
                try
                {
                    writer.applyAndAckSettings(peerSettings);
                    return;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }

            transient 
            {
                this$1 = Http2Connection.ReaderRunnable.this;
                peerSettings = settings1;
                super(final_s, aobj);
            }
        });
    }

    public void ackSettings()
    {
    }

    public void alternateService(int i, String s, ByteString bytestring, String s1, int j, long l)
    {
    }

    public void data(boolean flag, int i, BufferedSource bufferedsource, int j)
        throws IOException
    {
        if (!pushedStream(i))
        {
            Http2Stream http2stream = getStream(i);
            if (http2stream != null)
            {
                http2stream.receiveData(bufferedsource, j);
                if (!flag)
                {
                    return;
                } else
                {
                    http2stream.receiveFin();
                    return;
                }
            } else
            {
                writeSynResetLater(i, ErrorCode.PROTOCOL_ERROR);
                bufferedsource.skip(j);
                return;
            }
        } else
        {
            pushDataLater(i, bufferedsource, j, flag);
            return;
        }
    }

    protected void execute()
    {
        Object obj;
        ErrorCode errorcode;
        Object obj2;
        ErrorCode errorcode1;
        obj2 = ErrorCode.INTERNAL_ERROR;
        errorcode1 = ErrorCode.INTERNAL_ERROR;
        errorcode = ((ErrorCode) (obj2));
        obj = obj2;
        if (!client) goto _L2; else goto _L1
_L1:
        errorcode = ((ErrorCode) (obj2));
        obj = obj2;
        if (reader.nextFrame(this)) goto _L1; else goto _L3
_L3:
        errorcode = ((ErrorCode) (obj2));
        obj = obj2;
        obj2 = ErrorCode.NO_ERROR;
        errorcode = ((ErrorCode) (obj2));
        obj = obj2;
        ErrorCode errorcode2 = ErrorCode.CANCEL;
        IOException ioexception;
        Object obj1;
        try
        {
            close(((ErrorCode) (obj2)), errorcode2);
        }
        catch (IOException ioexception1) { }
        Util.closeQuietly(reader);
        return;
_L2:
        errorcode = ((ErrorCode) (obj2));
        obj = obj2;
        reader.readConnectionPreface();
          goto _L1
        obj;
        obj = errorcode;
        obj2 = ErrorCode.PROTOCOL_ERROR;
        obj = ErrorCode.PROTOCOL_ERROR;
        try
        {
            close(((ErrorCode) (obj2)), ((ErrorCode) (obj)));
        }
        // Misplaced declaration of an exception variable
        catch (IOException ioexception) { }
        Util.closeQuietly(reader);
        return;
        obj1;
        obj2 = obj;
        obj = obj1;
_L5:
        try
        {
            close(((ErrorCode) (obj2)), errorcode1);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj1) { }
        Util.closeQuietly(reader);
        throw obj;
        obj;
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void goAway(int i, ErrorCode errorcode, ByteString bytestring)
    {
        int j;
        int k;
        j = 0;
        bytestring.size();
        synchronized (Http2Connection.this)
        {
            bytestring = (Http2Stream[])streams.values().toArray(new Http2Stream[streams.size()]);
            shutdown = true;
        }
        k = bytestring.length;
_L2:
        if (j >= k)
        {
            return;
        }
        break MISSING_BLOCK_LABEL_78;
        bytestring;
        errorcode;
        JVM INSTR monitorexit ;
        throw bytestring;
        errorcode = bytestring[j];
        while (false) 
        {
            if (errorcode.getId() > i && errorcode.isLocallyInitiated())
            {
                errorcode.receiveRstStream(ErrorCode.REFUSED_STREAM);
                removeStream(errorcode.getId());
            }
            j++;
        }
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void headers(boolean flag, int i, int j, List list)
    {
        if (pushedStream(i))
        {
            break MISSING_BLOCK_LABEL_60;
        }
        Http2Connection http2connection = Http2Connection.this;
        http2connection;
        JVM INSTR monitorenter ;
        Http2Stream http2stream;
        if (shutdown)
        {
            break MISSING_BLOCK_LABEL_72;
        }
        http2stream = getStream(i);
        if (http2stream == null)
        {
            break MISSING_BLOCK_LABEL_76;
        }
        http2connection;
        JVM INSTR monitorexit ;
        http2stream.receiveHeaders(list);
        if (!flag)
        {
            return;
        } else
        {
            http2stream.receiveFin();
            return;
        }
        pushHeadersLater(i, list, flag);
        return;
        http2connection;
        JVM INSTR monitorexit ;
        return;
        if (i > lastGoodStreamId)
        {
            if (i % 2 != nextStreamId % 2)
            {
                list = new Http2Stream(i, Http2Connection.this, false, flag, list);
                lastGoodStreamId = i;
                streams.put(Integer.valueOf(i), list);
                Http2Connection.executor.execute(new NamedRunnable(new Object[] {
                    hostname, Integer.valueOf(i)
                }, list) {

                    final Http2Connection.ReaderRunnable this$1;
                    final Http2Stream val$newStream;

                    public void execute()
                    {
                        try
                        {
                            listener.onStream(newStream);
                            return;
                        }
                        catch (IOException ioexception)
                        {
                            Platform.get().log(4, (new StringBuilder()).append("FramedConnection.Listener failure for ").append(hostname).toString(), ioexception);
                        }
                        try
                        {
                            newStream.close(ErrorCode.PROTOCOL_ERROR);
                            return;
                        }
                        catch (IOException ioexception1)
                        {
                            return;
                        }
                    }

            transient 
            {
                this$1 = Http2Connection.ReaderRunnable.this;
                newStream = http2stream;
                super(final_s, aobj);
            }
                });
                return;
            }
            break MISSING_BLOCK_LABEL_196;
        }
        return;
        http2connection;
        JVM INSTR monitorexit ;
        return;
        list;
        http2connection;
        JVM INSTR monitorexit ;
        throw list;
    }

    public void ping(boolean flag, int i, int j)
    {
        if (!flag)
        {
            writePingLater(true, i, j, null);
        } else
        {
            Ping ping1 = removePing(i);
            if (ping1 != null)
            {
                ping1.receive();
                return;
            }
        }
    }

    public void priority(int i, int j, int k, boolean flag)
    {
    }

    public void pushPromise(int i, int j, List list)
    {
        pushRequestLater(j, list);
    }

    public void rstStream(int i, ErrorCode errorcode)
    {
        if (!pushedStream(i))
        {
            Http2Stream http2stream = removeStream(i);
            if (http2stream == null)
            {
                return;
            } else
            {
                http2stream.receiveRstStream(errorcode);
                return;
            }
        } else
        {
            pushResetLater(i, errorcode);
            return;
        }
    }

    public void settings(boolean flag, Settings settings1)
    {
        Http2Connection http2connection = Http2Connection.this;
        http2connection;
        JVM INSTR monitorenter ;
        int i = peerSettings.getInitialWindowSize();
        if (flag) goto _L2; else goto _L1
_L1:
        int k;
        peerSettings.merge(settings1);
        applyAndAckSettings(settings1);
        k = peerSettings.getInitialWindowSize();
          goto _L3
_L11:
        Http2Connection.executor.execute(new NamedRunnable("OkHttp %s settings", new Object[] {
            hostname
        }) {

            final Http2Connection.ReaderRunnable this$1;

            public void execute()
            {
                listener.onSettings(this$0);
            }

            transient 
            {
                this$1 = Http2Connection.ReaderRunnable.this;
                super(s, aobj);
            }
        });
        http2connection;
        JVM INSTR monitorexit ;
          goto _L4
_L2:
        peerSettings.clear();
        continue; /* Loop/switch isn't completed */
        settings1;
        http2connection;
        JVM INSTR monitorexit ;
        throw settings1;
_L3:
        if (k == -1 || k == i) goto _L6; else goto _L5
_L5:
        long l1 = k - i;
        if (!receivedInitialPeerSettings) goto _L8; else goto _L7
_L7:
        if (streams.isEmpty())
        {
            settings1 = null;
            continue; /* Loop/switch isn't completed */
        }
        break; /* Loop/switch isn't completed */
_L8:
        addBytesToWriteWindow(l1);
        receivedInitialPeerSettings = true;
        if (true) goto _L7; else goto _L9
_L9:
        settings1 = (Http2Stream[])streams.values().toArray(new Http2Stream[streams.size()]);
        continue; /* Loop/switch isn't completed */
_L4:
        if (settings1 == null)
        {
            return;
        }
        if (l1 != 0L)
        {
            int l = settings1.length;
            for (int j = 0; j < l; j++)
            {
                synchronized (settings1[j])
                {
                    http2stream.addBytesToWriteWindow(l1);
                }
            }

        }
        break; /* Loop/switch isn't completed */
        settings1;
        http2stream;
        JVM INSTR monitorexit ;
        throw settings1;
_L6:
        settings1 = null;
        l1 = 0L;
        if (true) goto _L11; else goto _L10
_L10:
        return;
        if (true) goto _L1; else goto _L12
_L12:
    }

    public void windowUpdate(int i, long l)
    {
        if (i != 0)
        {
            obj = getStream(i);
            if (obj == null)
            {
                return;
            }
        } else
        {
            synchronized (Http2Connection.this)
            {
                Http2Connection http2connection = Http2Connection.this;
                http2connection.bytesLeftInWriteWindow = http2connection.bytesLeftInWriteWindow + l;
                notifyAll();
            }
            return;
        }
        break MISSING_BLOCK_LABEL_66;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
        obj;
        JVM INSTR monitorenter ;
        ((Http2Stream) (obj)).addBytesToWriteWindow(l);
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception1;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        throw exception1;
    }

    _cls3.val.peerSettings(Http2Reader http2reader)
    {
        this$0 = Http2Connection.this;
        super("OkHttp %s", new Object[] {
            hostname
        });
        reader = http2reader;
    }
}
