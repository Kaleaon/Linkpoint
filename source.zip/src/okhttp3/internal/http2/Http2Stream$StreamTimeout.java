// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.net.SocketTimeoutException;
import okio.AsyncTimeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Stream, ErrorCode

class this._cls0 extends AsyncTimeout
{

    final Http2Stream this$0;

    public void exitAndThrowIfTimedOut()
        throws IOException
    {
        if (!exit())
        {
            return;
        } else
        {
            throw newTimeoutException(null);
        }
    }

    protected IOException newTimeoutException(IOException ioexception)
    {
        SocketTimeoutException sockettimeoutexception = new SocketTimeoutException("timeout");
        if (ioexception == null)
        {
            return sockettimeoutexception;
        } else
        {
            sockettimeoutexception.initCause(ioexception);
            return sockettimeoutexception;
        }
    }

    protected void timedOut()
    {
        closeLater(ErrorCode.CANCEL);
    }

    ()
    {
        this$0 = Http2Stream.this;
        super();
    }
}
