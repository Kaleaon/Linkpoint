// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, PushObserver

public static class client
{

    boolean client;
    String hostname;
     listener;
    PushObserver pushObserver;
    BufferedSink sink;
    Socket socket;
    BufferedSource source;

    public Http2Connection build()
        throws IOException
    {
        return new Http2Connection(this);
    }

    public  listener( )
    {
        listener = ;
        return this;
    }

    public listener pushObserver(PushObserver pushobserver)
    {
        pushObserver = pushobserver;
        return this;
    }

    public pushObserver socket(Socket socket1)
        throws IOException
    {
        return socket(socket1, ((InetSocketAddress)socket1.getRemoteSocketAddress()).getHostName(), Okio.buffer(Okio.source(socket1)), Okio.buffer(Okio.sink(socket1)));
    }

    public socket socket(Socket socket1, String s, BufferedSource bufferedsource, BufferedSink bufferedsink)
    {
        socket = socket1;
        hostname = s;
        source = bufferedsource;
        sink = bufferedsink;
        return this;
    }

    public (boolean flag)
    {
        listener = .REFUSE_INCOMING_STREAMS;
        pushObserver = PushObserver.CANCEL;
        client = flag;
    }
}
