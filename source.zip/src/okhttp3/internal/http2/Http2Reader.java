// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2, ErrorCode, Settings

final class Http2Reader
    implements Closeable
{
    static final class ContinuationSource
        implements Source
    {

        byte flags;
        int left;
        int length;
        short padding;
        private final BufferedSource source;
        int streamId;

        private void readContinuationHeader()
            throws IOException
        {
            int i = streamId;
            int j = Http2Reader.readMedium(source);
            left = j;
            length = j;
            byte byte0 = (byte)(source.readByte() & 0xff);
            flags = (byte)(source.readByte() & 0xff);
            if (Http2Reader.logger.isLoggable(Level.FINE))
            {
                Http2Reader.logger.fine(Http2.frameLog(true, streamId, length, byte0, flags));
            }
            streamId = source.readInt() & 0x7fffffff;
            if (byte0 == 9)
            {
                if (streamId == i)
                {
                    return;
                } else
                {
                    throw Http2.ioException("TYPE_CONTINUATION streamId changed", new Object[0]);
                }
            } else
            {
                throw Http2.ioException("%s != TYPE_CONTINUATION", new Object[] {
                    Byte.valueOf(byte0)
                });
            }
        }

        public void close()
            throws IOException
        {
        }

        public long read(Buffer buffer, long l)
            throws IOException
        {
            do
            {
                if (left != 0)
                {
                    l = source.read(buffer, Math.min(l, left));
                    if (l == -1L)
                    {
                        return -1L;
                    } else
                    {
                        left = (int)((long)left - l);
                        return l;
                    }
                }
                source.skip(padding);
                padding = 0;
                if ((flags & 4) == 0)
                {
                    readContinuationHeader();
                } else
                {
                    return -1L;
                }
            } while (true);
        }

        public Timeout timeout()
        {
            return source.timeout();
        }

        public ContinuationSource(BufferedSource bufferedsource)
        {
            source = bufferedsource;
        }
    }

    static interface Handler
    {

        public abstract void ackSettings();

        public abstract void alternateService(int i, String s, ByteString bytestring, String s1, int j, long l);

        public abstract void data(boolean flag, int i, BufferedSource bufferedsource, int j)
            throws IOException;

        public abstract void goAway(int i, ErrorCode errorcode, ByteString bytestring);

        public abstract void headers(boolean flag, int i, int j, List list);

        public abstract void ping(boolean flag, int i, int j);

        public abstract void priority(int i, int j, int k, boolean flag);

        public abstract void pushPromise(int i, int j, List list)
            throws IOException;

        public abstract void rstStream(int i, ErrorCode errorcode);

        public abstract void settings(boolean flag, Settings settings1);

        public abstract void windowUpdate(int i, long l);
    }


    static final Logger logger = Logger.getLogger(okhttp3/internal/http2/Http2.getName());
    private final boolean client;
    private final ContinuationSource continuation;
    final Hpack.Reader hpackReader;
    private final BufferedSource source;

    public Http2Reader(BufferedSource bufferedsource, boolean flag)
    {
        source = bufferedsource;
        client = flag;
        continuation = new ContinuationSource(source);
        hpackReader = new Hpack.Reader(4096, continuation);
    }

    static int lengthWithoutPadding(int i, byte byte0, short word0)
        throws IOException
    {
        if ((byte0 & 8) != 0)
        {
            i--;
        }
        if (word0 <= i)
        {
            return (short)(i - word0);
        } else
        {
            throw Http2.ioException("PROTOCOL_ERROR padding %s > remaining length %s", new Object[] {
                Short.valueOf(word0), Integer.valueOf(i)
            });
        }
    }

    private void readData(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        boolean flag = true;
        short word0 = 0;
        boolean flag1;
        if ((byte0 & 1) == 0)
        {
            flag1 = false;
        } else
        {
            flag1 = true;
        }
        if ((byte0 & 0x20) == 0)
        {
            flag = false;
        }
        if (!flag)
        {
            if ((byte0 & 8) != 0)
            {
                word0 = (short)(source.readByte() & 0xff);
            }
            i = lengthWithoutPadding(i, byte0, word0);
            handler.data(flag1, j, source, i);
            source.skip(word0);
            return;
        } else
        {
            throw Http2.ioException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
        }
    }

    private void readGoAway(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        if (i >= 8)
        {
            if (j == 0)
            {
                byte0 = source.readInt();
                j = source.readInt();
                i -= 8;
                ErrorCode errorcode = ErrorCode.fromHttp2(j);
                if (errorcode != null)
                {
                    ByteString bytestring = ByteString.EMPTY;
                    if (i > 0)
                    {
                        bytestring = source.readByteString(i);
                    }
                    handler.goAway(byte0, errorcode, bytestring);
                    return;
                } else
                {
                    throw Http2.ioException("TYPE_GOAWAY unexpected error code: %d", new Object[] {
                        Integer.valueOf(j)
                    });
                }
            } else
            {
                throw Http2.ioException("TYPE_GOAWAY streamId != 0", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("TYPE_GOAWAY length < 8: %s", new Object[] {
                Integer.valueOf(i)
            });
        }
    }

    private List readHeaderBlock(int i, short word0, byte byte0, int j)
        throws IOException
    {
        ContinuationSource continuationsource = continuation;
        continuation.left = i;
        continuationsource.length = i;
        continuation.padding = word0;
        continuation.flags = byte0;
        continuation.streamId = j;
        hpackReader.readHeaders();
        return hpackReader.getAndResetHeaderList();
    }

    private void readHeaders(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        short word0 = 0;
        if (j != 0)
        {
            boolean flag;
            if ((byte0 & 1) == 0)
            {
                flag = false;
            } else
            {
                flag = true;
            }
            if ((byte0 & 8) != 0)
            {
                word0 = (short)(source.readByte() & 0xff);
            }
            if ((byte0 & 0x20) != 0)
            {
                readPriority(handler, j);
                i -= 5;
            }
            handler.headers(flag, j, -1, readHeaderBlock(lengthWithoutPadding(i, byte0, word0), word0, byte0, j));
            return;
        } else
        {
            throw Http2.ioException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
        }
    }

    static int readMedium(BufferedSource bufferedsource)
        throws IOException
    {
        return (bufferedsource.readByte() & 0xff) << 16 | (bufferedsource.readByte() & 0xff) << 8 | bufferedsource.readByte() & 0xff;
    }

    private void readPing(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        boolean flag = false;
        if (i == 8)
        {
            if (j == 0)
            {
                i = source.readInt();
                j = source.readInt();
                if ((byte0 & 1) != 0)
                {
                    flag = true;
                }
                handler.ping(flag, i, j);
                return;
            } else
            {
                throw Http2.ioException("TYPE_PING streamId != 0", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("TYPE_PING length != 8: %s", new Object[] {
                Integer.valueOf(i)
            });
        }
    }

    private void readPriority(Handler handler, int i)
        throws IOException
    {
        boolean flag = false;
        int j = source.readInt();
        if ((0x80000000 & j) != 0)
        {
            flag = true;
        }
        handler.priority(i, j & 0x7fffffff, (source.readByte() & 0xff) + 1, flag);
    }

    private void readPriority(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        if (i == 5)
        {
            if (j != 0)
            {
                readPriority(handler, j);
                return;
            } else
            {
                throw Http2.ioException("TYPE_PRIORITY streamId == 0", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("TYPE_PRIORITY length: %d != 5", new Object[] {
                Integer.valueOf(i)
            });
        }
    }

    private void readPushPromise(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        short word0 = 0;
        if (j != 0)
        {
            if ((byte0 & 8) != 0)
            {
                word0 = (short)(source.readByte() & 0xff);
            }
            handler.pushPromise(j, source.readInt() & 0x7fffffff, readHeaderBlock(lengthWithoutPadding(i - 4, byte0, word0), word0, byte0, j));
            return;
        } else
        {
            throw Http2.ioException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
        }
    }

    private void readRstStream(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        if (i == 4)
        {
            if (j != 0)
            {
                i = source.readInt();
                ErrorCode errorcode = ErrorCode.fromHttp2(i);
                if (errorcode != null)
                {
                    handler.rstStream(j, errorcode);
                    return;
                } else
                {
                    throw Http2.ioException("TYPE_RST_STREAM unexpected error code: %d", new Object[] {
                        Integer.valueOf(i)
                    });
                }
            } else
            {
                throw Http2.ioException("TYPE_RST_STREAM streamId == 0", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("TYPE_RST_STREAM length: %d != 4", new Object[] {
                Integer.valueOf(i)
            });
        }
    }

    private void readSettings(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        Settings settings;
        if (j == 0)
        {
            if ((byte0 & 1) == 0)
            {
                if (i % 6 == 0)
                {
                    settings = new Settings();
                    j = 0;
                    break MISSING_BLOCK_LABEL_30;
                } else
                {
                    throw Http2.ioException("TYPE_SETTINGS length %% 6 != 0: %s", new Object[] {
                        Integer.valueOf(i)
                    });
                }
            } else
            if (i == 0)
            {
                handler.ackSettings();
                return;
            } else
            {
                throw Http2.ioException("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("TYPE_SETTINGS streamId != 0", new Object[0]);
        }
_L8:
        short word0;
        int k;
        if (j >= i)
        {
            handler.settings(false, settings);
            return;
        }
        word0 = source.readShort();
        k = source.readInt();
        byte0 = word0;
        word0;
        JVM INSTR tableswitch 1 6: default 160
    //                   1 163
    //                   2 182
    //                   3 209
    //                   4 214
    //                   5 232
    //                   6 163;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L2
_L6:
        break MISSING_BLOCK_LABEL_232;
_L3:
        break; /* Loop/switch isn't completed */
_L2:
        break; /* Loop/switch isn't completed */
_L1:
        byte0 = word0;
_L10:
        settings.set(byte0, k);
        j += 6;
        if (true) goto _L8; else goto _L7
_L7:
        byte0 = word0;
        if (k == 0) goto _L10; else goto _L9
_L9:
        byte0 = word0;
        if (k == 1) goto _L10; else goto _L11
_L11:
        throw Http2.ioException("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
_L4:
        byte0 = 4;
          goto _L10
_L5:
        byte0 = 7;
        if (k >= 0) goto _L10; else goto _L12
_L12:
        throw Http2.ioException("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
        while (k < 16384 || k > 0xffffff) 
        {
            throw Http2.ioException("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s", new Object[] {
                Integer.valueOf(k)
            });
        }
        byte0 = word0;
          goto _L10
    }

    private void readWindowUpdate(Handler handler, int i, byte byte0, int j)
        throws IOException
    {
        if (i == 4)
        {
            long l = (long)source.readInt() & 0x7fffffffL;
            if (l == 0L)
            {
                throw Http2.ioException("windowSizeIncrement was 0", new Object[] {
                    Long.valueOf(l)
                });
            } else
            {
                handler.windowUpdate(j, l);
                return;
            }
        } else
        {
            throw Http2.ioException("TYPE_WINDOW_UPDATE length !=4: %s", new Object[] {
                Integer.valueOf(i)
            });
        }
    }

    public void close()
        throws IOException
    {
        source.close();
    }

    public boolean nextFrame(Handler handler)
        throws IOException
    {
        int i;
        try
        {
            source.require(9L);
        }
        // Misplaced declaration of an exception variable
        catch (Handler handler)
        {
            return false;
        }
        for (i = readMedium(source); i < 0 || i > 16384;)
        {
            throw Http2.ioException("FRAME_SIZE_ERROR: %s", new Object[] {
                Integer.valueOf(i)
            });
        }

        byte byte0 = (byte)(source.readByte() & 0xff);
        byte byte1 = (byte)(source.readByte() & 0xff);
        int j = source.readInt() & 0x7fffffff;
        if (logger.isLoggable(Level.FINE))
        {
            logger.fine(Http2.frameLog(true, j, i, byte0, byte1));
        }
        switch (byte0)
        {
        default:
            source.skip(i);
            return true;

        case 0: // '\0'
            readData(handler, i, byte1, j);
            return true;

        case 1: // '\001'
            readHeaders(handler, i, byte1, j);
            return true;

        case 2: // '\002'
            readPriority(handler, i, byte1, j);
            return true;

        case 3: // '\003'
            readRstStream(handler, i, byte1, j);
            return true;

        case 4: // '\004'
            readSettings(handler, i, byte1, j);
            return true;

        case 5: // '\005'
            readPushPromise(handler, i, byte1, j);
            return true;

        case 6: // '\006'
            readPing(handler, i, byte1, j);
            return true;

        case 7: // '\007'
            readGoAway(handler, i, byte1, j);
            return true;

        case 8: // '\b'
            readWindowUpdate(handler, i, byte1, j);
            break;
        }
        return true;
    }

    public void readConnectionPreface()
        throws IOException
    {
        if (!client)
        {
            ByteString bytestring = source.readByteString(Http2.CONNECTION_PREFACE.size());
            if (logger.isLoggable(Level.FINE))
            {
                logger.fine(Util.format("<< CONNECTION %s", new Object[] {
                    bytestring.hex()
                }));
            }
            if (Http2.CONNECTION_PREFACE.equals(bytestring))
            {
                return;
            } else
            {
                throw Http2.ioException("Expected a connection header but was %s", new Object[] {
                    bytestring.utf8()
                });
            }
        } else
        {
            return;
        }
    }

}
