// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, Ping

class val.ping extends NamedRunnable
{

    final Http2Connection this$0;
    final int val$payload1;
    final int val$payload2;
    final Ping val$ping;
    final boolean val$reply;

    public void execute()
    {
        try
        {
            writePing(val$reply, val$payload1, val$payload2, val$ping);
            return;
        }
        catch (IOException ioexception)
        {
            return;
        }
    }

    transient (int j, Ping ping1)
    {
        this$0 = final_http2connection;
        val$reply = flag;
        val$payload1 = I.this;
        val$payload2 = j;
        val$ping = ping1;
        super(final_s, final_aobj);
    }
}
