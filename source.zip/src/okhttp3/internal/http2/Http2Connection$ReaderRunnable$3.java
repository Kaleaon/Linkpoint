// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, Http2Writer, Settings

class val.peerSettings extends NamedRunnable
{

    final val.peerSettings this$1;
    final Settings val$peerSettings;

    public void execute()
    {
        try
        {
            writer.applyAndAckSettings(val$peerSettings);
            return;
        }
        catch (IOException ioexception)
        {
            return;
        }
    }

    transient (Object aobj[], Settings settings)
    {
        this$1 = final_;
        val$peerSettings = settings;
        super(String.this, aobj);
    }
}
