// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import okio.Buffer;
import okio.BufferedSource;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Reader, Http2

static final class source
    implements Source
{

    byte flags;
    int left;
    int length;
    short padding;
    private final BufferedSource source;
    int streamId;

    private void readContinuationHeader()
        throws IOException
    {
        int i = streamId;
        int j = Http2Reader.readMedium(source);
        left = j;
        length = j;
        byte byte0 = (byte)(source.readByte() & 0xff);
        flags = (byte)(source.readByte() & 0xff);
        if (Http2Reader.logger.isLoggable(Level.FINE))
        {
            Http2Reader.logger.fine(Http2.frameLog(true, streamId, length, byte0, flags));
        }
        streamId = source.readInt() & 0x7fffffff;
        if (byte0 == 9)
        {
            if (streamId == i)
            {
                return;
            } else
            {
                throw Http2.ioException("TYPE_CONTINUATION streamId changed", new Object[0]);
            }
        } else
        {
            throw Http2.ioException("%s != TYPE_CONTINUATION", new Object[] {
                Byte.valueOf(byte0)
            });
        }
    }

    public void close()
        throws IOException
    {
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        do
        {
            if (left != 0)
            {
                l = source.read(buffer, Math.min(l, left));
                if (l == -1L)
                {
                    return -1L;
                } else
                {
                    left = (int)((long)left - l);
                    return l;
                }
            }
            source.skip(padding);
            padding = 0;
            if ((flags & 4) == 0)
            {
                readContinuationHeader();
            } else
            {
                return -1L;
            }
        } while (true);
    }

    public Timeout timeout()
    {
        return source.timeout();
    }

    public (BufferedSource bufferedsource)
    {
        source = bufferedsource;
    }
}
