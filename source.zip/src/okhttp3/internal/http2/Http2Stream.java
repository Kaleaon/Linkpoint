// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import okio.AsyncTimeout;
import okio.Buffer;
import okio.BufferedSource;
import okio.Sink;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, Settings, ErrorCode, StreamResetException

public final class Http2Stream
{
    final class FramedDataSink
        implements Sink
    {

        static final boolean $assertionsDisabled;
        private static final long EMIT_BUFFER_SIZE = 16384L;
        boolean closed;
        boolean finished;
        private final Buffer sendBuffer = new Buffer();
        final Http2Stream this$0;

        private void emitDataFrame(boolean flag)
            throws IOException
        {
            boolean flag1 = true;
            Object obj = Http2Stream.this;
            obj;
            JVM INSTR monitorenter ;
            writeTimeout.enter();
_L6:
            int i;
            long l;
            boolean flag2;
            if (bytesLeftInWriteWindow > 0L)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i != 0) goto _L2; else goto _L1
_L1:
            flag2 = finished;
            if (!flag2) goto _L3; else goto _L2
_L2:
            writeTimeout.exitAndThrowIfTimedOut();
            checkOutNotClosed();
            l = Math.min(bytesLeftInWriteWindow, sendBuffer.size());
            Http2Stream http2stream = Http2Stream.this;
            http2stream.bytesLeftInWriteWindow = http2stream.bytesLeftInWriteWindow - l;
            obj;
            JVM INSTR monitorexit ;
            writeTimeout.enter();
            obj = connection;
            i = id;
            if (!flag)
            {
                break MISSING_BLOCK_LABEL_250;
            }
              goto _L4
_L7:
            ((Http2Connection) (obj)).writeData(i, flag, sendBuffer, l);
            writeTimeout.exitAndThrowIfTimedOut();
            return;
_L3:
            if (closed || errorCode != null) goto _L2; else goto _L5
_L5:
            waitForIo();
              goto _L6
            Exception exception1;
            exception1;
            writeTimeout.exitAndThrowIfTimedOut();
            throw exception1;
            exception1;
            obj;
            JVM INSTR monitorexit ;
            throw exception1;
_L4:
            long l1 = sendBuffer.size();
            if (l != l1)
            {
                break MISSING_BLOCK_LABEL_250;
            }
            flag = flag1;
              goto _L7
            Exception exception;
            exception;
            writeTimeout.exitAndThrowIfTimedOut();
            throw exception;
            flag = false;
              goto _L7
        }

        public void close()
            throws IOException
        {
_L6:
            http2stream = Http2Stream.this;
            http2stream;
            JVM INSTR monitorenter ;
            if (closed) goto _L2; else goto _L1
_L1:
            if (!sink.finished) goto _L4; else goto _L3
_L3:
            synchronized (Http2Stream.this)
            {
                closed = true;
            }
            connection.flush();
            cancelStreamIfNecessary();
            return;
            if ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) goto _L6; else goto _L5
_L5:
            throw new AssertionError();
_L2:
            http2stream;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            http2stream;
            JVM INSTR monitorexit ;
            throw exception;
_L4:
            boolean flag;
            if (sendBuffer.size() <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                break MISSING_BLOCK_LABEL_147;
            }
            if (sendBuffer.size() <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag) goto _L3; else goto _L7
_L7:
            emitDataFrame(true);
            break MISSING_BLOCK_LABEL_111;
            connection.writeData(id, true, null, 0L);
              goto _L3
            exception1;
            http2stream;
            JVM INSTR monitorexit ;
            throw exception1;
        }

        public void flush()
            throws IOException
        {
            while ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) 
            {
                synchronized (Http2Stream.this)
                {
                    checkOutNotClosed();
                }
                do
                {
                    boolean flag;
                    if (sendBuffer.size() <= 0L)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (!flag)
                    {
                        emitDataFrame(false);
                        connection.flush();
                    } else
                    {
                        return;
                    }
                } while (true);
            }
            throw new AssertionError();
            exception;
            http2stream;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public Timeout timeout()
        {
            return writeTimeout;
        }

        public void write(Buffer buffer, long l)
            throws IOException
        {
            while ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) 
            {
                sendBuffer.write(buffer, l);
                do
                {
                    boolean flag;
                    if (sendBuffer.size() < 16384L)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (!flag)
                    {
                        emitDataFrame(false);
                    } else
                    {
                        return;
                    }
                } while (true);
            }
            throw new AssertionError();
        }

        static 
        {
            boolean flag = false;
            if (!okhttp3/internal/http2/Http2Stream.desiredAssertionStatus())
            {
                flag = true;
            }
            $assertionsDisabled = flag;
        }

        FramedDataSink()
        {
            this$0 = Http2Stream.this;
            super();
        }
    }

    private final class FramedDataSource
        implements Source
    {

        static final boolean $assertionsDisabled;
        boolean closed;
        boolean finished;
        private final long maxByteCount;
        private final Buffer readBuffer = new Buffer();
        private final Buffer receiveBuffer = new Buffer();
        final Http2Stream this$0;

        private void checkNotClosed()
            throws IOException
        {
            if (!closed)
            {
                if (errorCode == null)
                {
                    return;
                } else
                {
                    throw new StreamResetException(errorCode);
                }
            } else
            {
                throw new IOException("stream closed");
            }
        }

        private void waitUntilReadable()
            throws IOException
        {
            readTimeout.enter();
_L5:
            if (readBuffer.size() != 0L) goto _L2; else goto _L1
_L1:
            boolean flag = finished;
            if (!flag) goto _L3; else goto _L2
_L2:
            readTimeout.exitAndThrowIfTimedOut();
            return;
_L3:
            if (closed || errorCode != null) goto _L2; else goto _L4
_L4:
            waitForIo();
              goto _L5
            Exception exception;
            exception;
            readTimeout.exitAndThrowIfTimedOut();
            throw exception;
        }

        public void close()
            throws IOException
        {
            synchronized (Http2Stream.this)
            {
                closed = true;
                readBuffer.clear();
                notifyAll();
            }
            cancelStreamIfNecessary();
            return;
            exception;
            http2stream;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public long read(Buffer buffer, long l)
            throws IOException
        {
            boolean flag2;
label0:
            {
                flag2 = true;
                boolean flag;
                if (l >= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
                }
                synchronized (Http2Stream.this)
                {
                    waitUntilReadable();
                    checkNotClosed();
                    if (readBuffer.size() != 0L)
                    {
                        break label0;
                    }
                }
                return -1L;
            }
            l = readBuffer.read(buffer, Math.min(l, readBuffer.size()));
            buffer = Http2Stream.this;
            buffer.unacknowledgedBytesRead = ((Http2Stream) (buffer)).unacknowledgedBytesRead + l;
            boolean flag1;
            if (unacknowledgedBytesRead < (long)(connection.okHttpSettings.getInitialWindowSize() / 2))
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (flag1)
            {
                break MISSING_BLOCK_LABEL_188;
            }
            connection.writeWindowUpdateLater(id, unacknowledgedBytesRead);
            unacknowledgedBytesRead = 0L;
            obj;
            JVM INSTR monitorexit ;
            buffer = connection;
            buffer;
            JVM INSTR monitorenter ;
            obj = connection;
            obj.unacknowledgedBytesRead = ((Http2Connection) (obj)).unacknowledgedBytesRead + l;
            if (connection.unacknowledgedBytesRead < (long)(connection.okHttpSettings.getInitialWindowSize() / 2))
            {
                flag1 = flag2;
            } else
            {
                flag1 = false;
            }
            if (flag1)
            {
                break MISSING_BLOCK_LABEL_293;
            }
            connection.writeWindowUpdateLater(0, connection.unacknowledgedBytesRead);
            connection.unacknowledgedBytesRead = 0L;
            buffer;
            JVM INSTR monitorexit ;
            return l;
            buffer;
            obj;
            JVM INSTR monitorexit ;
            throw buffer;
            Exception exception;
            exception;
            buffer;
            JVM INSTR monitorexit ;
            throw exception;
        }

        void receive(BufferedSource bufferedsource, long l)
            throws IOException
        {
_L6:
            Http2Stream http2stream;
            boolean flag;
            boolean flag1;
            if (l <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag) goto _L2; else goto _L1
_L1:
            http2stream = Http2Stream.this;
            http2stream;
            JVM INSTR monitorenter ;
            flag1 = finished;
            if (readBuffer.size() + l <= maxByteCount)
            {
                flag = true;
            } else
            {
                flag = false;
            }
              goto _L3
_L7:
            http2stream;
            JVM INSTR monitorexit ;
              goto _L4
            if ($assertionsDisabled || !Thread.holdsLock(Http2Stream.this)) goto _L6; else goto _L5
_L5:
            throw new AssertionError();
_L10:
            flag = false;
              goto _L7
            bufferedsource;
            http2stream;
            JVM INSTR monitorexit ;
            throw bufferedsource;
_L4:
            long l1;
            if (!flag)
            {
                if (!flag1)
                {
                    l1 = bufferedsource.read(receiveBuffer, l);
                    if (l1 == -1L)
                    {
                        throw new EOFException();
                    }
                } else
                {
                    bufferedsource.skip(l);
                    return;
                }
            } else
            {
                bufferedsource.skip(l);
                closeLater(ErrorCode.FLOW_CONTROL_ERROR);
                return;
            }
            l -= l1;
            http2stream = Http2Stream.this;
            http2stream;
            JVM INSTR monitorenter ;
            if (readBuffer.size() == 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            readBuffer.writeAll(receiveBuffer);
            if (flag)
            {
                break MISSING_BLOCK_LABEL_233;
            }
_L8:
            http2stream;
            JVM INSTR monitorexit ;
              goto _L6
            bufferedsource;
            http2stream;
            JVM INSTR monitorexit ;
            throw bufferedsource;
            notifyAll();
              goto _L8
_L2:
            return;
_L3:
            if (flag) goto _L10; else goto _L9
_L9:
            flag = true;
              goto _L7
        }

        public Timeout timeout()
        {
            return readTimeout;
        }

        static 
        {
            boolean flag = false;
            if (!okhttp3/internal/http2/Http2Stream.desiredAssertionStatus())
            {
                flag = true;
            }
            $assertionsDisabled = flag;
        }

        FramedDataSource(long l)
        {
            this$0 = Http2Stream.this;
            super();
            maxByteCount = l;
        }
    }

    class StreamTimeout extends AsyncTimeout
    {

        final Http2Stream this$0;

        public void exitAndThrowIfTimedOut()
            throws IOException
        {
            if (!exit())
            {
                return;
            } else
            {
                throw newTimeoutException(null);
            }
        }

        protected IOException newTimeoutException(IOException ioexception)
        {
            SocketTimeoutException sockettimeoutexception = new SocketTimeoutException("timeout");
            if (ioexception == null)
            {
                return sockettimeoutexception;
            } else
            {
                sockettimeoutexception.initCause(ioexception);
                return sockettimeoutexception;
            }
        }

        protected void timedOut()
        {
            closeLater(ErrorCode.CANCEL);
        }

        StreamTimeout()
        {
            this$0 = Http2Stream.this;
            super();
        }
    }


    static final boolean $assertionsDisabled;
    long bytesLeftInWriteWindow;
    final Http2Connection connection;
    ErrorCode errorCode;
    final int id;
    final StreamTimeout readTimeout = new StreamTimeout();
    private final List requestHeaders;
    private List responseHeaders;
    final FramedDataSink sink;
    private final FramedDataSource source;
    long unacknowledgedBytesRead;
    final StreamTimeout writeTimeout = new StreamTimeout();

    Http2Stream(int i, Http2Connection http2connection, boolean flag, boolean flag1, List list)
    {
        unacknowledgedBytesRead = 0L;
        errorCode = null;
        if (http2connection != null)
        {
            if (list != null)
            {
                id = i;
                connection = http2connection;
                bytesLeftInWriteWindow = http2connection.peerSettings.getInitialWindowSize();
                source = new FramedDataSource(http2connection.okHttpSettings.getInitialWindowSize());
                sink = new FramedDataSink();
                source.finished = flag1;
                sink.finished = flag;
                requestHeaders = list;
                return;
            } else
            {
                throw new NullPointerException("requestHeaders == null");
            }
        } else
        {
            throw new NullPointerException("connection == null");
        }
    }

    private boolean closeInternal(ErrorCode errorcode)
    {
_L6:
        this;
        JVM INSTR monitorenter ;
        if (errorCode != null) goto _L2; else goto _L1
_L1:
        if (source.finished) goto _L4; else goto _L3
_L3:
        errorCode = errorcode;
        notifyAll();
        this;
        JVM INSTR monitorexit ;
        connection.removeStream(id);
        return true;
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L6; else goto _L5
_L5:
        throw new AssertionError();
_L2:
        this;
        JVM INSTR monitorexit ;
        return false;
_L4:
        if (!sink.finished) goto _L3; else goto _L7
_L7:
        this;
        JVM INSTR monitorexit ;
        return false;
        errorcode;
        this;
        JVM INSTR monitorexit ;
        throw errorcode;
    }

    void addBytesToWriteWindow(long l)
    {
        bytesLeftInWriteWindow = bytesLeftInWriteWindow + l;
        boolean flag;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            notifyAll();
        }
    }

    void cancelStreamIfNecessary()
        throws IOException
    {
        boolean flag1 = false;
          goto _L1
_L5:
        this;
        JVM INSTR monitorenter ;
        if (!source.finished) goto _L3; else goto _L2
_L2:
        boolean flag = flag1;
_L7:
        boolean flag2 = isOpen();
        this;
        JVM INSTR monitorexit ;
        Exception exception;
        if (!flag)
        {
            if (flag2)
            {
                return;
            } else
            {
                connection.removeStream(id);
                return;
            }
        } else
        {
            close(ErrorCode.CANCEL);
            return;
        }
_L1:
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L5; else goto _L4
_L4:
        throw new AssertionError();
_L3:
        flag = flag1;
        if (!source.closed) goto _L7; else goto _L6
_L6:
        if (sink.finished)
        {
            break MISSING_BLOCK_LABEL_121;
        }
        if (sink.closed)
        {
            break MISSING_BLOCK_LABEL_121;
        }
        flag = flag1;
          goto _L7
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        flag = true;
          goto _L7
    }

    void checkOutNotClosed()
        throws IOException
    {
        if (!sink.closed)
        {
            if (!sink.finished)
            {
                if (errorCode == null)
                {
                    return;
                } else
                {
                    throw new StreamResetException(errorCode);
                }
            } else
            {
                throw new IOException("stream finished");
            }
        } else
        {
            throw new IOException("stream closed");
        }
    }

    public void close(ErrorCode errorcode)
        throws IOException
    {
        if (closeInternal(errorcode))
        {
            connection.writeSynReset(id, errorcode);
            return;
        } else
        {
            return;
        }
    }

    public void closeLater(ErrorCode errorcode)
    {
        if (closeInternal(errorcode))
        {
            connection.writeSynResetLater(id, errorcode);
            return;
        } else
        {
            return;
        }
    }

    public Http2Connection getConnection()
    {
        return connection;
    }

    public ErrorCode getErrorCode()
    {
        this;
        JVM INSTR monitorenter ;
        ErrorCode errorcode = errorCode;
        this;
        JVM INSTR monitorexit ;
        return errorcode;
        Exception exception;
        exception;
        throw exception;
    }

    public int getId()
    {
        return id;
    }

    public List getRequestHeaders()
    {
        return requestHeaders;
    }

    public List getResponseHeaders()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        readTimeout.enter();
_L4:
        List list = responseHeaders;
        if (list == null) goto _L2; else goto _L1
_L1:
        readTimeout.exitAndThrowIfTimedOut();
        if (responseHeaders == null)
        {
            throw new StreamResetException(errorCode);
        }
        break MISSING_BLOCK_LABEL_73;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
_L2:
        if (errorCode != null) goto _L1; else goto _L3
_L3:
        waitForIo();
          goto _L4
        exception;
        readTimeout.exitAndThrowIfTimedOut();
        throw exception;
        exception = responseHeaders;
        this;
        JVM INSTR monitorexit ;
        return exception;
    }

    public Sink getSink()
    {
        this;
        JVM INSTR monitorenter ;
        if (responseHeaders == null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return sink;
_L2:
        if (isLocallyInitiated()) goto _L1; else goto _L3
_L3:
        throw new IllegalStateException("reply before requesting the sink");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public Source getSource()
    {
        return source;
    }

    public boolean isLocallyInitiated()
    {
        boolean flag;
        if ((id & 1) != 1)
        {
            flag = false;
        } else
        {
            flag = true;
        }
        return connection.client == flag;
    }

    public boolean isOpen()
    {
        this;
        JVM INSTR monitorenter ;
        if (errorCode != null) goto _L2; else goto _L1
_L1:
        if (!source.finished) goto _L4; else goto _L3
_L3:
        if (!sink.finished) goto _L6; else goto _L5
_L5:
        List list = responseHeaders;
        if (list != null) goto _L8; else goto _L7
_L7:
        return true;
_L2:
        this;
        JVM INSTR monitorexit ;
        return false;
_L4:
        if (source.closed) goto _L3; else goto _L7
_L6:
        boolean flag = sink.closed;
        if (flag) goto _L5; else goto _L7
_L8:
        this;
        JVM INSTR monitorexit ;
        return false;
        Exception exception;
        exception;
        throw exception;
    }

    public Timeout readTimeout()
    {
        return readTimeout;
    }

    void receiveData(BufferedSource bufferedsource, int i)
        throws IOException
    {
        while ($assertionsDisabled || !Thread.holdsLock(this)) 
        {
            source.receive(bufferedsource, i);
            return;
        }
        throw new AssertionError();
    }

    void receiveFin()
    {
_L2:
        this;
        JVM INSTR monitorenter ;
        boolean flag;
        source.finished = true;
        flag = isOpen();
        notifyAll();
        this;
        JVM INSTR monitorexit ;
        Exception exception;
        if (flag)
        {
            return;
        } else
        {
            connection.removeStream(id);
            return;
        }
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L2; else goto _L1
_L1:
        throw new AssertionError();
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    void receiveHeaders(List list)
    {
_L2:
        boolean flag = true;
        this;
        JVM INSTR monitorenter ;
        if (responseHeaders == null)
        {
            break MISSING_BLOCK_LABEL_71;
        }
        ArrayList arraylist = new ArrayList();
        arraylist.addAll(responseHeaders);
        arraylist.addAll(list);
        responseHeaders = arraylist;
_L3:
        this;
        JVM INSTR monitorexit ;
        if (flag)
        {
            return;
        } else
        {
            connection.removeStream(id);
            return;
        }
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L2; else goto _L1
_L1:
        throw new AssertionError();
        responseHeaders = list;
        flag = isOpen();
        notifyAll();
          goto _L3
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    void receiveRstStream(ErrorCode errorcode)
    {
        this;
        JVM INSTR monitorenter ;
        ErrorCode errorcode1 = errorCode;
        if (errorcode1 == null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        errorCode = errorcode;
        notifyAll();
        if (true) goto _L1; else goto _L3
_L3:
        errorcode;
        throw errorcode;
    }

    public void reply(List list, boolean flag)
        throws IOException
    {
        boolean flag1 = false;
          goto _L1
_L9:
        this;
        JVM INSTR monitorenter ;
        if (list == null) goto _L3; else goto _L2
_L2:
        if (responseHeaders != null) goto _L5; else goto _L4
_L4:
        responseHeaders = list;
        if (!flag) goto _L7; else goto _L6
_L6:
        flag = flag1;
_L10:
        this;
        JVM INSTR monitorexit ;
        connection.writeSynReply(id, flag, list);
        if (!flag)
        {
            return;
        } else
        {
            connection.flush();
            return;
        }
_L1:
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L9; else goto _L8
_L8:
        throw new AssertionError();
_L3:
        throw new NullPointerException("responseHeaders == null");
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
_L5:
        throw new IllegalStateException("reply already sent");
_L7:
        sink.finished = true;
        flag = true;
          goto _L10
    }

    void waitForIo()
        throws InterruptedIOException
    {
        try
        {
            wait();
            return;
        }
        catch (InterruptedException interruptedexception)
        {
            throw new InterruptedIOException();
        }
    }

    public Timeout writeTimeout()
    {
        return writeTimeout;
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/http2/Http2Stream.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }
}
