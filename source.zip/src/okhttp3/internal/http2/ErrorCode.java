// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;


public final class ErrorCode extends Enum
{

    private static final ErrorCode $VALUES[];
    public static final ErrorCode CANCEL;
    public static final ErrorCode FLOW_CONTROL_ERROR;
    public static final ErrorCode INTERNAL_ERROR;
    public static final ErrorCode NO_ERROR;
    public static final ErrorCode PROTOCOL_ERROR;
    public static final ErrorCode REFUSED_STREAM;
    public final int httpCode;

    private ErrorCode(String s, int i, int j)
    {
        super(s, i);
        httpCode = j;
    }

    public static ErrorCode fromHttp2(int i)
    {
        ErrorCode aerrorcode[] = values();
        int k = aerrorcode.length;
        int j = 0;
        do
        {
            if (j >= k)
            {
                return null;
            }
            ErrorCode errorcode = aerrorcode[j];
            if (errorcode.httpCode != i)
            {
                j++;
            } else
            {
                return errorcode;
            }
        } while (true);
    }

    public static ErrorCode valueOf(String s)
    {
        return (ErrorCode)Enum.valueOf(okhttp3/internal/http2/ErrorCode, s);
    }

    public static ErrorCode[] values()
    {
        return (ErrorCode[])$VALUES.clone();
    }

    static 
    {
        NO_ERROR = new ErrorCode("NO_ERROR", 0, 0);
        PROTOCOL_ERROR = new ErrorCode("PROTOCOL_ERROR", 1, 1);
        INTERNAL_ERROR = new ErrorCode("INTERNAL_ERROR", 2, 2);
        FLOW_CONTROL_ERROR = new ErrorCode("FLOW_CONTROL_ERROR", 3, 3);
        REFUSED_STREAM = new ErrorCode("REFUSED_STREAM", 4, 7);
        CANCEL = new ErrorCode("CANCEL", 5, 8);
        $VALUES = (new ErrorCode[] {
            NO_ERROR, PROTOCOL_ERROR, INTERNAL_ERROR, FLOW_CONTROL_ERROR, REFUSED_STREAM, CANCEL
        });
    }
}
