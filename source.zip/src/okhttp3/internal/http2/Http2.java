// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import okhttp3.internal.Util;
import okio.ByteString;

public final class Http2
{

    static final String BINARY[];
    static final ByteString CONNECTION_PREFACE;
    static final String FLAGS[];
    static final byte FLAG_ACK = 1;
    static final byte FLAG_COMPRESSED = 32;
    static final byte FLAG_END_HEADERS = 4;
    static final byte FLAG_END_PUSH_PROMISE = 4;
    static final byte FLAG_END_STREAM = 1;
    static final byte FLAG_NONE = 0;
    static final byte FLAG_PADDED = 8;
    static final byte FLAG_PRIORITY = 32;
    private static final String FRAME_NAMES[];
    static final int INITIAL_MAX_FRAME_SIZE = 16384;
    static final byte TYPE_CONTINUATION = 9;
    static final byte TYPE_DATA = 0;
    static final byte TYPE_GOAWAY = 7;
    static final byte TYPE_HEADERS = 1;
    static final byte TYPE_PING = 6;
    static final byte TYPE_PRIORITY = 2;
    static final byte TYPE_PUSH_PROMISE = 5;
    static final byte TYPE_RST_STREAM = 3;
    static final byte TYPE_SETTINGS = 4;
    static final byte TYPE_WINDOW_UPDATE = 8;

    private Http2()
    {
    }

    static String formatFlags(byte byte0, byte byte1)
    {
        if (byte1 != 0)
        {
            switch (byte0)
            {
            case 5: // '\005'
            default:
                String s;
                if (byte1 >= FLAGS.length)
                {
                    s = BINARY[byte1];
                } else
                {
                    s = FLAGS[byte1];
                }
                if (byte0 != 5 || (byte1 & 4) == 0)
                {
                    if (byte0 != 0 || (byte1 & 0x20) == 0)
                    {
                        return s;
                    } else
                    {
                        return s.replace("PRIORITY", "COMPRESSED");
                    }
                } else
                {
                    return s.replace("HEADERS", "PUSH_PROMISE");
                }

            case 4: // '\004'
            case 6: // '\006'
                if (byte1 != 1)
                {
                    return BINARY[byte1];
                } else
                {
                    return "ACK";
                }

            case 2: // '\002'
            case 3: // '\003'
            case 7: // '\007'
            case 8: // '\b'
                return BINARY[byte1];
            }
        } else
        {
            return "";
        }
    }

    static String frameLog(boolean flag, int i, int j, byte byte0, byte byte1)
    {
        String s;
        String s1;
        String s2;
        if (byte0 >= FRAME_NAMES.length)
        {
            s = Util.format("0x%02x", new Object[] {
                Byte.valueOf(byte0)
            });
        } else
        {
            s = FRAME_NAMES[byte0];
        }
        s2 = formatFlags(byte0, byte1);
        if (!flag)
        {
            s1 = ">>";
        } else
        {
            s1 = "<<";
        }
        return Util.format("%s 0x%08x %5d %-13s %s", new Object[] {
            s1, Integer.valueOf(i), Integer.valueOf(j), s, s2
        });
    }

    static transient IllegalArgumentException illegalArgument(String s, Object aobj[])
    {
        throw new IllegalArgumentException(Util.format(s, aobj));
    }

    static transient IOException ioException(String s, Object aobj[])
        throws IOException
    {
        throw new IOException(Util.format(s, aobj));
    }

    static 
    {
        int i;
        boolean flag;
        flag = false;
        CONNECTION_PREFACE = ByteString.encodeUtf8("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
        FRAME_NAMES = (new String[] {
            "DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"
        });
        FLAGS = new String[64];
        BINARY = new String[256];
        i = 0;
_L7:
        if (i < BINARY.length) goto _L2; else goto _L1
_L1:
        int ai[];
        int j;
        FLAGS[0] = "";
        FLAGS[1] = "END_STREAM";
        ai = new int[1];
        ai[0] = 1;
        FLAGS[8] = "PADDED";
        j = ai.length;
        i = 0;
_L8:
        if (i < j) goto _L4; else goto _L3
_L3:
        int ai1[];
        int k;
        FLAGS[4] = "END_HEADERS";
        FLAGS[32] = "PRIORITY";
        FLAGS[36] = "END_HEADERS|PRIORITY";
        ai1 = new int[3];
        ai1[0] = 4;
        ai1[1] = 32;
        ai1[2] = 36;
        k = ai1.length;
        i = 0;
_L9:
        if (i < k) goto _L6; else goto _L5
_L5:
        i = ((flag) ? 1 : 0);
_L11:
        if (i >= FLAGS.length)
        {
            return;
        }
        break MISSING_BLOCK_LABEL_413;
_L2:
        BINARY[i] = Util.format("%8s", new Object[] {
            Integer.toBinaryString(i)
        }).replace(' ', '0');
        i++;
          goto _L7
_L4:
        int l = ai[i];
        FLAGS[l | 8] = (new StringBuilder()).append(FLAGS[l]).append("|PADDED").toString();
        i++;
          goto _L8
_L6:
        int i1;
        int j1;
        i1 = ai1[i];
        j1 = ai.length;
        j = 0;
_L10:
label0:
        {
            if (j < j1)
            {
                break label0;
            }
            i++;
        }
          goto _L9
        int k1 = ai[j];
        FLAGS[k1 | i1] = (new StringBuilder()).append(FLAGS[k1]).append('|').append(FLAGS[i1]).toString();
        FLAGS[k1 | i1 | 8] = (new StringBuilder()).append(FLAGS[k1]).append('|').append(FLAGS[i1]).append("|PADDED").toString();
        j++;
          goto _L10
        if (FLAGS[i] == null)
        {
            FLAGS[i] = BINARY[i];
        }
        i++;
          goto _L11
    }
}
