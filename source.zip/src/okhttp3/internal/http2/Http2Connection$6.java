// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.Set;
import okhttp3.internal.NamedRunnable;
import okio.Buffer;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, PushObserver, ErrorCode, Http2Writer

class val.inFinished extends NamedRunnable
{

    final Http2Connection this$0;
    final Buffer val$buffer;
    final int val$byteCount;
    final boolean val$inFinished;
    final int val$streamId;

    public void execute()
    {
        boolean flag;
        try
        {
            flag = pushObserver.onData(val$streamId, val$buffer, val$byteCount, val$inFinished);
        }
        catch (IOException ioexception)
        {
            return;
        }
        if (flag) goto _L2; else goto _L1
_L3:
        synchronized (Http2Connection.this)
        {
            currentPushRequests.remove(Integer.valueOf(val$streamId));
        }
        return;
_L2:
        writer.rstStream(val$streamId, ErrorCode.CANCEL);
          goto _L1
_L4:
        flag = val$inFinished;
        if (!flag)
        {
            return;
        } else
        {
            break; /* Loop/switch isn't completed */
        }
        exception;
        http2connection;
        JVM INSTR monitorexit ;
        throw exception;
_L1:
        if (!flag) goto _L4; else goto _L3
    }

    transient (int j, boolean flag)
    {
        this$0 = final_http2connection;
        val$streamId = i;
        val$buffer = Buffer.this;
        val$byteCount = j;
        val$inFinished = flag;
        super(final_s, final_aobj);
    }
}
