// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, ErrorCode, Http2Stream

static class  extends 
{

    public void onStream(Http2Stream http2stream)
        throws IOException
    {
        http2stream.close(ErrorCode.REFUSED_STREAM);
    }

    ()
    {
    }
}
