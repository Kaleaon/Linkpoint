// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import okhttp3.Protocol;
import okhttp3.internal.NamedRunnable;
import okhttp3.internal.Util;
import okhttp3.internal.platform.Platform;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;

// Referenced classes of package okhttp3.internal.http2:
//            Settings, Http2Writer, Http2Reader, Http2Stream, 
//            ConnectionShutdownException, ErrorCode, Ping, PushObserver

public final class Http2Connection
    implements Closeable
{
    public static class Builder
    {

        boolean client;
        String hostname;
        Listener listener;
        PushObserver pushObserver;
        BufferedSink sink;
        Socket socket;
        BufferedSource source;

        public Http2Connection build()
            throws IOException
        {
            return new Http2Connection(this);
        }

        public Builder listener(Listener listener1)
        {
            listener = listener1;
            return this;
        }

        public Builder pushObserver(PushObserver pushobserver)
        {
            pushObserver = pushobserver;
            return this;
        }

        public Builder socket(Socket socket1)
            throws IOException
        {
            return socket(socket1, ((InetSocketAddress)socket1.getRemoteSocketAddress()).getHostName(), Okio.buffer(Okio.source(socket1)), Okio.buffer(Okio.sink(socket1)));
        }

        public Builder socket(Socket socket1, String s, BufferedSource bufferedsource, BufferedSink bufferedsink)
        {
            socket = socket1;
            hostname = s;
            source = bufferedsource;
            sink = bufferedsink;
            return this;
        }

        public Builder(boolean flag)
        {
            listener = Listener.REFUSE_INCOMING_STREAMS;
            pushObserver = PushObserver.CANCEL;
            client = flag;
        }
    }

    public static abstract class Listener
    {

        public static final Listener REFUSE_INCOMING_STREAMS = new Listener() {

            public void onStream(Http2Stream http2stream)
                throws IOException
            {
                http2stream.close(ErrorCode.REFUSED_STREAM);
            }

        };

        public void onSettings(Http2Connection http2connection)
        {
        }

        public abstract void onStream(Http2Stream http2stream)
            throws IOException;


        public Listener()
        {
        }
    }

    class ReaderRunnable extends NamedRunnable
        implements Http2Reader.Handler
    {

        final Http2Reader reader;
        final Http2Connection this$0;

        private void applyAndAckSettings(Settings settings1)
        {
            Http2Connection.executor.execute("OkHttp %s ACK Settings". new NamedRunnable(new Object[] {
                hostname
            }, settings1) {

                final ReaderRunnable this$1;
                final Settings val$peerSettings;

                public void execute()
                {
                    try
                    {
                        writer.applyAndAckSettings(peerSettings);
                        return;
                    }
                    catch (IOException ioexception)
                    {
                        return;
                    }
                }

            transient 
            {
                this$1 = final_readerrunnable;
                peerSettings = settings;
                super(String.this, aobj);
            }
            });
        }

        public void ackSettings()
        {
        }

        public void alternateService(int i, String s, ByteString bytestring, String s1, int j, long l)
        {
        }

        public void data(boolean flag, int i, BufferedSource bufferedsource, int j)
            throws IOException
        {
            if (!pushedStream(i))
            {
                Http2Stream http2stream = getStream(i);
                if (http2stream != null)
                {
                    http2stream.receiveData(bufferedsource, j);
                    if (!flag)
                    {
                        return;
                    } else
                    {
                        http2stream.receiveFin();
                        return;
                    }
                } else
                {
                    writeSynResetLater(i, ErrorCode.PROTOCOL_ERROR);
                    bufferedsource.skip(j);
                    return;
                }
            } else
            {
                pushDataLater(i, bufferedsource, j, flag);
                return;
            }
        }

        protected void execute()
        {
            Object obj;
            ErrorCode errorcode;
            Object obj2;
            ErrorCode errorcode1;
            obj2 = ErrorCode.INTERNAL_ERROR;
            errorcode1 = ErrorCode.INTERNAL_ERROR;
            errorcode = ((ErrorCode) (obj2));
            obj = obj2;
            if (!client) goto _L2; else goto _L1
_L1:
            errorcode = ((ErrorCode) (obj2));
            obj = obj2;
            if (reader.nextFrame(this)) goto _L1; else goto _L3
_L3:
            errorcode = ((ErrorCode) (obj2));
            obj = obj2;
            obj2 = ErrorCode.NO_ERROR;
            errorcode = ((ErrorCode) (obj2));
            obj = obj2;
            ErrorCode errorcode2 = ErrorCode.CANCEL;
            IOException ioexception;
            Object obj1;
            try
            {
                close(((ErrorCode) (obj2)), errorcode2);
            }
            catch (IOException ioexception1) { }
            Util.closeQuietly(reader);
            return;
_L2:
            errorcode = ((ErrorCode) (obj2));
            obj = obj2;
            reader.readConnectionPreface();
              goto _L1
            obj;
            obj = errorcode;
            obj2 = ErrorCode.PROTOCOL_ERROR;
            obj = ErrorCode.PROTOCOL_ERROR;
            try
            {
                close(((ErrorCode) (obj2)), ((ErrorCode) (obj)));
            }
            // Misplaced declaration of an exception variable
            catch (IOException ioexception) { }
            Util.closeQuietly(reader);
            return;
            obj1;
            obj2 = obj;
            obj = obj1;
_L5:
            try
            {
                close(((ErrorCode) (obj2)), errorcode1);
            }
            // Misplaced declaration of an exception variable
            catch (Object obj1) { }
            Util.closeQuietly(reader);
            throw obj;
            obj;
            if (true) goto _L5; else goto _L4
_L4:
        }

        public void goAway(int i, ErrorCode errorcode, ByteString bytestring)
        {
            int j;
            int k;
            j = 0;
            bytestring.size();
            synchronized (Http2Connection.this)
            {
                bytestring = (Http2Stream[])streams.values().toArray(new Http2Stream[streams.size()]);
                shutdown = true;
            }
            k = bytestring.length;
_L2:
            if (j >= k)
            {
                return;
            }
            break MISSING_BLOCK_LABEL_78;
            bytestring;
            errorcode;
            JVM INSTR monitorexit ;
            throw bytestring;
            errorcode = bytestring[j];
            while (false) 
            {
                if (errorcode.getId() > i && errorcode.isLocallyInitiated())
                {
                    errorcode.receiveRstStream(ErrorCode.REFUSED_STREAM);
                    removeStream(errorcode.getId());
                }
                j++;
            }
            if (true) goto _L2; else goto _L1
_L1:
        }

        public void headers(boolean flag, int i, int j, List list)
        {
            if (pushedStream(i))
            {
                break MISSING_BLOCK_LABEL_60;
            }
            Http2Connection http2connection = Http2Connection.this;
            http2connection;
            JVM INSTR monitorenter ;
            Http2Stream http2stream;
            if (shutdown)
            {
                break MISSING_BLOCK_LABEL_72;
            }
            http2stream = getStream(i);
            if (http2stream == null)
            {
                break MISSING_BLOCK_LABEL_76;
            }
            http2connection;
            JVM INSTR monitorexit ;
            http2stream.receiveHeaders(list);
            if (!flag)
            {
                return;
            } else
            {
                http2stream.receiveFin();
                return;
            }
            pushHeadersLater(i, list, flag);
            return;
            http2connection;
            JVM INSTR monitorexit ;
            return;
            if (i > lastGoodStreamId)
            {
                if (i % 2 != nextStreamId % 2)
                {
                    list = new Http2Stream(i, Http2Connection.this, false, flag, list);
                    lastGoodStreamId = i;
                    streams.put(Integer.valueOf(i), list);
                    Http2Connection.executor.execute("OkHttp %s stream %d". new NamedRunnable(new Object[] {
                        hostname, Integer.valueOf(i)
                    }, list) {

                        final ReaderRunnable this$1;
                        final Http2Stream val$newStream;

                        public void execute()
                        {
                            try
                            {
                                listener.onStream(newStream);
                                return;
                            }
                            catch (IOException ioexception)
                            {
                                Platform.get().log(4, (new StringBuilder()).append("FramedConnection.Listener failure for ").append(hostname).toString(), ioexception);
                            }
                            try
                            {
                                newStream.close(ErrorCode.PROTOCOL_ERROR);
                                return;
                            }
                            catch (IOException ioexception1)
                            {
                                return;
                            }
                        }

            transient 
            {
                this$1 = final_readerrunnable;
                newStream = http2stream;
                super(String.this, aobj);
            }
                    });
                    return;
                }
                break MISSING_BLOCK_LABEL_196;
            }
            return;
            http2connection;
            JVM INSTR monitorexit ;
            return;
            list;
            http2connection;
            JVM INSTR monitorexit ;
            throw list;
        }

        public void ping(boolean flag, int i, int j)
        {
            if (!flag)
            {
                writePingLater(true, i, j, null);
            } else
            {
                Ping ping1 = removePing(i);
                if (ping1 != null)
                {
                    ping1.receive();
                    return;
                }
            }
        }

        public void priority(int i, int j, int k, boolean flag)
        {
        }

        public void pushPromise(int i, int j, List list)
        {
            pushRequestLater(j, list);
        }

        public void rstStream(int i, ErrorCode errorcode)
        {
            if (!pushedStream(i))
            {
                Http2Stream http2stream = removeStream(i);
                if (http2stream == null)
                {
                    return;
                } else
                {
                    http2stream.receiveRstStream(errorcode);
                    return;
                }
            } else
            {
                pushResetLater(i, errorcode);
                return;
            }
        }

        public void settings(boolean flag, Settings settings1)
        {
            Http2Connection http2connection = Http2Connection.this;
            http2connection;
            JVM INSTR monitorenter ;
            int i = peerSettings.getInitialWindowSize();
            if (flag) goto _L2; else goto _L1
_L1:
            int k;
            peerSettings.merge(settings1);
            applyAndAckSettings(settings1);
            k = peerSettings.getInitialWindowSize();
              goto _L3
_L11:
            Http2Connection.executor.execute(new NamedRunnable("OkHttp %s settings", new Object[] {
                hostname
            }) {

                final ReaderRunnable this$1;

                public void execute()
                {
                    listener.onSettings(_fld0);
                }

            transient 
            {
                this$1 = ReaderRunnable.this;
                super(s, aobj);
            }
            });
            http2connection;
            JVM INSTR monitorexit ;
              goto _L4
_L2:
            peerSettings.clear();
            continue; /* Loop/switch isn't completed */
            settings1;
            http2connection;
            JVM INSTR monitorexit ;
            throw settings1;
_L3:
            if (k == -1 || k == i) goto _L6; else goto _L5
_L5:
            long l1 = k - i;
            if (!receivedInitialPeerSettings) goto _L8; else goto _L7
_L7:
            if (streams.isEmpty())
            {
                settings1 = null;
                continue; /* Loop/switch isn't completed */
            }
            break; /* Loop/switch isn't completed */
_L8:
            addBytesToWriteWindow(l1);
            receivedInitialPeerSettings = true;
            if (true) goto _L7; else goto _L9
_L9:
            settings1 = (Http2Stream[])streams.values().toArray(new Http2Stream[streams.size()]);
            continue; /* Loop/switch isn't completed */
_L4:
            if (settings1 == null)
            {
                return;
            }
            if (l1 != 0L)
            {
                int l = settings1.length;
                for (int j = 0; j < l; j++)
                {
                    synchronized (settings1[j])
                    {
                        http2stream.addBytesToWriteWindow(l1);
                    }
                }

            }
            break; /* Loop/switch isn't completed */
            settings1;
            http2stream;
            JVM INSTR monitorexit ;
            throw settings1;
_L6:
            settings1 = null;
            l1 = 0L;
            if (true) goto _L11; else goto _L10
_L10:
            return;
            if (true) goto _L1; else goto _L12
_L12:
        }

        public void windowUpdate(int i, long l)
        {
            if (i != 0)
            {
                obj = getStream(i);
                if (obj == null)
                {
                    return;
                }
            } else
            {
                synchronized (Http2Connection.this)
                {
                    Http2Connection http2connection = Http2Connection.this;
                    http2connection.bytesLeftInWriteWindow = http2connection.bytesLeftInWriteWindow + l;
                    notifyAll();
                }
                return;
            }
            break MISSING_BLOCK_LABEL_66;
            exception;
            obj;
            JVM INSTR monitorexit ;
            throw exception;
            obj;
            JVM INSTR monitorenter ;
            ((Http2Stream) (obj)).addBytesToWriteWindow(l);
            obj;
            JVM INSTR monitorexit ;
            return;
            Exception exception1;
            exception1;
            obj;
            JVM INSTR monitorexit ;
            throw exception1;
        }

        ReaderRunnable(Http2Reader http2reader)
        {
            this$0 = Http2Connection.this;
            super("OkHttp %s", new Object[] {
                hostname
            });
            reader = http2reader;
        }
    }


    static final boolean $assertionsDisabled;
    private static final int OKHTTP_CLIENT_WINDOW_SIZE = 0x1000000;
    static final ExecutorService executor;
    long bytesLeftInWriteWindow;
    final boolean client;
    final Set currentPushRequests = new LinkedHashSet();
    final String hostname;
    int lastGoodStreamId;
    final Listener listener;
    private int nextPingId;
    int nextStreamId;
    Settings okHttpSettings;
    final Settings peerSettings = new Settings();
    private Map pings;
    private final ExecutorService pushExecutor;
    final PushObserver pushObserver;
    final ReaderRunnable readerRunnable;
    boolean receivedInitialPeerSettings;
    boolean shutdown;
    final Socket socket;
    final Map streams = new LinkedHashMap();
    long unacknowledgedBytesRead;
    final Http2Writer writer;

    Http2Connection(Builder builder)
    {
        byte byte0 = 2;
        super();
        unacknowledgedBytesRead = 0L;
        okHttpSettings = new Settings();
        receivedInitialPeerSettings = false;
        pushObserver = builder.pushObserver;
        client = builder.client;
        listener = builder.listener;
        int i;
        if (!builder.client)
        {
            i = 2;
        } else
        {
            i = 1;
        }
        nextStreamId = i;
        if (builder.client)
        {
            nextStreamId = nextStreamId + 2;
        }
        if (!builder.client)
        {
            i = byte0;
        } else
        {
            i = 1;
        }
        nextPingId = i;
        if (builder.client)
        {
            okHttpSettings.set(7, 0x1000000);
        }
        hostname = builder.hostname;
        pushExecutor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), Util.threadFactory(Util.format("OkHttp %s Push Observer", new Object[] {
            hostname
        }), true));
        peerSettings.set(7, 65535);
        peerSettings.set(5, 16384);
        bytesLeftInWriteWindow = peerSettings.getInitialWindowSize();
        socket = builder.socket;
        writer = new Http2Writer(builder.sink, client);
        readerRunnable = new ReaderRunnable(new Http2Reader(builder.source, client));
    }

    private Http2Stream newStream(int i, List list, boolean flag)
        throws IOException
    {
        Http2Writer http2writer;
        Http2Stream http2stream;
        boolean flag1;
        int j;
        boolean flag2;
        flag1 = false;
        if (flag)
        {
            flag2 = false;
        } else
        {
            flag2 = true;
        }
        http2writer = writer;
        http2writer;
        JVM INSTR monitorenter ;
        this;
        JVM INSTR monitorenter ;
        if (shutdown) goto _L2; else goto _L1
_L1:
        j = nextStreamId;
        nextStreamId = nextStreamId + 2;
        http2stream = new Http2Stream(j, this, flag2, false, list);
        if (flag) goto _L4; else goto _L3
_L13:
        if (http2stream.isOpen()) goto _L6; else goto _L5
_L5:
        this;
        JVM INSTR monitorexit ;
        if (i == 0) goto _L8; else goto _L7
_L7:
        if (client) goto _L10; else goto _L9
_L9:
        writer.pushPromise(i, j, list);
_L11:
        http2writer;
        JVM INSTR monitorexit ;
        if (!flag1)
        {
            return http2stream;
        } else
        {
            writer.flush();
            return http2stream;
        }
_L2:
        throw new ConnectionShutdownException();
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
        list;
        http2writer;
        JVM INSTR monitorexit ;
        throw list;
_L4:
        if (bytesLeftInWriteWindow != 0L && http2stream.bytesLeftInWriteWindow != 0L)
        {
            continue; /* Loop/switch isn't completed */
        }
          goto _L3
_L6:
        streams.put(Integer.valueOf(j), http2stream);
          goto _L5
_L8:
        writer.synStream(flag2, j, i, list);
          goto _L11
_L10:
        throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");
          goto _L5
_L3:
        flag1 = true;
        if (true) goto _L13; else goto _L12
_L12:
    }

    void addBytesToWriteWindow(long l)
    {
        bytesLeftInWriteWindow = bytesLeftInWriteWindow + l;
        boolean flag;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            notifyAll();
        }
    }

    public void close()
        throws IOException
    {
        close(ErrorCode.NO_ERROR, ErrorCode.CANCEL);
    }

    void close(ErrorCode errorcode, ErrorCode errorcode1)
        throws IOException
    {
_L8:
        shutdown(errorcode);
        errorcode = null;
_L9:
        this;
        JVM INSTR monitorenter ;
        if (!streams.isEmpty()) goto _L2; else goto _L1
_L1:
        Http2Stream ahttp2stream[] = null;
_L10:
        if (pings != null) goto _L4; else goto _L3
_L3:
        Ping aping[] = null;
_L11:
        this;
        JVM INSTR monitorexit ;
        if (ahttp2stream != null) goto _L6; else goto _L5
_L5:
        if (aping != null)
        {
            int l = aping.length;
            int j = 0;
            while (j < l) 
            {
                aping[j].cancel();
                j++;
            }
        }
        writer.close();
        errorcode1 = errorcode;
_L16:
        Object obj;
        IOException ioexception;
        int i;
        int k;
        try
        {
            socket.close();
        }
        // Misplaced declaration of an exception variable
        catch (ErrorCode errorcode1) { }
        if (errorcode1 == null)
        {
            return;
        } else
        {
            throw errorcode1;
        }
        if ($assertionsDisabled || !Thread.holdsLock(this)) goto _L8; else goto _L7
_L7:
        throw new AssertionError();
        errorcode;
          goto _L9
_L2:
        ahttp2stream = (Http2Stream[])streams.values().toArray(new Http2Stream[streams.size()]);
        streams.clear();
          goto _L10
_L4:
        aping = (Ping[])pings.values().toArray(new Ping[pings.size()]);
        pings = null;
          goto _L11
        errorcode;
        this;
        JVM INSTR monitorexit ;
        throw errorcode;
_L6:
        k = ahttp2stream.length;
        i = 0;
_L14:
        if (i < k) goto _L12; else goto _L5
_L12:
        obj = ahttp2stream[i];
        ((Http2Stream) (obj)).close(errorcode1);
        obj = errorcode;
_L15:
        i++;
        errorcode = ((ErrorCode) (obj));
        if (true) goto _L14; else goto _L13
_L13:
          goto _L5
        ioexception;
        obj = errorcode;
        if (errorcode != null)
        {
            obj = ioexception;
        }
          goto _L15
        errorcode1;
        if (errorcode != null)
        {
            errorcode1 = errorcode;
        }
          goto _L16
    }

    public void flush()
        throws IOException
    {
        writer.flush();
    }

    public Protocol getProtocol()
    {
        return Protocol.HTTP_2;
    }

    Http2Stream getStream(int i)
    {
        this;
        JVM INSTR monitorenter ;
        Http2Stream http2stream = (Http2Stream)streams.get(Integer.valueOf(i));
        this;
        JVM INSTR monitorexit ;
        return http2stream;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isShutdown()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = shutdown;
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    public int maxConcurrentStreams()
    {
        this;
        JVM INSTR monitorenter ;
        int i = peerSettings.getMaxConcurrentStreams(0x7fffffff);
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public Http2Stream newStream(List list, boolean flag)
        throws IOException
    {
        return newStream(0, list, flag);
    }

    public int openStreamCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = streams.size();
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public Ping ping()
        throws IOException
    {
        Ping ping1 = new Ping();
        this;
        JVM INSTR monitorenter ;
        if (shutdown) goto _L2; else goto _L1
_L1:
        int i;
        i = nextPingId;
        nextPingId = nextPingId + 2;
        if (pings == null)
        {
            break MISSING_BLOCK_LABEL_81;
        }
_L3:
        pings.put(Integer.valueOf(i), ping1);
        this;
        JVM INSTR monitorexit ;
        writePing(false, i, 0x4f4b6f6b, ping1);
        return ping1;
_L2:
        throw new ConnectionShutdownException();
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        pings = new LinkedHashMap();
          goto _L3
    }

    void pushDataLater(int i, BufferedSource bufferedsource, int j, boolean flag)
        throws IOException
    {
        Buffer buffer = new Buffer();
        bufferedsource.require(j);
        bufferedsource.read(buffer, j);
        if (buffer.size() != (long)j)
        {
            throw new IOException((new StringBuilder()).append(buffer.size()).append(" != ").append(j).toString());
        } else
        {
            pushExecutor.execute(new NamedRunnable(j, flag) {

                final Http2Connection this$0;
                final Buffer val$buffer;
                final int val$byteCount;
                final boolean val$inFinished;
                final int val$streamId;

                public void execute()
                {
                    boolean flag1;
                    try
                    {
                        flag1 = pushObserver.onData(streamId, buffer, byteCount, inFinished);
                    }
                    catch (IOException ioexception)
                    {
                        return;
                    }
                    if (flag1) goto _L2; else goto _L1
_L3:
                    synchronized (Http2Connection.this)
                    {
                        currentPushRequests.remove(Integer.valueOf(streamId));
                    }
                    return;
_L2:
                    writer.rstStream(streamId, ErrorCode.CANCEL);
                      goto _L1
_L4:
                    flag1 = inFinished;
                    if (!flag1)
                    {
                        return;
                    } else
                    {
                        break; /* Loop/switch isn't completed */
                    }
                    exception;
                    http2connection;
                    JVM INSTR monitorexit ;
                    throw exception;
_L1:
                    if (!flag1) goto _L4; else goto _L3
                }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                buffer = buffer1;
                byteCount = j;
                inFinished = flag;
                super(final_s, final_aobj);
            }
            });
            return;
        }
    }

    void pushHeadersLater(int i, List list, boolean flag)
    {
        pushExecutor.execute(new NamedRunnable(list, flag) {

            final Http2Connection this$0;
            final boolean val$inFinished;
            final List val$requestHeaders;
            final int val$streamId;

            public void execute()
            {
                boolean flag1 = pushObserver.onHeaders(streamId, requestHeaders, inFinished);
                if (flag1)
                {
                    try
                    {
                        writer.rstStream(streamId, ErrorCode.CANCEL);
                    }
                    catch (IOException ioexception)
                    {
                        return;
                    }
                }
                if (!flag1) goto _L2; else goto _L1
_L1:
                synchronized (Http2Connection.this)
                {
                    currentPushRequests.remove(Integer.valueOf(streamId));
                }
                return;
_L2:
                if (flag1 = inFinished) goto _L1; else goto _L3
_L3:
                return;
                exception;
                http2connection;
                JVM INSTR monitorexit ;
                throw exception;
            }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                requestHeaders = list;
                inFinished = flag;
                super(final_s, final_aobj);
            }
        });
    }

    void pushRequestLater(int i, List list)
    {
        this;
        JVM INSTR monitorenter ;
        if (currentPushRequests.contains(Integer.valueOf(i)))
        {
            break MISSING_BLOCK_LABEL_75;
        }
        currentPushRequests.add(Integer.valueOf(i));
        this;
        JVM INSTR monitorexit ;
        pushExecutor.execute(new NamedRunnable(i, list) {

            final Http2Connection this$0;
            final List val$requestHeaders;
            final int val$streamId;

            public void execute()
            {
                if (!pushObserver.onRequest(streamId, requestHeaders))
                {
                    return;
                }
                writer.rstStream(streamId, ErrorCode.CANCEL);
                synchronized (Http2Connection.this)
                {
                    currentPushRequests.remove(Integer.valueOf(streamId));
                }
                return;
                exception;
                http2connection;
                JVM INSTR monitorexit ;
                try
                {
                    throw exception;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                requestHeaders = list;
                super(final_s, final_aobj);
            }
        });
        return;
        writeSynResetLater(i, ErrorCode.PROTOCOL_ERROR);
        this;
        JVM INSTR monitorexit ;
        return;
        list;
        this;
        JVM INSTR monitorexit ;
        throw list;
    }

    void pushResetLater(int i, ErrorCode errorcode)
    {
        pushExecutor.execute(new NamedRunnable(i, errorcode) {

            final Http2Connection this$0;
            final ErrorCode val$errorCode;
            final int val$streamId;

            public void execute()
            {
                pushObserver.onReset(streamId, errorCode);
                synchronized (Http2Connection.this)
                {
                    currentPushRequests.remove(Integer.valueOf(streamId));
                }
                return;
                exception;
                http2connection;
                JVM INSTR monitorexit ;
                throw exception;
            }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                errorCode = errorcode;
                super(final_s, final_aobj);
            }
        });
    }

    public Http2Stream pushStream(int i, List list, boolean flag)
        throws IOException
    {
        if (!client)
        {
            return newStream(i, list, flag);
        } else
        {
            throw new IllegalStateException("Client cannot push requests.");
        }
    }

    boolean pushedStream(int i)
    {
        while (i == 0 || (i & 1) != 0) 
        {
            return false;
        }
        return true;
    }

    Ping removePing(int i)
    {
        Ping ping1 = null;
        this;
        JVM INSTR monitorenter ;
        Map map = pings;
        if (map != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return ping1;
_L2:
        ping1 = (Ping)pings.remove(Integer.valueOf(i));
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    Http2Stream removeStream(int i)
    {
        this;
        JVM INSTR monitorenter ;
        Http2Stream http2stream;
        http2stream = (Http2Stream)streams.remove(Integer.valueOf(i));
        notifyAll();
        this;
        JVM INSTR monitorexit ;
        return http2stream;
        Exception exception;
        exception;
        throw exception;
    }

    public void setSettings(Settings settings)
        throws IOException
    {
        Http2Writer http2writer = writer;
        http2writer;
        JVM INSTR monitorenter ;
        this;
        JVM INSTR monitorenter ;
        if (shutdown)
        {
            break MISSING_BLOCK_LABEL_37;
        }
        okHttpSettings.merge(settings);
        writer.settings(settings);
        this;
        JVM INSTR monitorexit ;
        http2writer;
        JVM INSTR monitorexit ;
        return;
        throw new ConnectionShutdownException();
        settings;
        this;
        JVM INSTR monitorexit ;
        throw settings;
        settings;
        http2writer;
        JVM INSTR monitorexit ;
        throw settings;
    }

    public void shutdown(ErrorCode errorcode)
        throws IOException
    {
        Http2Writer http2writer = writer;
        http2writer;
        JVM INSTR monitorenter ;
        this;
        JVM INSTR monitorenter ;
        int i;
        if (shutdown)
        {
            break MISSING_BLOCK_LABEL_43;
        }
        shutdown = true;
        i = lastGoodStreamId;
        this;
        JVM INSTR monitorexit ;
        writer.goAway(i, errorcode, Util.EMPTY_BYTE_ARRAY);
        http2writer;
        JVM INSTR monitorexit ;
        return;
        this;
        JVM INSTR monitorexit ;
        http2writer;
        JVM INSTR monitorexit ;
        return;
        errorcode;
        this;
        JVM INSTR monitorexit ;
        throw errorcode;
        errorcode;
        http2writer;
        JVM INSTR monitorexit ;
        throw errorcode;
    }

    public void start()
        throws IOException
    {
        start(true);
    }

    void start(boolean flag)
        throws IOException
    {
        if (flag) goto _L2; else goto _L1
_L1:
        (new Thread(readerRunnable)).start();
        return;
_L2:
        writer.connectionPreface();
        writer.settings(okHttpSettings);
        int i = okHttpSettings.getInitialWindowSize();
        if (i != 65535)
        {
            writer.windowUpdate(0, i - 65535);
        }
        if (true) goto _L1; else goto _L3
_L3:
    }


// JavaClassFileOutputException: Prev chain is broken

    void writePing(boolean flag, int i, int j, Ping ping1)
        throws IOException
    {
        Http2Writer http2writer = writer;
        http2writer;
        JVM INSTR monitorenter ;
        if (ping1 != null) goto _L2; else goto _L1
_L1:
        writer.ping(flag, i, j);
        http2writer;
        JVM INSTR monitorexit ;
        return;
_L2:
        ping1.send();
        if (true) goto _L1; else goto _L3
_L3:
        ping1;
        http2writer;
        JVM INSTR monitorexit ;
        throw ping1;
    }

    void writePingLater(boolean flag, int i, int j, Ping ping1)
    {
        executor.execute(new NamedRunnable(j, ping1) {

            final Http2Connection this$0;
            final int val$payload1;
            final int val$payload2;
            final Ping val$ping;
            final boolean val$reply;

            public void execute()
            {
                try
                {
                    writePing(reply, payload1, payload2, ping);
                    return;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }

            transient 
            {
                this$0 = Http2Connection.this;
                reply = flag;
                payload1 = i;
                payload2 = j;
                ping = ping1;
                super(final_s, final_aobj);
            }
        });
    }

    void writeSynReply(int i, boolean flag, List list)
        throws IOException
    {
        writer.synReply(flag, i, list);
    }

    void writeSynReset(int i, ErrorCode errorcode)
        throws IOException
    {
        writer.rstStream(i, errorcode);
    }

    void writeSynResetLater(int i, ErrorCode errorcode)
    {
        executor.execute(new NamedRunnable(i, errorcode) {

            final Http2Connection this$0;
            final ErrorCode val$errorCode;
            final int val$streamId;

            public void execute()
            {
                try
                {
                    writeSynReset(streamId, errorCode);
                    return;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                errorCode = errorcode;
                super(final_s, final_aobj);
            }
        });
    }

    void writeWindowUpdateLater(int i, long l)
    {
        executor.execute(new NamedRunnable(i, l) {

            final Http2Connection this$0;
            final int val$streamId;
            final long val$unacknowledgedBytesRead;

            public void execute()
            {
                try
                {
                    writer.windowUpdate(streamId, unacknowledgedBytesRead);
                    return;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }

            transient 
            {
                this$0 = Http2Connection.this;
                streamId = i;
                unacknowledgedBytesRead = l;
                super(final_s, final_aobj);
            }
        });
    }

    static 
    {
        boolean flag;
        if (okhttp3/internal/http2/Http2Connection.desiredAssertionStatus())
        {
            flag = false;
        } else
        {
            flag = true;
        }
        $assertionsDisabled = flag;
        executor = new ThreadPoolExecutor(0, 0x7fffffff, 60L, TimeUnit.SECONDS, new SynchronousQueue(), Util.threadFactory("OkHttp FramedConnection", true));
    }
}
