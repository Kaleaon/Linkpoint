// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;
import okio.Source;

// Referenced classes of package okhttp3.internal.http2:
//            Header, Huffman

final class Hpack
{
    static final class Reader
    {

        Header dynamicTable[];
        int dynamicTableByteCount;
        int headerCount;
        private final List headerList;
        private final int headerTableSizeSetting;
        private int maxDynamicTableByteCount;
        int nextHeaderIndex;
        private final BufferedSource source;

        private void adjustDynamicTableByteCount()
        {
            if (maxDynamicTableByteCount >= dynamicTableByteCount)
            {
                return;
            }
            if (maxDynamicTableByteCount != 0)
            {
                evictToRecoverBytes(dynamicTableByteCount - maxDynamicTableByteCount);
                return;
            } else
            {
                clearDynamicTable();
                return;
            }
        }

        private void clearDynamicTable()
        {
            Arrays.fill(dynamicTable, null);
            nextHeaderIndex = dynamicTable.length - 1;
            headerCount = 0;
            dynamicTableByteCount = 0;
        }

        private int dynamicTableIndex(int i)
        {
            return nextHeaderIndex + 1 + i;
        }

        private int evictToRecoverBytes(int i)
        {
            boolean flag = false;
            if (i <= 0)
            {
                return 0;
            }
            int k = dynamicTable.length;
            int j = i;
            i = ((flag) ? 1 : 0);
            do
            {
                for (k--; k < nextHeaderIndex || j <= 0;)
                {
                    System.arraycopy(dynamicTable, nextHeaderIndex + 1, dynamicTable, nextHeaderIndex + 1 + i, headerCount);
                    nextHeaderIndex = nextHeaderIndex + i;
                    return i;
                }

                j -= dynamicTable[k].hpackSize;
                dynamicTableByteCount = dynamicTableByteCount - dynamicTable[k].hpackSize;
                headerCount = headerCount - 1;
                i++;
            } while (true);
        }

        private ByteString getName(int i)
        {
            if (!isStaticHeader(i))
            {
                return dynamicTable[dynamicTableIndex(i - Hpack.STATIC_HEADER_TABLE.length)].name;
            } else
            {
                return Hpack.STATIC_HEADER_TABLE[i].name;
            }
        }

        private void insertIntoDynamicTable(int i, Header header)
        {
            headerList.add(header);
            int j = header.hpackSize;
            if (i != -1)
            {
                j -= dynamicTable[dynamicTableIndex(i)].hpackSize;
            }
            if (j <= maxDynamicTableByteCount)
            {
                int k = evictToRecoverBytes((dynamicTableByteCount + j) - maxDynamicTableByteCount);
                if (i != -1)
                {
                    int l = dynamicTableIndex(i);
                    dynamicTable[k + l + i] = header;
                } else
                {
                    if (headerCount + 1 > dynamicTable.length)
                    {
                        Header aheader[] = new Header[dynamicTable.length * 2];
                        System.arraycopy(dynamicTable, 0, aheader, dynamicTable.length, dynamicTable.length);
                        nextHeaderIndex = dynamicTable.length - 1;
                        dynamicTable = aheader;
                    }
                    i = nextHeaderIndex;
                    nextHeaderIndex = i - 1;
                    dynamicTable[i] = header;
                    headerCount = headerCount + 1;
                }
                dynamicTableByteCount = j + dynamicTableByteCount;
                return;
            } else
            {
                clearDynamicTable();
                return;
            }
        }

        private boolean isStaticHeader(int i)
        {
            while (i < 0 || i > Hpack.STATIC_HEADER_TABLE.length - 1) 
            {
                return false;
            }
            return true;
        }

        private int readByte()
            throws IOException
        {
            return source.readByte() & 0xff;
        }

        private void readIndexedHeader(int i)
            throws IOException
        {
            int j;
            if (!isStaticHeader(i))
            {
                j = dynamicTableIndex(i - Hpack.STATIC_HEADER_TABLE.length);
                break MISSING_BLOCK_LABEL_19;
            } else
            {
                Header header = Hpack.STATIC_HEADER_TABLE[i];
                headerList.add(header);
                return;
            }
            if (j < 0 || j > dynamicTable.length - 1)
            {
                throw new IOException((new StringBuilder()).append("Header index too large ").append(i + 1).toString());
            } else
            {
                headerList.add(dynamicTable[j]);
                return;
            }
        }

        private void readLiteralHeaderWithIncrementalIndexingIndexedName(int i)
            throws IOException
        {
            insertIntoDynamicTable(-1, new Header(getName(i), readByteString()));
        }

        private void readLiteralHeaderWithIncrementalIndexingNewName()
            throws IOException
        {
            insertIntoDynamicTable(-1, new Header(Hpack.checkLowercase(readByteString()), readByteString()));
        }

        private void readLiteralHeaderWithoutIndexingIndexedName(int i)
            throws IOException
        {
            ByteString bytestring = getName(i);
            ByteString bytestring1 = readByteString();
            headerList.add(new Header(bytestring, bytestring1));
        }

        private void readLiteralHeaderWithoutIndexingNewName()
            throws IOException
        {
            ByteString bytestring = Hpack.checkLowercase(readByteString());
            ByteString bytestring1 = readByteString();
            headerList.add(new Header(bytestring, bytestring1));
        }

        public List getAndResetHeaderList()
        {
            ArrayList arraylist = new ArrayList(headerList);
            headerList.clear();
            return arraylist;
        }

        int maxDynamicTableByteCount()
        {
            return maxDynamicTableByteCount;
        }

        ByteString readByteString()
            throws IOException
        {
            boolean flag = false;
            int i = readByte();
            if ((i & 0x80) == 128)
            {
                flag = true;
            }
            i = readInt(i, 127);
            if (!flag)
            {
                return source.readByteString(i);
            } else
            {
                return ByteString.of(Huffman.get().decode(source.readByteArray(i)));
            }
        }

        void readHeaders()
            throws IOException
        {
            do
            {
                if (source.exhausted())
                {
                    return;
                }
                int i = source.readByte() & 0xff;
                if (i != 128)
                {
                    if ((i & 0x80) != 128)
                    {
                        if (i != 64)
                        {
                            if ((i & 0x40) != 64)
                            {
                                if ((i & 0x20) != 32)
                                {
                                    if (i == 16 || i == 0)
                                    {
                                        readLiteralHeaderWithoutIndexingNewName();
                                    } else
                                    {
                                        readLiteralHeaderWithoutIndexingIndexedName(readInt(i, 15) - 1);
                                    }
                                } else
                                {
                                    for (maxDynamicTableByteCount = readInt(i, 31); maxDynamicTableByteCount < 0 || maxDynamicTableByteCount > headerTableSizeSetting;)
                                    {
                                        throw new IOException((new StringBuilder()).append("Invalid dynamic table size update ").append(maxDynamicTableByteCount).toString());
                                    }

                                    adjustDynamicTableByteCount();
                                }
                            } else
                            {
                                readLiteralHeaderWithIncrementalIndexingIndexedName(readInt(i, 63) - 1);
                            }
                        } else
                        {
                            readLiteralHeaderWithIncrementalIndexingNewName();
                        }
                    } else
                    {
                        readIndexedHeader(readInt(i, 127) - 1);
                    }
                } else
                {
                    throw new IOException("index == 0");
                }
            } while (true);
        }

        int readInt(int i, int j)
            throws IOException
        {
            boolean flag = false;
            i &= j;
            if (i >= j)
            {
                i = ((flag) ? 1 : 0);
                break MISSING_BLOCK_LABEL_13;
            } else
            {
                return i;
            }
            do
            {
                int k = readByte();
                if ((k & 0x80) == 0)
                {
                    return (k << i) + j;
                }
                j += (k & 0x7f) << i;
                i += 7;
            } while (true);
        }

        Reader(int i, int j, Source source1)
        {
            headerList = new ArrayList();
            dynamicTable = new Header[8];
            nextHeaderIndex = dynamicTable.length - 1;
            headerCount = 0;
            dynamicTableByteCount = 0;
            headerTableSizeSetting = i;
            maxDynamicTableByteCount = j;
            source = Okio.buffer(source1);
        }

        Reader(int i, Source source1)
        {
            this(i, i, source1);
        }
    }

    static final class Writer
    {

        private static final int SETTINGS_HEADER_TABLE_SIZE = 4096;
        private static final int SETTINGS_HEADER_TABLE_SIZE_LIMIT = 16384;
        Header dynamicTable[];
        int dynamicTableByteCount;
        private boolean emitDynamicTableSizeUpdate;
        int headerCount;
        int headerTableSizeSetting;
        int maxDynamicTableByteCount;
        int nextHeaderIndex;
        private final Buffer out;
        private int smallestHeaderTableSizeSetting;
        private final boolean useCompression;

        private void adjustDynamicTableByteCount()
        {
            if (maxDynamicTableByteCount >= dynamicTableByteCount)
            {
                return;
            }
            if (maxDynamicTableByteCount != 0)
            {
                evictToRecoverBytes(dynamicTableByteCount - maxDynamicTableByteCount);
                return;
            } else
            {
                clearDynamicTable();
                return;
            }
        }

        private void clearDynamicTable()
        {
            Arrays.fill(dynamicTable, null);
            nextHeaderIndex = dynamicTable.length - 1;
            headerCount = 0;
            dynamicTableByteCount = 0;
        }

        private int evictToRecoverBytes(int i)
        {
            boolean flag = false;
            if (i <= 0)
            {
                return 0;
            }
            int k = dynamicTable.length;
            int j = i;
            i = ((flag) ? 1 : 0);
            do
            {
                for (k--; k < nextHeaderIndex || j <= 0;)
                {
                    System.arraycopy(dynamicTable, nextHeaderIndex + 1, dynamicTable, nextHeaderIndex + 1 + i, headerCount);
                    Arrays.fill(dynamicTable, nextHeaderIndex + 1, nextHeaderIndex + 1 + i, null);
                    nextHeaderIndex = nextHeaderIndex + i;
                    return i;
                }

                j -= dynamicTable[k].hpackSize;
                dynamicTableByteCount = dynamicTableByteCount - dynamicTable[k].hpackSize;
                headerCount = headerCount - 1;
                i++;
            } while (true);
        }

        private void insertIntoDynamicTable(Header header)
        {
            int i = header.hpackSize;
            if (i <= maxDynamicTableByteCount)
            {
                evictToRecoverBytes((dynamicTableByteCount + i) - maxDynamicTableByteCount);
                int j;
                if (headerCount + 1 > dynamicTable.length)
                {
                    Header aheader[] = new Header[dynamicTable.length * 2];
                    System.arraycopy(dynamicTable, 0, aheader, dynamicTable.length, dynamicTable.length);
                    nextHeaderIndex = dynamicTable.length - 1;
                    dynamicTable = aheader;
                }
                j = nextHeaderIndex;
                nextHeaderIndex = j - 1;
                dynamicTable[j] = header;
                headerCount = headerCount + 1;
                dynamicTableByteCount = i + dynamicTableByteCount;
                return;
            } else
            {
                clearDynamicTable();
                return;
            }
        }

        void setHeaderTableSizeSetting(int i)
        {
            headerTableSizeSetting = i;
            i = Math.min(i, 16384);
            if (maxDynamicTableByteCount != i)
            {
                if (i < maxDynamicTableByteCount)
                {
                    smallestHeaderTableSizeSetting = Math.min(smallestHeaderTableSizeSetting, i);
                }
                emitDynamicTableSizeUpdate = true;
                maxDynamicTableByteCount = i;
                adjustDynamicTableByteCount();
                return;
            } else
            {
                return;
            }
        }

        void writeByteString(ByteString bytestring)
            throws IOException
        {
            while (!useCompression || Huffman.get().encodedLength(bytestring) >= bytestring.size()) 
            {
                writeInt(bytestring.size(), 127, 0);
                out.write(bytestring);
                return;
            }
            Buffer buffer = new Buffer();
            Huffman.get().encode(bytestring, buffer);
            bytestring = buffer.readByteString();
            writeInt(bytestring.size(), 127, 128);
            out.write(bytestring);
        }

        void writeHeaders(List list)
            throws IOException
        {
            int k;
            int k1;
            if (emitDynamicTableSizeUpdate)
            {
                if (smallestHeaderTableSizeSetting < maxDynamicTableByteCount)
                {
                    writeInt(smallestHeaderTableSizeSetting, 31, 32);
                }
                emitDynamicTableSizeUpdate = false;
                smallestHeaderTableSizeSetting = 0x7fffffff;
                writeInt(maxDynamicTableByteCount, 31, 32);
            }
            k1 = list.size();
            k = 0;
_L3:
            Header header;
            ByteString bytestring;
            ByteString bytestring1;
            int i;
            int j;
            int i1;
            int j1;
            if (k >= k1)
            {
                return;
            }
            header = (Header)list.get(k);
            bytestring = header.name.toAsciiLowercase();
            bytestring1 = header.value;
            Integer integer = (Integer)Hpack.NAME_TO_FIRST_INDEX.get(bytestring);
            if (integer == null)
            {
                j = -1;
                i = -1;
            } else
            {
                j = integer.intValue() + 1;
                if (j <= 1 || j >= 8)
                {
                    i = -1;
                } else
                if (!Util.equal(Hpack.STATIC_HEADER_TABLE[j - 1].value, bytestring1))
                {
                    if (!Util.equal(Hpack.STATIC_HEADER_TABLE[j].value, bytestring1))
                    {
                        i = -1;
                    } else
                    {
                        i = j + 1;
                    }
                } else
                {
                    i = j;
                }
            }
            if (i == -1) goto _L2; else goto _L1
_L1:
            j1 = i;
            i1 = j;
_L5:
            int l;
            int l1;
            if (j1 == -1)
            {
                if (i1 != -1)
                {
                    if (!bytestring.startsWith(Header.PSEUDO_PREFIX) || Header.TARGET_AUTHORITY.equals(bytestring))
                    {
                        writeInt(i1, 63, 64);
                        writeByteString(bytestring1);
                        insertIntoDynamicTable(header);
                    } else
                    {
                        writeInt(i1, 15, 0);
                        writeByteString(bytestring1);
                    }
                } else
                {
                    out.writeByte(64);
                    writeByteString(bytestring);
                    writeByteString(bytestring1);
                    insertIntoDynamicTable(header);
                }
            } else
            {
                writeInt(j1, 127, 128);
            }
            k++;
            if (true) goto _L3; else goto _L2
_L2:
            l = nextHeaderIndex + 1;
            l1 = dynamicTable.length;
_L6:
            i1 = j;
            j1 = i;
            if (l >= l1) goto _L5; else goto _L4
_L4:
            if (!Util.equal(dynamicTable[l].name, bytestring))
            {
                i1 = j;
            } else
            {
label0:
                {
                    if (Util.equal(dynamicTable[l].value, bytestring1))
                    {
                        break label0;
                    }
                    i1 = j;
                    if (j == -1)
                    {
                        i1 = (l - nextHeaderIndex) + Hpack.STATIC_HEADER_TABLE.length;
                    }
                }
            }
            l++;
            j = i1;
              goto _L6
            j1 = (l - nextHeaderIndex) + Hpack.STATIC_HEADER_TABLE.length;
            i1 = j;
              goto _L5
        }

        void writeInt(int i, int j, int k)
        {
            if (i < j) goto _L2; else goto _L1
_L1:
            out.writeByte(k | j);
            i -= j;
_L4:
            if (i < 128)
            {
                out.writeByte(i);
                return;
            }
            out.writeByte(i & 0x7f | 0x80);
            i >>>= 7;
            continue; /* Loop/switch isn't completed */
_L2:
            out.writeByte(k | i);
            return;
            if (true) goto _L4; else goto _L3
_L3:
        }

        Writer(int i, boolean flag, Buffer buffer)
        {
            smallestHeaderTableSizeSetting = 0x7fffffff;
            dynamicTable = new Header[8];
            nextHeaderIndex = dynamicTable.length - 1;
            headerCount = 0;
            dynamicTableByteCount = 0;
            headerTableSizeSetting = i;
            maxDynamicTableByteCount = i;
            useCompression = flag;
            out = buffer;
        }

        Writer(Buffer buffer)
        {
            this(4096, true, buffer);
        }
    }


    static final Map NAME_TO_FIRST_INDEX = nameToFirstIndex();
    private static final int PREFIX_4_BITS = 15;
    private static final int PREFIX_5_BITS = 31;
    private static final int PREFIX_6_BITS = 63;
    private static final int PREFIX_7_BITS = 127;
    static final Header STATIC_HEADER_TABLE[];

    private Hpack()
    {
    }

    static ByteString checkLowercase(ByteString bytestring)
        throws IOException
    {
        int i;
        int j;
        i = 0;
        j = bytestring.size();
_L2:
        byte byte0;
        if (i >= j)
        {
            return bytestring;
        }
        byte0 = bytestring.getByte(i);
          goto _L1
_L4:
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        if (byte0 < 65 || byte0 > 90) goto _L4; else goto _L3
_L3:
        throw new IOException((new StringBuilder()).append("PROTOCOL_ERROR response malformed: mixed case name: ").append(bytestring.utf8()).toString());
    }

    private static Map nameToFirstIndex()
    {
        int i = 0;
        LinkedHashMap linkedhashmap = new LinkedHashMap(STATIC_HEADER_TABLE.length);
        do
        {
            if (i >= STATIC_HEADER_TABLE.length)
            {
                return Collections.unmodifiableMap(linkedhashmap);
            }
            if (!linkedhashmap.containsKey(STATIC_HEADER_TABLE[i].name))
            {
                linkedhashmap.put(STATIC_HEADER_TABLE[i].name, Integer.valueOf(i));
            }
            i++;
        } while (true);
    }

    static 
    {
        STATIC_HEADER_TABLE = (new Header[] {
            new Header(Header.TARGET_AUTHORITY, ""), new Header(Header.TARGET_METHOD, "GET"), new Header(Header.TARGET_METHOD, "POST"), new Header(Header.TARGET_PATH, "/"), new Header(Header.TARGET_PATH, "/index.html"), new Header(Header.TARGET_SCHEME, "http"), new Header(Header.TARGET_SCHEME, "https"), new Header(Header.RESPONSE_STATUS, "200"), new Header(Header.RESPONSE_STATUS, "204"), new Header(Header.RESPONSE_STATUS, "206"), 
            new Header(Header.RESPONSE_STATUS, "304"), new Header(Header.RESPONSE_STATUS, "400"), new Header(Header.RESPONSE_STATUS, "404"), new Header(Header.RESPONSE_STATUS, "500"), new Header("accept-charset", ""), new Header("accept-encoding", "gzip, deflate"), new Header("accept-language", ""), new Header("accept-ranges", ""), new Header("accept", ""), new Header("access-control-allow-origin", ""), 
            new Header("age", ""), new Header("allow", ""), new Header("authorization", ""), new Header("cache-control", ""), new Header("content-disposition", ""), new Header("content-encoding", ""), new Header("content-language", ""), new Header("content-length", ""), new Header("content-location", ""), new Header("content-range", ""), 
            new Header("content-type", ""), new Header("cookie", ""), new Header("date", ""), new Header("etag", ""), new Header("expect", ""), new Header("expires", ""), new Header("from", ""), new Header("host", ""), new Header("if-match", ""), new Header("if-modified-since", ""), 
            new Header("if-none-match", ""), new Header("if-range", ""), new Header("if-unmodified-since", ""), new Header("last-modified", ""), new Header("link", ""), new Header("location", ""), new Header("max-forwards", ""), new Header("proxy-authenticate", ""), new Header("proxy-authorization", ""), new Header("range", ""), 
            new Header("referer", ""), new Header("refresh", ""), new Header("retry-after", ""), new Header("server", ""), new Header("set-cookie", ""), new Header("strict-transport-security", ""), new Header("transfer-encoding", ""), new Header("user-agent", ""), new Header("vary", ""), new Header("via", ""), 
            new Header("www-authenticate", "")
        });
    }
}
