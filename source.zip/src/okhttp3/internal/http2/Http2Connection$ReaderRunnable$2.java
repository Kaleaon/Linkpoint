// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection

class this._cls1 extends NamedRunnable
{

    final is._cls0 this$1;

    public void execute()
    {
        listener.gs(_fld0);
    }

    transient (String s, Object aobj[])
    {
        this$1 = this._cls1.this;
        super(s, aobj);
    }
}
