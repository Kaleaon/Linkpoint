// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http2;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import okhttp3.internal.NamedRunnable;

// Referenced classes of package okhttp3.internal.http2:
//            Http2Connection, PushObserver, ErrorCode, Http2Writer

class val.inFinished extends NamedRunnable
{

    final Http2Connection this$0;
    final boolean val$inFinished;
    final List val$requestHeaders;
    final int val$streamId;

    public void execute()
    {
        boolean flag = pushObserver.onHeaders(val$streamId, val$requestHeaders, val$inFinished);
        if (flag)
        {
            try
            {
                writer.rstStream(val$streamId, ErrorCode.CANCEL);
            }
            catch (IOException ioexception)
            {
                return;
            }
        }
        if (!flag) goto _L2; else goto _L1
_L1:
        synchronized (Http2Connection.this)
        {
            currentPushRequests.remove(Integer.valueOf(val$streamId));
        }
        return;
_L2:
        if (flag = val$inFinished) goto _L1; else goto _L3
_L3:
        return;
        exception;
        http2connection;
        JVM INSTR monitorexit ;
        throw exception;
    }

    transient (List list, boolean flag)
    {
        this$0 = final_http2connection;
        val$streamId = I.this;
        val$requestHeaders = list;
        val$inFinished = flag;
        super(final_s, final_aobj);
    }
}
