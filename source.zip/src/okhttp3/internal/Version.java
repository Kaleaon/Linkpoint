// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal;


public final class Version
{

    private Version()
    {
    }

    public static String userAgent()
    {
        return "okhttp/3.5.0";
    }
}
