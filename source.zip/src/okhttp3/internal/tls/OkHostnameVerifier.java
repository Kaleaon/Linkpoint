// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3.internal.tls:
//            DistinguishedNameParser

public final class OkHostnameVerifier
    implements HostnameVerifier
{

    private static final int ALT_DNS_NAME = 2;
    private static final int ALT_IPA_NAME = 7;
    public static final OkHostnameVerifier INSTANCE = new OkHostnameVerifier();

    private OkHostnameVerifier()
    {
    }

    public static List allSubjectAltNames(X509Certificate x509certificate)
    {
        List list = getSubjectAltNames(x509certificate, 7);
        x509certificate = getSubjectAltNames(x509certificate, 2);
        ArrayList arraylist = new ArrayList(list.size() + x509certificate.size());
        arraylist.addAll(list);
        arraylist.addAll(x509certificate);
        return arraylist;
    }

    private static List getSubjectAltNames(X509Certificate x509certificate, int i)
    {
        ArrayList arraylist = new ArrayList();
        Object obj;
        Integer integer;
        try
        {
            x509certificate = x509certificate.getSubjectAlternativeNames();
        }
        // Misplaced declaration of an exception variable
        catch (X509Certificate x509certificate)
        {
            return Collections.emptyList();
        }
        if (x509certificate == null) goto _L2; else goto _L1
_L1:
        x509certificate = x509certificate.iterator();
_L5:
        if (!x509certificate.hasNext())
        {
            return arraylist;
        }
          goto _L3
_L2:
        return Collections.emptyList();
_L3:
        obj = (List)x509certificate.next();
        if (obj == null) goto _L5; else goto _L4
_L4:
        if (((List) (obj)).size() < 2) goto _L5; else goto _L6
_L6:
        integer = (Integer)((List) (obj)).get(0);
        if (integer == null) goto _L5; else goto _L7
_L7:
        if (integer.intValue() != i) goto _L5; else goto _L8
_L8:
        obj = (String)((List) (obj)).get(1);
        if (obj == null) goto _L5; else goto _L9
_L9:
        arraylist.add(obj);
          goto _L5
    }

    private boolean verifyHostname(String s, String s1)
    {
        int i;
        while (s == null || s.length() == 0 || s.startsWith(".") || s.endsWith("..")) 
        {
            return false;
        }
        while (s1 == null || s1.length() == 0 || s1.startsWith(".") || s1.endsWith("..")) 
        {
            return false;
        }
        if (!s.endsWith("."))
        {
            s = (new StringBuilder()).append(s).append('.').toString();
        }
        if (!s1.endsWith("."))
        {
            s1 = (new StringBuilder()).append(s1).append('.').toString();
        }
        s1 = s1.toLowerCase(Locale.US);
        if (s1.contains("*"))
        {
            if (!s1.startsWith("*.") || s1.indexOf('*', 1) != -1)
            {
                return false;
            }
        } else
        {
            return s.equals(s1);
        }
        if (s.length() >= s1.length())
        {
            if (!"*.".equals(s1))
            {
label0:
                {
                    s1 = s1.substring(1);
                    if (s.endsWith(s1))
                    {
                        i = s.length() - s1.length();
                        break label0;
                    } else
                    {
                        return false;
                    }
                }
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
        return i <= 0 || s.lastIndexOf('.', i - 1) == -1;
    }

    private boolean verifyHostname(String s, X509Certificate x509certificate)
    {
        List list;
        boolean flag;
        int i;
        int j;
        s = s.toLowerCase(Locale.US);
        list = getSubjectAltNames(x509certificate, 2);
        j = list.size();
        i = 0;
        flag = false;
_L7:
        if (i < j) goto _L2; else goto _L1
_L1:
        if (!flag) goto _L4; else goto _L3
_L3:
        return false;
_L2:
        if (!verifyHostname(s, (String)list.get(i)))
        {
            i++;
            flag = true;
        } else
        {
            return true;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if ((x509certificate = (new DistinguishedNameParser(x509certificate.getSubjectX500Principal())).findMostSpecific("cn")) == null) goto _L3; else goto _L5
_L5:
        return verifyHostname(s, ((String) (x509certificate)));
        if (true) goto _L7; else goto _L6
_L6:
    }

    private boolean verifyIpAddress(String s, X509Certificate x509certificate)
    {
        x509certificate = getSubjectAltNames(x509certificate, 7);
        int j = x509certificate.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return false;
            }
            if (!s.equalsIgnoreCase((String)x509certificate.get(i)))
            {
                i++;
            } else
            {
                return true;
            }
        } while (true);
    }

    public boolean verify(String s, X509Certificate x509certificate)
    {
        if (!Util.verifyAsIpAddress(s))
        {
            return verifyHostname(s, x509certificate);
        } else
        {
            return verifyIpAddress(s, x509certificate);
        }
    }

    public boolean verify(String s, SSLSession sslsession)
    {
        boolean flag;
        try
        {
            flag = verify(s, (X509Certificate)sslsession.getPeerCertificates()[0]);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return false;
        }
        return flag;
    }

}
