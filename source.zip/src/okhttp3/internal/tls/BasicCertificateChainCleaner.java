// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.security.GeneralSecurityException;
import java.security.Principal;
import java.security.cert.X509Certificate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

// Referenced classes of package okhttp3.internal.tls:
//            CertificateChainCleaner, TrustRootIndex

public final class BasicCertificateChainCleaner extends CertificateChainCleaner
{

    private static final int MAX_SIGNERS = 9;
    private final TrustRootIndex trustRootIndex;

    public BasicCertificateChainCleaner(TrustRootIndex trustrootindex)
    {
        trustRootIndex = trustrootindex;
    }

    private boolean verifySignature(X509Certificate x509certificate, X509Certificate x509certificate1)
    {
        if (x509certificate.getIssuerDN().equals(x509certificate1.getSubjectDN()))
        {
            try
            {
                x509certificate.verify(x509certificate1.getPublicKey());
            }
            // Misplaced declaration of an exception variable
            catch (X509Certificate x509certificate)
            {
                return false;
            }
            return true;
        } else
        {
            return false;
        }
    }

    public List clean(List list, String s)
        throws SSLPeerUnverifiedException
    {
        X509Certificate x509certificate;
        Object obj;
        boolean flag;
        int i;
        list = new ArrayDeque(list);
        s = new ArrayList();
        s.add(list.removeFirst());
        i = 0;
        flag = false;
        break MISSING_BLOCK_LABEL_36;
_L3:
        if (verifySignature(((X509Certificate) (obj)), ((X509Certificate) (obj)))) goto _L2; else goto _L1
_L1:
        flag = true;
_L4:
        i++;
        if (i >= 9)
        {
            throw new SSLPeerUnverifiedException((new StringBuilder()).append("Certificate chain too long: ").append(s).toString());
        }
        x509certificate = (X509Certificate)s.get(s.size() - 1);
        obj = trustRootIndex.findByIssuerAndSignature(x509certificate);
        if (obj == null)
        {
            obj = list.iterator();
            break MISSING_BLOCK_LABEL_111;
        }
        if (s.size() > 1 || !x509certificate.equals(obj))
        {
            s.add(obj);
        }
          goto _L3
_L2:
        return s;
        do
        {
            X509Certificate x509certificate1;
            if (!((Iterator) (obj)).hasNext())
            {
                if (!flag)
                {
                    throw new SSLPeerUnverifiedException((new StringBuilder()).append("Failed to find a trusted cert that signed ").append(x509certificate).toString());
                } else
                {
                    return s;
                }
            }
            x509certificate1 = (X509Certificate)((Iterator) (obj)).next();
        } while (!verifySignature(x509certificate, x509certificate1));
        ((Iterator) (obj)).remove();
        s.add(x509certificate1);
          goto _L4
    }

    public boolean equals(Object obj)
    {
label0:
        {
            boolean flag = true;
            if (obj != this)
            {
                break label0;
            } else
            {
                return true;
            }
        }
        if (!(obj instanceof BasicCertificateChainCleaner) || !((BasicCertificateChainCleaner)obj).trustRootIndex.equals(trustRootIndex))
        {
            flag = false;
        }
        return flag;
    }

    public int hashCode()
    {
        return trustRootIndex.hashCode();
    }
}
