// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.X509TrustManager;

public abstract class TrustRootIndex
{
    static final class AndroidTrustRootIndex extends TrustRootIndex
    {

        private final Method findByIssuerAndSignatureMethod;
        private final X509TrustManager trustManager;

        public boolean equals(Object obj)
        {
label0:
            {
                boolean flag = true;
                if (obj != this)
                {
                    if (obj instanceof AndroidTrustRootIndex)
                    {
                        obj = (AndroidTrustRootIndex)obj;
                        break label0;
                    } else
                    {
                        return false;
                    }
                } else
                {
                    return true;
                }
            }
            if (!trustManager.equals(((AndroidTrustRootIndex) (obj)).trustManager) || !findByIssuerAndSignatureMethod.equals(((AndroidTrustRootIndex) (obj)).findByIssuerAndSignatureMethod))
            {
                flag = false;
            }
            return flag;
        }

        public X509Certificate findByIssuerAndSignature(X509Certificate x509certificate)
        {
            try
            {
                x509certificate = (TrustAnchor)findByIssuerAndSignatureMethod.invoke(trustManager, new Object[] {
                    x509certificate
                });
            }
            // Misplaced declaration of an exception variable
            catch (X509Certificate x509certificate)
            {
                throw new AssertionError();
            }
            // Misplaced declaration of an exception variable
            catch (X509Certificate x509certificate)
            {
                return null;
            }
            if (x509certificate == null)
            {
                return null;
            }
            x509certificate = x509certificate.getTrustedCert();
            return x509certificate;
        }

        public int hashCode()
        {
            return trustManager.hashCode() + findByIssuerAndSignatureMethod.hashCode() * 31;
        }

        AndroidTrustRootIndex(X509TrustManager x509trustmanager, Method method)
        {
            findByIssuerAndSignatureMethod = method;
            trustManager = x509trustmanager;
        }
    }

    static final class BasicTrustRootIndex extends TrustRootIndex
    {

        private final Map subjectToCaCerts = new LinkedHashMap();

        public boolean equals(Object obj)
        {
label0:
            {
                boolean flag = true;
                if (obj != this)
                {
                    break label0;
                } else
                {
                    return true;
                }
            }
            if (!(obj instanceof BasicTrustRootIndex) || !((BasicTrustRootIndex)obj).subjectToCaCerts.equals(subjectToCaCerts))
            {
                flag = false;
            }
            return flag;
        }

        public X509Certificate findByIssuerAndSignature(X509Certificate x509certificate)
        {
            Object obj;
            obj = x509certificate.getIssuerX500Principal();
            obj = (Set)subjectToCaCerts.get(obj);
            if (obj != null)
            {
                obj = ((Set) (obj)).iterator();
                break MISSING_BLOCK_LABEL_30;
            } else
            {
                return null;
            }
_L2:
            X509Certificate x509certificate1;
            java.security.PublicKey publickey;
            if (!((Iterator) (obj)).hasNext())
            {
                return null;
            }
            x509certificate1 = (X509Certificate)((Iterator) (obj)).next();
            publickey = x509certificate1.getPublicKey();
            x509certificate.verify(publickey);
            return x509certificate1;
            Exception exception;
            exception;
            if (true) goto _L2; else goto _L1
_L1:
        }

        public int hashCode()
        {
            return subjectToCaCerts.hashCode();
        }

        public transient BasicTrustRootIndex(X509Certificate ax509certificate[])
        {
            int j = ax509certificate.length;
            int i = 0;
            do
            {
                if (i >= j)
                {
                    return;
                }
                X509Certificate x509certificate = ax509certificate[i];
                javax.security.auth.x500.X500Principal x500principal = x509certificate.getSubjectX500Principal();
                Object obj = (Set)subjectToCaCerts.get(x500principal);
                if (obj == null)
                {
                    obj = new LinkedHashSet(1);
                    subjectToCaCerts.put(x500principal, obj);
                }
                ((Set) (obj)).add(x509certificate);
                i++;
            } while (true);
        }
    }


    public TrustRootIndex()
    {
    }

    public static TrustRootIndex get(X509TrustManager x509trustmanager)
    {
        Object obj;
        try
        {
            obj = x509trustmanager.getClass().getDeclaredMethod("findTrustAnchorByIssuerAndSignature", new Class[] {
                java/security/cert/X509Certificate
            });
            ((Method) (obj)).setAccessible(true);
            obj = new AndroidTrustRootIndex(x509trustmanager, ((Method) (obj)));
        }
        catch (NoSuchMethodException nosuchmethodexception)
        {
            return get(x509trustmanager.getAcceptedIssuers());
        }
        return ((TrustRootIndex) (obj));
    }

    public static transient TrustRootIndex get(X509Certificate ax509certificate[])
    {
        return new BasicTrustRootIndex(ax509certificate);
    }

    public abstract X509Certificate findByIssuerAndSignature(X509Certificate x509certificate);
}
