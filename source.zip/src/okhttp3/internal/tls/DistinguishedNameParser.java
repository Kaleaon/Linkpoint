// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import javax.security.auth.x500.X500Principal;

final class DistinguishedNameParser
{

    private int beg;
    private char chars[];
    private int cur;
    private final String dn;
    private int end;
    private final int length;
    private int pos;

    public DistinguishedNameParser(X500Principal x500principal)
    {
        dn = x500principal.getName("RFC2253");
        length = dn.length();
    }

    private String escapedAV()
    {
        beg = pos;
        end = pos;
_L2:
        if (pos < length)
        {
            switch (chars[pos])
            {
            default:
                char ac[] = chars;
                int i = end;
                end = i + 1;
                ac[i] = chars[pos];
                pos = pos + 1;
                continue; /* Loop/switch isn't completed */

            case 43: // '+'
            case 44: // ','
            case 59: // ';'
                return new String(chars, beg, end - beg);

            case 92: // '\\'
                char ac1[] = chars;
                int j = end;
                end = j + 1;
                ac1[j] = getEscaped();
                pos = pos + 1;
                continue; /* Loop/switch isn't completed */

            case 32: // ' '
                cur = end;
                pos = pos + 1;
                char ac2[] = chars;
                int k = end;
                end = k + 1;
                ac2[k] = ' ';
                break;
            }
        } else
        {
            return new String(chars, beg, end - beg);
        }
        break; /* Loop/switch isn't completed */
_L3:
        return new String(chars, beg, cur - beg);
        if (true) goto _L2; else goto _L1
_L1:
        while (pos < length && chars[pos] == ' ') 
        {
            char ac3[] = chars;
            int l = end;
            end = l + 1;
            ac3[l] = ' ';
            pos = pos + 1;
        }
        if (pos == length || chars[pos] == ',' || chars[pos] == '+' || chars[pos] == ';') goto _L3; else goto _L2
    }

    private int getByte(int i)
    {
        int j;
        if (i + 1 < length)
        {
            j = chars[i];
            break MISSING_BLOCK_LABEL_17;
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("Malformed DN: ").append(dn).toString());
        }
        if (j < 48 || j > 57)
        {
            if (j < 97 || j > 102)
            {
                if (j < 65 || j > 70)
                {
                    throw new IllegalStateException((new StringBuilder()).append("Malformed DN: ").append(dn).toString());
                }
                j -= 55;
            } else
            {
                j -= 87;
            }
        } else
        {
            j -= 48;
        }
        i = chars[i + 1];
        if (i < 48 || i > 57)
        {
            if (i < 97 || i > 102)
            {
                if (i < 65 || i > 70)
                {
                    throw new IllegalStateException((new StringBuilder()).append("Malformed DN: ").append(dn).toString());
                }
                i -= 55;
            } else
            {
                i -= 87;
            }
        } else
        {
            i -= 48;
        }
        return (j << 4) + i;
    }

    private char getEscaped()
    {
        pos = pos + 1;
        if (pos != length)
        {
            switch (chars[pos])
            {
            default:
                return getUTF8();

            case 32: // ' '
            case 34: // '"'
            case 35: // '#'
            case 37: // '%'
            case 42: // '*'
            case 43: // '+'
            case 44: // ','
            case 59: // ';'
            case 60: // '<'
            case 61: // '='
            case 62: // '>'
            case 92: // '\\'
            case 95: // '_'
                return chars[pos];
            }
        } else
        {
            throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
        }
    }

    private char getUTF8()
    {
        int i = getByte(pos);
        pos = pos + 1;
        if (i >= 128)
        {
            if (i < 192 || i > 247)
            {
                return '?';
            }
        } else
        {
            return (char)i;
        }
        byte byte0;
        int j;
        boolean flag;
        if (i > 223)
        {
            if (i > 239)
            {
                byte0 = 3;
                i &= 7;
            } else
            {
                byte0 = 2;
                i &= 0xf;
            }
        } else
        {
            byte0 = 1;
            i &= 0x1f;
        }
        flag = false;
        j = i;
        i = ((flag) ? 1 : 0);
        do
        {
            if (i >= byte0)
            {
                return (char)j;
            }
            for (pos = pos + 1; pos == length || chars[pos] != '\\';)
            {
                return '?';
            }

            pos = pos + 1;
            int k = getByte(pos);
            pos = pos + 1;
            if ((k & 0xc0) == 128)
            {
                j = (j << 6) + (k & 0x3f);
                i++;
            } else
            {
                return '?';
            }
        } while (true);
    }

    private String hexAV()
    {
        int i;
        int l;
label0:
        {
            i = 0;
            if (pos + 4 < length)
            {
                beg = pos;
                pos = pos + 1;
                break label0;
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
            }
        }
_L2:
        if (pos == length || chars[pos] == '+' || chars[pos] == ',' || chars[pos] == ';')
        {
            end = pos;
        } else
        {
            if (chars[pos] != ' ')
            {
                if (chars[pos] >= 'A' && chars[pos] <= 'F')
                {
                    char ac[] = chars;
                    int j = pos;
                    ac[j] = (char)(ac[j] + 32);
                }
                pos = pos + 1;
                continue; /* Loop/switch isn't completed */
            }
            end = pos;
            pos = pos + 1;
            while (pos < length && chars[pos] == ' ') 
            {
                pos = pos + 1;
            }
        }
        l = end - beg;
        if (l < 5 || (l & 1) == 0)
        {
            throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
        }
        byte abyte0[] = new byte[l / 2];
        int k = beg + 1;
        do
        {
            if (i >= abyte0.length)
            {
                return new String(chars, beg, l);
            }
            abyte0[i] = (byte)getByte(k);
            k += 2;
            i++;
        } while (true);
        if (true) goto _L2; else goto _L1
_L1:
    }

    private String nextAT()
    {
        while (pos < length && chars[pos] == ' ') 
        {
            pos = pos + 1;
        }
        if (pos != length)
        {
            beg = pos;
            pos = pos + 1;
            while (pos < length && chars[pos] != '=' && chars[pos] != ' ') 
            {
                pos = pos + 1;
            }
            break MISSING_BLOCK_LABEL_51;
        } else
        {
            return null;
        }
        if (pos >= length) goto _L2; else goto _L1
_L1:
        end = pos;
        if (chars[pos] == ' ') goto _L4; else goto _L3
_L3:
        pos = pos + 1;
        while (pos < length && chars[pos] == ' ') 
        {
            pos = pos + 1;
        }
        if (end - beg > 4 && chars[beg + 3] == '.' && (chars[beg] == 'O' || chars[beg] == 'o') && (chars[beg + 1] == 'I' || chars[beg + 1] == 'i') && (chars[beg + 2] == 'D' || chars[beg + 2] == 'd'))
        {
            beg = beg + 4;
        }
        return new String(chars, beg, end - beg);
_L2:
        throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
_L5:
        throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
_L4:
        for (; pos < length && chars[pos] != '=' && chars[pos] == ' '; pos = pos + 1) { }
        if (chars[pos] != '=' || pos == length) goto _L5; else goto _L3
    }

    private String quotedAV()
    {
        pos = pos + 1;
        beg = pos;
        end = beg;
        while (pos != length) 
        {
            if (chars[pos] != '"')
            {
                if (chars[pos] != '\\')
                {
                    chars[end] = chars[pos];
                } else
                {
                    chars[end] = getEscaped();
                }
                pos = pos + 1;
                end = end + 1;
            } else
            {
                do
                {
                    for (pos = pos + 1; pos >= length || chars[pos] != ' ';)
                    {
                        return new String(chars, beg, end - beg);
                    }

                    pos = pos + 1;
                } while (true);
            }
        }
        throw new IllegalStateException((new StringBuilder()).append("Unexpected end of DN: ").append(dn).toString());
    }

    public String findMostSpecific(String s)
    {
        String s2;
        pos = 0;
        beg = 0;
        end = 0;
        cur = 0;
        chars = dn.toCharArray();
        s2 = nextAT();
        if (s2 == null) goto _L2; else goto _L1
_L1:
        String s1 = "";
        if (pos == length) goto _L4; else goto _L3
_L3:
        chars[pos];
        JVM INSTR lookupswitch 5: default 112
    //                   34: 205
    //                   35: 213
    //                   43: 117
    //                   44: 117
    //                   59: 117;
           goto _L5 _L6 _L7 _L8 _L8 _L8
_L5:
        s1 = escapedAV();
_L8:
        if (s.equalsIgnoreCase(s2)) goto _L10; else goto _L9
_L9:
        if (pos >= length) goto _L12; else goto _L11
_L14:
        pos = pos + 1;
        s1 = nextAT();
        s2 = s1;
        if (s1 == null)
        {
            throw new IllegalStateException((new StringBuilder()).append("Malformed DN: ").append(dn).toString());
        }
          goto _L1
_L2:
        return null;
_L4:
        return null;
_L6:
        s1 = quotedAV();
          goto _L8
_L7:
        s1 = hexAV();
          goto _L8
_L10:
        return s1;
_L12:
        return null;
_L11:
        if (chars[pos] == ',' || chars[pos] == ';' || chars[pos] == '+') goto _L14; else goto _L13
_L13:
        throw new IllegalStateException((new StringBuilder()).append("Malformed DN: ").append(dn).toString());
          goto _L8
    }
}
