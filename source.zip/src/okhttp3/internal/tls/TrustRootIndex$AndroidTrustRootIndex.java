// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;

// Referenced classes of package okhttp3.internal.tls:
//            TrustRootIndex

static final class trustManager extends TrustRootIndex
{

    private final Method findByIssuerAndSignatureMethod;
    private final X509TrustManager trustManager;

    public boolean equals(Object obj)
    {
label0:
        {
            boolean flag = true;
            if (obj != this)
            {
                if (obj instanceof trustManager)
                {
                    obj = (trustManager)obj;
                    break label0;
                } else
                {
                    return false;
                }
            } else
            {
                return true;
            }
        }
        if (!trustManager.equals(((trustManager) (obj)).trustManager) || !findByIssuerAndSignatureMethod.equals(((findByIssuerAndSignatureMethod) (obj)).findByIssuerAndSignatureMethod))
        {
            flag = false;
        }
        return flag;
    }

    public X509Certificate findByIssuerAndSignature(X509Certificate x509certificate)
    {
        try
        {
            x509certificate = (TrustAnchor)findByIssuerAndSignatureMethod.invoke(trustManager, new Object[] {
                x509certificate
            });
        }
        // Misplaced declaration of an exception variable
        catch (X509Certificate x509certificate)
        {
            throw new AssertionError();
        }
        // Misplaced declaration of an exception variable
        catch (X509Certificate x509certificate)
        {
            return null;
        }
        if (x509certificate == null)
        {
            return null;
        }
        x509certificate = x509certificate.getTrustedCert();
        return x509certificate;
    }

    public int hashCode()
    {
        return trustManager.hashCode() + findByIssuerAndSignatureMethod.hashCode() * 31;
    }

    (X509TrustManager x509trustmanager, Method method)
    {
        findByIssuerAndSignatureMethod = method;
        trustManager = x509trustmanager;
    }
}
