// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

// Referenced classes of package okhttp3.internal.tls:
//            TrustRootIndex

static final class subjectToCaCerts extends TrustRootIndex
{

    private final Map subjectToCaCerts = new LinkedHashMap();

    public boolean equals(Object obj)
    {
label0:
        {
            boolean flag = true;
            if (obj != this)
            {
                break label0;
            } else
            {
                return true;
            }
        }
        if (!(obj instanceof subjectToCaCerts) || !((subjectToCaCerts)obj).subjectToCaCerts.equals(subjectToCaCerts))
        {
            flag = false;
        }
        return flag;
    }

    public X509Certificate findByIssuerAndSignature(X509Certificate x509certificate)
    {
        Object obj;
        obj = x509certificate.getIssuerX500Principal();
        obj = (Set)subjectToCaCerts.get(obj);
        if (obj != null)
        {
            obj = ((Set) (obj)).iterator();
            break MISSING_BLOCK_LABEL_30;
        } else
        {
            return null;
        }
_L2:
        X509Certificate x509certificate1;
        java.security.PublicKey publickey;
        if (!((Iterator) (obj)).hasNext())
        {
            return null;
        }
        x509certificate1 = (X509Certificate)((Iterator) (obj)).next();
        publickey = x509certificate1.getPublicKey();
        x509certificate.verify(publickey);
        return x509certificate1;
        Exception exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public int hashCode()
    {
        return subjectToCaCerts.hashCode();
    }

    public transient (X509Certificate ax509certificate[])
    {
        int j = ax509certificate.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            X509Certificate x509certificate = ax509certificate[i];
            javax.security.auth.x500.X500Principal x500principal = x509certificate.getSubjectX500Principal();
            Object obj = (Set)subjectToCaCerts.get(x500principal);
            if (obj == null)
            {
                obj = new LinkedHashSet(1);
                subjectToCaCerts.put(x500principal, obj);
            }
            ((Set) (obj)).add(x509certificate);
            i++;
        } while (true);
    }
}
