// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.tls;

import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.X509TrustManager;
import okhttp3.internal.platform.Platform;

// Referenced classes of package okhttp3.internal.tls:
//            BasicCertificateChainCleaner, TrustRootIndex

public abstract class CertificateChainCleaner
{

    public CertificateChainCleaner()
    {
    }

    public static CertificateChainCleaner get(X509TrustManager x509trustmanager)
    {
        return Platform.get().buildCertificateChainCleaner(x509trustmanager);
    }

    public static transient CertificateChainCleaner get(X509Certificate ax509certificate[])
    {
        return new BasicCertificateChainCleaner(TrustRootIndex.get(ax509certificate));
    }

    public abstract List clean(List list, String s)
        throws SSLPeerUnverifiedException;
}
