// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocket;
import okhttp3.Address;
import okhttp3.Call;
import okhttp3.ConnectionPool;
import okhttp3.ConnectionSpec;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.internal.cache.InternalCache;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.RouteDatabase;
import okhttp3.internal.connection.StreamAllocation;

public abstract class Internal
{

    public static Internal instance;

    public Internal()
    {
    }

    public static void initializeInstanceForTests()
    {
        new OkHttpClient();
    }

    public abstract void addLenient(okhttp3.Headers.Builder builder, String s);

    public abstract void addLenient(okhttp3.Headers.Builder builder, String s, String s1);

    public abstract void apply(ConnectionSpec connectionspec, SSLSocket sslsocket, boolean flag);

    public abstract boolean connectionBecameIdle(ConnectionPool connectionpool, RealConnection realconnection);

    public abstract RealConnection get(ConnectionPool connectionpool, Address address, StreamAllocation streamallocation);

    public abstract HttpUrl getHttpUrlChecked(String s)
        throws MalformedURLException, UnknownHostException;

    public abstract Call newWebSocketCall(OkHttpClient okhttpclient, Request request);

    public abstract void put(ConnectionPool connectionpool, RealConnection realconnection);

    public abstract RouteDatabase routeDatabase(ConnectionPool connectionpool);

    public abstract void setCache(okhttp3.OkHttpClient.Builder builder, InternalCache internalcache);

    public abstract StreamAllocation streamAllocation(Call call);
}
