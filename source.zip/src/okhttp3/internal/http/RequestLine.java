// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import okhttp3.HttpUrl;
import okhttp3.Request;

public final class RequestLine
{

    private RequestLine()
    {
    }

    public static String get(Request request, java.net.Proxy.Type type)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(request.method());
        stringbuilder.append(' ');
        if (!includeAuthorityInRequestLine(request, type))
        {
            stringbuilder.append(requestPath(request.url()));
        } else
        {
            stringbuilder.append(request.url());
        }
        stringbuilder.append(" HTTP/1.1");
        return stringbuilder.toString();
    }

    private static boolean includeAuthorityInRequestLine(Request request, java.net.Proxy.Type type)
    {
        while (request.isHttps() || type != java.net.Proxy.Type.HTTP) 
        {
            return false;
        }
        return true;
    }

    public static String requestPath(HttpUrl httpurl)
    {
        String s = httpurl.encodedPath();
        httpurl = httpurl.encodedQuery();
        if (httpurl == null)
        {
            return s;
        } else
        {
            return (new StringBuilder()).append(s).append('?').append(httpurl).toString();
        }
    }
}
