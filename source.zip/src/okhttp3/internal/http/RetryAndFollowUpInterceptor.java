// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.HttpRetryException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import okhttp3.Address;
import okhttp3.Authenticator;
import okhttp3.Connection;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal.Util;
import okhttp3.internal.connection.RouteException;
import okhttp3.internal.connection.StreamAllocation;
import okhttp3.internal.http2.ConnectionShutdownException;

// Referenced classes of package okhttp3.internal.http:
//            HttpMethod, UnrepeatableRequestBody, RealInterceptorChain

public final class RetryAndFollowUpInterceptor
    implements Interceptor
{

    private static final int MAX_FOLLOW_UPS = 20;
    private Object callStackTrace;
    private volatile boolean canceled;
    private final OkHttpClient client;
    private final boolean forWebSocket;
    private StreamAllocation streamAllocation;

    public RetryAndFollowUpInterceptor(OkHttpClient okhttpclient, boolean flag)
    {
        client = okhttpclient;
        forWebSocket = flag;
    }

    private Address createAddress(HttpUrl httpurl)
    {
        okhttp3.CertificatePinner certificatepinner = null;
        javax.net.ssl.SSLSocketFactory sslsocketfactory;
        javax.net.ssl.HostnameVerifier hostnameverifier;
        if (!httpurl.isHttps())
        {
            hostnameverifier = null;
            sslsocketfactory = null;
        } else
        {
            sslsocketfactory = client.sslSocketFactory();
            hostnameverifier = client.hostnameVerifier();
            certificatepinner = client.certificatePinner();
        }
        return new Address(httpurl.host(), httpurl.port(), client.dns(), client.socketFactory(), sslsocketfactory, hostnameverifier, certificatepinner, client.proxyAuthenticator(), client.proxy(), client.protocols(), client.connectionSpecs(), client.proxySelector());
    }

    private Request followUpRequest(Response response)
        throws IOException
    {
        Proxy proxy = null;
        if (response == null) goto _L2; else goto _L1
_L1:
        Object obj;
        String s1;
        obj = streamAllocation.connection();
        int i;
        if (obj == null)
        {
            obj = null;
        } else
        {
            obj = ((Connection) (obj)).route();
        }
        i = response.code();
        s1 = response.request().method();
        i;
        JVM INSTR lookupswitch 9: default 120
    //                   300: 220
    //                   301: 220
    //                   302: 220
    //                   303: 220
    //                   307: 210
    //                   308: 210
    //                   401: 195
    //                   407: 140
    //                   408: 445;
           goto _L3 _L4 _L4 _L4 _L4 _L5 _L5 _L6 _L7 _L8
_L3:
        return null;
_L2:
        throw new IllegalStateException();
_L7:
        if (obj == null)
        {
            proxy = client.proxy();
        } else
        {
            proxy = ((Route) (obj)).proxy();
        }
        if (proxy.type() == java.net.Proxy.Type.HTTP)
        {
            return client.proxyAuthenticator().authenticate(((Route) (obj)), response);
        } else
        {
            throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
        }
_L6:
        return client.authenticator().authenticate(((Route) (obj)), response);
_L4:
        if (client.followRedirects())
        {
            String s = response.header("Location");
            if (s != null)
            {
                HttpUrl httpurl = response.request().url().resolve(s);
                if (httpurl != null)
                {
                    if (httpurl.scheme().equals(response.request().url().scheme()) || client.followSslRedirects())
                    {
                        okhttp3.Request.Builder builder = response.request().newBuilder();
                        if (HttpMethod.permitsRequestBody(s1))
                        {
                            boolean flag = HttpMethod.redirectsWithBody(s1);
                            if (!HttpMethod.redirectsToGet(s1))
                            {
                                Object obj1;
                                if (!flag)
                                {
                                    obj1 = proxy;
                                } else
                                {
                                    obj1 = response.request().body();
                                }
                                builder.method(s1, ((okhttp3.RequestBody) (obj1)));
                            } else
                            {
                                builder.method("GET", null);
                            }
                            if (!flag)
                            {
                                builder.removeHeader("Transfer-Encoding");
                                builder.removeHeader("Content-Length");
                                builder.removeHeader("Content-Type");
                            }
                        }
                        if (!sameConnection(response, httpurl))
                        {
                            builder.removeHeader("Authorization");
                        }
                        return builder.url(httpurl).build();
                    } else
                    {
                        return null;
                    }
                } else
                {
                    return null;
                }
            } else
            {
                return null;
            }
        } else
        {
            return null;
        }
_L5:
        if (s1.equals("GET") || s1.equals("HEAD")) goto _L4; else goto _L9
_L9:
        return null;
_L8:
        if (!(response.request().body() instanceof UnrepeatableRequestBody))
        {
            return response.request();
        } else
        {
            return null;
        }
    }

    private boolean isRecoverable(IOException ioexception, boolean flag)
    {
        boolean flag1 = true;
        if (!(ioexception instanceof ProtocolException))
        {
            if (!(ioexception instanceof InterruptedIOException))
            {
                if (!(ioexception instanceof SSLHandshakeException) || !(ioexception.getCause() instanceof CertificateException))
                {
                    return !(ioexception instanceof SSLPeerUnverifiedException);
                } else
                {
                    return false;
                }
            }
        } else
        {
            return false;
        }
        break MISSING_BLOCK_LABEL_34;
        if (!(ioexception instanceof SocketTimeoutException) || flag)
        {
            flag1 = false;
        }
        return flag1;
    }

    private boolean recover(IOException ioexception, boolean flag, Request request)
    {
        streamAllocation.streamFailed(ioexception);
        if (client.retryOnConnectionFailure())
        {
            if (!flag || !(request.body() instanceof UnrepeatableRequestBody))
            {
                if (isRecoverable(ioexception, flag))
                {
                    return streamAllocation.hasMoreRoutes();
                } else
                {
                    return false;
                }
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
    }

    private boolean sameConnection(Response response, HttpUrl httpurl)
    {
        for (response = response.request().url(); !response.host().equals(httpurl.host()) || response.port() != httpurl.port() || !response.scheme().equals(httpurl.scheme());)
        {
            return false;
        }

        return true;
    }

    public void cancel()
    {
        canceled = true;
        StreamAllocation streamallocation = streamAllocation;
        if (streamallocation == null)
        {
            return;
        } else
        {
            streamallocation.cancel();
            return;
        }
    }

    public Response intercept(okhttp3.Interceptor.Chain chain)
        throws IOException
    {
        Object obj;
        Object obj1;
        int i;
        obj1 = chain.request();
        streamAllocation = new StreamAllocation(client.connectionPool(), createAddress(((Request) (obj1)).url()), callStackTrace);
        obj = null;
        i = 0;
_L2:
        if (canceled)
        {
            break MISSING_BLOCK_LABEL_139;
        }
        Response response = ((RealInterceptorChain)chain).proceed(((Request) (obj1)), streamAllocation, null, null);
        obj1 = response;
        if (obj == null)
        {
            obj = obj1;
        } else
        {
            obj = ((Response) (obj1)).newBuilder().priorResponse(((Response) (obj)).newBuilder().body(null).build()).build();
        }
        obj1 = followUpRequest(((Response) (obj)));
        if (obj1 != null)
        {
            Util.closeQuietly(((Response) (obj)).body());
            i++;
            Object obj2;
            boolean flag;
            if (i <= 20)
            {
                if (!(((Request) (obj1)).body() instanceof UnrepeatableRequestBody))
                {
                    if (sameConnection(((Response) (obj)), ((Request) (obj1)).url()))
                    {
                        if (streamAllocation.codec() != null)
                        {
                            break; /* Loop/switch isn't completed */
                        }
                    } else
                    {
                        streamAllocation.release();
                        streamAllocation = new StreamAllocation(client.connectionPool(), createAddress(((Request) (obj1)).url()), callStackTrace);
                    }
                } else
                {
                    streamAllocation.release();
                    throw new HttpRetryException("Cannot retry streamed HTTP body", ((Response) (obj)).code());
                }
            } else
            {
                streamAllocation.release();
                throw new ProtocolException((new StringBuilder()).append("Too many follow-up requests: ").append(i).toString());
            }
        } else
        if (forWebSocket)
        {
            return ((Response) (obj));
        } else
        {
            streamAllocation.release();
            return ((Response) (obj));
        }
        continue; /* Loop/switch isn't completed */
        streamAllocation.release();
        throw new IOException("Canceled");
        obj2;
        if (!recover(((RouteException) (obj2)).getLastConnectException(), false, ((Request) (obj1))))
        {
            throw ((RouteException) (obj2)).getLastConnectException();
        }
        continue; /* Loop/switch isn't completed */
        chain;
        streamAllocation.streamFailed(null);
        streamAllocation.release();
        throw chain;
        obj2;
        if (obj2 instanceof ConnectionShutdownException)
        {
            flag = false;
        } else
        {
            flag = true;
        }
        if (!recover(((IOException) (obj2)), flag, ((Request) (obj1))))
        {
            throw obj2;
        }
        if (true) goto _L2; else goto _L1
_L1:
        throw new IllegalStateException((new StringBuilder()).append("Closing the body of ").append(obj).append(" didn't close its backing stream. Bad interceptor?").toString());
    }

    public boolean isCanceled()
    {
        return canceled;
    }

    public void setCallStackTrace(Object obj)
    {
        callStackTrace = obj;
    }

    public StreamAllocation streamAllocation()
    {
        return streamAllocation;
    }
}
