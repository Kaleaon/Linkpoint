// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import java.net.ProtocolException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.Util;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.StreamAllocation;
import okio.BufferedSink;
import okio.Okio;

// Referenced classes of package okhttp3.internal.http:
//            RealInterceptorChain, HttpCodec, HttpMethod

public final class CallServerInterceptor
    implements Interceptor
{

    private final boolean forWebSocket;

    public CallServerInterceptor(boolean flag)
    {
        forWebSocket = flag;
    }

    public Response intercept(okhttp3.Interceptor.Chain chain)
        throws IOException
    {
        StreamAllocation streamallocation;
        HttpCodec httpcodec;
        boolean flag;
        long l;
        flag = false;
        httpcodec = ((RealInterceptorChain)chain).httpStream();
        streamallocation = ((RealInterceptorChain)chain).streamAllocation();
        chain = chain.request();
        l = System.currentTimeMillis();
        httpcodec.writeRequestHeaders(chain);
        break MISSING_BLOCK_LABEL_38;
        int i;
        if (HttpMethod.permitsRequestBody(chain.method()) && chain.body() != null)
        {
            BufferedSink bufferedsink = Okio.buffer(httpcodec.createRequestBody(chain, chain.body().contentLength()));
            chain.body().writeTo(bufferedsink);
            bufferedsink.close();
        }
        httpcodec.finishRequest();
        chain = httpcodec.readResponseHeaders().request(chain).handshake(streamallocation.connection().handshake()).sentRequestAtMillis(l).receivedResponseAtMillis(System.currentTimeMillis()).build();
        i = chain.code();
        break MISSING_BLOCK_LABEL_95;
        if (!forWebSocket || i != 101)
        {
            chain = chain.newBuilder().body(httpcodec.openResponseBody(chain)).build();
        } else
        {
            chain = chain.newBuilder().body(Util.EMPTY_RESPONSE).build();
        }
        if ("close".equalsIgnoreCase(chain.request().header("Connection")) || "close".equalsIgnoreCase(chain.header("Connection")))
        {
            streamallocation.noNewStreams();
        }
        if (i == 204 || i == 205)
        {
            if (chain.body().contentLength() <= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                throw new ProtocolException((new StringBuilder()).append("HTTP ").append(i).append(" had non-zero Content-Length: ").append(chain.body().contentLength()).toString());
            }
        }
        return chain;
    }
}
