// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import java.net.ProtocolException;
import okhttp3.Protocol;
import okhttp3.Response;

public final class StatusLine
{

    public static final int HTTP_CONTINUE = 100;
    public static final int HTTP_PERM_REDIRECT = 308;
    public static final int HTTP_TEMP_REDIRECT = 307;
    public final int code;
    public final String message;
    public final Protocol protocol;

    public StatusLine(Protocol protocol1, int i, String s)
    {
        protocol = protocol1;
        code = i;
        message = s;
    }

    public static StatusLine get(Response response)
    {
        return new StatusLine(response.protocol(), response.code(), response.message());
    }

    public static StatusLine parse(String s)
        throws IOException
    {
        byte byte0;
        byte0 = 9;
        if (!s.startsWith("HTTP/1."))
        {
            Protocol protocol1;
            int i;
            if (!s.startsWith("ICY "))
            {
                throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
            }
            protocol1 = Protocol.HTTP_1_0;
            byte0 = 4;
            continue; /* Loop/switch isn't completed */
        }
        while (s.length() < 9 || s.charAt(8) != ' ') 
        {
            throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
        }
        i = s.charAt(7) - 48;
        if (i != 0)
        {
            if (i != 1)
            {
                throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
            }
            protocol1 = Protocol.HTTP_1_1;
            continue; /* Loop/switch isn't completed */
        }
        protocol1 = Protocol.HTTP_1_0;
_L8:
        if (s.length() < byte0 + 3) goto _L2; else goto _L1
_L1:
        try
        {
            i = Integer.parseInt(s.substring(byte0, byte0 + 3));
        }
        catch (NumberFormatException numberformatexception)
        {
            throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
        }
        if (s.length() > byte0 + 3) goto _L4; else goto _L3
_L3:
        s = "";
_L6:
        return new StatusLine(protocol1, i, s);
_L2:
        throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
_L4:
        if (s.charAt(byte0 + 3) != ' ')
        {
            break; /* Loop/switch isn't completed */
        }
        s = s.substring(byte0 + 4);
        if (true) goto _L6; else goto _L5
_L5:
        throw new ProtocolException((new StringBuilder()).append("Unexpected status line: ").append(s).toString());
        if (true) goto _L8; else goto _L7
_L7:
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder();
        String s;
        if (protocol != Protocol.HTTP_1_0)
        {
            s = "HTTP/1.1";
        } else
        {
            s = "HTTP/1.0";
        }
        stringbuilder.append(s);
        stringbuilder.append(' ').append(code);
        if (message != null)
        {
            stringbuilder.append(' ').append(message);
        }
        return stringbuilder.toString();
    }
}
