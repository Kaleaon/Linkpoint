// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.BufferedSource;

// Referenced classes of package okhttp3.internal.http:
//            HttpHeaders

public final class RealResponseBody extends ResponseBody
{

    private final Headers headers;
    private final BufferedSource source;

    public RealResponseBody(Headers headers1, BufferedSource bufferedsource)
    {
        headers = headers1;
        source = bufferedsource;
    }

    public long contentLength()
    {
        return HttpHeaders.contentLength(headers);
    }

    public MediaType contentType()
    {
        String s = headers.get("Content-Type");
        if (s == null)
        {
            return null;
        } else
        {
            return MediaType.parse(s);
        }
    }

    public BufferedSource source()
    {
        return source;
    }
}
