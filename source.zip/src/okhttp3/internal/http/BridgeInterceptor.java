// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import java.util.List;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.Util;
import okhttp3.internal.Version;
import okio.GzipSource;
import okio.Okio;

// Referenced classes of package okhttp3.internal.http:
//            HttpHeaders, RealResponseBody

public final class BridgeInterceptor
    implements Interceptor
{

    private final CookieJar cookieJar;

    public BridgeInterceptor(CookieJar cookiejar)
    {
        cookieJar = cookiejar;
    }

    private String cookieHeader(List list)
    {
        StringBuilder stringbuilder = new StringBuilder();
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return stringbuilder.toString();
            }
            Cookie cookie;
            if (i > 0)
            {
                stringbuilder.append("; ");
            }
            cookie = (Cookie)list.get(i);
            stringbuilder.append(cookie.name()).append('=').append(cookie.value());
            i++;
        } while (true);
    }

    public Response intercept(okhttp3.Interceptor.Chain chain)
        throws IOException
    {
        Object obj;
        boolean flag = false;
        obj = chain.request();
        okhttp3.Request.Builder builder = ((Request) (obj)).newBuilder();
        Object obj1 = ((Request) (obj)).body();
        if (obj1 != null)
        {
            MediaType mediatype = ((RequestBody) (obj1)).contentType();
            long l;
            if (mediatype != null)
            {
                builder.header("Content-Type", mediatype.toString());
            }
            l = ((RequestBody) (obj1)).contentLength();
            if (l != -1L)
            {
                builder.header("Content-Length", Long.toString(l));
                builder.removeHeader("Transfer-Encoding");
            } else
            {
                builder.header("Transfer-Encoding", "chunked");
                builder.removeHeader("Content-Length");
            }
        }
        if (((Request) (obj)).header("Host") == null)
        {
            builder.header("Host", Util.hostHeader(((Request) (obj)).url(), false));
        }
        if (((Request) (obj)).header("Connection") == null)
        {
            builder.header("Connection", "Keep-Alive");
        }
        if (((Request) (obj)).header("Accept-Encoding") == null)
        {
            flag = true;
            builder.header("Accept-Encoding", "gzip");
        }
        obj1 = cookieJar.loadForRequest(((Request) (obj)).url());
        if (!((List) (obj1)).isEmpty())
        {
            builder.header("Cookie", cookieHeader(((List) (obj1))));
        }
        if (((Request) (obj)).header("User-Agent") == null)
        {
            builder.header("User-Agent", Version.userAgent());
        }
        chain = chain.proceed(builder.build());
        HttpHeaders.receiveHeaders(cookieJar, ((Request) (obj)).url(), chain.headers());
        obj = chain.newBuilder().request(((Request) (obj)));
        break MISSING_BLOCK_LABEL_122;
        if (flag && "gzip".equalsIgnoreCase(chain.header("Content-Encoding")) && HttpHeaders.hasBody(chain))
        {
            GzipSource gzipsource = new GzipSource(chain.body().source());
            chain = chain.headers().newBuilder().removeAll("Content-Encoding").removeAll("Content-Length").build();
            ((okhttp3.Response.Builder) (obj)).headers(chain);
            ((okhttp3.Response.Builder) (obj)).body(new RealResponseBody(chain, Okio.buffer(gzipsource)));
        }
        return ((okhttp3.Response.Builder) (obj)).build();
    }
}
