// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import java.util.List;
import okhttp3.Address;
import okhttp3.Connection;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal.connection.StreamAllocation;

// Referenced classes of package okhttp3.internal.http:
//            HttpCodec

public final class RealInterceptorChain
    implements okhttp3.Interceptor.Chain
{

    private int calls;
    private final Connection connection;
    private final HttpCodec httpCodec;
    private final int index;
    private final List interceptors;
    private final Request request;
    private final StreamAllocation streamAllocation;

    public RealInterceptorChain(List list, StreamAllocation streamallocation, HttpCodec httpcodec, Connection connection1, int i, Request request1)
    {
        interceptors = list;
        connection = connection1;
        streamAllocation = streamallocation;
        httpCodec = httpcodec;
        index = i;
        request = request1;
    }

    private boolean sameConnection(HttpUrl httpurl)
    {
        while (!httpurl.host().equals(connection.route().address().url().host()) || httpurl.port() != connection.route().address().url().port()) 
        {
            return false;
        }
        return true;
    }

    public Connection connection()
    {
        return connection;
    }

    public HttpCodec httpStream()
    {
        return httpCodec;
    }

    public Response proceed(Request request1)
        throws IOException
    {
        return proceed(request1, streamAllocation, httpCodec, connection);
    }

    public Response proceed(Request request1, StreamAllocation streamallocation, HttpCodec httpcodec, Connection connection1)
        throws IOException
    {
        if (index < interceptors.size())
        {
            calls = calls + 1;
            if (httpCodec == null || sameConnection(request1.url()))
            {
                if (httpCodec == null || calls <= 1)
                {
                    request1 = new RealInterceptorChain(interceptors, streamallocation, httpcodec, connection1, index + 1, request1);
                    streamallocation = (Interceptor)interceptors.get(index);
                    connection1 = streamallocation.intercept(request1);
                    if (httpcodec == null || index + 1 >= interceptors.size() || ((RealInterceptorChain) (request1)).calls == 1)
                    {
                        if (connection1 != null)
                        {
                            return connection1;
                        } else
                        {
                            throw new NullPointerException((new StringBuilder()).append("interceptor ").append(streamallocation).append(" returned null").toString());
                        }
                    } else
                    {
                        throw new IllegalStateException((new StringBuilder()).append("network interceptor ").append(streamallocation).append(" must call proceed() exactly once").toString());
                    }
                } else
                {
                    throw new IllegalStateException((new StringBuilder()).append("network interceptor ").append(interceptors.get(index - 1)).append(" must call proceed() exactly once").toString());
                }
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("network interceptor ").append(interceptors.get(index - 1)).append(" must retain the same host and port").toString());
            }
        } else
        {
            throw new AssertionError();
        }
    }

    public Request request()
    {
        return request;
    }

    public StreamAllocation streamAllocation()
    {
        return streamAllocation;
    }
}
