// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;


public final class HttpMethod
{

    private HttpMethod()
    {
    }

    public static boolean invalidatesCache(String s)
    {
        while (s.equals("POST") || s.equals("PATCH") || s.equals("PUT") || s.equals("DELETE") || s.equals("MOVE")) 
        {
            return true;
        }
        return false;
    }

    public static boolean permitsRequestBody(String s)
    {
        while (requiresRequestBody(s) || s.equals("OPTIONS") || s.equals("DELETE") || s.equals("PROPFIND") || s.equals("MKCOL") || s.equals("LOCK")) 
        {
            return true;
        }
        return false;
    }

    public static boolean redirectsToGet(String s)
    {
        return !s.equals("PROPFIND");
    }

    public static boolean redirectsWithBody(String s)
    {
        return s.equals("PROPFIND");
    }

    public static boolean requiresRequestBody(String s)
    {
        while (s.equals("POST") || s.equals("PUT") || s.equals("PATCH") || s.equals("PROPPATCH") || s.equals("REPORT")) 
        {
            return true;
        }
        return false;
    }
}
