// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.Challenge;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.Util;

public final class HttpHeaders
{

    private static final Pattern PARAMETER = Pattern.compile(" +([^ \"=]*)=(:?\"([^\"]*)\"|([^ \"=]*)) *(:?,|$)");
    private static final String QUOTED_STRING = "\"([^\"]*)\"";
    private static final String TOKEN = "([^ \"=]*)";

    private HttpHeaders()
    {
    }

    public static long contentLength(Headers headers)
    {
        return stringToLong(headers.get("Content-Length"));
    }

    public static long contentLength(Response response)
    {
        return contentLength(response.headers());
    }

    public static boolean hasBody(Response response)
    {
        int i;
        if (!response.request().method().equals("HEAD"))
        {
            i = response.code();
            break MISSING_BLOCK_LABEL_20;
        } else
        {
            return false;
        }
        if (i >= 100 && i < 200 || (i == 204 || i == 304))
        {
            return contentLength(response) != -1L || "chunked".equalsIgnoreCase(response.header("Transfer-Encoding"));
        } else
        {
            return true;
        }
    }

    public static boolean hasVaryAll(Headers headers)
    {
        return varyFields(headers).contains("*");
    }

    public static boolean hasVaryAll(Response response)
    {
        return hasVaryAll(response.headers());
    }

    public static List parseChallenges(Headers headers, String s)
    {
        ArrayList arraylist;
        arraylist = new ArrayList();
        headers = headers.values(s).iterator();
_L6:
        Matcher matcher;
        int i;
        int j;
        do
        {
            if (!headers.hasNext())
            {
                return arraylist;
            }
            s = (String)headers.next();
            j = s.indexOf(' ');
        } while (j == -1);
        matcher = PARAMETER.matcher(s);
        i = j;
_L2:
        if (!matcher.find(i))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (s.regionMatches(true, matcher.start(1), "realm", 0, 5))
        {
            break; /* Loop/switch isn't completed */
        }
_L4:
        i = matcher.end();
        if (true) goto _L2; else goto _L1
_L1:
        String s1;
        String s2;
        s1 = s.substring(0, j);
        s2 = matcher.group(3);
        if (s2 == null) goto _L4; else goto _L3
_L3:
        arraylist.add(new Challenge(s1, s2));
        if (true) goto _L6; else goto _L5
_L5:
    }

    public static int parseSeconds(String s, int i)
    {
        boolean flag = true;
        long l;
        try
        {
            l = Long.parseLong(s);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return i;
        }
        if (l <= 0x7fffffffL)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            return 0x7fffffff;
        }
        if (l >= 0L)
        {
            i = ((flag) ? 1 : 0);
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            return 0;
        } else
        {
            return (int)l;
        }
    }

    public static void receiveHeaders(CookieJar cookiejar, HttpUrl httpurl, Headers headers)
    {
        if (cookiejar != CookieJar.NO_COOKIES)
        {
            headers = Cookie.parseAll(httpurl, headers);
            if (!headers.isEmpty())
            {
                cookiejar.saveFromResponse(httpurl, headers);
                return;
            } else
            {
                return;
            }
        } else
        {
            return;
        }
    }

    public static int skipUntil(String s, int i, String s1)
    {
        while (i < s.length() && s1.indexOf(s.charAt(i)) == -1) 
        {
            i++;
        }
        return i;
    }

    public static int skipWhitespace(String s, int i)
    {
_L3:
        if (i < s.length()) goto _L2; else goto _L1
_L1:
        return i;
_L2:
        char c;
        c = s.charAt(i);
        continue; /* Loop/switch isn't completed */
_L4:
        i++;
          goto _L3
        if (c != ' ' && c != '\t') goto _L1; else goto _L4
    }

    private static long stringToLong(String s)
    {
        if (s != null)
        {
            long l;
            try
            {
                l = Long.parseLong(s);
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                return -1L;
            }
            return l;
        } else
        {
            return -1L;
        }
    }

    public static Set varyFields(Headers headers)
    {
        Object obj;
        int i;
        int k;
        obj = Collections.emptySet();
        k = headers.size();
        i = 0;
_L3:
        Object obj1;
        if (i >= k)
        {
            return ((Set) (obj));
        }
        obj1 = obj;
        if (!"Vary".equalsIgnoreCase(headers.name(i))) goto _L2; else goto _L1
_L1:
        int j;
        obj1 = headers.value(i);
        int l;
        if (((Set) (obj)).isEmpty())
        {
            obj = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        }
        obj1 = ((String) (obj1)).split(",");
        l = obj1.length;
        j = 0;
_L4:
        if (j < l)
        {
            break MISSING_BLOCK_LABEL_96;
        }
        obj1 = obj;
_L2:
        i++;
        obj = obj1;
          goto _L3
        ((Set) (obj)).add(obj1[j].trim());
        j++;
          goto _L4
    }

    private static Set varyFields(Response response)
    {
        return varyFields(response.headers());
    }

    public static Headers varyHeaders(Headers headers, Headers headers1)
    {
        int i;
        i = 0;
        headers1 = varyFields(headers1);
        if (headers1.isEmpty()) goto _L2; else goto _L1
_L1:
        okhttp3.Headers.Builder builder;
        int j;
        builder = new okhttp3.Headers.Builder();
        j = headers.size();
_L4:
        if (i >= j)
        {
            return builder.build();
        }
        String s = headers.name(i);
        if (headers1.contains(s))
        {
            builder.add(s, headers.value(i));
        }
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        return (new okhttp3.Headers.Builder()).build();
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static Headers varyHeaders(Response response)
    {
        return varyHeaders(response.networkResponse().request().headers(), response.headers());
    }

    public static boolean varyMatches(Response response, Headers headers, Request request)
    {
        response = varyFields(response).iterator();
        String s;
        do
        {
            if (!response.hasNext())
            {
                return true;
            }
            s = (String)response.next();
        } while (Util.equal(headers.values(s), request.headers(s)));
        return false;
    }

}
