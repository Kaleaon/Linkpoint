// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.http;

import java.io.IOException;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Sink;

public interface HttpCodec
{

    public static final int DISCARD_STREAM_TIMEOUT_MILLIS = 100;

    public abstract void cancel();

    public abstract Sink createRequestBody(Request request, long l);

    public abstract void finishRequest()
        throws IOException;

    public abstract ResponseBody openResponseBody(Response response)
        throws IOException;

    public abstract okhttp3.Response.Builder readResponseHeaders()
        throws IOException;

    public abstract void writeRequestHeaders(Request request)
        throws IOException;
}
