// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache2;

import java.io.IOException;
import java.io.RandomAccessFile;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.cache2:
//            Relay, FileOperator

class >
    implements Source
{

    private FileOperator fileOperator;
    private long sourcePos;
    final Relay this$0;
    private final Timeout timeout = new Timeout();

    public void close()
        throws IOException
    {
        Object obj;
        obj = null;
        if (fileOperator == null)
        {
            break MISSING_BLOCK_LABEL_82;
        }
        fileOperator = null;
        Relay relay = Relay.this;
        relay;
        JVM INSTR monitorenter ;
        Relay relay1 = Relay.this;
        relay1.sourceCount = relay1.sourceCount - 1;
        if (sourceCount == 0)
        {
            break MISSING_BLOCK_LABEL_53;
        }
_L1:
        if (obj == null)
        {
            return;
        } else
        {
            Util.closeQuietly(((java.io.Closeable) (obj)));
            return;
        }
        obj = file;
        file = null;
          goto _L1
        obj;
        relay;
        JVM INSTR monitorexit ;
        throw obj;
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        if (fileOperator == null) goto _L2; else goto _L1
_L1:
        Relay relay = Relay.this;
        relay;
        JVM INSTR monitorenter ;
_L17:
        long l1;
        long l2;
        l2 = sourcePos;
        l1 = upstreamPos;
        if (l2 != l1) goto _L4; else goto _L3
_L3:
        if (complete) goto _L6; else goto _L5
_L5:
        if (upstreamReader != null) goto _L8; else goto _L7
_L7:
        upstreamReader = Thread.currentThread();
        int i = 1;
        relay;
        JVM INSTR monitorexit ;
_L15:
        if (i == 2) goto _L10; else goto _L9
_L9:
        l2 = upstream.read(upstreamBuffer, bufferMaxSize);
        if (l2 != -1L) goto _L12; else goto _L11
_L11:
        commit(l1);
        synchronized (Relay.this)
        {
            upstreamReader = null;
            notifyAll();
        }
        return -1L;
_L2:
        throw new IllegalStateException("closed");
_L6:
        relay;
        JVM INSTR monitorexit ;
        return -1L;
_L8:
        timeout.waitUntilNotified(Relay.this);
        continue; /* Loop/switch isn't completed */
        buffer;
        relay;
        JVM INSTR monitorexit ;
        throw buffer;
_L4:
        l2 = l1 - Relay.this.buffer.size();
        Exception exception1;
        if (sourcePos >= l2)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L14; else goto _L13
_L13:
        i = 2;
        relay;
        JVM INSTR monitorexit ;
          goto _L15
_L14:
        l = Math.min(l, l1 - sourcePos);
        Relay.this.buffer.copyTo(buffer, sourcePos - l2, l);
        sourcePos = sourcePos + l;
        relay;
        JVM INSTR monitorexit ;
        return l;
_L10:
        l = Math.min(l, l1 - sourcePos);
        fileOperator.read(32L + sourcePos, buffer, l);
        sourcePos = sourcePos + l;
        return l;
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
_L12:
        l = Math.min(l2, l);
        upstreamBuffer.copyTo(buffer, 0L, l);
        sourcePos = sourcePos + l;
        fileOperator.write(32L + l1, upstreamBuffer.clone(), l2);
        buffer = Relay.this;
        buffer;
        JVM INSTR monitorenter ;
        Relay.this.buffer.write(upstreamBuffer, l2);
        Relay relay1;
        if (Relay.this.buffer.size() <= bufferMaxSize)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_468;
        }
        Relay.this.buffer.skip(Relay.this.buffer.size() - bufferMaxSize);
        relay1 = Relay.this;
        relay1.upstreamPos = relay1.upstreamPos + l2;
        buffer;
        JVM INSTR monitorexit ;
        synchronized (Relay.this)
        {
            upstreamReader = null;
            notifyAll();
        }
        return l;
        exception1;
        buffer;
        JVM INSTR monitorexit ;
        throw exception1;
        exception1;
        synchronized (Relay.this)
        {
            upstreamReader = null;
            notifyAll();
        }
        throw exception1;
        exception2;
        buffer;
        JVM INSTR monitorexit ;
        throw exception2;
        exception3;
        buffer;
        JVM INSTR monitorexit ;
        throw exception3;
        if (true) goto _L17; else goto _L16
_L16:
    }

    public Timeout timeout()
    {
        return timeout;
    }

    ()
    {
        this$0 = Relay.this;
        super();
        fileOperator = new FileOperator(file.getChannel());
    }
}
