// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache2;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.ByteString;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.cache2:
//            FileOperator

final class Relay
{
    class RelaySource
        implements Source
    {

        private FileOperator fileOperator;
        private long sourcePos;
        final Relay this$0;
        private final Timeout timeout = new Timeout();

        public void close()
            throws IOException
        {
            Object obj;
            obj = null;
            if (fileOperator == null)
            {
                break MISSING_BLOCK_LABEL_82;
            }
            fileOperator = null;
            Relay relay = Relay.this;
            relay;
            JVM INSTR monitorenter ;
            Relay relay1 = Relay.this;
            relay1.sourceCount = relay1.sourceCount - 1;
            if (sourceCount == 0)
            {
                break MISSING_BLOCK_LABEL_53;
            }
_L1:
            if (obj == null)
            {
                return;
            } else
            {
                Util.closeQuietly(((java.io.Closeable) (obj)));
                return;
            }
            obj = file;
            file = null;
              goto _L1
            obj;
            relay;
            JVM INSTR monitorexit ;
            throw obj;
        }

        public long read(Buffer buffer1, long l)
            throws IOException
        {
            if (fileOperator == null) goto _L2; else goto _L1
_L1:
            Relay relay = Relay.this;
            relay;
            JVM INSTR monitorenter ;
_L17:
            long l1;
            long l2;
            l2 = sourcePos;
            l1 = upstreamPos;
            if (l2 != l1) goto _L4; else goto _L3
_L3:
            if (complete) goto _L6; else goto _L5
_L5:
            if (upstreamReader != null) goto _L8; else goto _L7
_L7:
            upstreamReader = Thread.currentThread();
            int i = 1;
            relay;
            JVM INSTR monitorexit ;
_L15:
            if (i == 2) goto _L10; else goto _L9
_L9:
            l2 = upstream.read(upstreamBuffer, bufferMaxSize);
            if (l2 != -1L) goto _L12; else goto _L11
_L11:
            commit(l1);
            synchronized (Relay.this)
            {
                upstreamReader = null;
                notifyAll();
            }
            return -1L;
_L2:
            throw new IllegalStateException("closed");
_L6:
            relay;
            JVM INSTR monitorexit ;
            return -1L;
_L8:
            timeout.waitUntilNotified(Relay.this);
            continue; /* Loop/switch isn't completed */
            buffer1;
            relay;
            JVM INSTR monitorexit ;
            throw buffer1;
_L4:
            l2 = l1 - buffer.size();
            Exception exception1;
            if (sourcePos >= l2)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i != 0) goto _L14; else goto _L13
_L13:
            i = 2;
            relay;
            JVM INSTR monitorexit ;
              goto _L15
_L14:
            l = Math.min(l, l1 - sourcePos);
            buffer.copyTo(buffer1, sourcePos - l2, l);
            sourcePos = sourcePos + l;
            relay;
            JVM INSTR monitorexit ;
            return l;
_L10:
            l = Math.min(l, l1 - sourcePos);
            fileOperator.read(32L + sourcePos, buffer1, l);
            sourcePos = sourcePos + l;
            return l;
            exception;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception;
_L12:
            l = Math.min(l2, l);
            upstreamBuffer.copyTo(buffer1, 0L, l);
            sourcePos = sourcePos + l;
            fileOperator.write(32L + l1, upstreamBuffer.clone(), l2);
            buffer1 = Relay.this;
            buffer1;
            JVM INSTR monitorenter ;
            buffer.write(upstreamBuffer, l2);
            Relay relay1;
            if (buffer.size() <= bufferMaxSize)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i != 0)
            {
                break MISSING_BLOCK_LABEL_468;
            }
            buffer.skip(buffer.size() - bufferMaxSize);
            relay1 = Relay.this;
            relay1.upstreamPos = relay1.upstreamPos + l2;
            buffer1;
            JVM INSTR monitorexit ;
            synchronized (Relay.this)
            {
                upstreamReader = null;
                notifyAll();
            }
            return l;
            exception1;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception1;
            exception1;
            synchronized (Relay.this)
            {
                upstreamReader = null;
                notifyAll();
            }
            throw exception1;
            exception2;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception2;
            exception3;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception3;
            if (true) goto _L17; else goto _L16
_L16:
        }

        public Timeout timeout()
        {
            return timeout;
        }

        RelaySource()
        {
            this$0 = Relay.this;
            super();
            fileOperator = new FileOperator(file.getChannel());
        }
    }


    private static final long FILE_HEADER_SIZE = 32L;
    static final ByteString PREFIX_CLEAN = ByteString.encodeUtf8("OkHttp cache v1\n");
    static final ByteString PREFIX_DIRTY = ByteString.encodeUtf8("OkHttp DIRTY :(\n");
    private static final int SOURCE_FILE = 2;
    private static final int SOURCE_UPSTREAM = 1;
    final Buffer buffer = new Buffer();
    final long bufferMaxSize;
    boolean complete;
    RandomAccessFile file;
    private final ByteString metadata;
    int sourceCount;
    Source upstream;
    final Buffer upstreamBuffer = new Buffer();
    long upstreamPos;
    Thread upstreamReader;

    private Relay(RandomAccessFile randomaccessfile, Source source, long l, ByteString bytestring, long l1)
    {
        file = randomaccessfile;
        upstream = source;
        boolean flag;
        if (source != null)
        {
            flag = false;
        } else
        {
            flag = true;
        }
        complete = flag;
        upstreamPos = l;
        metadata = bytestring;
        bufferMaxSize = l1;
    }

    public static Relay edit(File file1, Source source, ByteString bytestring, long l)
        throws IOException
    {
        file1 = new RandomAccessFile(file1, "rw");
        source = new Relay(file1, source, 0L, bytestring, l);
        file1.setLength(0L);
        source.writeHeader(PREFIX_DIRTY, -1L, -1L);
        return source;
    }

    public static Relay read(File file1)
        throws IOException
    {
        file1 = new RandomAccessFile(file1, "rw");
        FileOperator fileoperator = new FileOperator(file1.getChannel());
        Buffer buffer1 = new Buffer();
        fileoperator.read(0L, buffer1, 32L);
        if (buffer1.readByteString(PREFIX_CLEAN.size()).equals(PREFIX_CLEAN))
        {
            long l = buffer1.readLong();
            long l1 = buffer1.readLong();
            buffer1 = new Buffer();
            fileoperator.read(32L + l, buffer1, l1);
            return new Relay(file1, null, l, buffer1.readByteString(), 0L);
        } else
        {
            throw new IOException("unreadable cache file");
        }
    }

    private void writeHeader(ByteString bytestring, long l, long l1)
        throws IOException
    {
        Buffer buffer1 = new Buffer();
        buffer1.write(bytestring);
        buffer1.writeLong(l);
        buffer1.writeLong(l1);
        if (buffer1.size() != 32L)
        {
            throw new IllegalArgumentException();
        } else
        {
            (new FileOperator(file.getChannel())).write(0L, buffer1, 32L);
            return;
        }
    }

    private void writeMetadata(long l)
        throws IOException
    {
        Buffer buffer1 = new Buffer();
        buffer1.write(metadata);
        (new FileOperator(file.getChannel())).write(32L + l, buffer1, metadata.size());
    }

    void commit(long l)
        throws IOException
    {
        writeMetadata(l);
        file.getChannel().force(false);
        writeHeader(PREFIX_CLEAN, l, metadata.size());
        file.getChannel().force(false);
        this;
        JVM INSTR monitorenter ;
        complete = true;
        this;
        JVM INSTR monitorexit ;
        Util.closeQuietly(upstream);
        upstream = null;
        return;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    boolean isClosed()
    {
        return file == null;
    }

    public ByteString metadata()
    {
        return metadata;
    }

    public Source newSource()
    {
        this;
        JVM INSTR monitorenter ;
        if (file == null)
        {
            break MISSING_BLOCK_LABEL_30;
        }
        sourceCount = sourceCount + 1;
        return new RelaySource();
        this;
        JVM INSTR monitorexit ;
        return null;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

}
