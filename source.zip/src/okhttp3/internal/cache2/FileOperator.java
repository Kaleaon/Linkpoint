// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache2;

import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import okio.Buffer;

final class FileOperator
{

    private static final int BUFFER_SIZE = 8192;
    private final byte byteArray[] = new byte[8192];
    private final ByteBuffer byteBuffer;
    private final FileChannel fileChannel;

    public FileOperator(FileChannel filechannel)
    {
        byteBuffer = ByteBuffer.wrap(byteArray);
        fileChannel = filechannel;
    }

    public void read(long l, Buffer buffer, long l1)
        throws IOException
    {
        boolean flag;
        if (l1 >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IndexOutOfBoundsException();
        }
_L1:
        int i;
        if (l1 <= 0L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_148;
        }
        byteBuffer.limit((int)Math.min(8192L, l1));
        if (fileChannel.read(byteBuffer, l) == -1)
        {
            break MISSING_BLOCK_LABEL_129;
        }
        i = byteBuffer.position();
        buffer.write(byteArray, 0, i);
        l += i;
        l1 -= i;
        byteBuffer.clear();
          goto _L1
        throw new EOFException();
        buffer;
        byteBuffer.clear();
        throw buffer;
    }

    public void write(long l, Buffer buffer, long l1)
        throws IOException
    {
label0:
        {
            boolean flag;
            if (l1 < 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                if (l1 <= buffer.size())
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (flag)
                {
                    break label0;
                }
            }
            throw new IndexOutOfBoundsException();
        }
_L1:
        l1 -= i;
        byteBuffer.clear();
        if (l1 <= 0L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_175;
        }
        i = (int)Math.min(8192L, l1);
        buffer.read(byteArray, 0, i);
        byteBuffer.limit(i);
        l2 = l;
_L2:
        l = l2 + (long)fileChannel.write(byteBuffer, l2);
        flag1 = byteBuffer.hasRemaining();
        l2 = l;
        if (flag1) goto _L2; else goto _L1
        buffer;
        byteBuffer.clear();
        throw buffer;
    }
}
