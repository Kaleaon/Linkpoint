// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import okio.Okio;
import okio.Sink;
import okio.Source;

// Referenced classes of package okhttp3.internal.io:
//            FileSystem

static class 
    implements FileSystem
{

    public Sink appendingSink(File file)
        throws FileNotFoundException
    {
        Sink sink1;
        try
        {
            sink1 = Okio.appendingSink(file);
        }
        catch (FileNotFoundException filenotfoundexception)
        {
            file.getParentFile().mkdirs();
            return Okio.appendingSink(file);
        }
        return sink1;
    }

    public void delete(File file)
        throws IOException
    {
        while (file.delete() || !file.exists()) 
        {
            return;
        }
        throw new IOException((new StringBuilder()).append("failed to delete ").append(file).toString());
    }

    public void deleteContents(File file)
        throws IOException
    {
        File afile[];
        int i;
        i = 0;
        afile = file.listFiles();
        int j;
        if (afile != null)
        {
            j = afile.length;
            break MISSING_BLOCK_LABEL_15;
        } else
        {
            throw new IOException((new StringBuilder()).append("not a readable directory: ").append(file).toString());
        }
        do
        {
            if (i >= j)
            {
                return;
            }
            file = afile[i];
            if (file.isDirectory())
            {
                deleteContents(file);
            }
            if (file.delete())
            {
                i++;
            } else
            {
                throw new IOException((new StringBuilder()).append("failed to delete ").append(file).toString());
            }
        } while (true);
    }

    public boolean exists(File file)
    {
        return file.exists();
    }

    public void rename(File file, File file1)
        throws IOException
    {
        delete(file1);
        if (file.renameTo(file1))
        {
            return;
        } else
        {
            throw new IOException((new StringBuilder()).append("failed to rename ").append(file).append(" to ").append(file1).toString());
        }
    }

    public Sink sink(File file)
        throws FileNotFoundException
    {
        Sink sink1;
        try
        {
            sink1 = Okio.sink(file);
        }
        catch (FileNotFoundException filenotfoundexception)
        {
            file.getParentFile().mkdirs();
            return Okio.sink(file);
        }
        return sink1;
    }

    public long size(File file)
    {
        return file.length();
    }

    public Source source(File file)
        throws FileNotFoundException
    {
        return Okio.source(file);
    }

    ()
    {
    }
}
