// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import okhttp3.Request;
import okhttp3.Response;

// Referenced classes of package okhttp3.internal.cache:
//            CacheRequest, CacheStrategy

public interface InternalCache
{

    public abstract Response get(Request request)
        throws IOException;

    public abstract CacheRequest put(Response response)
        throws IOException;

    public abstract void remove(Request request)
        throws IOException;

    public abstract void trackConditionalCacheHit();

    public abstract void trackResponse(CacheStrategy cachestrategy);

    public abstract void update(Response response, Response response1);
}
