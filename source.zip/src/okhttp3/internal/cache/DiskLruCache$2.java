// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import okio.Sink;

// Referenced classes of package okhttp3.internal.cache:
//            FaultHidingSink, DiskLruCache

class  extends FaultHidingSink
{

    static final boolean $assertionsDisabled;
    final DiskLruCache this$0;

    protected void onException(IOException ioexception)
    {
        while ($assertionsDisabled || Thread.holdsLock(DiskLruCache.this)) 
        {
            hasJournalErrors = true;
            return;
        }
        throw new AssertionError();
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/cache/DiskLruCache.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }

    (Sink sink)
    {
        this$0 = DiskLruCache.this;
        super(sink);
    }
}
