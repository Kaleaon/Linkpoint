// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http.HttpMethod;
import okhttp3.internal.http.RealResponseBody;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.cache:
//            CacheRequest, CacheStrategy, InternalCache

public final class CacheInterceptor
    implements Interceptor
{

    final InternalCache cache;

    public CacheInterceptor(InternalCache internalcache)
    {
        cache = internalcache;
    }

    private Response cacheWritingResponse(CacheRequest cacherequest, Response response)
        throws IOException
    {
        if (cacherequest != null)
        {
            okio.Sink sink = cacherequest.body();
            if (sink != null)
            {
                cacherequest = new Source() {

                    boolean cacheRequestClosed;
                    final CacheInterceptor this$0;
                    final BufferedSink val$cacheBody;
                    final CacheRequest val$cacheRequest;
                    final BufferedSource val$source;

                    public void close()
                        throws IOException
                    {
                        if (!cacheRequestClosed && !Util.discard(this, 100, TimeUnit.MILLISECONDS))
                        {
                            cacheRequestClosed = true;
                            cacheRequest.abort();
                        }
                        source.close();
                    }

                    public long read(Buffer buffer, long l)
                        throws IOException
                    {
                        try
                        {
                            l = source.read(buffer, l);
                        }
                        // Misplaced declaration of an exception variable
                        catch (Buffer buffer)
                        {
                            if (!cacheRequestClosed)
                            {
                                cacheRequestClosed = true;
                                cacheRequest.abort();
                            }
                            throw buffer;
                        }
                        if (l == -1L)
                        {
                            if (cacheRequestClosed)
                            {
                                return -1L;
                            } else
                            {
                                cacheRequestClosed = true;
                                cacheBody.close();
                                return -1L;
                            }
                        } else
                        {
                            buffer.copyTo(cacheBody.buffer(), buffer.size() - l, l);
                            cacheBody.emitCompleteSegments();
                            return l;
                        }
                    }

                    public Timeout timeout()
                    {
                        return source.timeout();
                    }

            
            {
                this$0 = CacheInterceptor.this;
                source = bufferedsource;
                cacheRequest = cacherequest;
                cacheBody = bufferedsink;
                super();
            }
                };
                return response.newBuilder().body(new RealResponseBody(response.headers(), Okio.buffer(cacherequest))).build();
            } else
            {
                return response;
            }
        } else
        {
            return response;
        }
    }

    private static Headers combine(Headers headers, Headers headers1)
    {
        okhttp3.Headers.Builder builder;
        int i;
        boolean flag;
        int j;
        flag = false;
        builder = new okhttp3.Headers.Builder();
        j = headers.size();
        i = 0;
_L3:
        if (i < j) goto _L2; else goto _L1
_L1:
        j = headers1.size();
        i = ((flag) ? 1 : 0);
_L4:
        if (i >= j)
        {
            return builder.build();
        }
        break MISSING_BLOCK_LABEL_123;
_L2:
        String s = headers.name(i);
        String s1 = headers.value(i);
        if ((!"Warning".equalsIgnoreCase(s) || !s1.startsWith("1")) && (!isEndToEnd(s) || headers1.get(s) == null))
        {
            Internal.instance.addLenient(builder, s, s1);
        }
        i++;
          goto _L3
        headers = headers1.name(i);
        if (!"Content-Length".equalsIgnoreCase(headers) && isEndToEnd(headers))
        {
            Internal.instance.addLenient(builder, headers, headers1.value(i));
        }
        i++;
          goto _L4
    }

    static boolean isEndToEnd(String s)
    {
        while ("Connection".equalsIgnoreCase(s) || "Keep-Alive".equalsIgnoreCase(s) || "Proxy-Authenticate".equalsIgnoreCase(s) || "Proxy-Authorization".equalsIgnoreCase(s) || "TE".equalsIgnoreCase(s) || "Trailers".equalsIgnoreCase(s) || "Transfer-Encoding".equalsIgnoreCase(s) || "Upgrade".equalsIgnoreCase(s)) 
        {
            return false;
        }
        return true;
    }

    private CacheRequest maybeCache(Response response, Request request, InternalCache internalcache)
        throws IOException
    {
        if (internalcache != null)
        {
            if (CacheStrategy.isCacheable(response, request))
            {
                return internalcache.put(response);
            }
        } else
        {
            return null;
        }
        if (!HttpMethod.invalidatesCache(request.method()))
        {
            return null;
        }
        try
        {
            internalcache.remove(request);
        }
        // Misplaced declaration of an exception variable
        catch (Response response)
        {
            return null;
        }
        return null;
    }

    private static Response stripBody(Response response)
    {
        while (response == null || response.body() == null) 
        {
            return response;
        }
        return response.newBuilder().body(null).build();
    }

    public Response intercept(okhttp3.Interceptor.Chain chain)
        throws IOException
    {
_L2:
        if (request == null)
        {
            break MISSING_BLOCK_LABEL_219;
        }
        chain = chain.proceed(request);
        if (chain == null && response != null)
        {
            Util.closeQuietly(response.body());
        }
        if (response1 != null)
        {
            if (chain.code() != 304)
            {
                Util.closeQuietly(response1.body());
            } else
            {
                response = response1.newBuilder().headers(combine(response1.headers(), chain.headers())).sentRequestAtMillis(chain.sentRequestAtMillis()).receivedResponseAtMillis(chain.receivedResponseAtMillis()).cacheResponse(stripBody(response1)).networkResponse(stripBody(chain)).build();
                chain.body().close();
                cache.trackConditionalCacheHit();
                cache.update(response1, response);
                return response;
            }
        }
        response = chain.newBuilder().cacheResponse(stripBody(response1)).networkResponse(stripBody(chain)).build();
        if (!HttpHeaders.hasBody(response))
        {
            return response;
        } else
        {
            return cacheWritingResponse(maybeCache(response, chain.request(), cache), response);
        }
        CacheStrategy cachestrategy;
        Request request;
        if (cache == null)
        {
            response = null;
        } else
        {
            response = cache.get(chain.request());
        }
        cachestrategy = (new CacheStrategy.Factory(System.currentTimeMillis(), chain.request(), response)).get();
        request = cachestrategy.networkRequest;
        response1 = cachestrategy.cacheResponse;
        if (cache != null)
        {
            cache.trackResponse(cachestrategy);
        }
        if (response != null && response1 == null)
        {
            Util.closeQuietly(response.body());
        }
        if (request != null || response1 != null) goto _L2; else goto _L1
_L1:
        return (new okhttp3.Response.Builder()).request(chain.request()).protocol(Protocol.HTTP_1_1).code(504).message("Unsatisfiable Request (only-if-cached)").body(Util.EMPTY_RESPONSE).sentRequestAtMillis(-1L).receivedResponseAtMillis(System.currentTimeMillis()).build();
        return response1.newBuilder().cacheResponse(stripBody(response1)).build();
        chain;
        break MISSING_BLOCK_LABEL_249;
        if (true && response != null)
        {
            Util.closeQuietly(response.body());
        }
        throw chain;
    }
}
