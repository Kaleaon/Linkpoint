// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import okio.Okio;

// Referenced classes of package okhttp3.internal.cache:
//            DiskLruCache

class this._cls0
    implements Runnable
{

    final DiskLruCache this$0;

    public void run()
    {
        boolean flag = false;
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        Object obj;
        boolean flag1;
        if (!initialized)
        {
            flag = true;
        }
        flag1 = closed;
        if (flag | flag1) goto _L2; else goto _L1
_L1:
        trimToSize();
_L5:
        flag1 = journalRebuildRequired();
        if (flag1) goto _L4; else goto _L3
_L3:
        disklrucache;
        JVM INSTR monitorexit ;
        return;
_L2:
        disklrucache;
        JVM INSTR monitorexit ;
        return;
        obj;
        mostRecentTrimFailed = true;
          goto _L5
        obj;
        disklrucache;
        JVM INSTR monitorexit ;
        throw obj;
_L4:
        rebuildJournal();
        redundantOpCount = 0;
          goto _L3
        obj;
        mostRecentRebuildFailed = true;
        journalWriter = Okio.buffer(Okio.blackhole());
          goto _L3
    }

    ()
    {
        this$0 = DiskLruCache.this;
        super();
    }
}
