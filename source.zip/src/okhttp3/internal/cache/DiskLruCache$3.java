// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.NoSuchElementException;

// Referenced classes of package okhttp3.internal.cache:
//            DiskLruCache

class uEntries
    implements Iterator
{

    final Iterator _flddelegate;
    apshot nextSnapshot;
    apshot removeSnapshot;
    final DiskLruCache this$0;

    public boolean hasNext()
    {
        if (nextSnapshot != null)
        {
            break MISSING_BLOCK_LABEL_78;
        }
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (closed) goto _L2; else goto _L1
_L1:
        if (!_flddelegate.hasNext())
        {
            return false;
        }
          goto _L3
_L2:
        disklrucache;
        JVM INSTR monitorexit ;
        return false;
_L3:
        apshot apshot = ((try)_flddelegate.next()).snapshot();
        if (apshot == null) goto _L1; else goto _L4
_L4:
        nextSnapshot = apshot;
        disklrucache;
        JVM INSTR monitorexit ;
        return true;
        Exception exception;
        exception;
        disklrucache;
        JVM INSTR monitorexit ;
        throw exception;
        return true;
    }

    public volatile Object next()
    {
        return next();
    }

    public apshot next()
    {
        if (hasNext())
        {
            removeSnapshot = nextSnapshot;
            nextSnapshot = null;
            return removeSnapshot;
        } else
        {
            throw new NoSuchElementException();
        }
    }

    public void remove()
    {
        if (removeSnapshot != null)
        {
            Exception exception;
            try
            {
                DiskLruCache.this.remove(apshot.access._mth000(removeSnapshot));
            }
            catch (IOException ioexception) { }
            finally
            {
                removeSnapshot = null;
            }
            removeSnapshot = null;
            return;
        } else
        {
            throw new IllegalStateException("remove() before next()");
        }
        throw exception;
    }

    apshot()
    {
        this$0 = DiskLruCache.this;
        super();
        _flddelegate = (new ArrayList(lruEntries.values())).iterator();
    }
}
