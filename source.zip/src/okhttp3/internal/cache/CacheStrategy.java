// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.Internal;
import okhttp3.internal.http.HttpDate;
import okhttp3.internal.http.HttpHeaders;

public final class CacheStrategy
{
    public static class Factory
    {

        private int ageSeconds;
        final Response cacheResponse;
        private String etag;
        private Date expires;
        private Date lastModified;
        private String lastModifiedString;
        final long nowMillis;
        private long receivedResponseMillis;
        final Request request;
        private long sentRequestMillis;
        private Date servedDate;
        private String servedDateString;

        private long cacheResponseAge()
        {
            long l = 0L;
            if (servedDate != null)
            {
                l = Math.max(0L, receivedResponseMillis - servedDate.getTime());
            }
            if (ageSeconds != -1)
            {
                l = Math.max(l, TimeUnit.SECONDS.toMillis(ageSeconds));
            }
            return l + (receivedResponseMillis - sentRequestMillis) + (nowMillis - receivedResponseMillis);
        }

        private long computeFreshnessLifetime()
        {
            boolean flag = true;
            long l2 = 0L;
            CacheControl cachecontrol = cacheResponse.cacheControl();
            if (cachecontrol.maxAgeSeconds() == -1)
            {
                if (expires == null)
                {
                    if (lastModified == null || cacheResponse.request().url().query() != null)
                    {
                        return 0L;
                    }
                } else
                {
                    long l;
                    if (servedDate == null)
                    {
                        l = receivedResponseMillis;
                    } else
                    {
                        l = servedDate.getTime();
                    }
                    l = expires.getTime() - l;
                    if (l > 0L)
                    {
                        flag = false;
                    }
                    if (!flag)
                    {
                        return l;
                    } else
                    {
                        return 0L;
                    }
                }
            } else
            {
                return TimeUnit.SECONDS.toMillis(cachecontrol.maxAgeSeconds());
            }
            long l1;
            long l3;
            if (servedDate == null)
            {
                l1 = sentRequestMillis;
            } else
            {
                l1 = servedDate.getTime();
            }
            l3 = l1 - lastModified.getTime();
            if (l3 <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            l1 = l2;
            if (!flag)
            {
                l1 = l3 / 10L;
            }
            return l1;
        }

        private CacheStrategy getCandidate()
        {
            long l;
            long l1;
            long l2;
            long l3;
            if (cacheResponse != null)
            {
                if (!request.isHttps() || cacheResponse.handshake() != null)
                {
                    if (!CacheStrategy.isCacheable(cacheResponse, request))
                    {
                        break MISSING_BLOCK_LABEL_95;
                    }
                    CacheControl cachecontrol = request.cacheControl();
                    if (cachecontrol.noCache() || hasConditions(request))
                    {
                        return new CacheStrategy(request, null);
                    }
                    l3 = cacheResponseAge();
                    l = computeFreshnessLifetime();
                    CacheControl cachecontrol1;
                    if (cachecontrol.maxAgeSeconds() != -1)
                    {
                        l = Math.min(l, TimeUnit.SECONDS.toMillis(cachecontrol.maxAgeSeconds()));
                    }
                    l1 = 0L;
                    if (cachecontrol.minFreshSeconds() != -1)
                    {
                        l1 = TimeUnit.SECONDS.toMillis(cachecontrol.minFreshSeconds());
                    }
                    l2 = 0L;
                    cachecontrol1 = cacheResponse.cacheControl();
                    if (!cachecontrol1.mustRevalidate() && cachecontrol.maxStaleSeconds() != -1)
                    {
                        l2 = TimeUnit.SECONDS.toMillis(cachecontrol.maxStaleSeconds());
                    }
                    break MISSING_BLOCK_LABEL_167;
                } else
                {
                    return new CacheStrategy(request, null);
                }
            } else
            {
                return new CacheStrategy(request, null);
            }
            return new CacheStrategy(request, null);
            if (!cachecontrol1.noCache())
            {
                boolean flag;
                if (l3 + l1 >= l2 + l)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    okhttp3.Response.Builder builder = cacheResponse.newBuilder();
                    if (l1 + l3 < l)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (!flag)
                    {
                        builder.addHeader("Warning", "110 HttpURLConnection \"Response is stale\"");
                    }
                    if (l3 <= 0x5265c00L)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (!flag && isFreshnessLifetimeHeuristic())
                    {
                        builder.addHeader("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                    }
                    return new CacheStrategy(null, builder.build());
                }
            }
            if (etag != null) goto _L2; else goto _L1
_L2:
            s1 = "If-None-Match";
            s = etag;
_L4:
            okhttp3.Headers.Builder builder1 = request.headers().newBuilder();
            Internal.instance.addLenient(builder1, s1, s);
            return new CacheStrategy(request.newBuilder().headers(builder1.build()).build(), cacheResponse);
_L1:
            String s;
            String s1;
            if (lastModified == null)
            {
                if (servedDate == null)
                {
                    return new CacheStrategy(request, null);
                }
            } else
            {
                s1 = "If-Modified-Since";
                s = lastModifiedString;
                continue; /* Loop/switch isn't completed */
            }
            s1 = "If-Modified-Since";
            s = servedDateString;
            if (true) goto _L4; else goto _L3
_L3:
        }

        private static boolean hasConditions(Request request1)
        {
            while (request1.header("If-Modified-Since") != null || request1.header("If-None-Match") != null) 
            {
                return true;
            }
            return false;
        }

        private boolean isFreshnessLifetimeHeuristic()
        {
            while (cacheResponse.cacheControl().maxAgeSeconds() != -1 || expires != null) 
            {
                return false;
            }
            return true;
        }

        public CacheStrategy get()
        {
            for (CacheStrategy cachestrategy = getCandidate(); cachestrategy.networkRequest == null || !request.cacheControl().onlyIfCached();)
            {
                return cachestrategy;
            }

            return new CacheStrategy(null, null);
        }

        public Factory(long l, Request request1, Response response)
        {
            int i = 0;
            super();
            ageSeconds = -1;
            nowMillis = l;
            request = request1;
            cacheResponse = response;
            if (response != null)
            {
                sentRequestMillis = response.sentRequestAtMillis();
                receivedResponseMillis = response.receivedResponseAtMillis();
                request1 = response.headers();
                int j = request1.size();
                while (i < j) 
                {
                    response = request1.name(i);
                    String s = request1.value(i);
                    if (!"Date".equalsIgnoreCase(response))
                    {
                        if (!"Expires".equalsIgnoreCase(response))
                        {
                            if (!"Last-Modified".equalsIgnoreCase(response))
                            {
                                if (!"ETag".equalsIgnoreCase(response))
                                {
                                    if ("Age".equalsIgnoreCase(response))
                                    {
                                        ageSeconds = HttpHeaders.parseSeconds(s, -1);
                                    }
                                } else
                                {
                                    etag = s;
                                }
                            } else
                            {
                                lastModified = HttpDate.parse(s);
                                lastModifiedString = s;
                            }
                        } else
                        {
                            expires = HttpDate.parse(s);
                        }
                    } else
                    {
                        servedDate = HttpDate.parse(s);
                        servedDateString = s;
                    }
                    i++;
                }
            }
        }
    }


    public final Response cacheResponse;
    public final Request networkRequest;

    CacheStrategy(Request request, Response response)
    {
        networkRequest = request;
        cacheResponse = response;
    }

    public static boolean isCacheable(Response response, Request request)
    {
        response.code();
        JVM INSTR lookupswitch 13: default 120
    //                   200: 131
    //                   203: 131
    //                   204: 131
    //                   300: 131
    //                   301: 131
    //                   302: 122
    //                   307: 122
    //                   308: 131
    //                   404: 131
    //                   405: 131
    //                   410: 131
    //                   414: 131
    //                   501: 131;
           goto _L1 _L2 _L2 _L2 _L2 _L2 _L3 _L3 _L2 _L2 _L2 _L2 _L2 _L2
_L1:
        return false;
_L3:
        if (response.header("Expires") != null || response.cacheControl().maxAgeSeconds() != -1 || response.cacheControl().isPublic() || response.cacheControl().isPrivate()) goto _L2; else goto _L4
_L4:
        return false;
_L2:
        return !response.cacheControl().noStore() && !request.cacheControl().noStore();
    }
}
