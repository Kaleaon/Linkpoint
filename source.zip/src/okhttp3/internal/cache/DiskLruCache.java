// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.NoSuchElementException;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.internal.Util;
import okhttp3.internal.io.FileSystem;
import okhttp3.internal.platform.Platform;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;
import okio.Source;

// Referenced classes of package okhttp3.internal.cache:
//            FaultHidingSink

public final class DiskLruCache
    implements Closeable, Flushable
{
    public final class Editor
    {

        private boolean done;
        final Entry entry;
        final DiskLruCache this$0;
        final boolean written[];

        public void abort()
            throws IOException
        {
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            if (done) goto _L2; else goto _L1
_L1:
            if (entry.currentEditor == this)
            {
                break MISSING_BLOCK_LABEL_46;
            }
_L3:
            done = true;
            return;
_L2:
            throw new IllegalStateException();
            Exception exception;
            exception;
            disklrucache;
            JVM INSTR monitorexit ;
            throw exception;
            completeEdit(this, false);
              goto _L3
        }

        public void abortUnlessCommitted()
        {
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            if (!done) goto _L2; else goto _L1
_L1:
            return;
_L2:
            Editor editor = entry.currentEditor;
            Exception exception;
            if (editor == this)
            {
                try
                {
                    completeEdit(this, false);
                }
                catch (IOException ioexception) { }
                finally { }
            }
              goto _L1
            disklrucache;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void commit()
            throws IOException
        {
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            if (done) goto _L2; else goto _L1
_L1:
            if (entry.currentEditor == this)
            {
                break MISSING_BLOCK_LABEL_46;
            }
_L3:
            done = true;
            return;
_L2:
            throw new IllegalStateException();
            Exception exception;
            exception;
            disklrucache;
            JVM INSTR monitorexit ;
            throw exception;
            completeEdit(this, true);
              goto _L3
        }

        void detach()
        {
            if (entry.currentEditor != this)
            {
                return;
            }
            int i = 0;
            do
            {
                if (i >= valueCount)
                {
                    entry.currentEditor = null;
                    return;
                }
                try
                {
                    fileSystem.delete(entry.dirtyFiles[i]);
                }
                catch (IOException ioexception) { }
                i++;
            } while (true);
        }

        public Sink newSink(int i)
        {
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            if (done) goto _L2; else goto _L1
_L1:
            if (entry.currentEditor != this) goto _L4; else goto _L3
_L3:
            if (!entry.readable)
            {
                break MISSING_BLOCK_LABEL_94;
            }
_L5:
            Object obj = entry.dirtyFiles[i];
            obj = fileSystem.sink(((File) (obj)));
            obj = new FaultHidingSink(((Sink) (obj))) {

                final Editor this$1;

                protected void onException(IOException ioexception)
                {
                    synchronized (_fld0)
                    {
                        detach();
                    }
                    return;
                    exception;
                    ioexception;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

            
            {
                this$1 = Editor.this;
                super(sink);
            }
            };
            return ((Sink) (obj));
_L2:
            throw new IllegalStateException();
            Object obj1;
            obj1;
            disklrucache;
            JVM INSTR monitorexit ;
            throw obj1;
_L4:
            obj1 = Okio.blackhole();
            disklrucache;
            JVM INSTR monitorexit ;
            return ((Sink) (obj1));
            written[i] = true;
              goto _L5
            obj1;
            obj1 = Okio.blackhole();
            disklrucache;
            JVM INSTR monitorexit ;
            return ((Sink) (obj1));
        }

        public Source newSource(int i)
        {
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            if (done) goto _L2; else goto _L1
_L1:
            if (entry.readable) goto _L4; else goto _L3
_L3:
            return null;
_L2:
            throw new IllegalStateException();
            Object obj;
            obj;
            disklrucache;
            JVM INSTR monitorexit ;
            Object obj1;
            throw obj;
_L4:
            if ((obj1 = entry.currentEditor) != this) goto _L3; else goto _L5
_L5:
            obj1 = fileSystem.source(entry.cleanFiles[i]);
            disklrucache;
            JVM INSTR monitorexit ;
            return ((Source) (obj1));
            obj1;
            disklrucache;
            JVM INSTR monitorexit ;
            return null;
        }

        Editor(Entry entry1)
        {
            this$0 = DiskLruCache.this;
            super();
            entry = entry1;
            if (!entry1.readable)
            {
                disklrucache = new boolean[valueCount];
            } else
            {
                disklrucache = null;
            }
            written = DiskLruCache.this;
        }
    }

    private final class Entry
    {

        final File cleanFiles[];
        Editor currentEditor;
        final File dirtyFiles[];
        final String key;
        final long lengths[];
        boolean readable;
        long sequenceNumber;
        final DiskLruCache this$0;

        private IOException invalidLengths(String as[])
            throws IOException
        {
            throw new IOException((new StringBuilder()).append("unexpected journal line: ").append(Arrays.toString(as)).toString());
        }

        void setLengths(String as[])
            throws IOException
        {
            if (as.length != valueCount) goto _L2; else goto _L1
_L1:
            int i = 0;
_L4:
            int j;
            try
            {
                j = as.length;
            }
            catch (NumberFormatException numberformatexception)
            {
                throw invalidLengths(as);
            }
            if (i >= j)
            {
                return;
            }
              goto _L3
_L2:
            throw invalidLengths(as);
_L3:
            lengths[i] = Long.parseLong(as[i]);
            i++;
              goto _L4
        }

        Snapshot snapshot()
        {
            boolean flag = false;
            if (!Thread.holdsLock(DiskLruCache.this)) goto _L2; else goto _L1
_L1:
            Source asource[];
            long al[];
            int i;
            asource = new Source[valueCount];
            al = (long[])lengths.clone();
            i = 0;
_L6:
            if (i < valueCount) goto _L4; else goto _L3
_L3:
            Snapshot snapshot1 = new Snapshot(key, sequenceNumber, asource, al);
            return snapshot1;
_L2:
            throw new AssertionError();
_L4:
            asource[i] = fileSystem.source(cleanFiles[i]);
            i++;
            if (true) goto _L6; else goto _L5
_L5:
            Util.closeQuietly(asource[i]);
            i++;
_L8:
            while (i >= valueCount || asource[i] == null) 
            {
                try
                {
                    removeEntry(this);
                }
                catch (IOException ioexception)
                {
                    return null;
                }
                return null;
            }
            if (true) goto _L5; else goto _L7
_L7:
            FileNotFoundException filenotfoundexception;
            filenotfoundexception;
            i = ((flag) ? 1 : 0);
              goto _L8
        }

        void writeLengths(BufferedSink bufferedsink)
            throws IOException
        {
            long al[] = lengths;
            int j = al.length;
            int i = 0;
            do
            {
                if (i >= j)
                {
                    return;
                }
                long l = al[i];
                bufferedsink.writeByte(32).writeDecimalLong(l);
                i++;
            } while (true);
        }

        Entry(String s)
        {
            this$0 = DiskLruCache.this;
            super();
            key = s;
            lengths = new long[valueCount];
            cleanFiles = new File[valueCount];
            dirtyFiles = new File[valueCount];
            s = (new StringBuilder(s)).append('.');
            int j = s.length();
            int i = 0;
            do
            {
                if (i >= valueCount)
                {
                    return;
                }
                s.append(i);
                cleanFiles[i] = new File(directory, s.toString());
                s.append(".tmp");
                dirtyFiles[i] = new File(directory, s.toString());
                s.setLength(j);
                i++;
            } while (true);
        }
    }

    public final class Snapshot
        implements Closeable
    {

        private final String key;
        private final long lengths[];
        private final long sequenceNumber;
        private final Source sources[];
        final DiskLruCache this$0;

        public void close()
        {
            Source asource[] = sources;
            int j = asource.length;
            int i = 0;
            do
            {
                if (i >= j)
                {
                    return;
                }
                Util.closeQuietly(asource[i]);
                i++;
            } while (true);
        }

        public Editor edit()
            throws IOException
        {
            return DiskLruCache.this.edit(key, sequenceNumber);
        }

        public long getLength(int i)
        {
            return lengths[i];
        }

        public Source getSource(int i)
        {
            return sources[i];
        }

        public String key()
        {
            return key;
        }


        Snapshot(String s, long l, Source asource[], long al[])
        {
            this$0 = DiskLruCache.this;
            super();
            key = s;
            sequenceNumber = l;
            sources = asource;
            lengths = al;
        }
    }


    static final boolean $assertionsDisabled;
    static final long ANY_SEQUENCE_NUMBER = -1L;
    private static final String CLEAN = "CLEAN";
    private static final String DIRTY = "DIRTY";
    static final String JOURNAL_FILE = "journal";
    static final String JOURNAL_FILE_BACKUP = "journal.bkp";
    static final String JOURNAL_FILE_TEMP = "journal.tmp";
    static final Pattern LEGAL_KEY_PATTERN = Pattern.compile("[a-z0-9_-]{1,120}");
    static final String MAGIC = "libcore.io.DiskLruCache";
    private static final String READ = "READ";
    private static final String REMOVE = "REMOVE";
    static final String VERSION_1 = "1";
    private final int appVersion;
    private final Runnable cleanupRunnable = new Runnable() {

        final DiskLruCache this$0;

        public void run()
        {
            boolean flag = false;
            DiskLruCache disklrucache = DiskLruCache.this;
            disklrucache;
            JVM INSTR monitorenter ;
            Object obj;
            boolean flag1;
            if (!initialized)
            {
                flag = true;
            }
            flag1 = closed;
            if (flag | flag1) goto _L2; else goto _L1
_L1:
            trimToSize();
_L5:
            flag1 = journalRebuildRequired();
            if (flag1) goto _L4; else goto _L3
_L3:
            disklrucache;
            JVM INSTR monitorexit ;
            return;
_L2:
            disklrucache;
            JVM INSTR monitorexit ;
            return;
            obj;
            mostRecentTrimFailed = true;
              goto _L5
            obj;
            disklrucache;
            JVM INSTR monitorexit ;
            throw obj;
_L4:
            rebuildJournal();
            redundantOpCount = 0;
              goto _L3
            obj;
            mostRecentRebuildFailed = true;
            journalWriter = Okio.buffer(Okio.blackhole());
              goto _L3
        }

            
            {
                this$0 = DiskLruCache.this;
                super();
            }
    };
    boolean closed;
    final File directory;
    private final Executor executor;
    final FileSystem fileSystem;
    boolean hasJournalErrors;
    boolean initialized;
    private final File journalFile;
    private final File journalFileBackup;
    private final File journalFileTmp;
    BufferedSink journalWriter;
    final LinkedHashMap lruEntries = new LinkedHashMap(0, 0.75F, true);
    private long maxSize;
    boolean mostRecentRebuildFailed;
    boolean mostRecentTrimFailed;
    private long nextSequenceNumber;
    int redundantOpCount;
    private long size;
    final int valueCount;

    DiskLruCache(FileSystem filesystem, File file, int i, int j, long l, Executor executor1)
    {
        size = 0L;
        nextSequenceNumber = 0L;
        fileSystem = filesystem;
        directory = file;
        appVersion = i;
        journalFile = new File(file, "journal");
        journalFileTmp = new File(file, "journal.tmp");
        journalFileBackup = new File(file, "journal.bkp");
        valueCount = j;
        maxSize = l;
        executor = executor1;
    }

    private void checkNotClosed()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = isClosed();
        if (flag)
        {
            break MISSING_BLOCK_LABEL_14;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        throw new IllegalStateException("cache is closed");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public static DiskLruCache create(FileSystem filesystem, File file, int i, int j, long l)
    {
        boolean flag;
        if (l > 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        if (j > 0)
        {
            return new DiskLruCache(filesystem, file, i, j, l, new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), Util.threadFactory("OkHttp DiskLruCache", true)));
        } else
        {
            throw new IllegalArgumentException("valueCount <= 0");
        }
    }

    private BufferedSink newJournalWriter()
        throws FileNotFoundException
    {
        return Okio.buffer(new FaultHidingSink(fileSystem.appendingSink(journalFile)) {

            static final boolean $assertionsDisabled;
            final DiskLruCache this$0;

            protected void onException(IOException ioexception)
            {
                while ($assertionsDisabled || Thread.holdsLock(DiskLruCache.this)) 
                {
                    hasJournalErrors = true;
                    return;
                }
                throw new AssertionError();
            }

            static 
            {
                boolean flag = false;
                if (!okhttp3/internal/cache/DiskLruCache.desiredAssertionStatus())
                {
                    flag = true;
                }
                $assertionsDisabled = flag;
            }

            
            {
                this$0 = DiskLruCache.this;
                super(sink);
            }
        });
    }

    private void processJournal()
        throws IOException
    {
        Iterator iterator;
        fileSystem.delete(journalFileTmp);
        iterator = lruEntries.values().iterator();
_L3:
        Entry entry;
        if (!iterator.hasNext())
        {
            return;
        }
        entry = (Entry)iterator.next();
        if (entry.currentEditor == null) goto _L2; else goto _L1
_L1:
        int i;
        entry.currentEditor = null;
        i = 0;
_L4:
        if (i < valueCount)
        {
            break MISSING_BLOCK_LABEL_109;
        }
        iterator.remove();
          goto _L3
_L2:
        i = 0;
        while (i < valueCount) 
        {
            size = size + entry.lengths[i];
            i++;
        }
          goto _L3
        fileSystem.delete(entry.cleanFiles[i]);
        fileSystem.delete(entry.dirtyFiles[i]);
        i++;
          goto _L4
    }

    private void readJournal()
        throws IOException
    {
        BufferedSource bufferedsource;
        int i;
        i = 0;
        bufferedsource = Okio.buffer(fileSystem.source(journalFile));
        String s;
        String s1;
        String s2;
        String s3;
        String s4;
        s = bufferedsource.readUtf8LineStrict();
        s1 = bufferedsource.readUtf8LineStrict();
        s2 = bufferedsource.readUtf8LineStrict();
        s3 = bufferedsource.readUtf8LineStrict();
        s4 = bufferedsource.readUtf8LineStrict();
        if ("libcore.io.DiskLruCache".equals(s)) goto _L2; else goto _L1
_L1:
        throw new IOException((new StringBuilder()).append("unexpected journal header: [").append(s).append(", ").append(s1).append(", ").append(s3).append(", ").append(s4).append("]").toString());
        Object obj;
        obj;
        Util.closeQuietly(bufferedsource);
        throw obj;
_L2:
        boolean flag;
        if (!"1".equals(s1) || !Integer.toString(appVersion).equals(s2) || !Integer.toString(valueCount).equals(s3) || !(flag = "".equals(s4))) goto _L1; else goto _L3
_L3:
        readJournalLine(bufferedsource.readUtf8LineStrict());
        i++;
        if (true) goto _L3; else goto _L4
_L4:
        obj;
        redundantOpCount = i - lruEntries.size();
        if (!bufferedsource.exhausted())
        {
            break MISSING_BLOCK_LABEL_250;
        }
        journalWriter = newJournalWriter();
_L5:
        Util.closeQuietly(bufferedsource);
        return;
        rebuildJournal();
          goto _L5
    }

    private void readJournalLine(String s)
        throws IOException
    {
        Object obj;
        int i;
        int k;
        i = s.indexOf(' ');
        if (i != -1)
        {
            int j = i + 1;
            k = s.indexOf(' ', j);
            Entry entry;
            if (k != -1)
            {
                obj = s.substring(j, k);
            } else
            {
                obj = s.substring(j);
                if (i == "REMOVE".length() && s.startsWith("REMOVE"))
                {
                    lruEntries.remove(obj);
                    return;
                }
            }
            entry = (Entry)lruEntries.get(obj);
            if (entry != null)
            {
                obj = entry;
            } else
            {
                Entry entry1 = new Entry(((String) (obj)));
                lruEntries.put(obj, entry1);
                obj = entry1;
            }
            break MISSING_BLOCK_LABEL_63;
        } else
        {
            throw new IOException((new StringBuilder()).append("unexpected journal line: ").append(s).toString());
        }
        if (k == -1 || i != "CLEAN".length() || !s.startsWith("CLEAN")) goto _L2; else goto _L1
_L1:
        s = s.substring(k + 1).split(" ");
        obj.readable = true;
        obj.currentEditor = null;
        ((Entry) (obj)).setLengths(s);
_L5:
        return;
_L2:
        if (k != -1 || i != "DIRTY".length() || !s.startsWith("DIRTY")) goto _L4; else goto _L3
_L3:
        obj.currentEditor = new Editor(((Entry) (obj)));
        return;
_L4:
        if (k != -1 || i != "READ".length() || !s.startsWith("READ"))
        {
            throw new IOException((new StringBuilder()).append("unexpected journal line: ").append(s).toString());
        }
          goto _L5
    }

    private void validateKey(String s)
    {
        if (LEGAL_KEY_PATTERN.matcher(s).matches())
        {
            return;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("keys must match regex [a-z0-9_-]{1,120}: \"").append(s).append("\"").toString());
        }
    }

    public void close()
        throws IOException
    {
        int i = 0;
        this;
        JVM INSTR monitorenter ;
        if (initialized) goto _L2; else goto _L1
_L1:
        closed = true;
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (closed) goto _L1; else goto _L3
_L3:
        Entry aentry[];
        int j;
        aentry = (Entry[])lruEntries.values().toArray(new Entry[lruEntries.size()]);
        j = aentry.length;
_L5:
        if (i < j)
        {
            break MISSING_BLOCK_LABEL_88;
        }
        trimToSize();
        journalWriter.close();
        journalWriter = null;
        closed = true;
        this;
        JVM INSTR monitorexit ;
        return;
        Entry entry = aentry[i];
        if (entry.currentEditor == null)
        {
            break MISSING_BLOCK_LABEL_117;
        }
        entry.currentEditor.abort();
        break MISSING_BLOCK_LABEL_117;
        Exception exception;
        exception;
        throw exception;
        i++;
        if (true) goto _L5; else goto _L4
_L4:
    }

    void completeEdit(Editor editor, boolean flag)
        throws IOException
    {
        boolean flag1 = true;
        this;
        JVM INSTR monitorenter ;
        Entry entry = editor.entry;
        if (entry.currentEditor != editor) goto _L2; else goto _L1
_L1:
        if (flag) goto _L4; else goto _L3
_L20:
        int i;
        if (i < valueCount) goto _L6; else goto _L5
_L5:
        redundantOpCount = redundantOpCount + 1;
        entry.currentEditor = null;
        if (entry.readable | flag) goto _L8; else goto _L7
_L7:
        lruEntries.remove(entry.key);
        journalWriter.writeUtf8("REMOVE").writeByte(32);
        journalWriter.writeUtf8(entry.key);
        journalWriter.writeByte(10);
_L18:
        journalWriter.flush();
        if (size > maxSize)
        {
            i = ((flag1) ? 1 : 0);
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L10; else goto _L9
_L9:
        flag = journalRebuildRequired();
        if (flag) goto _L10; else goto _L11
_L11:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        throw new IllegalStateException();
        editor;
        this;
        JVM INSTR monitorexit ;
        throw editor;
_L4:
        if (entry.readable) goto _L3; else goto _L12
_L12:
        i = 0;
_L13:
        if (i >= valueCount)
        {
            break; /* Loop/switch isn't completed */
        }
        if (!editor.written[i])
        {
            break MISSING_BLOCK_LABEL_227;
        }
        if (!fileSystem.exists(entry.dirtyFiles[i]))
        {
            break MISSING_BLOCK_LABEL_260;
        }
        i++;
        if (true) goto _L13; else goto _L3
        editor.abort();
        throw new IllegalStateException((new StringBuilder()).append("Newly created entry didn't create value for index ").append(i).toString());
        editor.abort();
        this;
        JVM INSTR monitorexit ;
        return;
_L6:
        editor = entry.dirtyFiles[i];
        if (flag) goto _L15; else goto _L14
_L14:
        fileSystem.delete(editor);
          goto _L16
_L15:
        if (fileSystem.exists(editor))
        {
            File file = entry.cleanFiles[i];
            fileSystem.rename(editor, file);
            long l = entry.lengths[i];
            long l2 = fileSystem.size(file);
            entry.lengths[i] = l2;
            size = l2 + (size - l);
        }
          goto _L16
_L8:
        entry.readable = true;
        journalWriter.writeUtf8("CLEAN").writeByte(32);
        journalWriter.writeUtf8(entry.key);
        entry.writeLengths(journalWriter);
        journalWriter.writeByte(10);
        if (!flag) goto _L18; else goto _L17
_L17:
        long l1 = nextSequenceNumber;
        nextSequenceNumber = 1L + l1;
        entry.sequenceNumber = l1;
          goto _L18
_L10:
        executor.execute(cleanupRunnable);
          goto _L11
_L3:
        i = 0;
        continue; /* Loop/switch isn't completed */
_L16:
        i++;
        if (true) goto _L20; else goto _L19
_L19:
    }

    public void delete()
        throws IOException
    {
        close();
        fileSystem.deleteContents(directory);
    }

    public Editor edit(String s)
        throws IOException
    {
        return edit(s, -1L);
    }

    Editor edit(String s, long l)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        Object obj;
        initialize();
        checkNotClosed();
        validateKey(s);
        obj = (Entry)lruEntries.get(s);
        if (l == -1L) goto _L2; else goto _L1
_L1:
        if (obj != null) goto _L4; else goto _L3
_L3:
        this;
        JVM INSTR monitorexit ;
        return null;
_L4:
        if (((Entry) (obj)).sequenceNumber != l) goto _L3; else goto _L2
_L13:
        if (!mostRecentTrimFailed) goto _L6; else goto _L5
_L5:
        executor.execute(cleanupRunnable);
        this;
        JVM INSTR monitorexit ;
        return null;
_L14:
        Editor editor = ((Entry) (obj)).currentEditor;
        if (editor == null)
        {
            break; /* Loop/switch isn't completed */
        }
        this;
        JVM INSTR monitorexit ;
        return null;
_L6:
        if (mostRecentRebuildFailed) goto _L5; else goto _L7
_L7:
        journalWriter.writeUtf8("DIRTY").writeByte(32).writeUtf8(s).writeByte(10);
        journalWriter.flush();
        if (hasJournalErrors) goto _L9; else goto _L8
_L8:
        if (obj == null) goto _L11; else goto _L10
_L10:
        s = ((String) (obj));
_L12:
        obj = new Editor(s);
        s.currentEditor = ((Editor) (obj));
        this;
        JVM INSTR monitorexit ;
        return ((Editor) (obj));
_L9:
        this;
        JVM INSTR monitorexit ;
        return null;
_L11:
        obj = new Entry(s);
        lruEntries.put(s, obj);
        s = ((String) (obj));
          goto _L12
        s;
        throw s;
_L2:
        if (obj != null) goto _L14; else goto _L13
    }

    public void evictAll()
        throws IOException
    {
        int i = 0;
        this;
        JVM INSTR monitorenter ;
        Entry aentry[];
        int j;
        initialize();
        aentry = (Entry[])lruEntries.values().toArray(new Entry[lruEntries.size()]);
        j = aentry.length;
_L2:
        if (i < j)
        {
            break MISSING_BLOCK_LABEL_50;
        }
        mostRecentTrimFailed = false;
        this;
        JVM INSTR monitorexit ;
        return;
        removeEntry(aentry[i]);
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        throw exception;
    }

    public void flush()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (!initialized)
        {
            break MISSING_BLOCK_LABEL_29;
        }
        checkNotClosed();
        trimToSize();
        journalWriter.flush();
        return;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Snapshot get(String s)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        Object obj;
        initialize();
        checkNotClosed();
        validateKey(s);
        obj = (Entry)lruEntries.get(s);
        if (obj != null) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return null;
_L2:
        if (!((Entry) (obj)).readable) goto _L1; else goto _L3
_L3:
        obj = ((Entry) (obj)).snapshot();
        if (obj == null) goto _L5; else goto _L4
_L4:
        boolean flag;
        redundantOpCount = redundantOpCount + 1;
        journalWriter.writeUtf8("READ").writeByte(32).writeUtf8(s).writeByte(10);
        flag = journalRebuildRequired();
        if (flag) goto _L7; else goto _L6
_L6:
        this;
        JVM INSTR monitorexit ;
        return ((Snapshot) (obj));
_L5:
        this;
        JVM INSTR monitorexit ;
        return null;
_L7:
        executor.execute(cleanupRunnable);
        if (true) goto _L6; else goto _L8
_L8:
        s;
        throw s;
    }

    public File getDirectory()
    {
        return directory;
    }

    public long getMaxSize()
    {
        this;
        JVM INSTR monitorenter ;
        long l = maxSize;
        this;
        JVM INSTR monitorexit ;
        return l;
        Exception exception;
        exception;
        throw exception;
    }

    public void initialize()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (!$assertionsDisabled) goto _L2; else goto _L1
_L1:
        if (initialized) goto _L4; else goto _L3
_L3:
        if (fileSystem.exists(journalFileBackup)) goto _L6; else goto _L5
_L5:
        if (fileSystem.exists(journalFile)) goto _L8; else goto _L7
_L7:
        rebuildJournal();
        initialized = true;
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (Thread.holdsLock(this)) goto _L1; else goto _L9
_L9:
        throw new AssertionError();
        Object obj;
        obj;
        this;
        JVM INSTR monitorexit ;
        throw obj;
_L4:
        this;
        JVM INSTR monitorexit ;
        return;
_L6:
label0:
        {
            if (fileSystem.exists(journalFile))
            {
                break label0;
            }
            fileSystem.rename(journalFileBackup, journalFile);
        }
          goto _L5
        fileSystem.delete(journalFileBackup);
          goto _L5
_L8:
        readJournal();
        processJournal();
        initialized = true;
        this;
        JVM INSTR monitorexit ;
        return;
        obj;
        Platform.get().log(5, (new StringBuilder()).append("DiskLruCache ").append(directory).append(" is corrupt: ").append(((IOException) (obj)).getMessage()).append(", removing").toString(), ((Throwable) (obj)));
        delete();
        closed = false;
          goto _L7
    }

    public boolean isClosed()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = closed;
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    boolean journalRebuildRequired()
    {
        while (redundantOpCount < 2000 || redundantOpCount < lruEntries.size()) 
        {
            return false;
        }
        return true;
    }

    void rebuildJournal()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        if (journalWriter != null) goto _L2; else goto _L1
_L1:
        Object obj = Okio.buffer(fileSystem.sink(journalFileTmp));
        Iterator iterator;
        ((BufferedSink) (obj)).writeUtf8("libcore.io.DiskLruCache").writeByte(10);
        ((BufferedSink) (obj)).writeUtf8("1").writeByte(10);
        ((BufferedSink) (obj)).writeDecimalLong(appVersion).writeByte(10);
        ((BufferedSink) (obj)).writeDecimalLong(valueCount).writeByte(10);
        ((BufferedSink) (obj)).writeByte(10);
        iterator = lruEntries.values().iterator();
_L5:
        boolean flag = iterator.hasNext();
        if (flag) goto _L4; else goto _L3
_L3:
        ((BufferedSink) (obj)).close();
        if (fileSystem.exists(journalFile))
        {
            break MISSING_BLOCK_LABEL_330;
        }
_L6:
        fileSystem.rename(journalFileTmp, journalFile);
        fileSystem.delete(journalFileBackup);
        journalWriter = newJournalWriter();
        hasJournalErrors = false;
        mostRecentRebuildFailed = false;
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        journalWriter.close();
          goto _L1
        obj;
        throw obj;
_L4:
        Entry entry;
        entry = (Entry)iterator.next();
        if (entry.currentEditor != null)
        {
            break MISSING_BLOCK_LABEL_291;
        }
        ((BufferedSink) (obj)).writeUtf8("CLEAN").writeByte(32);
        ((BufferedSink) (obj)).writeUtf8(entry.key);
        entry.writeLengths(((BufferedSink) (obj)));
        ((BufferedSink) (obj)).writeByte(10);
          goto _L5
        Exception exception;
        exception;
        ((BufferedSink) (obj)).close();
        throw exception;
        ((BufferedSink) (obj)).writeUtf8("DIRTY").writeByte(32);
        ((BufferedSink) (obj)).writeUtf8(entry.key);
        ((BufferedSink) (obj)).writeByte(10);
          goto _L5
        fileSystem.rename(journalFile, journalFileBackup);
          goto _L6
    }

    public boolean remove(String s)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        initialize();
        checkNotClosed();
        validateKey(s);
        s = (Entry)lruEntries.get(s);
        if (s == null) goto _L2; else goto _L1
_L1:
        boolean flag1 = removeEntry(s);
        if (flag1) goto _L4; else goto _L3
_L3:
        this;
        JVM INSTR monitorexit ;
        return flag1;
_L2:
        this;
        JVM INSTR monitorexit ;
        return false;
_L4:
        boolean flag;
        if (size > maxSize)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            continue; /* Loop/switch isn't completed */
        }
        mostRecentTrimFailed = false;
        if (true) goto _L3; else goto _L5
_L5:
        s;
        throw s;
    }

    boolean removeEntry(Entry entry)
        throws IOException
    {
        int i = 0;
        if (entry.currentEditor != null)
        {
            entry.currentEditor.detach();
        }
        do
        {
            if (i >= valueCount)
            {
                redundantOpCount = redundantOpCount + 1;
                journalWriter.writeUtf8("REMOVE").writeByte(32).writeUtf8(entry.key).writeByte(10);
                lruEntries.remove(entry.key);
                if (journalRebuildRequired())
                {
                    executor.execute(cleanupRunnable);
                }
                return true;
            }
            fileSystem.delete(entry.cleanFiles[i]);
            size = size - entry.lengths[i];
            entry.lengths[i] = 0L;
            i++;
        } while (true);
    }

    public void setMaxSize(long l)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag;
        maxSize = l;
        flag = initialized;
        if (flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        executor.execute(cleanupRunnable);
        if (true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public long size()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        long l;
        initialize();
        l = size;
        this;
        JVM INSTR monitorexit ;
        return l;
        Exception exception;
        exception;
        throw exception;
    }

    public Iterator snapshots()
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        Iterator iterator;
        initialize();
        iterator = new Iterator() {

            final Iterator _flddelegate;
            Snapshot nextSnapshot;
            Snapshot removeSnapshot;
            final DiskLruCache this$0;

            public boolean hasNext()
            {
                if (nextSnapshot != null)
                {
                    break MISSING_BLOCK_LABEL_78;
                }
                DiskLruCache disklrucache = DiskLruCache.this;
                disklrucache;
                JVM INSTR monitorenter ;
                if (closed) goto _L2; else goto _L1
_L1:
                if (!_flddelegate.hasNext())
                {
                    return false;
                }
                  goto _L3
_L2:
                disklrucache;
                JVM INSTR monitorexit ;
                return false;
_L3:
                Snapshot snapshot = ((Entry)_flddelegate.next()).snapshot();
                if (snapshot == null) goto _L1; else goto _L4
_L4:
                nextSnapshot = snapshot;
                disklrucache;
                JVM INSTR monitorexit ;
                return true;
                Exception exception1;
                exception1;
                disklrucache;
                JVM INSTR monitorexit ;
                throw exception1;
                return true;
            }

            public volatile Object next()
            {
                return next();
            }

            public Snapshot next()
            {
                if (hasNext())
                {
                    removeSnapshot = nextSnapshot;
                    nextSnapshot = null;
                    return removeSnapshot;
                } else
                {
                    throw new NoSuchElementException();
                }
            }

            public void remove()
            {
                if (removeSnapshot != null)
                {
                    Exception exception1;
                    try
                    {
                        DiskLruCache.this.remove(removeSnapshot.key);
                    }
                    catch (IOException ioexception) { }
                    finally
                    {
                        removeSnapshot = null;
                    }
                    removeSnapshot = null;
                    return;
                } else
                {
                    throw new IllegalStateException("remove() before next()");
                }
                throw exception1;
            }

            
            {
                this$0 = DiskLruCache.this;
                super();
                _flddelegate = (new ArrayList(lruEntries.values())).iterator();
            }
        };
        this;
        JVM INSTR monitorexit ;
        return iterator;
        Exception exception;
        exception;
        throw exception;
    }

    void trimToSize()
        throws IOException
    {
        do
        {
            boolean flag;
            if (size <= maxSize)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                removeEntry((Entry)lruEntries.values().iterator().next());
            } else
            {
                mostRecentTrimFailed = false;
                return;
            }
        } while (true);
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/cache/DiskLruCache.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }
}
