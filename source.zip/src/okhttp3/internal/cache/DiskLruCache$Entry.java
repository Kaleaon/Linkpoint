// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import okhttp3.internal.Util;
import okhttp3.internal.io.FileSystem;
import okio.BufferedSink;
import okio.Source;

// Referenced classes of package okhttp3.internal.cache:
//            DiskLruCache

private final class ory
{

    final File cleanFiles[];
     currentEditor;
    final File dirtyFiles[];
    final String key;
    final long lengths[];
    boolean readable;
    long sequenceNumber;
    final DiskLruCache this$0;

    private IOException invalidLengths(String as[])
        throws IOException
    {
        throw new IOException((new StringBuilder()).append("unexpected journal line: ").append(Arrays.toString(as)).toString());
    }

    void setLengths(String as[])
        throws IOException
    {
        if (as.length != valueCount) goto _L2; else goto _L1
_L1:
        int i = 0;
_L4:
        int j;
        try
        {
            j = as.length;
        }
        catch (NumberFormatException numberformatexception)
        {
            throw invalidLengths(as);
        }
        if (i >= j)
        {
            return;
        }
          goto _L3
_L2:
        throw invalidLengths(as);
_L3:
        lengths[i] = Long.parseLong(as[i]);
        i++;
          goto _L4
    }

    ot snapshot()
    {
        boolean flag = false;
        if (!Thread.holdsLock(DiskLruCache.this)) goto _L2; else goto _L1
_L1:
        Source asource[];
        long al[];
        int i;
        asource = new Source[valueCount];
        al = (long[])lengths.clone();
        i = 0;
_L6:
        if (i < valueCount) goto _L4; else goto _L3
_L3:
        ot ot = new ot(DiskLruCache.this, key, sequenceNumber, asource, al);
        return ot;
_L2:
        throw new AssertionError();
_L4:
        asource[i] = fileSystem.source(cleanFiles[i]);
        i++;
        if (true) goto _L6; else goto _L5
_L5:
        Util.closeQuietly(asource[i]);
        i++;
_L8:
        while (i >= valueCount || asource[i] == null) 
        {
            try
            {
                removeEntry(this);
            }
            catch (IOException ioexception)
            {
                return null;
            }
            return null;
        }
        if (true) goto _L5; else goto _L7
_L7:
        FileNotFoundException filenotfoundexception;
        filenotfoundexception;
        i = ((flag) ? 1 : 0);
          goto _L8
    }

    void writeLengths(BufferedSink bufferedsink)
        throws IOException
    {
        long al[] = lengths;
        int j = al.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            long l = al[i];
            bufferedsink.writeByte(32).writeDecimalLong(l);
            i++;
        } while (true);
    }

    ot(String s)
    {
        this$0 = DiskLruCache.this;
        super();
        key = s;
        lengths = new long[valueCount];
        cleanFiles = new File[valueCount];
        dirtyFiles = new File[valueCount];
        s = (new StringBuilder(s)).append('.');
        int j = s.length();
        int i = 0;
        do
        {
            if (i >= valueCount)
            {
                return;
            }
            s.append(i);
            cleanFiles[i] = new File(directory, s.toString());
            s.append(".tmp");
            dirtyFiles[i] = new File(directory, s.toString());
            s.setLength(j);
            i++;
        } while (true);
    }
}
