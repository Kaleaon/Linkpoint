// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import okio.Sink;

// Referenced classes of package okhttp3.internal.cache:
//            FaultHidingSink, DiskLruCache

class  extends FaultHidingSink
{

    final tach this$1;

    protected void onException(IOException ioexception)
    {
        synchronized (_fld0)
        {
            tach();
        }
        return;
        exception;
        ioexception;
        JVM INSTR monitorexit ;
        throw exception;
    }

    (Sink sink)
    {
        this$1 = this._cls1.this;
        super(sink);
    }
}
