// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.IOException;
import okio.Buffer;
import okio.ForwardingSink;
import okio.Sink;

class FaultHidingSink extends ForwardingSink
{

    private boolean hasErrors;

    public FaultHidingSink(Sink sink)
    {
        super(sink);
    }

    public void close()
        throws IOException
    {
        if (!hasErrors)
        {
            try
            {
                super.close();
                return;
            }
            catch (IOException ioexception)
            {
                hasErrors = true;
                onException(ioexception);
                return;
            }
        } else
        {
            return;
        }
    }

    public void flush()
        throws IOException
    {
        if (!hasErrors)
        {
            try
            {
                super.flush();
                return;
            }
            catch (IOException ioexception)
            {
                hasErrors = true;
                onException(ioexception);
                return;
            }
        } else
        {
            return;
        }
    }

    protected void onException(IOException ioexception)
    {
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        if (!hasErrors)
        {
            try
            {
                super.write(buffer, l);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Buffer buffer)
            {
                hasErrors = true;
            }
        } else
        {
            buffer.skip(l);
            return;
        }
        onException(buffer);
    }
}
