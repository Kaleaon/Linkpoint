// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.FileNotFoundException;
import java.io.IOException;
import okhttp3.internal.io.FileSystem;
import okio.Okio;
import okio.Sink;
import okio.Source;

// Referenced classes of package okhttp3.internal.cache:
//            DiskLruCache, FaultHidingSink

public final class written
{

    private boolean done;
    final leanFiles entry;
    final DiskLruCache this$0;
    final boolean written[];

    public void abort()
        throws IOException
    {
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (done) goto _L2; else goto _L1
_L1:
        if (entry.urrentEditor == this)
        {
            break MISSING_BLOCK_LABEL_46;
        }
_L3:
        done = true;
        return;
_L2:
        throw new IllegalStateException();
        Exception exception;
        exception;
        disklrucache;
        JVM INSTR monitorexit ;
        throw exception;
        completeEdit(this, false);
          goto _L3
    }

    public void abortUnlessCommitted()
    {
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (!done) goto _L2; else goto _L1
_L1:
        return;
_L2:
        eEdit eedit = entry.urrentEditor;
        Exception exception;
        if (eedit == this)
        {
            try
            {
                completeEdit(this, false);
            }
            catch (IOException ioexception) { }
            finally { }
        }
          goto _L1
        disklrucache;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void commit()
        throws IOException
    {
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (done) goto _L2; else goto _L1
_L1:
        if (entry.urrentEditor == this)
        {
            break MISSING_BLOCK_LABEL_46;
        }
_L3:
        done = true;
        return;
_L2:
        throw new IllegalStateException();
        Exception exception;
        exception;
        disklrucache;
        JVM INSTR monitorexit ;
        throw exception;
        completeEdit(this, true);
          goto _L3
    }

    void detach()
    {
        if (entry.urrentEditor != this)
        {
            return;
        }
        int i = 0;
        do
        {
            if (i >= valueCount)
            {
                entry.urrentEditor = null;
                return;
            }
            try
            {
                fileSystem.delete(entry.irtyFiles[i]);
            }
            catch (IOException ioexception) { }
            i++;
        } while (true);
    }

    public Sink newSink(int i)
    {
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (done) goto _L2; else goto _L1
_L1:
        if (entry.urrentEditor != this) goto _L4; else goto _L3
_L3:
        if (!entry.eadable)
        {
            break MISSING_BLOCK_LABEL_94;
        }
_L5:
        Object obj = entry.irtyFiles[i];
        obj = fileSystem.sink(((java.io.File) (obj)));
        obj = new FaultHidingSink(((Sink) (obj))) {

            final DiskLruCache.Editor this$1;

            protected void onException(IOException ioexception)
            {
                synchronized (this$0)
                {
                    detach();
                }
                return;
                exception;
                ioexception;
                JVM INSTR monitorexit ;
                throw exception;
            }

            
            {
                this$1 = DiskLruCache.Editor.this;
                super(sink);
            }
        };
        return ((Sink) (obj));
_L2:
        throw new IllegalStateException();
        Object obj1;
        obj1;
        disklrucache;
        JVM INSTR monitorexit ;
        throw obj1;
_L4:
        obj1 = Okio.blackhole();
        disklrucache;
        JVM INSTR monitorexit ;
        return ((Sink) (obj1));
        written[i] = true;
          goto _L5
        obj1;
        obj1 = Okio.blackhole();
        disklrucache;
        JVM INSTR monitorexit ;
        return ((Sink) (obj1));
    }

    public Source newSource(int i)
    {
        DiskLruCache disklrucache = DiskLruCache.this;
        disklrucache;
        JVM INSTR monitorenter ;
        if (done) goto _L2; else goto _L1
_L1:
        if (entry.eadable) goto _L4; else goto _L3
_L3:
        return null;
_L2:
        throw new IllegalStateException();
        Object obj;
        obj;
        disklrucache;
        JVM INSTR monitorexit ;
        Object obj1;
        throw obj;
_L4:
        if ((obj1 = entry.urrentEditor) != this) goto _L3; else goto _L5
_L5:
        obj1 = fileSystem.source(entry.leanFiles[i]);
        disklrucache;
        JVM INSTR monitorexit ;
        return ((Source) (obj1));
        obj1;
        disklrucache;
        JVM INSTR monitorexit ;
        return null;
    }

    t>(t> t>)
    {
        this$0 = DiskLruCache.this;
        super();
        entry = t>;
        if (!t>.eadable)
        {
            disklrucache = new boolean[valueCount];
        } else
        {
            disklrucache = null;
        }
        written = DiskLruCache.this;
    }
}
