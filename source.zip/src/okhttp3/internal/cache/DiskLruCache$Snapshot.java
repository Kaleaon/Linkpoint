// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.cache;

import java.io.Closeable;
import java.io.IOException;
import okhttp3.internal.Util;
import okio.Source;

// Referenced classes of package okhttp3.internal.cache:
//            DiskLruCache

public final class lengths
    implements Closeable
{

    private final String key;
    private final long lengths[];
    private final long sequenceNumber;
    private final Source sources[];
    final DiskLruCache this$0;

    public void close()
    {
        Source asource[] = sources;
        int j = asource.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            Util.closeQuietly(asource[i]);
            i++;
        } while (true);
    }

    public sources edit()
        throws IOException
    {
        return DiskLruCache.this.edit(key, sequenceNumber);
    }

    public long getLength(int i)
    {
        return lengths[i];
    }

    public Source getSource(int i)
    {
        return sources[i];
    }

    public String key()
    {
        return key;
    }


    (String s, long l, Source asource[], long al[])
    {
        this$0 = DiskLruCache.this;
        super();
        key = s;
        sequenceNumber = l;
        sources = asource;
        lengths = al;
    }
}
