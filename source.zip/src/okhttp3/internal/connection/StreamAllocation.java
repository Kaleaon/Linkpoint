// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.io.IOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.Address;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import okhttp3.Route;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpCodec;
import okhttp3.internal.http1.Http1Codec;
import okhttp3.internal.http2.ConnectionShutdownException;
import okhttp3.internal.http2.ErrorCode;
import okhttp3.internal.http2.Http2Codec;
import okhttp3.internal.http2.StreamResetException;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.connection:
//            RouteSelector, RealConnection, RouteDatabase, RouteException

public final class StreamAllocation
{
    public static final class StreamAllocationReference extends WeakReference
    {

        public final Object callStackTrace;

        StreamAllocationReference(StreamAllocation streamallocation, Object obj)
        {
            super(streamallocation);
            callStackTrace = obj;
        }
    }


    static final boolean $assertionsDisabled;
    public final Address address;
    private final Object callStackTrace;
    private boolean canceled;
    private HttpCodec codec;
    private RealConnection connection;
    private final ConnectionPool connectionPool;
    private int refusedStreamCount;
    private boolean released;
    private Route route;
    private final RouteSelector routeSelector;

    public StreamAllocation(ConnectionPool connectionpool, Address address1, Object obj)
    {
        connectionPool = connectionpool;
        address = address1;
        routeSelector = new RouteSelector(address1, routeDatabase());
        callStackTrace = obj;
    }

    private void deallocate(boolean flag, boolean flag1, boolean flag2)
    {
        Object obj;
        Object obj1;
        obj1 = null;
        obj = null;
        ConnectionPool connectionpool = connectionPool;
        connectionpool;
        JVM INSTR monitorenter ;
        if (flag2) goto _L2; else goto _L1
_L1:
        if (flag1) goto _L4; else goto _L3
_L3:
        if (connection != null) goto _L6; else goto _L5
_L5:
        Exception exception = obj;
_L8:
        connectionpool;
        JVM INSTR monitorexit ;
        if (exception == null)
        {
            return;
        } else
        {
            Util.closeQuietly(exception.socket());
            return;
        }
_L2:
        codec = null;
          goto _L1
        exception;
        connectionpool;
        JVM INSTR monitorexit ;
        throw exception;
_L4:
        released = true;
          goto _L3
_L16:
        exception = obj;
        if (codec != null) goto _L8; else goto _L7
_L7:
        if (!released) goto _L10; else goto _L9
_L9:
        release(connection);
        if (connection.allocations.isEmpty()) goto _L12; else goto _L11
_L11:
        exception = obj1;
_L15:
        connection = null;
          goto _L8
_L17:
        connection.noNewStreams = true;
        break; /* Loop/switch isn't completed */
_L10:
        if (connection.noNewStreams) goto _L9; else goto _L13
_L13:
        exception = obj;
          goto _L8
_L12:
        connection.idleAtNanos = System.nanoTime();
        exception = obj1;
        if (!Internal.instance.connectionBecameIdle(connectionPool, connection)) goto _L15; else goto _L14
_L14:
        exception = connection;
          goto _L15
_L6:
        if (flag) goto _L17; else goto _L16
    }

    private RealConnection findConnection(int i, int j, int k, boolean flag)
        throws IOException
    {
        Object obj1 = connectionPool;
        obj1;
        JVM INSTR monitorenter ;
        if (released) goto _L2; else goto _L1
_L1:
        if (codec != null) goto _L4; else goto _L3
_L3:
        if (canceled) goto _L6; else goto _L5
_L5:
        obj = connection;
          goto _L7
_L9:
        obj = Internal.instance.get(connectionPool, address, this);
        if (obj != null)
        {
            break MISSING_BLOCK_LABEL_215;
        }
        obj = route;
        obj1;
        JVM INSTR monitorexit ;
        if (obj == null)
        {
            obj = routeSelector.next();
            synchronized (connectionPool)
            {
                route = ((Route) (obj));
                refusedStreamCount = 0;
            }
        }
        obj1 = new RealConnection(((Route) (obj)));
        synchronized (connectionPool)
        {
            acquire(((RealConnection) (obj1)));
            Internal.instance.put(connectionPool, ((RealConnection) (obj1)));
            connection = ((RealConnection) (obj1));
            if (canceled)
            {
                break MISSING_BLOCK_LABEL_270;
            }
        }
        ((RealConnection) (obj1)).connect(i, j, k, address.connectionSpecs(), flag);
        routeDatabase().connected(((RealConnection) (obj1)).route());
        return ((RealConnection) (obj1));
_L2:
        throw new IllegalStateException("released");
        obj;
        obj1;
        JVM INSTR monitorexit ;
        throw obj;
_L4:
        throw new IllegalStateException("codec != null");
_L6:
        throw new IOException("Canceled");
_L7:
        if (obj == null || ((RealConnection) (obj)).noNewStreams) goto _L9; else goto _L8
_L8:
        obj1;
        JVM INSTR monitorexit ;
        return ((RealConnection) (obj));
        connection = ((RealConnection) (obj));
        obj1;
        JVM INSTR monitorexit ;
        return ((RealConnection) (obj));
        obj;
        connectionpool;
        JVM INSTR monitorexit ;
        throw obj;
        throw new IOException("Canceled");
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    private RealConnection findHealthyConnection(int i, int j, int k, boolean flag, boolean flag1)
        throws IOException
    {
_L2:
        RealConnection realconnection;
label0:
        {
            realconnection = findConnection(i, j, k, flag);
            synchronized (connectionPool)
            {
                if (realconnection.successCount == 0)
                {
                    break label0;
                }
            }
            if (realconnection.isHealthy(flag1))
            {
                return realconnection;
            }
            break MISSING_BLOCK_LABEL_58;
        }
        connectionpool;
        JVM INSTR monitorexit ;
        return realconnection;
        exception;
        connectionpool;
        JVM INSTR monitorexit ;
        throw exception;
        noNewStreams();
        if (true) goto _L2; else goto _L1
_L1:
    }

    private void release(RealConnection realconnection)
    {
        int j = realconnection.allocations.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                throw new IllegalStateException();
            }
            if (((Reference)realconnection.allocations.get(i)).get() != this)
            {
                i++;
            } else
            {
                realconnection.allocations.remove(i);
                return;
            }
        } while (true);
    }

    private RouteDatabase routeDatabase()
    {
        return Internal.instance.routeDatabase(connectionPool);
    }

    public void acquire(RealConnection realconnection)
    {
        while ($assertionsDisabled || Thread.holdsLock(connectionPool)) 
        {
            realconnection.allocations.add(new StreamAllocationReference(this, callStackTrace));
            return;
        }
        throw new AssertionError();
    }

    public void cancel()
    {
        RealConnection realconnection;
        synchronized (connectionPool)
        {
            canceled = true;
            obj = codec;
            realconnection = connection;
        }
        if (obj == null)
        {
            if (realconnection == null)
            {
                return;
            } else
            {
                realconnection.cancel();
                return;
            }
        } else
        {
            ((HttpCodec) (obj)).cancel();
            return;
        }
        obj;
        connectionpool;
        JVM INSTR monitorexit ;
        throw obj;
    }

    public HttpCodec codec()
    {
        HttpCodec httpcodec;
        synchronized (connectionPool)
        {
            httpcodec = codec;
        }
        return httpcodec;
        exception;
        connectionpool;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public RealConnection connection()
    {
        this;
        JVM INSTR monitorenter ;
        RealConnection realconnection = connection;
        this;
        JVM INSTR monitorexit ;
        return realconnection;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean hasMoreRoutes()
    {
        while (route != null || routeSelector.hasNext()) 
        {
            return true;
        }
        return false;
    }

    public HttpCodec newStream(OkHttpClient okhttpclient, boolean flag)
    {
        int i;
        int j;
        int k;
        boolean flag1;
        i = okhttpclient.connectTimeoutMillis();
        j = okhttpclient.readTimeoutMillis();
        k = okhttpclient.writeTimeoutMillis();
        flag1 = okhttpclient.retryOnConnectionFailure();
        obj = findHealthyConnection(i, j, k, flag1, flag);
        if (((RealConnection) (obj)).http2Connection != null) goto _L2; else goto _L1
_L1:
        ((RealConnection) (obj)).socket().setSoTimeout(j);
        ((RealConnection) (obj)).source.timeout().timeout(j, TimeUnit.MILLISECONDS);
        ((RealConnection) (obj)).sink.timeout().timeout(k, TimeUnit.MILLISECONDS);
        okhttpclient = new Http1Codec(okhttpclient, this, ((RealConnection) (obj)).source, ((RealConnection) (obj)).sink);
_L4:
        synchronized (connectionPool)
        {
            codec = okhttpclient;
        }
        return okhttpclient;
_L2:
        try
        {
            okhttpclient = new Http2Codec(okhttpclient, this, ((RealConnection) (obj)).http2Connection);
        }
        // Misplaced declaration of an exception variable
        catch (OkHttpClient okhttpclient)
        {
            throw new RouteException(okhttpclient);
        }
        if (true) goto _L4; else goto _L3
_L3:
        okhttpclient;
        obj;
        JVM INSTR monitorexit ;
        throw okhttpclient;
    }

    public void noNewStreams()
    {
        deallocate(true, false, false);
    }

    public void release()
    {
        deallocate(false, true, false);
    }

    public void streamFailed(IOException ioexception)
    {
        ConnectionPool connectionpool = connectionPool;
        connectionpool;
        JVM INSTR monitorenter ;
        if (ioexception instanceof StreamResetException) goto _L2; else goto _L1
_L1:
        if (connection != null) goto _L4; else goto _L3
_L3:
        if (ioexception instanceof ConnectionShutdownException)
        {
            break; /* Loop/switch isn't completed */
        }
        boolean flag = false;
_L9:
        connectionpool;
        JVM INSTR monitorexit ;
        deallocate(flag, false, true);
        return;
_L2:
        ioexception = (StreamResetException)ioexception;
        if (((StreamResetException) (ioexception)).errorCode == ErrorCode.REFUSED_STREAM) goto _L6; else goto _L5
_L5:
        if (((StreamResetException) (ioexception)).errorCode == ErrorCode.REFUSED_STREAM) goto _L8; else goto _L7
_L7:
        route = null;
        flag = true;
          goto _L9
_L6:
        refusedStreamCount = refusedStreamCount + 1;
          goto _L5
        ioexception;
        connectionpool;
        JVM INSTR monitorexit ;
        throw ioexception;
_L8:
        if (refusedStreamCount > 1) goto _L7; else goto _L10
_L10:
        flag = false;
          goto _L9
_L4:
        if (connection.isMultiplexed()) goto _L3; else goto _L11
_L11:
        if (connection.successCount == 0) goto _L13; else goto _L12
_L12:
        flag = true;
          goto _L9
_L15:
        route = null;
        flag = true;
          goto _L9
_L13:
        if (route == null || ioexception == null) goto _L15; else goto _L14
_L14:
        routeSelector.connectFailed(route, ioexception);
          goto _L15
    }

    public void streamFinished(boolean flag, HttpCodec httpcodec)
    {
        ConnectionPool connectionpool = connectionPool;
        connectionpool;
        JVM INSTR monitorenter ;
        if (httpcodec != null) goto _L2; else goto _L1
_L1:
        throw new IllegalStateException((new StringBuilder()).append("expected ").append(codec).append(" but was ").append(httpcodec).toString());
        httpcodec;
        connectionpool;
        JVM INSTR monitorexit ;
        throw httpcodec;
_L2:
        if (httpcodec != codec) goto _L1; else goto _L3
_L3:
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_79;
        }
_L4:
        connectionpool;
        JVM INSTR monitorexit ;
        deallocate(flag, false, true);
        return;
        httpcodec = connection;
        httpcodec.successCount = ((RealConnection) (httpcodec)).successCount + 1;
          goto _L4
    }

    public String toString()
    {
        return address.toString();
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/connection/StreamAllocation.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }
}
