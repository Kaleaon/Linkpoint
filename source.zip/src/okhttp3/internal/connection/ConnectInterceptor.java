// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http.RealInterceptorChain;

// Referenced classes of package okhttp3.internal.connection:
//            StreamAllocation

public final class ConnectInterceptor
    implements Interceptor
{

    public final OkHttpClient client;

    public ConnectInterceptor(OkHttpClient okhttpclient)
    {
        client = okhttpclient;
    }

    public Response intercept(okhttp3.Interceptor.Chain chain)
        throws IOException
    {
        boolean flag = false;
        chain = (RealInterceptorChain)chain;
        Request request = chain.request();
        StreamAllocation streamallocation = chain.streamAllocation();
        if (!request.method().equals("GET"))
        {
            flag = true;
        }
        return chain.proceed(request, streamallocation, streamallocation.newStream(client, flag), streamallocation.connection());
    }
}
