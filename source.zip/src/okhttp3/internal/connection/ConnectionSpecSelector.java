// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.UnknownServiceException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLProtocolException;
import javax.net.ssl.SSLSocket;
import okhttp3.ConnectionSpec;
import okhttp3.internal.Internal;

public final class ConnectionSpecSelector
{

    private final List connectionSpecs;
    private boolean isFallback;
    private boolean isFallbackPossible;
    private int nextModeIndex;

    public ConnectionSpecSelector(List list)
    {
        nextModeIndex = 0;
        connectionSpecs = list;
    }

    private boolean isFallbackPossible(SSLSocket sslsocket)
    {
        int i = nextModeIndex;
        do
        {
            if (i >= connectionSpecs.size())
            {
                return false;
            }
            if (!((ConnectionSpec)connectionSpecs.get(i)).isCompatible(sslsocket))
            {
                i++;
            } else
            {
                return true;
            }
        } while (true);
    }

    public ConnectionSpec configureSecureSocket(SSLSocket sslsocket)
        throws IOException
    {
        int i;
        int j;
        i = nextModeIndex;
        j = connectionSpecs.size();
_L3:
        if (i < j) goto _L2; else goto _L1
_L1:
        ConnectionSpec connectionspec = null;
_L4:
        if (connectionspec != null)
        {
            isFallbackPossible = isFallbackPossible(sslsocket);
            Internal.instance.apply(connectionspec, sslsocket, isFallback);
            return connectionspec;
        } else
        {
            throw new UnknownServiceException((new StringBuilder()).append("Unable to find acceptable protocols. isFallback=").append(isFallback).append(", modes=").append(connectionSpecs).append(", supported protocols=").append(Arrays.toString(sslsocket.getEnabledProtocols())).toString());
        }
_L2:
label0:
        {
            connectionspec = (ConnectionSpec)connectionSpecs.get(i);
            if (connectionspec.isCompatible(sslsocket))
            {
                break label0;
            }
            i++;
        }
          goto _L3
        nextModeIndex = i + 1;
          goto _L4
    }

    public boolean connectionFailed(IOException ioexception)
    {
        isFallback = true;
        if (isFallbackPossible)
        {
            if (!(ioexception instanceof ProtocolException))
            {
                if (!(ioexception instanceof InterruptedIOException))
                {
                    if (!(ioexception instanceof SSLHandshakeException) || !(ioexception.getCause() instanceof CertificateException))
                    {
                        if (!(ioexception instanceof SSLPeerUnverifiedException))
                        {
                            return (ioexception instanceof SSLHandshakeException) || (ioexception instanceof SSLProtocolException);
                        } else
                        {
                            return false;
                        }
                    } else
                    {
                        return false;
                    }
                } else
                {
                    return false;
                }
            } else
            {
                return false;
            }
        } else
        {
            return false;
        }
    }
}
