// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.io.IOException;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownServiceException;
import java.security.Principal;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import okhttp3.Address;
import okhttp3.Authenticator;
import okhttp3.CertificatePinner;
import okhttp3.Connection;
import okhttp3.ConnectionSpec;
import okhttp3.Handshake;
import okhttp3.HttpUrl;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal.Util;
import okhttp3.internal.Version;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http1.Http1Codec;
import okhttp3.internal.http2.ErrorCode;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.http2.Http2Stream;
import okhttp3.internal.platform.Platform;
import okhttp3.internal.tls.OkHostnameVerifier;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.connection:
//            ConnectionSpecSelector, RouteException

public final class RealConnection extends okhttp3.internal.http2.Http2Connection.Listener
    implements Connection
{

    public int allocationLimit;
    public final List allocations = new ArrayList();
    private Handshake handshake;
    public volatile Http2Connection http2Connection;
    public long idleAtNanos;
    public boolean noNewStreams;
    private Protocol protocol;
    private Socket rawSocket;
    private final Route route;
    public BufferedSink sink;
    public Socket socket;
    public BufferedSource source;
    public int successCount;

    public RealConnection(Route route1)
    {
        idleAtNanos = 0x7fffffffffffffffL;
        route = route1;
    }

    private void buildConnection(int i, int j, int k, ConnectionSpecSelector connectionspecselector)
        throws IOException
    {
        connectSocket(i, j);
        establishProtocol(j, k, connectionspecselector);
    }

    private void buildTunneledConnection(int i, int j, int k, ConnectionSpecSelector connectionspecselector)
        throws IOException
    {
        Request request = createTunnelRequest();
        HttpUrl httpurl = request.url();
        int l = 0;
        do
        {
            l++;
            if (l <= 21)
            {
                connectSocket(i, j);
                request = createTunnel(j, k, request, httpurl);
                if (request != null)
                {
                    Util.closeQuietly(rawSocket);
                    rawSocket = null;
                    sink = null;
                    source = null;
                } else
                {
                    establishProtocol(j, k, connectionspecselector);
                    return;
                }
            } else
            {
                throw new ProtocolException((new StringBuilder()).append("Too many tunnel connections attempted: ").append(21).toString());
            }
        } while (true);
    }

    private void connectSocket(int i, int j)
        throws IOException
    {
        Object obj;
        Address address;
        obj = route.proxy();
        address = route.address();
        break MISSING_BLOCK_LABEL_17;
        if (((Proxy) (obj)).type() == java.net.Proxy.Type.DIRECT || ((Proxy) (obj)).type() == java.net.Proxy.Type.HTTP)
        {
            obj = address.socketFactory().createSocket();
        } else
        {
            obj = new Socket(((Proxy) (obj)));
        }
        rawSocket = ((Socket) (obj));
        rawSocket.setSoTimeout(j);
        try
        {
            Platform.get().connectSocket(rawSocket, route.socketAddress(), i);
        }
        catch (ConnectException connectexception)
        {
            ConnectException connectexception1 = new ConnectException((new StringBuilder()).append("Failed to connect to ").append(route.socketAddress()).toString());
            connectexception1.initCause(connectexception);
            throw connectexception1;
        }
        source = Okio.buffer(Okio.source(rawSocket));
        sink = Okio.buffer(Okio.sink(rawSocket));
        return;
    }

    private void connectTls(int i, int j, ConnectionSpecSelector connectionspecselector)
        throws IOException
    {
        Object obj;
        Object obj1;
        Object obj2;
        Object obj3;
        Address address;
        obj3 = null;
        obj = null;
        obj2 = null;
        address = route.address();
        obj1 = address.sslSocketFactory();
        obj1 = (SSLSocket)((SSLSocketFactory) (obj1)).createSocket(rawSocket, address.url().host(), address.url().port(), true);
        connectionspecselector = connectionspecselector.configureSecureSocket(((SSLSocket) (obj1)));
        if (connectionspecselector.supportsTlsExtensions()) goto _L2; else goto _L1
_L1:
        ((SSLSocket) (obj1)).startHandshake();
        obj = Handshake.get(((SSLSocket) (obj1)).getSession());
        if (!address.hostnameVerifier().verify(address.url().host(), ((SSLSocket) (obj1)).getSession())) goto _L4; else goto _L3
_L3:
        address.certificatePinner().check(address.url().host(), ((Handshake) (obj)).peerCertificates());
        if (connectionspecselector.supportsTlsExtensions()) goto _L6; else goto _L5
_L5:
        connectionspecselector = obj2;
_L11:
        socket = ((Socket) (obj1));
        source = Okio.buffer(Okio.source(socket));
        sink = Okio.buffer(Okio.sink(socket));
        handshake = ((Handshake) (obj));
        if (connectionspecselector != null) goto _L8; else goto _L7
_L7:
        connectionspecselector = Protocol.HTTP_1_1;
_L12:
        protocol = connectionspecselector;
        if (obj1 == null)
        {
            return;
        } else
        {
            Platform.get().afterHandshake(((SSLSocket) (obj1)));
            return;
        }
_L2:
        Platform.get().configureTlsExtensions(((SSLSocket) (obj1)), address.url().host(), address.protocols());
          goto _L1
        obj;
        connectionspecselector = ((ConnectionSpecSelector) (obj1));
        obj1 = obj;
_L13:
        obj = connectionspecselector;
        if (Util.isAndroidGetsocknameError(((AssertionError) (obj1)))) goto _L10; else goto _L9
_L9:
        obj = connectionspecselector;
        throw obj1;
        connectionspecselector;
_L14:
        if (obj != null)
        {
            Platform.get().afterHandshake(((SSLSocket) (obj)));
        }
        Util.closeQuietly(((Socket) (obj)));
        throw connectionspecselector;
_L4:
        connectionspecselector = (X509Certificate)((Handshake) (obj)).peerCertificates().get(0);
        throw new SSLPeerUnverifiedException((new StringBuilder()).append("Hostname ").append(address.url().host()).append(" not verified:\n    certificate: ").append(CertificatePinner.pin(connectionspecselector)).append("\n    DN: ").append(connectionspecselector.getSubjectDN().getName()).append("\n    subjectAltNames: ").append(OkHostnameVerifier.allSubjectAltNames(connectionspecselector)).toString());
_L6:
        connectionspecselector = Platform.get().getSelectedProtocol(((SSLSocket) (obj1)));
          goto _L11
_L8:
        connectionspecselector = Protocol.get(connectionspecselector);
          goto _L12
_L10:
        obj = connectionspecselector;
        throw new IOException(((Throwable) (obj1)));
        obj1;
        connectionspecselector = obj3;
          goto _L13
        connectionspecselector;
        obj = obj1;
          goto _L14
    }

    private Request createTunnel(int i, int j, Request request, HttpUrl httpurl)
        throws IOException
    {
        String s = (new StringBuilder()).append("CONNECT ").append(Util.hostHeader(httpurl, true)).append(" HTTP/1.1").toString();
        do
        {
            httpurl = new Http1Codec(null, null, source, sink);
            source.timeout().timeout(i, TimeUnit.MILLISECONDS);
            sink.timeout().timeout(j, TimeUnit.MILLISECONDS);
            httpurl.writeRequest(request.headers(), s);
            httpurl.finishRequest();
            Response response = httpurl.readResponse().request(request).build();
            long l1 = HttpHeaders.contentLength(response);
            long l = l1;
            if (l1 == -1L)
            {
                l = 0L;
            }
            request = httpurl.newFixedLengthSource(l);
            Util.skipAll(request, 0x7fffffff, TimeUnit.MILLISECONDS);
            request.close();
            switch (response.code())
            {
            default:
                throw new IOException((new StringBuilder()).append("Unexpected response code for CONNECT: ").append(response.code()).toString());

            case 200: 
                while (!source.buffer().exhausted() || !sink.buffer().exhausted()) 
                {
                    throw new IOException("TLS tunnel buffered too many bytes!");
                }
                return null;

            case 407: 
                httpurl = route.address().proxyAuthenticator().authenticate(route, response);
                break;
            }
            if (httpurl != null)
            {
                request = httpurl;
                if ("close".equalsIgnoreCase(response.header("Connection")))
                {
                    return httpurl;
                }
            } else
            {
                throw new IOException("Failed to authenticate with proxy");
            }
        } while (true);
    }

    private Request createTunnelRequest()
    {
        return (new okhttp3.Request.Builder()).url(route.address().url()).header("Host", Util.hostHeader(route.address().url(), true)).header("Proxy-Connection", "Keep-Alive").header("User-Agent", Version.userAgent()).build();
    }

    private void establishProtocol(int i, int j, ConnectionSpecSelector connectionspecselector)
        throws IOException
    {
        if (route.address().sslSocketFactory() == null)
        {
            protocol = Protocol.HTTP_1_1;
            socket = rawSocket;
        } else
        {
            connectTls(i, j, connectionspecselector);
        }
        if (protocol != Protocol.HTTP_2)
        {
            allocationLimit = 1;
            return;
        } else
        {
            socket.setSoTimeout(0);
            connectionspecselector = (new okhttp3.internal.http2.Http2Connection.Builder(true)).socket(socket, route.address().url().host(), source, sink).listener(this).build();
            connectionspecselector.start();
            allocationLimit = connectionspecselector.maxConcurrentStreams();
            http2Connection = connectionspecselector;
            return;
        }
    }

    public void cancel()
    {
        Util.closeQuietly(rawSocket);
    }

    public void connect(int i, int j, int k, List list, boolean flag)
    {
        if (protocol != null) goto _L2; else goto _L1
_L1:
        ConnectionSpecSelector connectionspecselector;
        connectionspecselector = new ConnectionSpecSelector(list);
        if (route.address().sslSocketFactory() != null)
        {
            list = null;
        } else
        if (list.contains(ConnectionSpec.CLEARTEXT))
        {
            list = route.address().url().host();
            if (Platform.get().isCleartextTrafficPermitted(list))
            {
                list = null;
            } else
            {
                throw new RouteException(new UnknownServiceException((new StringBuilder()).append("CLEARTEXT communication to ").append(list).append(" not permitted by network security policy").toString()));
            }
        } else
        {
            throw new RouteException(new UnknownServiceException("CLEARTEXT communication not enabled for client"));
        }
_L7:
        if (protocol != null)
        {
            return;
        }
          goto _L3
_L2:
        throw new IllegalStateException("already connected");
_L3:
        if (route.requiresTunnel()) goto _L5; else goto _L4
_L4:
        buildConnection(i, j, k, connectionspecselector);
          goto _L6
        IOException ioexception;
        ioexception;
        Util.closeQuietly(socket);
        Util.closeQuietly(rawSocket);
        socket = null;
        rawSocket = null;
        source = null;
        sink = null;
        handshake = null;
        protocol = null;
        if (list != null)
        {
            list.addConnectException(ioexception);
        } else
        {
            list = new RouteException(ioexception);
        }
        break MISSING_BLOCK_LABEL_238;
        throw list;
_L5:
        buildTunneledConnection(i, j, k, connectionspecselector);
        continue; /* Loop/switch isn't completed */
        if (!flag || !connectionspecselector.connectionFailed(ioexception))
        {
            break MISSING_BLOCK_LABEL_243;
        }
_L6:
        if (true) goto _L7; else goto _L5
    }

    public Handshake handshake()
    {
        return handshake;
    }

    public boolean isHealthy(boolean flag)
    {
        while (socket.isClosed() || socket.isInputShutdown() || socket.isOutputShutdown()) 
        {
            return false;
        }
        if (http2Connection == null)
        {
            if (!flag)
            {
                return true;
            }
        } else
        {
            return !http2Connection.isShutdown();
        }
        Exception exception;
        int i;
        try
        {
            i = socket.getSoTimeout();
        }
        catch (SocketTimeoutException sockettimeoutexception)
        {
            return true;
        }
        catch (IOException ioexception)
        {
            return false;
        }
        socket.setSoTimeout(1);
        flag = source.exhausted();
        if (flag)
        {
            break MISSING_BLOCK_LABEL_99;
        }
        socket.setSoTimeout(i);
        return true;
        socket.setSoTimeout(i);
        return false;
        exception;
        socket.setSoTimeout(i);
        throw exception;
    }

    public boolean isMultiplexed()
    {
        return http2Connection != null;
    }

    public void onSettings(Http2Connection http2connection)
    {
        allocationLimit = http2connection.maxConcurrentStreams();
    }

    public void onStream(Http2Stream http2stream)
        throws IOException
    {
        http2stream.close(ErrorCode.REFUSED_STREAM);
    }

    public Protocol protocol()
    {
        if (http2Connection != null)
        {
            return Protocol.HTTP_2;
        }
        if (protocol == null)
        {
            return Protocol.HTTP_1_1;
        } else
        {
            return protocol;
        }
    }

    public Route route()
    {
        return route;
    }

    public Socket socket()
    {
        return socket;
    }

    public String toString()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append("Connection{").append(route.address().url().host()).append(":").append(route.address().url().port()).append(", proxy=").append(route.proxy()).append(" hostAddress=").append(route.socketAddress()).append(" cipherSuite=");
        Object obj;
        if (handshake == null)
        {
            obj = "none";
        } else
        {
            obj = handshake.cipherSuite();
        }
        return stringbuilder.append(obj).append(" protocol=").append(protocol).append('}').toString();
    }
}
