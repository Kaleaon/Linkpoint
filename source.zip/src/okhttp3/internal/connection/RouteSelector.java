// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import okhttp3.Address;
import okhttp3.Dns;
import okhttp3.HttpUrl;
import okhttp3.Route;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3.internal.connection:
//            RouteDatabase

public final class RouteSelector
{

    private final Address address;
    private List inetSocketAddresses;
    private InetSocketAddress lastInetSocketAddress;
    private Proxy lastProxy;
    private int nextInetSocketAddressIndex;
    private int nextProxyIndex;
    private final List postponedRoutes = new ArrayList();
    private List proxies;
    private final RouteDatabase routeDatabase;

    public RouteSelector(Address address1, RouteDatabase routedatabase)
    {
        proxies = Collections.emptyList();
        inetSocketAddresses = Collections.emptyList();
        address = address1;
        routeDatabase = routedatabase;
        resetNextProxy(address1.url(), address1.proxy());
    }

    static String getHostString(InetSocketAddress inetsocketaddress)
    {
        InetAddress inetaddress = inetsocketaddress.getAddress();
        if (inetaddress != null)
        {
            return inetaddress.getHostAddress();
        } else
        {
            return inetsocketaddress.getHostName();
        }
    }

    private boolean hasNextInetSocketAddress()
    {
        return nextInetSocketAddressIndex < inetSocketAddresses.size();
    }

    private boolean hasNextPostponed()
    {
        return !postponedRoutes.isEmpty();
    }

    private boolean hasNextProxy()
    {
        return nextProxyIndex < proxies.size();
    }

    private InetSocketAddress nextInetSocketAddress()
        throws IOException
    {
        if (hasNextInetSocketAddress())
        {
            List list = inetSocketAddresses;
            int i = nextInetSocketAddressIndex;
            nextInetSocketAddressIndex = i + 1;
            return (InetSocketAddress)list.get(i);
        } else
        {
            throw new SocketException((new StringBuilder()).append("No route to ").append(address.url().host()).append("; exhausted inet socket addresses: ").append(inetSocketAddresses).toString());
        }
    }

    private Route nextPostponed()
    {
        return (Route)postponedRoutes.remove(0);
    }

    private Proxy nextProxy()
        throws IOException
    {
        if (hasNextProxy())
        {
            Object obj = proxies;
            int i = nextProxyIndex;
            nextProxyIndex = i + 1;
            obj = (Proxy)((List) (obj)).get(i);
            resetNextInetSocketAddress(((Proxy) (obj)));
            return ((Proxy) (obj));
        } else
        {
            throw new SocketException((new StringBuilder()).append("No route to ").append(address.url().host()).append("; exhausted proxy configurations: ").append(proxies).toString());
        }
    }

    private void resetNextInetSocketAddress(Proxy proxy)
        throws IOException
    {
        Object obj;
        int i;
        inetSocketAddresses = new ArrayList();
        if (proxy.type() == java.net.Proxy.Type.DIRECT || proxy.type() == java.net.Proxy.Type.SOCKS)
        {
            obj = address.url().host();
            i = address.url().port();
        } else
        {
            obj = proxy.address();
            if (obj instanceof InetSocketAddress)
            {
                InetSocketAddress inetsocketaddress = (InetSocketAddress)obj;
                obj = getHostString(inetsocketaddress);
                i = inetsocketaddress.getPort();
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("Proxy.address() is not an InetSocketAddress: ").append(obj.getClass()).toString());
            }
        }
        if (i < 1 || i > 65535)
        {
            throw new SocketException((new StringBuilder()).append("No route to ").append(((String) (obj))).append(":").append(i).append("; port is out of range").toString());
        }
        if (proxy.type() == java.net.Proxy.Type.SOCKS) goto _L2; else goto _L1
_L1:
        int j;
        int k;
        proxy = address.dns().lookup(((String) (obj)));
        k = proxy.size();
        j = 0;
_L6:
        if (j < k) goto _L4; else goto _L3
_L3:
        nextInetSocketAddressIndex = 0;
        return;
_L2:
        inetSocketAddresses.add(InetSocketAddress.createUnresolved(((String) (obj)), i));
        if (true) goto _L3; else goto _L4
_L4:
        InetAddress inetaddress = (InetAddress)proxy.get(j);
        inetSocketAddresses.add(new InetSocketAddress(inetaddress, i));
        j++;
        if (true) goto _L6; else goto _L5
_L5:
    }

    private void resetNextProxy(HttpUrl httpurl, Proxy proxy)
    {
        if (proxy != null) goto _L2; else goto _L1
_L1:
        httpurl = address.proxySelector().select(httpurl.uri());
_L3:
        if (httpurl == null || httpurl.isEmpty())
        {
            httpurl = Util.immutableList(new Proxy[] {
                Proxy.NO_PROXY
            });
        } else
        {
            httpurl = Util.immutableList(httpurl);
        }
        proxies = httpurl;
_L4:
        nextProxyIndex = 0;
        return;
_L2:
        proxies = Collections.singletonList(proxy);
        if (true) goto _L4; else goto _L3
    }

    public void connectFailed(Route route, IOException ioexception)
    {
        if (route.proxy().type() != java.net.Proxy.Type.DIRECT && address.proxySelector() != null)
        {
            address.proxySelector().connectFailed(address.url().uri(), route.proxy().address(), ioexception);
        }
        routeDatabase.failed(route);
    }

    public boolean hasNext()
    {
        while (hasNextInetSocketAddress() || hasNextProxy() || hasNextPostponed()) 
        {
            return true;
        }
        return false;
    }

    public Route next()
        throws IOException
    {
        Route route;
        if (!hasNextInetSocketAddress())
        {
            if (hasNextProxy())
            {
                lastProxy = nextProxy();
            } else
            if (hasNextPostponed())
            {
                return nextPostponed();
            } else
            {
                throw new NoSuchElementException();
            }
        }
        lastInetSocketAddress = nextInetSocketAddress();
        route = new Route(address, lastProxy, lastInetSocketAddress);
        if (!routeDatabase.shouldPostpone(route))
        {
            return route;
        } else
        {
            postponedRoutes.add(route);
            return next();
        }
    }
}
