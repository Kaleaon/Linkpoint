// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.connection;

import java.lang.ref.WeakReference;

// Referenced classes of package okhttp3.internal.connection:
//            StreamAllocation

public static final class callStackTrace extends WeakReference
{

    public final Object callStackTrace;

    (StreamAllocation streamallocation, Object obj)
    {
        super(streamallocation);
        callStackTrace = obj;
    }
}
