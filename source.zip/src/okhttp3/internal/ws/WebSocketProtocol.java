// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import okio.ByteString;

public final class WebSocketProtocol
{

    static final String ACCEPT_MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    static final int B0_FLAG_FIN = 128;
    static final int B0_FLAG_RSV1 = 64;
    static final int B0_FLAG_RSV2 = 32;
    static final int B0_FLAG_RSV3 = 16;
    static final int B0_MASK_OPCODE = 15;
    static final int B1_FLAG_MASK = 128;
    static final int B1_MASK_LENGTH = 127;
    static final int CLOSE_ABNORMAL_TERMINATION = 1006;
    static final int CLOSE_CLIENT_GOING_AWAY = 1001;
    static final long CLOSE_MESSAGE_MAX = 123L;
    static final int CLOSE_NO_STATUS_CODE = 1005;
    static final int CLOSE_PROTOCOL_EXCEPTION = 1002;
    static final int OPCODE_BINARY = 2;
    static final int OPCODE_CONTINUATION = 0;
    static final int OPCODE_CONTROL_CLOSE = 8;
    static final int OPCODE_CONTROL_PING = 9;
    static final int OPCODE_CONTROL_PONG = 10;
    static final int OPCODE_FLAG_CONTROL = 8;
    static final int OPCODE_TEXT = 1;
    static final long PAYLOAD_BYTE_MAX = 125L;
    static final int PAYLOAD_LONG = 127;
    static final int PAYLOAD_SHORT = 126;
    static final long PAYLOAD_SHORT_MAX = 65535L;

    private WebSocketProtocol()
    {
        throw new AssertionError("No instances.");
    }

    public static String acceptHeader(String s)
    {
        return ByteString.encodeUtf8((new StringBuilder()).append(s).append("258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toString()).sha1().base64();
    }

    static String closeCodeExceptionMessage(int i)
    {
        while (i < 1000 || i >= 5000) 
        {
            return (new StringBuilder()).append("Code must be in range [1000,5000): ").append(i).toString();
        }
        break MISSING_BLOCK_LABEL_34;
        while (i >= 1004 && i <= 1006 || i >= 1012 && i <= 2999) 
        {
            return (new StringBuilder()).append("Code ").append(i).append(" is reserved and may not be used.").toString();
        }
        return null;
    }

    static void toggleMask(byte abyte0[], long l, byte abyte1[], long l1)
    {
        int k = abyte1.length;
        int i = 0;
        do
        {
            int j;
            if ((long)i >= l)
            {
                j = 1;
            } else
            {
                j = 0;
            }
            if (j == 0)
            {
                j = (int)(l1 % (long)k);
                byte byte0 = abyte0[i];
                abyte0[i] = (byte)(abyte1[j] ^ byte0);
                l1++;
                i++;
            } else
            {
                return;
            }
        } while (true);
    }

    static void validateCloseCode(int i)
    {
        String s = closeCodeExceptionMessage(i);
        if (s == null)
        {
            return;
        } else
        {
            throw new IllegalArgumentException(s);
        }
    }
}
