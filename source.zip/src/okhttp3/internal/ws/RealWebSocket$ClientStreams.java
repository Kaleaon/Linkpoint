// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.StreamAllocation;

// Referenced classes of package okhttp3.internal.ws:
//            RealWebSocket

static final class streamAllocation extends streamAllocation
{

    private final StreamAllocation streamAllocation;

    public void close()
    {
        streamAllocation.streamFinished(true, streamAllocation.codec());
    }

    (StreamAllocation streamallocation)
    {
        super(true, streamallocation.connection().source, streamallocation.connection().sink);
        streamAllocation = streamallocation;
    }
}
