// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;


// Referenced classes of package okhttp3.internal.ws:
//            RealWebSocket

final class this._cls0
    implements Runnable
{

    final RealWebSocket this$0;

    public void run()
    {
        cancel();
    }

    ()
    {
        this$0 = RealWebSocket.this;
        super();
    }
}
