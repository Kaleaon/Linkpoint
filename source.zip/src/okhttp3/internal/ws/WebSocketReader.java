// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.ws:
//            WebSocketProtocol

final class WebSocketReader
{
    public static interface FrameCallback
    {

        public abstract void onReadClose(int i, String s);

        public abstract void onReadMessage(String s)
            throws IOException;

        public abstract void onReadMessage(ByteString bytestring)
            throws IOException;

        public abstract void onReadPing(ByteString bytestring);

        public abstract void onReadPong(ByteString bytestring);
    }


    boolean closed;
    long frameBytesRead;
    final FrameCallback frameCallback;
    long frameLength;
    final boolean isClient;
    boolean isControlFrame;
    boolean isFinalFrame;
    boolean isMasked;
    final byte maskBuffer[] = new byte[8192];
    final byte maskKey[] = new byte[4];
    int opcode;
    final BufferedSource source;

    WebSocketReader(boolean flag, BufferedSource bufferedsource, FrameCallback framecallback)
    {
        if (bufferedsource != null)
        {
            if (framecallback != null)
            {
                isClient = flag;
                source = bufferedsource;
                frameCallback = framecallback;
                return;
            } else
            {
                throw new NullPointerException("frameCallback == null");
            }
        } else
        {
            throw new NullPointerException("source == null");
        }
    }

    private void readControlFrame()
        throws IOException
    {
        Object obj;
        int i;
        obj = new Buffer();
        if (frameBytesRead >= frameLength)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L2; else goto _L1
_L1:
        if (isClient) goto _L4; else goto _L3
_L3:
        if (frameBytesRead >= frameLength)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L2; else goto _L5
_L5:
        i = (int)Math.min(frameLength - frameBytesRead, maskBuffer.length);
        i = source.read(maskBuffer, 0, i);
        if (i != -1)
        {
            WebSocketProtocol.toggleMask(maskBuffer, i, maskKey, frameBytesRead);
            ((Buffer) (obj)).write(maskBuffer, 0, i);
            frameBytesRead = frameBytesRead + (long)i;
        } else
        {
            throw new EOFException();
        }
        if (true) goto _L3; else goto _L2
_L4:
        source.readFully(((Buffer) (obj)), frameLength);
_L2:
label0:
        {
            String s;
            long l;
            switch (opcode)
            {
            default:
                throw new ProtocolException((new StringBuilder()).append("Unknown control opcode: ").append(Integer.toHexString(opcode)).toString());

            case 9: // '\t'
                frameCallback.onReadPing(((Buffer) (obj)).readByteString());
                return;

            case 10: // '\n'
                frameCallback.onReadPong(((Buffer) (obj)).readByteString());
                return;

            case 8: // '\b'
                i = 1005;
                s = "";
                l = ((Buffer) (obj)).size();
                break;
            }
            if (l == 1L)
            {
                throw new ProtocolException("Malformed close payload length of 1.");
            }
            if (l != 0L)
            {
                i = ((Buffer) (obj)).readShort();
                s = ((Buffer) (obj)).readUtf8();
                obj = WebSocketProtocol.closeCodeExceptionMessage(i);
                if (obj != null)
                {
                    break label0;
                }
            }
            frameCallback.onReadClose(i, s);
            closed = true;
            return;
        }
        throw new ProtocolException(((String) (obj)));
    }

    private void readHeader()
        throws IOException
    {
        boolean flag4;
        long l;
        flag4 = true;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_168;
        }
        l = source.timeout().timeoutNanos();
        source.timeout().clearTimeout();
        int i;
        boolean flag2;
        boolean flag3;
        i = source.readByte();
        break MISSING_BLOCK_LABEL_47;
        throw new IOException("closed");
        exception;
        source.timeout().timeout(l, TimeUnit.NANOSECONDS);
        throw exception;
        int j = i & 0xff;
        source.timeout().timeout(l, TimeUnit.NANOSECONDS);
        opcode = j & 0xf;
        Exception exception;
        boolean flag5;
        if ((j & 0x80) == 0)
        {
            flag5 = false;
        } else
        {
            flag5 = true;
        }
        isFinalFrame = flag5;
        if ((j & 8) == 0)
        {
            flag5 = false;
        } else
        {
            flag5 = true;
        }
        isControlFrame = flag5;
        if (isControlFrame && !isFinalFrame)
        {
            throw new ProtocolException("Control frames must be final.");
        } else
        {
            break MISSING_BLOCK_LABEL_123;
        }
        if ((j & 0x40) == 0)
        {
            i = 0;
        } else
        {
            i = 1;
        }
        if ((j & 0x20) == 0)
        {
            flag2 = false;
        } else
        {
            flag2 = true;
        }
        if ((j & 0x10) == 0)
        {
            flag3 = false;
        } else
        {
            flag3 = true;
        }
        if (i || flag2 || flag3)
        {
            throw new ProtocolException("Reserved flags are unsupported.");
        }
        i = source.readByte() & 0xff;
        boolean flag6;
        if ((i & 0x80) == 0)
        {
            flag6 = false;
        } else
        {
            flag6 = true;
        }
        isMasked = flag6;
        if (isMasked != isClient)
        {
            frameLength = i & 0x7f;
            String s;
            if (frameLength == 126L)
            {
                frameLength = (long)source.readShort() & 65535L;
            } else
            if (frameLength == 127L)
            {
                frameLength = source.readLong();
                boolean flag;
                if (frameLength >= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    throw new ProtocolException((new StringBuilder()).append("Frame length 0x").append(Long.toHexString(frameLength)).append(" > 0x7FFFFFFFFFFFFFFF").toString());
                }
            }
            frameBytesRead = 0L;
            if (isControlFrame)
            {
                boolean flag1;
                if (frameLength <= 125L)
                {
                    flag1 = flag4;
                } else
                {
                    flag1 = false;
                }
                if (!flag1)
                {
                    throw new ProtocolException("Control frame must be less than 125B.");
                }
            }
            if (!isMasked)
            {
                return;
            } else
            {
                source.readFully(maskKey);
                return;
            }
        } else
        {
            if (!isClient)
            {
                s = "Client-sent frames must be masked.";
            } else
            {
                s = "Server-sent frames must not be masked.";
            }
            throw new ProtocolException(s);
        }
    }

    private void readMessage(Buffer buffer)
        throws IOException
    {
_L2:
        long l;
        if (closed)
        {
            break MISSING_BLOCK_LABEL_94;
        }
        if (frameBytesRead == frameLength)
        {
            if (!isFinalFrame)
            {
label0:
                {
                    readUntilNonControlFrame();
                    long l1;
                    if (opcode == 0)
                    {
                        break label0;
                    } else
                    {
                        throw new ProtocolException((new StringBuilder()).append("Expected continuation opcode. Got: ").append(Integer.toHexString(opcode)).toString());
                    }
                }
            } else
            {
                return;
            }
        }
        l = frameLength - frameBytesRead;
        if (!isMasked)
        {
            l1 = source.read(buffer, l);
            l = l1;
            if (l1 == -1L)
            {
                throw new EOFException();
            }
        } else
        {
            l = Math.min(l, maskBuffer.length);
            l = source.read(maskBuffer, 0, (int)l);
            if (l == -1L)
            {
                throw new EOFException();
            }
            WebSocketProtocol.toggleMask(maskBuffer, l, maskKey, frameBytesRead);
            buffer.write(maskBuffer, 0, (int)l);
        }
        break MISSING_BLOCK_LABEL_221;
        throw new IOException("closed");
        if (isFinalFrame && frameLength == 0L)
        {
            return;
        } else
        {
            break MISSING_BLOCK_LABEL_44;
        }
        frameBytesRead = frameBytesRead + l;
        if (true) goto _L2; else goto _L1
_L1:
    }

    private void readMessageFrame()
        throws IOException
    {
        for (int i = opcode; i == 1 || i == 2;)
        {
            Buffer buffer = new Buffer();
            readMessage(buffer);
            if (i != 1)
            {
                frameCallback.onReadMessage(buffer.readByteString());
                return;
            } else
            {
                frameCallback.onReadMessage(buffer.readUtf8());
                return;
            }
        }

        throw new ProtocolException((new StringBuilder()).append("Unknown opcode: ").append(Integer.toHexString(i)).toString());
    }

    void processNextFrame()
        throws IOException
    {
        readHeader();
        if (!isControlFrame)
        {
            readMessageFrame();
            return;
        } else
        {
            readControlFrame();
            return;
        }
    }

    void readUntilNonControlFrame()
        throws IOException
    {
_L5:
        if (!closed) goto _L2; else goto _L1
_L1:
        return;
_L2:
        readHeader();
        if (!isControlFrame) goto _L1; else goto _L3
_L3:
        readControlFrame();
        if (true) goto _L5; else goto _L4
_L4:
    }
}
