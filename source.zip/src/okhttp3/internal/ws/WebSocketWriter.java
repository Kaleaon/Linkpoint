// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.IOException;
import java.util.Random;
import okio.Buffer;
import okio.BufferedSink;
import okio.ByteString;
import okio.Sink;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.ws:
//            WebSocketProtocol

final class WebSocketWriter
{
    final class FrameSink
        implements Sink
    {

        boolean closed;
        long contentLength;
        int formatOpcode;
        boolean isFirstFrame;
        final WebSocketWriter this$0;

        public void close()
            throws IOException
        {
            if (!closed)
            {
                synchronized (WebSocketWriter.this)
                {
                    writeMessageFrameSynchronized(formatOpcode, buffer.size(), isFirstFrame, true);
                }
                closed = true;
                activeWriter = false;
                return;
            } else
            {
                throw new IOException("closed");
            }
            exception;
            websocketwriter;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void flush()
            throws IOException
        {
            if (!closed)
            {
                synchronized (WebSocketWriter.this)
                {
                    writeMessageFrameSynchronized(formatOpcode, buffer.size(), isFirstFrame, false);
                }
                isFirstFrame = false;
                return;
            } else
            {
                throw new IOException("closed");
            }
            exception;
            websocketwriter;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public Timeout timeout()
        {
            return sink.timeout();
        }

        public void write(Buffer buffer1, long l)
            throws IOException
        {
            boolean flag1 = true;
            if (closed) goto _L2; else goto _L1
_L1:
            buffer.write(buffer1, l);
              goto _L3
_L5:
            boolean flag = false;
_L7:
            l = buffer.completeSegmentByteCount();
            if (l > 0L)
            {
                flag1 = false;
            }
            if (flag1 || flag)
            {
                return;
            }
            break MISSING_BLOCK_LABEL_129;
_L2:
            throw new IOException("closed");
_L3:
            if (!isFirstFrame || contentLength == -1L) goto _L5; else goto _L4
_L4:
            if (buffer.size() <= contentLength - 8192L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag) goto _L5; else goto _L6
_L6:
            flag = true;
              goto _L7
            synchronized (WebSocketWriter.this)
            {
                writeMessageFrameSynchronized(formatOpcode, l, isFirstFrame, false);
            }
            isFirstFrame = false;
            return;
            exception;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception;
        }

        FrameSink()
        {
            this$0 = WebSocketWriter.this;
            super();
        }
    }


    static final boolean $assertionsDisabled;
    boolean activeWriter;
    final Buffer buffer = new Buffer();
    final FrameSink frameSink = new FrameSink();
    final boolean isClient;
    final byte maskBuffer[];
    final byte maskKey[];
    final Random random;
    final BufferedSink sink;
    boolean writerClosed;

    WebSocketWriter(boolean flag, BufferedSink bufferedsink, Random random1)
    {
        Object obj = null;
        super();
        if (bufferedsink != null)
        {
            if (random1 != null)
            {
                isClient = flag;
                sink = bufferedsink;
                random = random1;
                if (!flag)
                {
                    bufferedsink = null;
                } else
                {
                    bufferedsink = new byte[4];
                }
                maskKey = bufferedsink;
                if (!flag)
                {
                    bufferedsink = obj;
                } else
                {
                    bufferedsink = new byte[8192];
                }
                maskBuffer = bufferedsink;
                return;
            } else
            {
                throw new NullPointerException("random == null");
            }
        } else
        {
            throw new NullPointerException("sink == null");
        }
    }

    private void writeControlFrameSynchronized(int i, ByteString bytestring)
        throws IOException
    {
        boolean flag = false;
        int j;
        if ($assertionsDisabled || Thread.holdsLock(this))
        {
            if (!writerClosed)
            {
                j = bytestring.size();
                if ((long)j <= 125L)
                {
                    flag = true;
                }
                if (!flag)
                {
                    throw new IllegalArgumentException("Payload size must be less than or equal to 125");
                }
            } else
            {
                throw new IOException("closed");
            }
        } else
        {
            throw new AssertionError();
        }
        sink.writeByte(i | 0x80);
        if (!isClient)
        {
            sink.writeByte(j);
            sink.write(bytestring);
        } else
        {
            sink.writeByte(j | 0x80);
            random.nextBytes(maskKey);
            sink.write(maskKey);
            bytestring = bytestring.toByteArray();
            WebSocketProtocol.toggleMask(bytestring, bytestring.length, maskKey, 0L);
            sink.write(bytestring);
        }
        sink.flush();
    }

    Sink newMessageSink(int i, long l)
    {
        if (!activeWriter)
        {
            activeWriter = true;
            frameSink.formatOpcode = i;
            frameSink.contentLength = l;
            frameSink.isFirstFrame = true;
            frameSink.closed = false;
            return frameSink;
        } else
        {
            throw new IllegalStateException("Another message writer is active. Did you call close()?");
        }
    }


// JavaClassFileOutputException: Prev chain is broken

    void writeMessageFrameSynchronized(int i, long l, boolean flag, boolean flag1)
        throws IOException
    {
_L6:
        if (writerClosed) goto _L2; else goto _L1
_L1:
        if (!flag)
        {
            i = 0;
        }
        int j;
        if (flag1)
        {
            i |= 0x80;
        }
        sink.writeByte(i);
        if (!isClient)
        {
            i = 0;
        } else
        {
            i = 128;
        }
        if (l > 125L)
        {
            j = 1;
        } else
        {
            j = 0;
        }
        if (j == 0)
        {
            j = (int)l;
            sink.writeByte(j | i);
        } else
        {
            boolean flag2;
            if (l > 65535L)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
            if (!flag2)
            {
                sink.writeByte(i | 0x7e);
                sink.writeShort((int)l);
            } else
            {
                sink.writeByte(i | 0x7f);
                sink.writeLong(l);
            }
        }
        if (isClient) goto _L4; else goto _L3
_L3:
        sink.write(buffer, l);
_L8:
        sink.emit();
        return;
        if ($assertionsDisabled || Thread.holdsLock(this)) goto _L6; else goto _L5
_L5:
        throw new AssertionError();
_L2:
        throw new IOException("closed");
_L4:
        long l1;
        random.nextBytes(maskKey);
        sink.write(maskKey);
        l1 = 0L;
_L9:
        if (l1 >= l)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L8; else goto _L7
_L7:
        i = (int)Math.min(l, maskBuffer.length);
        i = buffer.read(maskBuffer, 0, i);
        if (i != -1)
        {
            WebSocketProtocol.toggleMask(maskBuffer, i, maskKey, l1);
            sink.write(maskBuffer, 0, i);
            l1 += i;
        } else
        {
            throw new AssertionError();
        }
          goto _L9
    }

    void writePing(ByteString bytestring)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        writeControlFrameSynchronized(9, bytestring);
        this;
        JVM INSTR monitorexit ;
        return;
        bytestring;
        this;
        JVM INSTR monitorexit ;
        throw bytestring;
    }

    void writePong(ByteString bytestring)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        writeControlFrameSynchronized(10, bytestring);
        this;
        JVM INSTR monitorexit ;
        return;
        bytestring;
        this;
        JVM INSTR monitorexit ;
        throw bytestring;
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/ws/WebSocketWriter.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
    }
}
