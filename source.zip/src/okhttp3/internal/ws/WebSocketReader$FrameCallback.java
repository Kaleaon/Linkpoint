// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.IOException;
import okio.ByteString;

// Referenced classes of package okhttp3.internal.ws:
//            WebSocketReader

public static interface 
{

    public abstract void onReadClose(int i, String s);

    public abstract void onReadMessage(String s)
        throws IOException;

    public abstract void onReadMessage(ByteString bytestring)
        throws IOException;

    public abstract void onReadPing(ByteString bytestring);

    public abstract void onReadPong(ByteString bytestring);
}
