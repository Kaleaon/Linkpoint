// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.Closeable;
import okio.BufferedSink;
import okio.BufferedSource;

// Referenced classes of package okhttp3.internal.ws:
//            RealWebSocket

public static abstract class sink
    implements Closeable
{

    public final boolean client;
    public final BufferedSink sink;
    public final BufferedSource source;

    public (boolean flag, BufferedSource bufferedsource, BufferedSink bufferedsink)
    {
        client = flag;
        source = bufferedsource;
        sink = bufferedsink;
    }
}
