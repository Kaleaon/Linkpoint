// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.Closeable;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Socket;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.internal.Internal;
import okhttp3.internal.Util;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.connection.StreamAllocation;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;

// Referenced classes of package okhttp3.internal.ws:
//            WebSocketWriter, WebSocketProtocol, WebSocketReader

public final class RealWebSocket
    implements WebSocket, WebSocketReader.FrameCallback
{
    final class CancelRunnable
        implements Runnable
    {

        final RealWebSocket this$0;

        public void run()
        {
            cancel();
        }

        CancelRunnable()
        {
            this$0 = RealWebSocket.this;
            super();
        }
    }

    static final class ClientStreams extends Streams
    {

        private final StreamAllocation streamAllocation;

        public void close()
        {
            streamAllocation.streamFinished(true, streamAllocation.codec());
        }

        ClientStreams(StreamAllocation streamallocation)
        {
            super(true, streamallocation.connection().source, streamallocation.connection().sink);
            streamAllocation = streamallocation;
        }
    }

    static final class Close
    {

        final long cancelAfterCloseMillis;
        final int code;
        final ByteString reason;

        Close(int i, ByteString bytestring, long l)
        {
            code = i;
            reason = bytestring;
            cancelAfterCloseMillis = l;
        }
    }

    static final class Message
    {

        final ByteString data;
        final int formatOpcode;

        Message(int i, ByteString bytestring)
        {
            formatOpcode = i;
            data = bytestring;
        }
    }

    private final class PingRunnable
        implements Runnable
    {

        final RealWebSocket this$0;

        public void run()
        {
            writePingFrame();
        }

        private PingRunnable()
        {
            this$0 = RealWebSocket.this;
            super();
        }

    }

    public static abstract class Streams
        implements Closeable
    {

        public final boolean client;
        public final BufferedSink sink;
        public final BufferedSource source;

        public Streams(boolean flag, BufferedSource bufferedsource, BufferedSink bufferedsink)
        {
            client = flag;
            source = bufferedsource;
            sink = bufferedsink;
        }
    }


    static final boolean $assertionsDisabled;
    private static final long CANCEL_AFTER_CLOSE_MILLIS = 60000L;
    private static final long MAX_QUEUE_SIZE = 0x1000000L;
    private static final List ONLY_HTTP1;
    private Call call;
    private ScheduledFuture cancelFuture;
    private boolean enqueuedClose;
    private ScheduledExecutorService executor;
    private boolean failed;
    private final String key;
    final WebSocketListener listener;
    private final ArrayDeque messageAndCloseQueue = new ArrayDeque();
    private final Request originalRequest;
    int pingCount;
    int pongCount;
    private final ArrayDeque pongQueue = new ArrayDeque();
    private long queueSize;
    private final Random random;
    private WebSocketReader reader;
    private int receivedCloseCode;
    private String receivedCloseReason;
    private Streams streams;
    private WebSocketWriter writer;
    private final Runnable writerRunnable;

    public RealWebSocket(Request request1, WebSocketListener websocketlistener, Random random1)
    {
        receivedCloseCode = -1;
        if ("GET".equals(request1.method()))
        {
            originalRequest = request1;
            listener = websocketlistener;
            random = random1;
            request1 = new byte[16];
            random1.nextBytes(request1);
            key = ByteString.of(request1).base64();
            writerRunnable = new Runnable() {

                final RealWebSocket this$0;

                public void run()
                {
                    boolean flag;
                    do
                    {
                        flag = writeOneFrame();
                    } while (flag);
                    return;
                    IOException ioexception;
                    ioexception;
                    failWebSocket(ioexception, null);
                    return;
                }

            
            {
                this$0 = RealWebSocket.this;
                super();
            }
            };
            return;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Request must be GET: ").append(request1.method()).toString());
        }
    }

    private void runWriter()
    {
        while ($assertionsDisabled || Thread.holdsLock(this)) 
        {
            if (executor == null)
            {
                return;
            } else
            {
                executor.execute(writerRunnable);
                return;
            }
        }
        throw new AssertionError();
    }

    private boolean send(ByteString bytestring, int i)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag1 = failed;
        if (!flag1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return false;
_L2:
        if (enqueuedClose) goto _L1; else goto _L3
_L3:
        boolean flag;
        if (queueSize + (long)bytestring.size() <= 0x1000000L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_65;
        }
        close(1001, null);
        this;
        JVM INSTR monitorexit ;
        return false;
        queueSize = queueSize + (long)bytestring.size();
        messageAndCloseQueue.add(new Message(i, bytestring));
        runWriter();
        this;
        JVM INSTR monitorexit ;
        return true;
        bytestring;
        throw bytestring;
    }

    private void writePingFrame()
    {
        this;
        JVM INSTR monitorenter ;
        WebSocketWriter websocketwriter;
        if (failed)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        websocketwriter = writer;
        this;
        JVM INSTR monitorexit ;
        Exception exception;
        try
        {
            websocketwriter.writePing(ByteString.EMPTY);
            return;
        }
        catch (IOException ioexception)
        {
            failWebSocket(ioexception, null);
        }
        break MISSING_BLOCK_LABEL_39;
        this;
        JVM INSTR monitorexit ;
        return;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void cancel()
    {
        call.cancel();
    }

    void checkResponse(Response response)
        throws ProtocolException
    {
        if (response.code() == 101)
        {
            String s = response.header("Connection");
            if ("Upgrade".equalsIgnoreCase(s))
            {
                s = response.header("Upgrade");
                if ("websocket".equalsIgnoreCase(s))
                {
                    response = response.header("Sec-WebSocket-Accept");
                    s = ByteString.encodeUtf8((new StringBuilder()).append(key).append("258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toString()).sha1().base64();
                    if (s.equals(response))
                    {
                        return;
                    } else
                    {
                        throw new ProtocolException((new StringBuilder()).append("Expected 'Sec-WebSocket-Accept' header value '").append(s).append("' but was '").append(response).append("'").toString());
                    }
                } else
                {
                    throw new ProtocolException((new StringBuilder()).append("Expected 'Upgrade' header value 'websocket' but was '").append(s).append("'").toString());
                }
            } else
            {
                throw new ProtocolException((new StringBuilder()).append("Expected 'Connection' header value 'Upgrade' but was '").append(s).append("'").toString());
            }
        } else
        {
            throw new ProtocolException((new StringBuilder()).append("Expected HTTP 101 response but was '").append(response.code()).append(" ").append(response.message()).append("'").toString());
        }
    }

    public boolean close(int i, String s)
    {
        return close(i, s, 60000L);
    }

    boolean close(int i, String s, long l)
    {
        ByteString bytestring = null;
        this;
        JVM INSTR monitorenter ;
        WebSocketProtocol.validateCloseCode(i);
        if (s != null) goto _L2; else goto _L1
_L1:
        boolean flag1 = failed;
        if (!flag1) goto _L4; else goto _L3
_L3:
        this;
        JVM INSTR monitorexit ;
        return false;
_L2:
        bytestring = ByteString.encodeUtf8(s);
        boolean flag;
        if ((long)bytestring.size() <= 123L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L1; else goto _L5
_L5:
        throw new IllegalArgumentException((new StringBuilder()).append("reason.size() > 123: ").append(s).toString());
        s;
        this;
        JVM INSTR monitorexit ;
        throw s;
_L4:
        if (enqueuedClose) goto _L3; else goto _L6
_L6:
        enqueuedClose = true;
        messageAndCloseQueue.add(new Close(i, bytestring, l));
        runWriter();
        this;
        JVM INSTR monitorexit ;
        return true;
    }

    public void connect(OkHttpClient okhttpclient)
    {
        okhttpclient = okhttpclient.newBuilder().protocols(ONLY_HTTP1).build();
        final int pingIntervalMillis = okhttpclient.pingIntervalMillis();
        final Request request = originalRequest.newBuilder().header("Upgrade", "websocket").header("Connection", "Upgrade").header("Sec-WebSocket-Key", key).header("Sec-WebSocket-Version", "13").build();
        call = Internal.instance.newWebSocketCall(okhttpclient, request);
        call.enqueue(new Callback() {

            final RealWebSocket this$0;
            final int val$pingIntervalMillis;
            final Request val$request;

            public void onFailure(Call call1, IOException ioexception)
            {
                failWebSocket(ioexception, null);
            }

            public void onResponse(Call call1, Response response)
            {
                ClientStreams clientstreams;
                try
                {
                    checkResponse(response);
                }
                // Misplaced declaration of an exception variable
                catch (Call call1)
                {
                    failWebSocket(call1, response);
                    Util.closeQuietly(response);
                    return;
                }
                call1 = Internal.instance.streamAllocation(call1);
                call1.noNewStreams();
                clientstreams = new ClientStreams(call1);
                try
                {
                    listener.onOpen(RealWebSocket.this, response);
                    response = (new StringBuilder()).append("OkHttp WebSocket ").append(request.url().redact()).toString();
                    initReaderAndWriter(response, pingIntervalMillis, clientstreams);
                    call1.connection().socket().setSoTimeout(0);
                    loopReader();
                    return;
                }
                // Misplaced declaration of an exception variable
                catch (Call call1)
                {
                    failWebSocket(call1, null);
                }
            }

            
            {
                this$0 = RealWebSocket.this;
                request = request1;
                pingIntervalMillis = i;
                super();
            }
        });
    }

    void failWebSocket(Exception exception, Response response)
    {
        this;
        JVM INSTR monitorenter ;
        if (failed) goto _L2; else goto _L1
_L1:
        Streams streams1;
        failed = true;
        streams1 = streams;
        streams = null;
        if (cancelFuture != null) goto _L4; else goto _L3
_L3:
        if (executor != null) goto _L6; else goto _L5
_L5:
        this;
        JVM INSTR monitorexit ;
        listener.onFailure(this, exception, response);
        Util.closeQuietly(streams1);
        return;
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        cancelFuture.cancel(false);
          goto _L3
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
_L6:
        executor.shutdown();
          goto _L5
        exception;
        Util.closeQuietly(streams1);
        throw exception;
          goto _L3
    }

    public void initReaderAndWriter(String s, long l, Streams streams1)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        streams = streams1;
        writer = new WebSocketWriter(streams1.client, streams1.sink, random);
        executor = new ScheduledThreadPoolExecutor(1, Util.threadFactory(s, false));
        if (l == 0L)
        {
            break MISSING_BLOCK_LABEL_80;
        }
        executor.scheduleAtFixedRate(new PingRunnable(), l, l, TimeUnit.MILLISECONDS);
        if (!messageAndCloseQueue.isEmpty())
        {
            break MISSING_BLOCK_LABEL_115;
        }
_L1:
        this;
        JVM INSTR monitorexit ;
        reader = new WebSocketReader(streams1.client, streams1.source, this);
        return;
        runWriter();
          goto _L1
        s;
        this;
        JVM INSTR monitorexit ;
        throw s;
    }

    public void loopReader()
        throws IOException
    {
        do
        {
            if (receivedCloseCode != -1)
            {
                return;
            }
            reader.processNextFrame();
        } while (true);
    }

    public void onReadClose(int i, String s)
    {
        if (i == -1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorenter ;
        if (receivedCloseCode != -1) goto _L4; else goto _L3
_L3:
        receivedCloseCode = i;
        receivedCloseReason = s;
        if (enqueuedClose) goto _L6; else goto _L5
_L11:
        this;
        JVM INSTR monitorexit ;
        listener.onClosing(this, i, s);
        Streams streams1;
        if (streams1 != null) goto _L8; else goto _L7
_L7:
        Util.closeQuietly(streams1);
        return;
_L2:
        throw new IllegalArgumentException();
_L4:
        throw new IllegalStateException("already closed");
        s;
        this;
        JVM INSTR monitorexit ;
        throw s;
_L6:
        if (!messageAndCloseQueue.isEmpty())
        {
            break; /* Loop/switch isn't completed */
        }
        streams1 = streams;
        streams = null;
        if (cancelFuture != null)
        {
            break MISSING_BLOCK_LABEL_119;
        }
_L9:
        executor.shutdown();
        continue; /* Loop/switch isn't completed */
        cancelFuture.cancel(false);
          goto _L9
_L8:
        listener.onClosed(this, i, s);
        if (true) goto _L7; else goto _L5
        s;
        Util.closeQuietly(streams1);
        throw s;
_L5:
        streams1 = null;
        if (true) goto _L11; else goto _L10
_L10:
    }

    public void onReadMessage(String s)
        throws IOException
    {
        listener.onMessage(this, s);
    }

    public void onReadMessage(ByteString bytestring)
        throws IOException
    {
        listener.onMessage(this, bytestring);
    }

    public void onReadPing(ByteString bytestring)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = failed;
        if (!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if (enqueuedClose) goto _L4; else goto _L3
_L3:
        pongQueue.add(bytestring);
        runWriter();
        pingCount = pingCount + 1;
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        flag = messageAndCloseQueue.isEmpty();
        if (flag) goto _L1; else goto _L3
        bytestring;
        throw bytestring;
    }

    public void onReadPong(ByteString bytestring)
    {
        this;
        JVM INSTR monitorenter ;
        pongCount = pongCount + 1;
        this;
        JVM INSTR monitorexit ;
        return;
        bytestring;
        throw bytestring;
    }

    int pingCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = pingCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    boolean pong(ByteString bytestring)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = failed;
        if (!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return false;
_L2:
        if (enqueuedClose) goto _L4; else goto _L3
_L3:
        pongQueue.add(bytestring);
        runWriter();
        this;
        JVM INSTR monitorexit ;
        return true;
_L4:
        flag = messageAndCloseQueue.isEmpty();
        if (flag) goto _L1; else goto _L3
        bytestring;
        throw bytestring;
    }

    int pongCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = pongCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    boolean processNextFrame()
        throws IOException
    {
        int i;
        try
        {
            reader.processNextFrame();
            i = receivedCloseCode;
        }
        catch (Exception exception)
        {
            failWebSocket(exception, null);
            return false;
        }
        return i == -1;
    }

    public long queueSize()
    {
        this;
        JVM INSTR monitorenter ;
        long l = queueSize;
        this;
        JVM INSTR monitorexit ;
        return l;
        Exception exception;
        exception;
        throw exception;
    }

    public Request request()
    {
        return originalRequest;
    }

    public boolean send(String s)
    {
        if (s != null)
        {
            return send(ByteString.encodeUtf8(s), 1);
        } else
        {
            throw new NullPointerException("text == null");
        }
    }

    public boolean send(ByteString bytestring)
    {
        if (bytestring != null)
        {
            return send(bytestring, 2);
        } else
        {
            throw new NullPointerException("bytes == null");
        }
    }

    boolean writeOneFrame()
        throws IOException
    {
        Object obj2 = null;
        this;
        JVM INSTR monitorenter ;
        if (failed) goto _L2; else goto _L1
_L1:
        WebSocketWriter websocketwriter;
        ByteString bytestring;
        websocketwriter = writer;
        bytestring = (ByteString)pongQueue.poll();
        if (bytestring == null) goto _L4; else goto _L3
_L3:
        Object obj;
        Object obj1;
        int i;
        obj = null;
        i = -1;
        obj1 = null;
_L10:
        this;
        JVM INSTR monitorexit ;
        if (bytestring != null) goto _L6; else goto _L5
_L5:
        if (obj1 instanceof Message) goto _L8; else goto _L7
_L7:
        if (!(obj1 instanceof Close))
        {
            throw new AssertionError();
        }
          goto _L9
        obj1;
        Util.closeQuietly(((Closeable) (obj)));
        throw obj1;
_L2:
        this;
        JVM INSTR monitorexit ;
        return false;
_L4:
        obj = messageAndCloseQueue.poll();
        if (obj instanceof Close)
        {
            break MISSING_BLOCK_LABEL_114;
        }
        if (obj == null)
        {
            break MISSING_BLOCK_LABEL_201;
        }
        i = -1;
        Object obj3 = null;
        obj1 = obj;
        obj = obj3;
          goto _L10
        i = receivedCloseCode;
        obj2 = receivedCloseReason;
        if (i != -1)
        {
            break MISSING_BLOCK_LABEL_173;
        }
        cancelFuture = executor.schedule(new CancelRunnable(), ((Close)obj).cancelAfterCloseMillis, TimeUnit.MILLISECONDS);
        Object obj4 = null;
        obj1 = obj;
        obj = obj4;
          goto _L10
        Streams streams1;
        streams1 = streams;
        streams = null;
        executor.shutdown();
        obj1 = obj;
        obj = streams1;
          goto _L10
        this;
        JVM INSTR monitorexit ;
        return false;
        obj;
        this;
        JVM INSTR monitorexit ;
        throw obj;
_L6:
        websocketwriter.writePong(bytestring);
_L11:
        Util.closeQuietly(((Closeable) (obj)));
        return true;
_L8:
        obj2 = ((Message)obj1).data;
        obj1 = Okio.buffer(websocketwriter.newMessageSink(((Message)obj1).formatOpcode, ((ByteString) (obj2)).size()));
        ((BufferedSink) (obj1)).write(((ByteString) (obj2)));
        ((BufferedSink) (obj1)).close();
        this;
        JVM INSTR monitorenter ;
        queueSize = queueSize - (long)((ByteString) (obj2)).size();
        this;
        JVM INSTR monitorexit ;
          goto _L11
        obj1;
        this;
        JVM INSTR monitorexit ;
        throw obj1;
_L9:
        obj1 = (Close)obj1;
        websocketwriter.writeClose(((Close) (obj1)).code, ((Close) (obj1)).reason);
        if (obj == null) goto _L11; else goto _L12
_L12:
        listener.onClosed(this, i, ((String) (obj2)));
          goto _L11
    }

    static 
    {
        boolean flag = false;
        if (!okhttp3/internal/ws/RealWebSocket.desiredAssertionStatus())
        {
            flag = true;
        }
        $assertionsDisabled = flag;
        ONLY_HTTP1 = Collections.singletonList(Protocol.HTTP_1_1);
    }

}
