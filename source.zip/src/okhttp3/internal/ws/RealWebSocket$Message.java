// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import okio.ByteString;

// Referenced classes of package okhttp3.internal.ws:
//            RealWebSocket

static final class data
{

    final ByteString data;
    final int formatOpcode;

    (int i, ByteString bytestring)
    {
        formatOpcode = i;
        data = bytestring;
    }
}
