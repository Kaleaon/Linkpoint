// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.ws;

import java.io.IOException;
import okio.Buffer;
import okio.BufferedSink;
import okio.Sink;
import okio.Timeout;

// Referenced classes of package okhttp3.internal.ws:
//            WebSocketWriter

final class this._cls0
    implements Sink
{

    boolean closed;
    long contentLength;
    int formatOpcode;
    boolean isFirstFrame;
    final WebSocketWriter this$0;

    public void close()
        throws IOException
    {
        if (!closed)
        {
            synchronized (WebSocketWriter.this)
            {
                writeMessageFrameSynchronized(formatOpcode, buffer.size(), isFirstFrame, true);
            }
            closed = true;
            activeWriter = false;
            return;
        } else
        {
            throw new IOException("closed");
        }
        exception;
        websocketwriter;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void flush()
        throws IOException
    {
        if (!closed)
        {
            synchronized (WebSocketWriter.this)
            {
                writeMessageFrameSynchronized(formatOpcode, buffer.size(), isFirstFrame, false);
            }
            isFirstFrame = false;
            return;
        } else
        {
            throw new IOException("closed");
        }
        exception;
        websocketwriter;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public Timeout timeout()
    {
        return sink.timeout();
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        boolean flag1 = true;
        if (closed) goto _L2; else goto _L1
_L1:
        WebSocketWriter.this.buffer.write(buffer, l);
          goto _L3
_L5:
        boolean flag = false;
_L7:
        l = WebSocketWriter.this.buffer.completeSegmentByteCount();
        if (l > 0L)
        {
            flag1 = false;
        }
        if (flag1 || flag)
        {
            return;
        }
        break MISSING_BLOCK_LABEL_129;
_L2:
        throw new IOException("closed");
_L3:
        if (!isFirstFrame || contentLength == -1L) goto _L5; else goto _L4
_L4:
        if (WebSocketWriter.this.buffer.size() <= contentLength - 8192L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L5; else goto _L6
_L6:
        flag = true;
          goto _L7
        synchronized (WebSocketWriter.this)
        {
            writeMessageFrameSynchronized(formatOpcode, l, isFirstFrame, false);
        }
        isFirstFrame = false;
        return;
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
    }

    ()
    {
        this$0 = WebSocketWriter.this;
        super();
    }
}
