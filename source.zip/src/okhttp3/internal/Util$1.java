// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal;

import java.util.concurrent.ThreadFactory;

// Referenced classes of package okhttp3.internal:
//            Util

static class val.daemon
    implements ThreadFactory
{

    final boolean val$daemon;
    final String val$name;

    public Thread newThread(Runnable runnable)
    {
        runnable = new Thread(runnable, val$name);
        runnable.setDaemon(val$daemon);
        return runnable;
    }

    eadFactory(String s, boolean flag)
    {
        val$name = s;
        val$daemon = flag;
        super();
    }
}
