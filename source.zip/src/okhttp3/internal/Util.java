// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal;

import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.Array;
import java.net.IDN;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.HttpUrl;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Source;
import okio.Timeout;

public final class Util
{

    public static final byte EMPTY_BYTE_ARRAY[];
    public static final RequestBody EMPTY_REQUEST;
    public static final ResponseBody EMPTY_RESPONSE;
    public static final String EMPTY_STRING_ARRAY[] = new String[0];
    public static final TimeZone UTC = TimeZone.getTimeZone("GMT");
    private static final Charset UTF_16_BE = Charset.forName("UTF-16BE");
    private static final ByteString UTF_16_BE_BOM = ByteString.decodeHex("feff");
    private static final Charset UTF_16_LE = Charset.forName("UTF-16LE");
    private static final ByteString UTF_16_LE_BOM = ByteString.decodeHex("fffe");
    private static final Charset UTF_32_BE = Charset.forName("UTF-32BE");
    private static final ByteString UTF_32_BE_BOM = ByteString.decodeHex("0000ffff");
    private static final Charset UTF_32_LE = Charset.forName("UTF-32LE");
    private static final ByteString UTF_32_LE_BOM = ByteString.decodeHex("ffff0000");
    public static final Charset UTF_8 = Charset.forName("UTF-8");
    private static final ByteString UTF_8_BOM = ByteString.decodeHex("efbbbf");
    private static final Pattern VERIFY_AS_IP_ADDRESS = Pattern.compile("([0-9a-fA-F]*:[0-9a-fA-F:.]*)|([\\d.]+)");

    private Util()
    {
    }

    public static Charset bomAwareCharset(BufferedSource bufferedsource, Charset charset)
        throws IOException
    {
        if (!bufferedsource.rangeEquals(0L, UTF_8_BOM))
        {
            if (!bufferedsource.rangeEquals(0L, UTF_16_BE_BOM))
            {
                if (!bufferedsource.rangeEquals(0L, UTF_16_LE_BOM))
                {
                    if (!bufferedsource.rangeEquals(0L, UTF_32_BE_BOM))
                    {
                        if (!bufferedsource.rangeEquals(0L, UTF_32_LE_BOM))
                        {
                            return charset;
                        } else
                        {
                            bufferedsource.skip(UTF_32_LE_BOM.size());
                            return UTF_32_LE;
                        }
                    } else
                    {
                        bufferedsource.skip(UTF_32_BE_BOM.size());
                        return UTF_32_BE;
                    }
                } else
                {
                    bufferedsource.skip(UTF_16_LE_BOM.size());
                    return UTF_16_LE;
                }
            } else
            {
                bufferedsource.skip(UTF_16_BE_BOM.size());
                return UTF_16_BE;
            }
        } else
        {
            bufferedsource.skip(UTF_8_BOM.size());
            return UTF_8;
        }
    }

    public static void checkOffsetAndCount(long l, long l1, long l2)
    {
label0:
        {
            boolean flag1 = true;
            boolean flag;
            if ((l1 | l2) < 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                if (l1 > l)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    if (l - l1 >= l2)
                    {
                        flag = flag1;
                    } else
                    {
                        flag = false;
                    }
                    if (flag)
                    {
                        break label0;
                    }
                }
            }
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public static void closeQuietly(Closeable closeable)
    {
        if (closeable == null)
        {
            return;
        }
        try
        {
            closeable.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Closeable closeable)
        {
            throw closeable;
        }
        // Misplaced declaration of an exception variable
        catch (Closeable closeable)
        {
            return;
        }
    }

    public static void closeQuietly(ServerSocket serversocket)
    {
        if (serversocket == null)
        {
            return;
        }
        try
        {
            serversocket.close();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (ServerSocket serversocket)
        {
            throw serversocket;
        }
        // Misplaced declaration of an exception variable
        catch (ServerSocket serversocket)
        {
            return;
        }
    }

    public static void closeQuietly(Socket socket)
    {
        if (socket != null)
        {
            try
            {
                socket.close();
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Socket socket) { }
            // Misplaced declaration of an exception variable
            catch (Socket socket)
            {
                throw socket;
            }
            // Misplaced declaration of an exception variable
            catch (Socket socket)
            {
                return;
            }
            if (!isAndroidGetsocknameError(socket))
            {
                throw socket;
            }
        }
    }

    public static String[] concat(String as[], String s)
    {
        String as1[] = new String[as.length + 1];
        System.arraycopy(as, 0, as1, 0, as.length);
        as1[as1.length - 1] = s;
        return as1;
    }

    private static boolean containsInvalidHostnameAsciiCodes(String s)
    {
        int i = 0;
        do
        {
            if (i >= s.length())
            {
                return false;
            }
            char c;
            for (c = s.charAt(i); c <= '\037' || c >= '\177';)
            {
                return true;
            }

            if (" #%/:?@[\\]".indexOf(c) == -1)
            {
                i++;
            } else
            {
                return true;
            }
        } while (true);
    }

    public static int delimiterOffset(String s, int i, int j, char c)
    {
        do
        {
            if (i >= j)
            {
                return j;
            }
            if (s.charAt(i) != c)
            {
                i++;
            } else
            {
                return i;
            }
        } while (true);
    }

    public static int delimiterOffset(String s, int i, int j, String s1)
    {
        do
        {
            if (i >= j)
            {
                return j;
            }
            if (s1.indexOf(s.charAt(i)) == -1)
            {
                i++;
            } else
            {
                return i;
            }
        } while (true);
    }

    public static boolean discard(Source source, int i, TimeUnit timeunit)
    {
        boolean flag;
        try
        {
            flag = skipAll(source, i, timeunit);
        }
        // Misplaced declaration of an exception variable
        catch (Source source)
        {
            return false;
        }
        return flag;
    }

    public static String domainToAscii(String s)
    {
label0:
        {
            boolean flag;
            try
            {
                s = IDN.toASCII(s).toLowerCase(Locale.US);
                if (s.isEmpty())
                {
                    break label0;
                }
                flag = containsInvalidHostnameAsciiCodes(s);
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                return null;
            }
            if (!flag)
            {
                return s;
            } else
            {
                return null;
            }
        }
        return null;
    }

    public static boolean equal(Object obj, Object obj1)
    {
        boolean flag = false;
        if (obj != obj1) goto _L2; else goto _L1
_L1:
        flag = true;
_L4:
        return flag;
_L2:
        if (obj == null) goto _L4; else goto _L3
_L3:
        if (!obj.equals(obj1))
        {
            return false;
        }
        if (true) goto _L1; else goto _L5
_L5:
    }

    public static transient String format(String s, Object aobj[])
    {
        return String.format(Locale.US, s, aobj);
    }

    public static String hostHeader(HttpUrl httpurl, boolean flag)
    {
        String s;
        if (!httpurl.host().contains(":"))
        {
            s = httpurl.host();
        } else
        {
            s = (new StringBuilder()).append("[").append(httpurl.host()).append("]").toString();
        }
        while (flag || httpurl.port() != HttpUrl.defaultPort(httpurl.scheme())) 
        {
            return (new StringBuilder()).append(s).append(":").append(httpurl.port()).toString();
        }
        return s;
    }

    public static List immutableList(List list)
    {
        return Collections.unmodifiableList(new ArrayList(list));
    }

    public static transient List immutableList(Object aobj[])
    {
        return Collections.unmodifiableList(Arrays.asList((Object[])aobj.clone()));
    }

    public static int indexOf(Object aobj[], Object obj)
    {
        int i = 0;
        int j = aobj.length;
        do
        {
            if (i >= j)
            {
                return -1;
            }
            if (!equal(aobj[i], obj))
            {
                i++;
            } else
            {
                return i;
            }
        } while (true);
    }

    private static List intersect(Object aobj[], Object aobj1[])
    {
        ArrayList arraylist;
        int i;
        int k;
        arraylist = new ArrayList();
        k = aobj.length;
        i = 0;
_L3:
        Object obj;
        int j;
        int l;
        if (i >= k)
        {
            return arraylist;
        }
        obj = aobj[i];
        l = aobj1.length;
        j = 0;
_L4:
        if (j < l) goto _L2; else goto _L1
_L1:
        i++;
          goto _L3
_L2:
        Object obj1;
label0:
        {
            obj1 = aobj1[j];
            if (obj.equals(obj1))
            {
                break label0;
            }
            j++;
        }
          goto _L4
        arraylist.add(obj1);
          goto _L1
    }

    public static Object[] intersect(Class class1, Object aobj[], Object aobj1[])
    {
        aobj = intersect(aobj, aobj1);
        return ((List) (aobj)).toArray((Object[])(Object[])Array.newInstance(class1, ((List) (aobj)).size()));
    }

    public static boolean isAndroidGetsocknameError(AssertionError assertionerror)
    {
        while (assertionerror.getCause() == null || assertionerror.getMessage() == null || !assertionerror.getMessage().contains("getsockname failed")) 
        {
            return false;
        }
        return true;
    }

    public static boolean skipAll(Source source, int i, TimeUnit timeunit)
        throws IOException
    {
        long l;
        long l1;
        l1 = System.nanoTime();
        if (!source.timeout().hasDeadline())
        {
            l = 0x7fffffffffffffffL;
        } else
        {
            l = source.timeout().deadlineNanoTime() - l1;
        }
        source.timeout().deadlineNanoTime(Math.min(l, timeunit.toNanos(i)) + l1);
        try
        {
            for (timeunit = new Buffer(); source.read(timeunit, 8192L) != -1L; timeunit.clear()) { }
        }
        // Misplaced declaration of an exception variable
        catch (TimeUnit timeunit)
        {
            if (l == 0x7fffffffffffffffL)
            {
                source.timeout().clearDeadline();
            } else
            {
                source.timeout().deadlineNanoTime(l + l1);
            }
            return false;
        }
        finally
        {
            if (l != 0x7fffffffffffffffL) goto _L0; else goto _L0
        }
        if (l == 0x7fffffffffffffffL)
        {
            source.timeout().clearDeadline();
        } else
        {
            source.timeout().deadlineNanoTime(l + l1);
        }
        return true;
        source.timeout().clearDeadline();
_L2:
        throw timeunit;
        source.timeout().deadlineNanoTime(l + l1);
        if (true) goto _L2; else goto _L1
_L1:
    }

    public static int skipLeadingAsciiWhitespace(String s, int i, int j)
    {
        do
        {
            if (i >= j)
            {
                return j;
            }
            switch (s.charAt(i))
            {
            default:
                return i;

            case 9: // '\t'
            case 10: // '\n'
            case 12: // '\f'
            case 13: // '\r'
            case 32: // ' '
                i++;
                break;
            }
        } while (true);
    }

    public static int skipTrailingAsciiWhitespace(String s, int i, int j)
    {
        j--;
        do
        {
            if (j < i)
            {
                return i;
            }
            switch (s.charAt(j))
            {
            default:
                return j + 1;

            case 9: // '\t'
            case 10: // '\n'
            case 12: // '\f'
            case 13: // '\r'
            case 32: // ' '
                j--;
                break;
            }
        } while (true);
    }

    public static ThreadFactory threadFactory(String s, boolean flag)
    {
        return new ThreadFactory(s, flag) {

            final boolean val$daemon;
            final String val$name;

            public Thread newThread(Runnable runnable)
            {
                runnable = new Thread(runnable, name);
                runnable.setDaemon(daemon);
                return runnable;
            }

            
            {
                name = s;
                daemon = flag;
                super();
            }
        };
    }

    public static void throwIfFatal(Throwable throwable)
    {
        if (!(throwable instanceof VirtualMachineError))
        {
            if (!(throwable instanceof ThreadDeath))
            {
                if (!(throwable instanceof LinkageError))
                {
                    return;
                } else
                {
                    throw (LinkageError)throwable;
                }
            } else
            {
                throw (ThreadDeath)throwable;
            }
        } else
        {
            throw (VirtualMachineError)throwable;
        }
    }

    public static String toHumanReadableAscii(String s)
    {
        int i;
        int i1;
        i1 = s.length();
        i = 0;
_L4:
        int j;
        if (i >= i1)
        {
            return s;
        }
        j = s.codePointAt(i);
          goto _L1
_L3:
        Buffer buffer;
        buffer = new Buffer();
        buffer.writeUtf8(s, 0, i);
_L5:
        if (i >= i1)
        {
            return buffer.readUtf8();
        }
        break MISSING_BLOCK_LABEL_71;
_L1:
        if (j <= 31 || j >= 127) goto _L3; else goto _L2
_L2:
        i += Character.charCount(j);
          goto _L4
        int l = s.codePointAt(i);
        int k;
        if (l <= 31 || l >= 127)
        {
            k = 63;
        } else
        {
            k = l;
        }
        buffer.writeUtf8CodePoint(k);
        i = Character.charCount(l) + i;
          goto _L5
    }

    public static String trimSubstring(String s, int i, int j)
    {
        i = skipLeadingAsciiWhitespace(s, i, j);
        return s.substring(i, skipTrailingAsciiWhitespace(s, i, j));
    }

    public static boolean verifyAsIpAddress(String s)
    {
        return VERIFY_AS_IP_ADDRESS.matcher(s).matches();
    }

    static 
    {
        EMPTY_BYTE_ARRAY = new byte[0];
        EMPTY_RESPONSE = ResponseBody.create(null, EMPTY_BYTE_ARRAY);
        EMPTY_REQUEST = RequestBody.create(null, EMPTY_BYTE_ARRAY);
    }
}
