// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import okhttp3.internal.tls.CertificateChainCleaner;

// Referenced classes of package okhttp3.internal.platform:
//            AndroidPlatform

static final class checkServerTrusted extends CertificateChainCleaner
{

    private final Method checkServerTrusted;
    private final Object x509TrustManagerExtensions;

    public List clean(List list, String s)
        throws SSLPeerUnverifiedException
    {
        try
        {
            list = (X509Certificate[])list.toArray(new X509Certificate[list.size()]);
            list = (List)checkServerTrusted.invoke(x509TrustManagerExtensions, new Object[] {
                list, "RSA", s
            });
        }
        // Misplaced declaration of an exception variable
        catch (List list)
        {
            s = new SSLPeerUnverifiedException(list.getMessage());
            s.initCause(list);
            throw s;
        }
        // Misplaced declaration of an exception variable
        catch (List list)
        {
            throw new AssertionError(list);
        }
        return list;
    }

    public boolean equals(Object obj)
    {
        return obj instanceof x509TrustManagerExtensions;
    }

    public int hashCode()
    {
        return 0;
    }

    (Object obj, Method method)
    {
        x509TrustManagerExtensions = obj;
        checkServerTrusted = method;
    }
}
