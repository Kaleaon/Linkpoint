// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import java.lang.reflect.Method;

// Referenced classes of package okhttp3.internal.platform:
//            AndroidPlatform

static final class warnIfOpenMethod
{

    private final Method getMethod;
    private final Method openMethod;
    private final Method warnIfOpenMethod;

    static warnIfOpenMethod get()
    {
        Method method = null;
        Method method1;
        Method method2;
        Object obj;
        obj = Class.forName("dalvik.system.CloseGuard");
        method2 = ((Class) (obj)).getMethod("get", new Class[0]);
        method1 = ((Class) (obj)).getMethod("open", new Class[] {
            java/lang/String
        });
        obj = ((Class) (obj)).getMethod("warnIfOpen", new Class[0]);
        method = ((Method) (obj));
_L2:
        return new <init>(method2, method1, method);
        Exception exception;
        exception;
        exception = null;
        method2 = null;
        if (true) goto _L2; else goto _L1
_L1:
    }

    Object createAndOpen(String s)
    {
        if (getMethod == null)
        {
            return null;
        }
        Object obj;
        try
        {
            obj = getMethod.invoke(null, new Object[0]);
            openMethod.invoke(obj, new Object[] {
                s
            });
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return null;
        }
        return obj;
    }

    boolean warnIfOpen(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        try
        {
            warnIfOpenMethod.invoke(obj, new Object[0]);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            return false;
        }
        return true;
    }

    (Method method, Method method1, Method method2)
    {
        getMethod = method;
        openMethod = method1;
        warnIfOpenMethod = method2;
    }
}
