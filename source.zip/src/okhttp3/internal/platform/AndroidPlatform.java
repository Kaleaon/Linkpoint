// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.internal.Util;
import okhttp3.internal.tls.CertificateChainCleaner;

// Referenced classes of package okhttp3.internal.platform:
//            Platform, OptionalMethod

class AndroidPlatform extends Platform
{
    static final class AndroidCertificateChainCleaner extends CertificateChainCleaner
    {

        private final Method checkServerTrusted;
        private final Object x509TrustManagerExtensions;

        public List clean(List list, String s)
            throws SSLPeerUnverifiedException
        {
            try
            {
                list = (X509Certificate[])list.toArray(new X509Certificate[list.size()]);
                list = (List)checkServerTrusted.invoke(x509TrustManagerExtensions, new Object[] {
                    list, "RSA", s
                });
            }
            // Misplaced declaration of an exception variable
            catch (List list)
            {
                s = new SSLPeerUnverifiedException(list.getMessage());
                s.initCause(list);
                throw s;
            }
            // Misplaced declaration of an exception variable
            catch (List list)
            {
                throw new AssertionError(list);
            }
            return list;
        }

        public boolean equals(Object obj)
        {
            return obj instanceof AndroidCertificateChainCleaner;
        }

        public int hashCode()
        {
            return 0;
        }

        AndroidCertificateChainCleaner(Object obj, Method method)
        {
            x509TrustManagerExtensions = obj;
            checkServerTrusted = method;
        }
    }

    static final class CloseGuard
    {

        private final Method getMethod;
        private final Method openMethod;
        private final Method warnIfOpenMethod;

        static CloseGuard get()
        {
            Method method = null;
            Method method1;
            Method method2;
            Object obj;
            obj = Class.forName("dalvik.system.CloseGuard");
            method2 = ((Class) (obj)).getMethod("get", new Class[0]);
            method1 = ((Class) (obj)).getMethod("open", new Class[] {
                java/lang/String
            });
            obj = ((Class) (obj)).getMethod("warnIfOpen", new Class[0]);
            method = ((Method) (obj));
_L2:
            return new CloseGuard(method2, method1, method);
            Exception exception;
            exception;
            exception = null;
            method2 = null;
            if (true) goto _L2; else goto _L1
_L1:
        }

        Object createAndOpen(String s)
        {
            if (getMethod == null)
            {
                return null;
            }
            Object obj;
            try
            {
                obj = getMethod.invoke(null, new Object[0]);
                openMethod.invoke(obj, new Object[] {
                    s
                });
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                return null;
            }
            return obj;
        }

        boolean warnIfOpen(Object obj)
        {
            if (obj == null)
            {
                return false;
            }
            try
            {
                warnIfOpenMethod.invoke(obj, new Object[0]);
            }
            // Misplaced declaration of an exception 