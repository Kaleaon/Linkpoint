// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.List;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3.internal.platform:
//            JdkWithJettyBootPlatform

private static class protocols
    implements InvocationHandler
{

    private final List protocols;
    String selected;
    boolean unsupported;

    public Object invoke(Object obj, Method method, Object aobj[])
        throws Throwable
    {
        obj = method.getName();
        Class class1 = method.getReturnType();
        if (aobj == null)
        {
            aobj = Util.EMPTY_STRING_ARRAY;
        }
        if (!((String) (obj)).equals("supports") || Boolean.TYPE != class1)
        {
            if (!((String) (obj)).equals("unsupported") || Void.TYPE != class1)
            {
                if (!((String) (obj)).equals("protocols") || aobj.length != 0)
                {
                    int i;
                    int j;
                    if (!((String) (obj)).equals("selectProtocol") && !((String) (obj)).equals("select") || (java/lang/String != class1 || aobj.length != 1) || !(aobj[0] instanceof List))
                    {
                        if (!((String) (obj)).equals("protocolSelected") && !((String) (obj)).equals("selected") || aobj.length != 1)
                        {
                            return method.invoke(this, aobj);
                        } else
                        {
                            selected = (String)aobj[0];
                            return null;
                        }
                    }
                    obj = (List)aobj[0];
                    j = ((List) (obj)).size();
                    i = 0;
                } else
                {
                    return protocols;
                }
            } else
            {
                unsupported = true;
                return null;
            }
        } else
        {
            return Boolean.valueOf(true);
        }
        do
        {
            if (i >= j)
            {
                obj = (String)protocols.get(0);
                selected = ((String) (obj));
                return obj;
            }
            if (!protocols.contains(((List) (obj)).get(i)))
            {
                i++;
            } else
            {
                obj = (String)((List) (obj)).get(i);
                selected = ((String) (obj));
                return obj;
            }
        } while (true);
    }

    public (List list)
    {
        protocols = list;
    }
}
