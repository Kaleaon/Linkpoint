// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class OptionalMethod
{

    private final String methodName;
    private final Class methodParams[];
    private final Class returnType;

    public transient OptionalMethod(Class class1, String s, Class aclass[])
    {
        returnType = class1;
        methodName = s;
        methodParams = aclass;
    }

    private Method getMethod(Class class1)
    {
        if (methodName != null)
        {
            for (class1 = getPublicMethod(class1, methodName, methodParams); class1 == null || returnType == null;)
            {
                return class1;
            }

            if (returnType.isAssignableFrom(class1.getReturnType()))
            {
                return class1;
            }
        }
        return null;
    }

    private static Method getPublicMethod(Class class1, String s, Class aclass[])
    {
        int i;
        try
        {
            class1 = class1.getMethod(s, aclass);
        }
        // Misplaced declaration of an exception variable
        catch (Class class1)
        {
            return null;
        }
        try
        {
            i = class1.getModifiers();
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            return class1;
        }
        if ((i & 1) != 0)
        {
            return class1;
        } else
        {
            return null;
        }
    }

    public transient Object invoke(Object obj, Object aobj[])
        throws InvocationTargetException
    {
        Method method = getMethod(obj.getClass());
        if (method != null)
        {
            try
            {
                obj = method.invoke(obj, aobj);
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                aobj = new AssertionError((new StringBuilder()).append("Unexpectedly could not call: ").append(method).toString());
                ((AssertionError) (aobj)).initCause(((Throwable) (obj)));
                throw aobj;
            }
            return obj;
        } else
        {
            throw new AssertionError((new StringBuilder()).append("Method ").append(methodName).append(" not supported for object ").append(obj).toString());
        }
    }

    public transient Object invokeOptional(Object obj, Object aobj[])
        throws InvocationTargetException
    {
        Method method = getMethod(obj.getClass());
        if (method != null)
        {
            try
            {
                obj = method.invoke(obj, aobj);
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                return null;
            }
            return obj;
        } else
        {
            return null;
        }
    }

    public transient Object invokeOptionalWithoutCheckedException(Object obj, Object aobj[])
    {
        try
        {
            obj = invokeOptional(obj, aobj);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            obj = ((InvocationTargetException) (obj)).getTargetException();
            if (!(obj instanceof RuntimeException))
            {
                aobj = new AssertionError("Unexpected exception");
                ((AssertionError) (aobj)).initCause(((Throwable) (obj)));
                throw aobj;
            } else
            {
                throw (RuntimeException)obj;
            }
        }
        return obj;
    }

    public transient Object invokeWithoutCheckedException(Object obj, Object aobj[])
    {
        try
        {
            obj = invoke(obj, aobj);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            obj = ((InvocationTargetException) (obj)).getTargetException();
            if (!(obj instanceof RuntimeException))
            {
                aobj = new AssertionError("Unexpected exception");
                ((AssertionError) (aobj)).initCause(((Throwable) (obj)));
                throw aobj;
            } else
            {
                throw (RuntimeException)obj;
            }
        }
        return obj;
    }

    public boolean isSupported(Object obj)
    {
        return getMethod(obj.getClass()) != null;
    }
}
