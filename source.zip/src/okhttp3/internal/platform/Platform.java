// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3.internal.platform;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.internal.tls.BasicCertificateChainCleaner;
import okhttp3.internal.tls.CertificateChainCleaner;
import okhttp3.internal.tls.TrustRootIndex;
import okio.Buffer;

// Referenced classes of package okhttp3.internal.platform:
//            AndroidPlatform, Jdk9Platform, JdkWithJettyBootPlatform

public class Platform
{

    public static final int INFO = 4;
    private static final Platform PLATFORM = findPlatform();
    public static final int WARN = 5;
    private static final Logger logger = Logger.getLogger(okhttp3/OkHttpClient.getName());

    public Platform()
    {
    }

    public static List alpnProtocolNames(List list)
    {
        ArrayList arraylist = new ArrayList(list.size());
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return arraylist;
            }
            Protocol protocol = (Protocol)list.get(i);
            if (protocol != Protocol.HTTP_1_0)
            {
                arraylist.add(protocol.toString());
            }
            i++;
        } while (true);
    }

    static byte[] concatLengthPrefixed(List list)
    {
        Buffer buffer = new Buffer();
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return buffer.readByteArray();
            }
            Protocol protocol = (Protocol)list.get(i);
            if (protocol != Protocol.HTTP_1_0)
            {
                buffer.writeByte(protocol.toString().length());
                buffer.writeUtf8(protocol.toString());
            }
            i++;
        } while (true);
    }

    private static Platform findPlatform()
    {
        Object obj = AndroidPlatform.buildIfSupported();
        if (obj == null)
        {
            obj = Jdk9Platform.buildIfSupported();
            if (obj == null)
            {
                obj = JdkWithJettyBootPlatform.buildIfSupported();
                if (obj == null)
                {
                    return new Platform();
                } else
                {
                    return ((Platform) (obj));
                }
            } else
            {
                return ((Platform) (obj));
            }
        } else
        {
            return ((Platform) (obj));
        }
    }

    public static Platform get()
    {
        return PLATFORM;
    }

    static Object readFieldOrNull(Object obj, Class class1, String s)
    {
        Class class2 = obj.getClass();
_L2:
        if (class2 == java/lang/Object)
        {
            Object obj1;
            NoSuchFieldException nosuchfieldexception;
            if (!s.equals("delegate"))
            {
                if ((obj = readFieldOrNull(obj, java/lang/Object, "delegate")) != null)
                {
                    return readFieldOrNull(obj, class1, s);
                }
            }
            return null;
        }
        try
        {
            obj1 = class2.getDeclaredField(s);
            ((Field) (obj1)).setAccessible(true);
            obj1 = ((Field) (obj1)).get(obj);
        }
        // Misplaced declaration of an exception variable
        catch (NoSuchFieldException nosuchfieldexception)
        {
            class2 = class2.getSuperclass();
            continue; /* Loop/switch isn't completed */
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            throw new AssertionError();
        }
        if (obj1 == null)
        {
            return null;
        }
        if (!class1.isInstance(obj1))
        {
            break MISSING_BLOCK_LABEL_109;
        }
        obj1 = class1.cast(obj1);
        return obj1;
        return null;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void afterHandshake(SSLSocket sslsocket)
    {
    }

    public CertificateChainCleaner buildCertificateChainCleaner(X509TrustManager x509trustmanager)
    {
        return new BasicCertificateChainCleaner(TrustRootIndex.get(x509trustmanager));
    }

    public void configureTlsExtensions(SSLSocket sslsocket, String s, List list)
    {
    }

    public void connectSocket(Socket socket, InetSocketAddress inetsocketaddress, int i)
        throws IOException
    {
        socket.connect(inetsocketaddress, i);
    }

    public String getPrefix()
    {
        return "OkHttp";
    }

    public String getSelectedProtocol(SSLSocket sslsocket)
    {
        return null;
    }

    public Object getStackTraceForCloseable(String s)
    {
        if (!logger.isLoggable(Level.FINE))
        {
            return null;
        } else
        {
            return new Throwable(s);
        }
    }

    public boolean isCleartextTrafficPermitted(String s)
    {
        return true;
    }

    public void log(int i, String s, Throwable throwable)
    {
        Level level;
        if (i != 5)
        {
            level = Level.INFO;
        } else
        {
            level = Level.WARNING;
        }
        logger.log(level, s, throwable);
    }

    public void logCloseableLeak(String s, Object obj)
    {
        if (obj == null)
        {
            s = (new StringBuilder()).append(s).append(" To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);").toString();
        }
        log(5, s, (Throwable)obj);
    }

    public X509TrustManager trustManager(SSLSocketFactory sslsocketfactory)
    {
        try
        {
            sslsocketfactory = ((SSLSocketFactory) (readFieldOrNull(sslsocketfactory, Class.forName("sun.security.ssl.SSLContextImpl"), "context")));
        }
        // Misplaced declaration of an exception variable
        catch (SSLSocketFactory sslsocketfactory)
        {
            return null;
        }
        if (sslsocketfactory == null)
        {
            break MISSING_BLOCK_LABEL_30;
        }
        sslsocketfactory = (X509TrustManager)readFieldOrNull(sslsocketfactory, javax/net/ssl/X509TrustManager, "trustManager");
        return sslsocketfactory;
        return null;
    }

}
