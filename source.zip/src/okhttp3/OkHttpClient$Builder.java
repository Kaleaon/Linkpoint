// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.Proxy;
import java.net.ProxySelector;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.internal.Util;
import okhttp3.internal.cache.InternalCache;
import okhttp3.internal.platform.Platform;
import okhttp3.internal.tls.CertificateChainCleaner;
import okhttp3.internal.tls.OkHostnameVerifier;

// Referenced classes of package okhttp3:
//            OkHttpClient, Dispatcher, CookieJar, CertificatePinner, 
//            Authenticator, ConnectionPool, Dns, Protocol, 
//            Cache, Interceptor

public static final class rval
{

    Authenticator authenticator;
    Cache cache;
    CertificateChainCleaner certificateChainCleaner;
    CertificatePinner certificatePinner;
    int connectTimeout;
    ConnectionPool connectionPool;
    List connectionSpecs;
    CookieJar cookieJar;
    Dispatcher dispatcher;
    Dns dns;
    boolean followRedirects;
    boolean followSslRedirects;
    HostnameVerifier hostnameVerifier;
    final List interceptors;
    InternalCache internalCache;
    final List networkInterceptors;
    int pingInterval;
    List protocols;
    Proxy proxy;
    Authenticator proxyAuthenticator;
    ProxySelector proxySelector;
    int readTimeout;
    boolean retryOnConnectionFailure;
    SocketFactory socketFactory;
    SSLSocketFactory sslSocketFactory;
    int writeTimeout;

    private static int checkDuration(String s, long l, TimeUnit timeunit)
    {
        boolean flag3 = true;
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append(s).append(" < 0").toString());
        }
        long l1;
        if (timeunit != null)
        {
            l1 = timeunit.toMillis(l);
            boolean flag1;
            if (l1 <= 0x7fffffffL)
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (!flag1)
            {
                throw new IllegalArgumentException((new StringBuilder()).append(s).append(" too large.").toString());
            }
        } else
        {
            throw new NullPointerException("unit == null");
        }
        if (l1 == 0L)
        {
            boolean flag2;
            if (l <= 0L)
            {
                flag2 = flag3;
            } else
            {
                flag2 = false;
            }
            if (!flag2)
            {
                throw new IllegalArgumentException((new StringBuilder()).append(s).append(" too small.").toString());
            }
        }
        return (int)l1;
    }

    public ing addInterceptor(Interceptor interceptor)
    {
        interceptors.add(interceptor);
        return this;
    }

    public interceptors addNetworkInterceptor(Interceptor interceptor)
    {
        networkInterceptors.add(interceptor);
        return this;
    }

    public tworkInterceptors authenticator(Authenticator authenticator1)
    {
        if (authenticator1 != null)
        {
            authenticator = authenticator1;
            return this;
        } else
        {
            throw new NullPointerException("authenticator == null");
        }
    }

    public OkHttpClient build()
    {
        return new OkHttpClient(this);
    }

    public n cache(Cache cache1)
    {
        cache = cache1;
        internalCache = null;
        return this;
    }

    public internalCache certificatePinner(CertificatePinner certificatepinner)
    {
        if (certificatepinner != null)
        {
            certificatePinner = certificatepinner;
            return this;
        } else
        {
            throw new NullPointerException("certificatePinner == null");
        }
    }

    public  connectTimeout(long l, TimeUnit timeunit)
    {
        connectTimeout = checkDuration("timeout", l, timeunit);
        return this;
    }

    public  connectionPool(ConnectionPool connectionpool)
    {
        if (connectionpool != null)
        {
            connectionPool = connectionpool;
            return this;
        } else
        {
            throw new NullPointerException("connectionPool == null");
        }
    }

    public n connectionSpecs(List list)
    {
        connectionSpecs = Util.immutableList(list);
        return this;
    }

    public leList cookieJar(CookieJar cookiejar)
    {
        if (cookiejar != null)
        {
            cookieJar = cookiejar;
            return this;
        } else
        {
            throw new NullPointerException("cookieJar == null");
        }
    }

    public n dispatcher(Dispatcher dispatcher1)
    {
        if (dispatcher1 != null)
        {
            dispatcher = dispatcher1;
            return this;
        } else
        {
            throw new IllegalArgumentException("dispatcher == null");
        }
    }

    public ption dns(Dns dns1)
    {
        if (dns1 != null)
        {
            dns = dns1;
            return this;
        } else
        {
            throw new NullPointerException("dns == null");
        }
    }

    public n followRedirects(boolean flag)
    {
        followRedirects = flag;
        return this;
    }

    public followRedirects followSslRedirects(boolean flag)
    {
        followSslRedirects = flag;
        return this;
    }

    public r hostnameVerifier(HostnameVerifier hostnameverifier)
    {
        if (hostnameverifier != null)
        {
            hostnameVerifier = hostnameverifier;
            return this;
        } else
        {
            throw new NullPointerException("hostnameVerifier == null");
        }
    }

    public List interceptors()
    {
        return interceptors;
    }

    public List networkInterceptors()
    {
        return networkInterceptors;
    }

    public  pingInterval(long l, TimeUnit timeunit)
    {
        pingInterval = checkDuration("interval", l, timeunit);
        return this;
    }

    public  protocols(List list)
    {
        list = new ArrayList(list);
        if (list.contains(Protocol.HTTP_1_1))
        {
            if (!list.contains(Protocol.HTTP_1_0))
            {
                if (!list.contains(null))
                {
                    if (list.contains(Protocol.SPDY_3))
                    {
                        list.remove(Protocol.SPDY_3);
                    }
                    protocols = Collections.unmodifiableList(list);
                    return this;
                } else
                {
                    throw new IllegalArgumentException("protocols must not contain null");
                }
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("protocols must not contain http/1.0: ").append(list).toString());
            }
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("protocols doesn't contain http/1.1: ").append(list).toString());
        }
    }

    public ing proxy(Proxy proxy1)
    {
        proxy = proxy1;
        return this;
    }

    public proxy proxyAuthenticator(Authenticator authenticator1)
    {
        if (authenticator1 != null)
        {
            proxyAuthenticator = authenticator1;
            return this;
        } else
        {
            throw new NullPointerException("proxyAuthenticator == null");
        }
    }

    public n proxySelector(ProxySelector proxyselector)
    {
        proxySelector = proxyselector;
        return this;
    }

    public  readTimeout(long l, TimeUnit timeunit)
    {
        readTimeout = checkDuration("timeout", l, timeunit);
        return this;
    }

    public  retryOnConnectionFailure(boolean flag)
    {
        retryOnConnectionFailure = flag;
        return this;
    }

    void setInternalCache(InternalCache internalcache)
    {
        internalCache = internalcache;
        cache = null;
    }

    public cache socketFactory(SocketFactory socketfactory)
    {
        if (socketfactory != null)
        {
            socketFactory = socketfactory;
            return this;
        } else
        {
            throw new NullPointerException("socketFactory == null");
        }
    }

    public y sslSocketFactory(SSLSocketFactory sslsocketfactory)
    {
        if (sslsocketfactory != null)
        {
            X509TrustManager x509trustmanager = Platform.get().trustManager(sslsocketfactory);
            if (x509trustmanager != null)
            {
                sslSocketFactory = sslsocketfactory;
                certificateChainCleaner = CertificateChainCleaner.get(x509trustmanager);
                return this;
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("Unable to extract the trust manager on ").append(Platform.get()).append(", sslSocketFactory is ").append(sslsocketfactory.getClass()).toString());
            }
        } else
        {
            throw new NullPointerException("sslSocketFactory == null");
        }
    }

    public r sslSocketFactory(SSLSocketFactory sslsocketfactory, X509TrustManager x509trustmanager)
    {
        if (sslsocketfactory != null)
        {
            if (x509trustmanager != null)
            {
                sslSocketFactory = sslsocketfactory;
                certificateChainCleaner = CertificateChainCleaner.get(x509trustmanager);
                return this;
            } else
            {
                throw new NullPointerException("trustManager == null");
            }
        } else
        {
            throw new NullPointerException("sslSocketFactory == null");
        }
    }

    public  writeTimeout(long l, TimeUnit timeunit)
    {
        writeTimeout = checkDuration("timeout", l, timeunit);
        return this;
    }

    public ()
    {
        interceptors = new ArrayList();
        networkInterceptors = new ArrayList();
        dispatcher = new Dispatcher();
        protocols = OkHttpClient.DEFAULT_PROTOCOLS;
        connectionSpecs = OkHttpClient.DEFAULT_CONNECTION_SPECS;
        proxySelector = ProxySelector.getDefault();
        cookieJar = CookieJar.NO_COOKIES;
        socketFactory = SocketFactory.getDefault();
        hostnameVerifier = OkHostnameVerifier.INSTANCE;
        certificatePinner = CertificatePinner.DEFAULT;
        proxyAuthenticator = Authenticator.NONE;
        authenticator = Authenticator.NONE;
        connectionPool = new ConnectionPool();
        dns = Dns.SYSTEM;
        followSslRedirects = true;
        followRedirects = true;
        retryOnConnectionFailure = true;
        connectTimeout = 10000;
        readTimeout = 10000;
        writeTimeout = 10000;
        pingInterval = 0;
    }

    pingInterval(OkHttpClient okhttpclient)
    {
        interceptors = new ArrayList();
        networkInterceptors = new ArrayList();
        dispatcher = okhttpclient.dispatcher;
        proxy = okhttpclient.proxy;
        protocols = okhttpclient.protocols;
        connectionSpecs = okhttpclient.connectionSpecs;
        interceptors.addAll(okhttpclient.interceptors);
        networkInterceptors.addAll(okhttpclient.networkInterceptors);
        proxySelector = okhttpclient.proxySelector;
        cookieJar = okhttpclient.cookieJar;
        internalCache = okhttpclient.internalCache;
        cache = okhttpclient.cache;
        socketFactory = okhttpclient.socketFactory;
        sslSocketFactory = okhttpclient.sslSocketFactory;
        certificateChainCleaner = okhttpclient.certificateChainCleaner;
        hostnameVerifier = okhttpclient.hostnameVerifier;
        certificatePinner = okhttpclient.certificatePinner;
        proxyAuthenticator = okhttpclient.proxyAuthenticator;
        authenticator = okhttpclient.authenticator;
        connectionPool = okhttpclient.connectionPool;
        dns = okhttpclient.dns;
        followSslRedirects = okhttpclient.followSslRedirects;
        followRedirects = okhttpclient.followRedirects;
        retryOnConnectionFailure = okhttpclient.retryOnConnectionFailure;
        connectTimeout = okhttpclient.connectTimeout;
        readTimeout = okhttpclient.readTimeout;
        writeTimeout = okhttpclient.writeTimeout;
        pingInterval = okhttpclient.pingInterval;
    }
}
