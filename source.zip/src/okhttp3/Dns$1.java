// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;

// Referenced classes of package okhttp3:
//            Dns

static class wnHostException
    implements Dns
{

    public List lookup(String s)
        throws UnknownHostException
    {
        if (s != null)
        {
            return Arrays.asList(InetAddress.getAllByName(s));
        } else
        {
            throw new UnknownHostException("hostname == null");
        }
    }

    Exception()
    {
    }
}
