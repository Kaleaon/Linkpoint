// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;

// Referenced classes of package okhttp3:
//            Interceptor, Connection, Request, Response

public static interface 
{

    public abstract Connection connection();

    public abstract Response proceed(Request request1)
        throws IOException;

    public abstract Request request();
}
