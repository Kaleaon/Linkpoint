// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            Authenticator, Route, Response, Request

static class 
    implements Authenticator
{

    public Request authenticate(Route route, Response response)
    {
        return null;
    }

    ()
    {
    }
}
