// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;


// Referenced classes of package okhttp3:
//            MultipartBody, Headers, RequestBody

public static final class body
{

    final RequestBody body;
    final Headers headers;

    public static body create(Headers headers1, RequestBody requestbody)
    {
        if (requestbody != null)
        {
            if (headers1 == null || headers1.get("Content-Type") == null)
            {
                if (headers1 == null || headers1.get("Content-Length") == null)
                {
                    return new <init>(headers1, requestbody);
                } else
                {
                    throw new IllegalArgumentException("Unexpected header: Content-Length");
                }
            } else
            {
                throw new IllegalArgumentException("Unexpected header: Content-Type");
            }
        } else
        {
            throw new NullPointerException("body == null");
        }
    }

    public static ion create(RequestBody requestbody)
    {
        return create(null, requestbody);
    }

    public static create createFormData(String s, String s1)
    {
        return createFormData(s, null, RequestBody.create(null, s1));
    }

    public static createFormData createFormData(String s, String s1, RequestBody requestbody)
    {
        if (s != null)
        {
            StringBuilder stringbuilder = new StringBuilder("form-data; name=");
            MultipartBody.appendQuotedString(stringbuilder, s);
            if (s1 != null)
            {
                stringbuilder.append("; filename=");
                MultipartBody.appendQuotedString(stringbuilder, s1);
            }
            return create(Headers.of(new String[] {
                "Content-Disposition", stringbuilder.toString()
            }), requestbody);
        } else
        {
            throw new NullPointerException("name == null");
        }
    }

    public RequestBody body()
    {
        return body;
    }

    public Headers headers()
    {
        return headers;
    }

    private ception(Headers headers1, RequestBody requestbody)
    {
        headers = headers1;
        body = requestbody;
    }
}
