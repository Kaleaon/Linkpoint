// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import okhttp3.internal.Util;
import okio.Buffer;

public final class HttpUrl
{
    public static final class Builder
    {

        String encodedFragment;
        String encodedPassword;
        final List encodedPathSegments = new ArrayList();
        List encodedQueryNamesAndValues;
        String encodedUsername;
        String host;
        int port;
        String scheme;

        private Builder addPathSegments(String s, boolean flag)
        {
            int i = 0;
            do
            {
                int j = Util.delimiterOffset(s, i, s.length(), "/\\");
                boolean flag1;
                if (j >= s.length())
                {
                    flag1 = false;
                } else
                {
                    flag1 = true;
                }
                push(s, i, j, flag1, flag);
                j++;
                i = j;
            } while (j <= s.length());
            return this;
        }

        private static String canonicalizeHost(String s, int i, int j)
        {
            s = HttpUrl.percentDecode(s, i, j, false);
            if (!s.contains(":"))
            {
                return Util.domainToAscii(s);
            }
            break MISSING_BLOCK_LABEL_22;
            if (!s.startsWith("[") || !s.endsWith("]"))
            {
                s = decodeIpv6(s, 0, s.length());
            } else
            {
                s = decodeIpv6(s, 1, s.length() - 1);
            }
            if (s != null)
            {
                s = s.getAddress();
                if (s.length != 16)
                {
                    throw new AssertionError();
                } else
                {
                    return inet6AddressToAscii(s);
                }
            } else
            {
                return null;
            }
        }

        private static boolean decodeIpv4Suffix(String s, int i, int j, byte abyte0[], int k)
        {
            int i1 = k;
_L5:
            int l;
            int j1;
            char c;
            if (i >= j)
            {
                return i1 == k + 4;
            }
            if (i1 == abyte0.length) goto _L2; else goto _L1
_L1:
            if (i1 != k)
            {
                if (s.charAt(i) == '.')
                {
                    i++;
                } else
                {
                    return false;
                }
            }
            j1 = 0;
            l = i;
_L7:
            if (l < j) goto _L4; else goto _L3
_L3:
            if (l - i != 0)
            {
                abyte0[i1] = (byte)j1;
                i1++;
                i = l;
            } else
            {
                return false;
            }
              goto _L5
_L2:
            return false;
_L4:
            if ((c = s.charAt(l)) < '0' || c > '9') goto _L3; else goto _L6
_L6:
            if (j1 != 0 || i == l)
            {
                j1 = (j1 * 10 + c) - 48;
                if (j1 <= 255)
                {
                    l++;
                } else
                {
                    return false;
                }
            } else
            {
                return false;
            }
              goto _L7
        }

        private static InetAddress decodeIpv6(String s, int i, int j)
        {
            byte abyte0[];
            int k;
            int l;
            int i1;
            abyte0 = new byte[16];
            i1 = -1;
            l = -1;
            k = 0;
_L10:
            if (i < j) goto _L2; else goto _L1
_L1:
            int j1;
            int k1;
            int l1;
            if (k != abyte0.length)
            {
label0:
                {
                    if (l == -1)
                    {
                        break label0;
                    }
                    System.arraycopy(abyte0, l, abyte0, abyte0.length - (k - l), k - l);
                    Arrays.fill(abyte0, l, (abyte0.length - k) + l, (byte)0);
                }
            }
            try
            {
                s = InetAddress.getByAddress(abyte0);
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                throw new AssertionError();
            }
            return s;
_L2:
            if (k == abyte0.length) goto _L4; else goto _L3
_L3:
            if (i + 2 > j || !s.regionMatches(i, "::", 0, 2))
            {
                if (k == 0)
                {
                    i1 = k;
                } else
                {
label1:
                    {
                        if (!s.regionMatches(i, ":", 0, 1))
                        {
                            if (!s.regionMatches(i, ".", 0, 1))
                            {
                                return null;
                            }
                            break label1;
                        }
                        i++;
                        i1 = k;
                    }
                }
            } else
            if (l == -1)
            {
                i += 2;
                k += 2;
                if (i == j)
                {
                    break MISSING_BLOCK_LABEL_129;
                }
                i1 = k;
                l = k;
            } else
            {
                return null;
            }
            j1 = 0;
            k = i;
_L8:
            if (k < j) goto _L6; else goto _L5
_L4:
            return null;
            i = k;
            l = k;
            k = i;
              goto _L1
            if (decodeIpv4Suffix(s, i1, j, abyte0, k - 2))
            {
                k += 2;
            } else
            {
                return null;
            }
              goto _L1
_L6:
            if ((k1 = HttpUrl.decodeHexDigit(s.charAt(k))) == -1) goto _L5; else goto _L7
_L7:
            j1 = (j1 << 4) + k1;
            k++;
              goto _L8
_L5:
            k1 = k - i;
            if (k1 == 0 || k1 > 4)
            {
                return null;
            }
            l1 = i1 + 1;
            abyte0[i1] = (byte)(j1 >>> 8 & 0xff);
            k1 = l1 + 1;
            abyte0[l1] = (byte)(j1 & 0xff);
            i1 = i;
            i = k;
            k = k1;
            continue; /* Loop/switch isn't completed */
            return null;
            if (true) goto _L10; else goto _L9
_L9:
        }

        private static String inet6AddressToAscii(byte abyte0[])
        {
            int i;
            int j;
            int k;
            boolean flag;
            flag = false;
            j = 0;
            k = -1;
            i = 0;
_L3:
            if (i < abyte0.length) goto _L2; else goto _L1
_L1:
            Buffer buffer;
            buffer = new Buffer();
            i = ((flag) ? 1 : 0);
_L4:
            if (i >= abyte0.length)
            {
                return buffer.readUtf8();
            }
            break MISSING_BLOCK_LABEL_102;
_L2:
            int l = i;
            int j1;
            while (l < 16 && abyte0[l] == 0 && abyte0[l + 1] == 0) 
            {
                l += 2;
            }
            j1 = l - i;
            if (j1 > j)
            {
                j = j1;
                k = i;
            }
            i = l + 2;
              goto _L3
            if (i != k)
            {
                int i1;
                if (i > 0)
                {
                    buffer.writeByte(58);
                }
                buffer.writeHexadecimalUnsignedLong((abyte0[i] & 0xff) << 8 | abyte0[i + 1] & 0xff);
                i += 2;
            } else
            {
                buffer.writeByte(58);
                i1 = i + j;
                i = i1;
                if (i1 == 16)
                {
                    buffer.writeByte(58);
                    i = i1;
                }
            }
              goto _L4
        }

        private boolean isDot(String s)
        {
            while (s.equals(".") || s.equalsIgnoreCase("%2e")) 
            {
                return true;
            }
            return false;
        }

        private boolean isDotDot(String s)
        {
            while (s.equals("..") || s.equalsIgnoreCase("%2e.") || s.equalsIgnoreCase(".%2e") || s.equalsIgnoreCase("%2e%2e")) 
            {
                return true;
            }
            return false;
        }

        private static int parsePort(String s, int i, int j)
        {
            try
            {
                i = Integer.parseInt(HttpUrl.canonicalize(s, i, j, "", false, false, false, true));
            }
            // Misplaced declaration of an exception variable
            catch (String s)
            {
                return -1;
            }
            while (i <= 0 || i > 65535) 
            {
                return -1;
            }
            return i;
        }

        private void pop()
        {
            while (!((String)encodedPathSegments.remove(encodedPathSegments.size() - 1)).isEmpty() || encodedPathSegments.isEmpty()) 
            {
                encodedPathSegments.add("");
                return;
            }
            encodedPathSegments.set(encodedPathSegments.size() - 1, "");
        }

        private static int portColonOffset(String s, int i, int j)
        {
_L4:
            int k;
            if (i >= j)
            {
                return j;
            }
            k = i;
            s.charAt(i);
            JVM INSTR lookupswitch 2: default 40
        //                       58: 73
        //                       91: 59;
               goto _L1 _L2 _L3
_L1:
            i++;
              goto _L4
_L6:
            i = k;
            if (s.charAt(k) == ']') goto _L1; else goto _L3
_L3:
            k++;
            if (k < j) goto _L6; else goto _L5
_L5:
            i = k;
              goto _L1
_L2:
            return i;
        }

        private void push(String s, int i, int j, boolean flag, boolean flag1)
        {
            s = HttpUrl.canonicalize(s, i, j, " \"<>^`{}|/\\?#", flag1, false, false, true);
            if (!isDot(s))
            {
                if (!isDotDot(s))
                {
                    if (!((String)encodedPathSegments.get(encodedPathSegments.size() - 1)).isEmpty())
                    {
                        encodedPathSegments.add(s);
                    } else
                    {
                        encodedPathSegments.set(encodedPathSegments.size() - 1, s);
                    }
                    if (!flag)
                    {
                        return;
                    } else
                    {
                        encodedPathSegments.add("");
                        return;
                    }
                } else
                {
                    pop();
                    return;
                }
            } else
            {
                return;
            }
        }

        private void removeAllCanonicalQueryParameters(String s)
        {
            int i = encodedQueryNamesAndValues.size();
            do
            {
                int j;
                do
                {
                    j = i - 2;
                    if (j < 0)
                    {
                        return;
                    }
                    i = j;
                } while (!s.equals(encodedQueryNamesAndValues.get(j)));
                encodedQueryNamesAndValues.remove(j + 1);
                encodedQueryNamesAndValues.remove(j);
                i = j;
            } while (!encodedQueryNamesAndValues.isEmpty());
            encodedQueryNamesAndValues = null;
        }

        private void resolvePath(String s, int i, int j)
        {
            if (i != j)
            {
                char c = s.charAt(i);
                if (c == '/' || c == '\\')
                {
                    encodedPathSegments.clear();
                    encodedPathSegments.add("");
                    i++;
                } else
                {
                    encodedPathSegments.set(encodedPathSegments.size() - 1, "");
                }
                break MISSING_BLOCK_LABEL_44;
            } else
            {
                return;
            }
            do
            {
                if (i >= j)
                {
                    return;
                }
                int k = Util.delimiterOffset(s, i, j, "/\\");
                boolean flag;
                if (k >= j)
                {
                    flag = false;
                } else
                {
                    flag = true;
                }
                push(s, i, k, flag, true);
                if (!flag)
                {
                    i = k;
                } else
                {
                    i = k + 1;
                }
            } while (true);
        }

        private static int schemeDelimiterOffset(String s, int i, int j)
        {
            return -1;
            i++;
_L2:
            if (i >= j)
            {
                return -1;
            }
            break MISSING_BLOCK_LABEL_55;
            {
                char c;
label0:
                {
                    if (j - i < 2)
                    {
                        break label0;
                    }
                    c = s.charAt(i);
                }
                if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z'))
                {
                    return -1;
                }
                break MISSING_BLOCK_LABEL_35;
            }
            char c1 = s.charAt(i);
            if (c1 >= 'a' && c1 <= 'z' || c1 >= 'A' && c1 <= 'Z' || c1 >= '0' && c1 <= '9' || (c1 == '+' || c1 == '-') || c1 == '.')
            {
                i++;
            } else
            if (c1 != ':')
            {
                return -1;
            } else
            {
                return i;
            }
            if (true) goto _L2; else goto _L1
_L1:
        }

        private static int slashCount(String s, int i, int j)
        {
            int k = 0;
_L2:
            char c;
            if (i >= j)
            {
                return k;
            }
            c = s.charAt(i);
              goto _L1
_L4:
            k++;
            i++;
            if (true) goto _L2; else goto _L1
_L1:
            if (c == '\\' || c == '/') goto _L4; else goto _L3
_L3:
            return k;
        }

        public Builder addEncodedPathSegment(String s)
        {
            if (s != null)
            {
                push(s, 0, s.length(), false, true);
                return this;
            } else
            {
                throw new NullPointerException("encodedPathSegment == null");
            }
        }

        public Builder addEncodedPathSegments(String s)
        {
            if (s != null)
            {
                return addPathSegments(s, true);
            } else
            {
                throw new NullPointerException("encodedPathSegments == null");
            }
        }

        public Builder addEncodedQueryParameter(String s, String s1)
        {
            if (s != null)
            {
                List list;
                if (encodedQueryNamesAndValues == null)
                {
                    encodedQueryNamesAndValues = new ArrayList();
                }
                encodedQueryNamesAndValues.add(HttpUrl.canonicalize(s, " \"'<>#&=", true, false, true, true));
                list = encodedQueryNamesAndValues;
                if (s1 == null)
                {
                    s = null;
                } else
                {
                    s = HttpUrl.canonicalize(s1, " \"'<>#&=", true, false, true, true);
                }
                list.add(s);
                return this;
            } else
            {
                throw new NullPointerException("encodedName == null");
            }
        }

        public Builder addPathSegment(String s)
        {
            if (s != null)
            {
                push(s, 0, s.length(), false, false);
                return this;
            } else
            {
                throw new NullPointerException("pathSegment == null");
            }
        }

        public Builder addPathSegments(String s)
        {
            if (s != null)
            {
                return addPathSegments(s, false);
            } else
            {
                throw new NullPointerException("pathSegments == null");
            }
        }

        public Builder addQueryParameter(String s, String s1)
        {
            if (s != null)
            {
                List list;
                if (encodedQueryNamesAndValues == null)
                {
                    encodedQueryNamesAndValues = new ArrayList();
                }
                encodedQueryNamesAndValues.add(HttpUrl.canonicalize(s, " \"'<>#&=", false, false, true, true));
                list = encodedQueryNamesAndValues;
                if (s1 == null)
                {
                    s = null;
                } else
                {
                    s = HttpUrl.canonicalize(s1, " \"'<>#&=", false, false, true, true);
                }
                list.add(s);
                return this;
            } else
            {
                throw new NullPointerException("name == null");
            }
        }

        public HttpUrl build()
        {
            if (scheme != null)
            {
                if (host != null)
                {
                    return new HttpUrl(this);
                } else
                {
                    throw new IllegalStateException("host == null");
                }
            } else
            {
                throw new IllegalStateException("scheme == null");
            }
        }

        int effectivePort()
        {
            if (port == -1)
            {
                return HttpUrl.defaultPort(scheme);
            } else
            {
                return port;
            }
        }

        public Builder encodedFragment(String s)
        {
            Object obj = null;
            if (s == null)
            {
                s = obj;
            } else
            {
                s = HttpUrl.canonicalize(s, "", true, false, false, false);
            }
            encodedFragment = s;
            return this;
        }

        public Builder encodedPassword(String s)
        {
            if (s != null)
            {
                encodedPassword = HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
                return this;
            } else
            {
                throw new NullPointerException("encodedPassword == null");
            }
        }

        public Builder encodedPath(String s)
        {
            if (s != null)
            {
                if (s.startsWith("/"))
                {
                    resolvePath(s, 0, s.length());
                    return this;
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("unexpected encodedPath: ").append(s).toString());
                }
            } else
            {
                throw new NullPointerException("encodedPath == null");
            }
        }

        public Builder encodedQuery(String s)
        {
            Object obj = null;
            if (s == null)
            {
                s = obj;
            } else
            {
                s = HttpUrl.queryStringToNamesAndValues(HttpUrl.canonicalize(s, " \"'<>#", true, false, true, true));
            }
            encodedQueryNamesAndValues = s;
            return this;
        }

        public Builder encodedUsername(String s)
        {
            if (s != null)
            {
                encodedUsername = HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
                return this;
            } else
            {
                throw new NullPointerException("encodedUsername == null");
            }
        }

        public Builder fragment(String s)
        {
            Object obj = null;
            if (s == null)
            {
                s = obj;
            } else
            {
                s = HttpUrl.canonicalize(s, "", false, false, false, false);
            }
            encodedFragment = s;
            return this;
        }

        public Builder host(String s)
        {
            if (s != null)
            {
                String s1 = canonicalizeHost(s, 0, s.length());
                if (s1 != null)
                {
                    host = s1;
                    return this;
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("unexpected host: ").append(s).toString());
                }
            } else
            {
                throw new NullPointerException("host == null");
            }
        }

        ParseResult parse(HttpUrl httpurl, String s)
        {
            int j;
            k = 0;
            j = 0;
            l = i + l;
            i = k;
            k = l;
_L4:
            k1 = Util.delimiterOffset(s, k, l1, "@/\\?#");
            int i1;
            if (k1 == l1)
            {
                i1 = -1;
            } else
            {
                i1 = s.charAt(k1);
            }
            i1;
            JVM INSTR lookupswitch 6: default 208
        //                       -1: 572
        //                       35: 572
        //                       47: 572
        //                       63: 572
        //                       64: 400
        //                       92: 572;
               goto _L1 _L2 _L2 _L2 _L2 _L3 _L2
_L1:
            i1 = i;
            i = k;
            k = i1;
_L5:
            i1 = k;
            k = i;
            i = i1;
              goto _L4
            i = Util.skipLeadingAsciiWhitespace(s, 0, s.length());
            l1 = Util.skipTrailingAsciiWhitespace(s, i, s.length());
            int k;
            int k1;
            if (schemeDelimiterOffset(s, i, l1) == -1)
            {
                int l;
                if (httpurl == null)
                {
                    return ParseResult.MISSING_SCHEME;
                }
                scheme = httpurl.scheme;
            } else
            if (!s.regionMatches(true, i, "https:", 0, 6))
            {
                if (!s.regionMatches(true, i, "http:", 0, 5))
                {
                    return ParseResult.UNSUPPORTED_SCHEME;
                }
                scheme = "http";
                i += "http:".length();
            } else
            {
                scheme = "https";
                i += "https:".length();
            }
            l = slashCount(s, i, l1);
            if (l < 2 && httpurl != null && httpurl.scheme.equals(scheme))
            {
                encodedUsername = httpurl.encodedUsername();
                encodedPassword = httpurl.encodedPassword();
                host = httpurl.host;
                port = httpurl.port;
                encodedPathSegments.clear();
                encodedPathSegments.addAll(httpurl.encodedPathSegments());
                int j1;
                if (i == l1 || s.charAt(i) == '#')
                {
                    encodedQuery(httpurl.encodedQuery());
                }
                break MISSING_BLOCK_LABEL_349;
            } else
            {
                break MISSING_BLOCK_LABEL_104;
            }
_L8:
            j = Util.delimiterOffset(s, i, l1, "?#");
            resolvePath(s, i, j);
            if (j >= l1 || s.charAt(j) != '?')
            {
                i = j;
            } else
            {
                i = Util.delimiterOffset(s, j, l1, '#');
                encodedQueryNamesAndValues = HttpUrl.queryStringToNamesAndValues(HttpUrl.canonicalize(s, j + 1, i, " \"'<>#", true, false, true, true));
            }
            if (i < l1 && s.charAt(i) == '#')
            {
                encodedFragment = HttpUrl.canonicalize(s, i + 1, l1, "", true, false, false, false);
            }
            return ParseResult.SUCCESS;
_L3:
            if (i != 0)
            {
                encodedPassword = (new StringBuilder()).append(encodedPassword).append("%40").append(HttpUrl.canonicalize(s, k, k1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true)).toString();
            } else
            {
                j1 = Util.delimiterOffset(s, k, k1, ':');
                httpurl = HttpUrl.canonicalize(s, k, j1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
                if (j != 0)
                {
                    httpurl = (new StringBuilder()).append(encodedUsername).append("%40").append(httpurl).toString();
                }
                encodedUsername = httpurl;
                if (j1 != k1)
                {
                    i = 1;
                    encodedPassword = HttpUrl.canonicalize(s, j1 + 1, k1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
                }
                j = 1;
            }
            j1 = k1 + 1;
            k = i;
            i = j1;
              goto _L5
_L2:
            i = portColonOffset(s, k, k1);
            if (i + 1 < k1) goto _L7; else goto _L6
_L6:
            host = canonicalizeHost(s, k, i);
            port = HttpUrl.defaultPort(scheme);
_L10:
            if (host != null)
            {
                i = k1;
            } else
            {
                return ParseResult.INVALID_HOST;
            }
              goto _L8
_L7:
            host = canonicalizeHost(s, k, i);
            port = parsePort(s, i + 1, k1);
            if (port != -1) goto _L10; else goto _L9
_L9:
            return ParseResult.INVALID_PORT;
              goto _L5
        }

        public Builder password(String s)
        {
            if (s != null)
            {
                encodedPassword = HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
                return this;
            } else
            {
                throw new NullPointerException("password == null");
            }
        }

        public Builder port(int i)
        {
            while (i <= 0 || i > 65535) 
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected port: ").append(i).toString());
            }
            port = i;
            return this;
        }

        public Builder query(String s)
        {
            Object obj = null;
            if (s == null)
            {
                s = obj;
            } else
            {
                s = HttpUrl.queryStringToNamesAndValues(HttpUrl.canonicalize(s, " \"'<>#", false, false, true, true));
            }
            encodedQueryNamesAndValues = s;
            return this;
        }

        Builder reencodeForUri()
        {
            int k = encodedPathSegments.size();
            int i = 0;
            do
            {
                if (i >= k)
                {
                    String s;
                    if (encodedQueryNamesAndValues != null)
                    {
                        int l = encodedQueryNamesAndValues.size();
                        int j = 0;
                        while (j < l) 
                        {
                            String s1 = (String)encodedQueryNamesAndValues.get(j);
                            if (s1 != null)
                            {
                                encodedQueryNamesAndValues.set(j, HttpUrl.canonicalize(s1, "\\^`{|}", true, true, true, true));
                            }
                            j++;
                        }
                    }
                    if (encodedFragment == null)
                    {
                        return this;
                    } else
                    {
                        encodedFragment = HttpUrl.canonicalize(encodedFragment, " \"#<>\\^`{|}", true, true, false, false);
                        return this;
                    }
                }
                s = (String)encodedPathSegments.get(i);
                encodedPathSegments.set(i, HttpUrl.canonicalize(s, "[]", true, true, false, true));
                i++;
            } while (true);
        }

        public Builder removeAllEncodedQueryParameters(String s)
        {
            if (s != null)
            {
                if (encodedQueryNamesAndValues != null)
                {
                    removeAllCanonicalQueryParameters(HttpUrl.canonicalize(s, " \"'<>#&=", true, false, true, true));
                    return this;
                } else
                {
                    return this;
                }
            } else
            {
                throw new NullPointerException("encodedName == null");
            }
        }

        public Builder removeAllQueryParameters(String s)
        {
            if (s != null)
            {
                if (encodedQueryNamesAndValues != null)
                {
                    removeAllCanonicalQueryParameters(HttpUrl.canonicalize(s, " \"'<>#&=", false, false, true, true));
                    return this;
                } else
                {
                    return this;
                }
            } else
            {
                throw new NullPointerException("name == null");
            }
        }

        public Builder removePathSegment(int i)
        {
            encodedPathSegments.remove(i);
            if (!encodedPathSegments.isEmpty())
            {
                return this;
            } else
            {
                encodedPathSegments.add("");
                return this;
            }
        }

        public Builder scheme(String s)
        {
            if (s != null)
            {
                if (!s.equalsIgnoreCase("http"))
                {
                    if (!s.equalsIgnoreCase("https"))
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("unexpected scheme: ").append(s).toString());
                    } else
                    {
                        scheme = "https";
                        return this;
                    }
                } else
                {
                    scheme = "http";
                    return this;
                }
            } else
            {
                throw new NullPointerException("scheme == null");
            }
        }

        public Builder setEncodedPathSegment(int i, String s)
        {
            String s1;
            if (s != null)
            {
                s1 = HttpUrl.canonicalize(s, 0, s.length(), " \"<>^`{}|/\\?#", true, false, false, true);
                encodedPathSegments.set(i, s1);
                break MISSING_BLOCK_LABEL_32;
            } else
            {
                throw new NullPointerException("encodedPathSegment == null");
            }
            if (isDot(s1) || isDotDot(s1))
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected path segment: ").append(s).toString());
            } else
            {
                return this;
            }
        }

        public Builder setEncodedQueryParameter(String s, String s1)
        {
            removeAllEncodedQueryParameters(s);
            addEncodedQueryParameter(s, s1);
            return this;
        }

        public Builder setPathSegment(int i, String s)
        {
            String s1;
            if (s != null)
            {
                s1 = HttpUrl.canonicalize(s, 0, s.length(), " \"<>^`{}|/\\?#", false, false, false, true);
                break MISSING_BLOCK_LABEL_20;
            } else
            {
                throw new NullPointerException("pathSegment == null");
            }
            if (isDot(s1) || isDotDot(s1))
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected path segment: ").append(s).toString());
            } else
            {
                encodedPathSegments.set(i, s1);
                return this;
            }
        }

        public Builder setQueryParameter(String s, String s1)
        {
            removeAllQueryParameters(s);
            addQueryParameter(s, s1);
            return this;
        }

        public String toString()
        {
            StringBuilder stringbuilder;
            stringbuilder = new StringBuilder();
            stringbuilder.append(scheme);
            stringbuilder.append("://");
            break MISSING_BLOCK_LABEL_25;
            int i;
            if (!encodedUsername.isEmpty() || !encodedPassword.isEmpty())
            {
                stringbuilder.append(encodedUsername);
                if (!encodedPassword.isEmpty())
                {
                    stringbuilder.append(':');
                    stringbuilder.append(encodedPassword);
                }
                stringbuilder.append('@');
            }
            if (host.indexOf(':') == -1)
            {
                stringbuilder.append(host);
            } else
            {
                stringbuilder.append('[');
                stringbuilder.append(host);
                stringbuilder.append(']');
            }
            i = effectivePort();
            if (i != HttpUrl.defaultPort(scheme))
            {
                stringbuilder.append(':');
                stringbuilder.append(i);
            }
            HttpUrl.pathSegmentsToString(stringbuilder, encodedPathSegments);
            if (encodedQueryNamesAndValues != null)
            {
                stringbuilder.append('?');
                HttpUrl.namesAndValuesToQueryString(stringbuilder, encodedQueryNamesAndValues);
            }
            if (encodedFragment != null)
            {
                stringbuilder.append('#');
                stringbuilder.append(encodedFragment);
            }
            return stringbuilder.toString();
        }

        public Builder username(String s)
        {
            if (s != null)
            {
                encodedUsername = HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
                return this;
            } else
            {
                throw new NullPointerException("username == null");
            }
        }

        public Builder()
        {
            encodedUsername = "";
            encodedPassword = "";
            port = -1;
            encodedPathSegments.add("");
        }
    }

    static final class Builder.ParseResult extends Enum
    {

        private static final Builder.ParseResult $VALUES[];
        public static final Builder.ParseResult INVALID_HOST;
        public static final Builder.ParseResult INVALID_PORT;
        public static final Builder.ParseResult MISSING_SCHEME;
        public static final Builder.ParseResult SUCCESS;
        public static final Builder.ParseResult UNSUPPORTED_SCHEME;

        public static Builder.ParseResult valueOf(String s)
        {
            return (Builder.ParseResult)Enum.valueOf(okhttp3/HttpUrl$Builder$ParseResult, s);
        }

        public static Builder.ParseResult[] values()
        {
            return (Builder.ParseResult[])$VALUES.clone();
        }

        static 
        {
            SUCCESS = new Builder.ParseResult("SUCCESS", 0);
            MISSING_SCHEME = new Builder.ParseResult("MISSING_SCHEME", 1);
            UNSUPPORTED_SCHEME = new Builder.ParseResult("UNSUPPORTED_SCHEME", 2);
            INVALID_PORT = new Builder.ParseResult("INVALID_PORT", 3);
            INVALID_HOST = new Builder.ParseResult("INVALID_HOST", 4);
            $VALUES = (new Builder.ParseResult[] {
                SUCCESS, MISSING_SCHEME, UNSUPPORTED_SCHEME, INVALID_PORT, INVALID_HOST
            });
        }

        private Builder.ParseResult(String s, int i)
        {
            super(s, i);
        }
    }


    static final String FORM_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#&!$(),~";
    static final String FRAGMENT_ENCODE_SET = "";
    static final String FRAGMENT_ENCODE_SET_URI = " \"#<>\\^`{|}";
    private static final char HEX_DIGITS[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        'A', 'B', 'C', 'D', 'E', 'F'
    };
    static final String PASSWORD_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
    static final String PATH_SEGMENT_ENCODE_SET = " \"<>^`{}|/\\?#";
    static final String PATH_SEGMENT_ENCODE_SET_URI = "[]";
    static final String QUERY_COMPONENT_ENCODE_SET = " \"'<>#&=";
    static final String QUERY_COMPONENT_ENCODE_SET_URI = "\\^`{|}";
    static final String QUERY_ENCODE_SET = " \"'<>#";
    static final String USERNAME_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
    private final String fragment;
    final String host;
    private final String password;
    private final List pathSegments;
    final int port;
    private final List queryNamesAndValues;
    final String scheme;
    private final String url;
    private final String username;

    HttpUrl(Builder builder)
    {
        Object obj1 = null;
        super();
        scheme = builder.scheme;
        username = percentDecode(builder.encodedUsername, false);
        password = percentDecode(builder.encodedPassword, false);
        host = builder.host;
        port = builder.effectivePort();
        pathSegments = percentDecode(builder.encodedPathSegments, false);
        Object obj;
        if (builder.encodedQueryNamesAndValues == null)
        {
            obj = null;
        } else
        {
            obj = percentDecode(builder.encodedQueryNamesAndValues, true);
        }
        queryNamesAndValues = ((List) (obj));
        if (builder.encodedFragment == null)
        {
            obj = obj1;
        } else
        {
            obj = percentDecode(builder.encodedFragment, false);
        }
        fragment = ((String) (obj));
        url = builder.toString();
    }

    static String canonicalize(String s, int i, int j, String s1, boolean flag, boolean flag1, boolean flag2, boolean flag3)
    {
        int k = i;
        do
        {
            if (k >= j)
            {
                return s.substring(i, j);
            }
            int l = s.codePointAt(k);
            while (false) 
            {
                if (l < 32 || l == 127 || l >= 128 && flag3 || (s1.indexOf(l) != -1 || l == 37 && (!flag || flag1 && !percentEncoded(s, k, j))) || l == 43 && flag2)
                {
                    Buffer buffer = new Buffer();
                    buffer.writeUtf8(s, i, k);
                    canonicalize(buffer, s, k, j, s1, flag, flag1, flag2, flag3);
                    return buffer.readUtf8();
                }
                k += Character.charCount(l);
            }
        } while (true);
    }

    static String canonicalize(String s, String s1, boolean flag, boolean flag1, boolean flag2, boolean flag3)
    {
        return canonicalize(s, 0, s.length(), s1, flag, flag1, flag2, flag3);
    }

    static void canonicalize(Buffer buffer, String s, int i, int j, String s1, boolean flag, boolean flag1, boolean flag2, 
            boolean flag3)
    {
        Buffer buffer1 = null;
_L5:
        int k;
        if (i >= j)
        {
            return;
        }
        k = s.codePointAt(i);
        if (flag) goto _L2; else goto _L1
_L13:
        Object obj;
        if (buffer1 == null)
        {
            buffer1 = new Buffer();
        }
        buffer1.writeUtf8CodePoint(k);
_L14:
        if (!buffer1.exhausted()) goto _L4; else goto _L3
_L3:
        obj = buffer1;
_L7:
        i += Character.charCount(k);
        buffer1 = ((Buffer) (obj));
          goto _L5
_L2:
        obj = buffer1;
        if (k == 9) goto _L7; else goto _L6
_L6:
        obj = buffer1;
        if (k == 10) goto _L7; else goto _L8
_L8:
        obj = buffer1;
        if (k == 12) goto _L7; else goto _L9
_L9:
        obj = buffer1;
        if (k == 13) goto _L7; else goto _L1
_L1:
        if (k != 43 || !flag2) goto _L11; else goto _L10
_L10:
        if (!flag)
        {
            obj = "%2B";
        } else
        {
            obj = "+";
        }
        buffer.writeUtf8(((String) (obj)));
        obj = buffer1;
          goto _L7
_L12:
        buffer.writeUtf8CodePoint(k);
        obj = buffer1;
          goto _L7
_L11:
        if (k < 32 || k == 127 || k >= 128 && flag3 || (s1.indexOf(k) != -1 || k == 37 && (!flag || flag1 && !percentEncoded(s, i, j)))) goto _L13; else goto _L12
_L4:
        int l = buffer1.readByte() & 0xff;
        buffer.writeByte(37);
        buffer.writeByte(HEX_DIGITS[l >> 4 & 0xf]);
        buffer.writeByte(HEX_DIGITS[l & 0xf]);
          goto _L14
    }

    static int decodeHexDigit(char c)
    {
        if (c < '0' || c > '9')
        {
            if (c < 'a' || c > 'f')
            {
                if (c < 'A' || c > 'F')
                {
                    return -1;
                } else
                {
                    return (c - 65) + 10;
                }
            } else
            {
                return (c - 97) + 10;
            }
        } else
        {
            return c - 48;
        }
    }

    public static int defaultPort(String s)
    {
        if (!s.equals("http"))
        {
            return s.equals("https") ? 443 : -1;
        } else
        {
            return 80;
        }
    }

    public static HttpUrl get(URI uri1)
    {
        return parse(uri1.toString());
    }

    public static HttpUrl get(URL url1)
    {
        return parse(url1.toString());
    }

    static HttpUrl getChecked(String s)
        throws MalformedURLException, UnknownHostException
    {
        Builder builder = new Builder();
        Builder.ParseResult parseresult = builder.parse(null, s);
        static class _cls1
        {

            static final int $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[];

            static 
            {
                $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult = new int[Builder.ParseResult.values().length];
                try
                {
                    $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[Builder.ParseResult.SUCCESS.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[Builder.ParseResult.INVALID_HOST.ordinal()] = 2;
                }
                catch (NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[Builder.ParseResult.UNSUPPORTED_SCHEME.ordinal()] = 3;
                }
                catch (NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[Builder.ParseResult.MISSING_SCHEME.ordinal()] = 4;
                }
                catch (NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$okhttp3$HttpUrl$Builder$ParseResult[Builder.ParseResult.INVALID_PORT.ordinal()] = 5;
                }
                catch (NoSuchFieldError nosuchfielderror)
                {
                    return;
                }
            }
        }

        switch (_cls1..SwitchMap.okhttp3.HttpUrl.Builder.ParseResult[parseresult.ordinal()])
        {
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        default:
            throw new MalformedURLException((new StringBuilder()).append("Invalid URL: ").append(parseresult).append(" for ").append(s).toString());

        case 1: // '\001'
            return builder.build();

        case 2: // '\002'
            throw new UnknownHostException((new StringBuilder()).append("Invalid host: ").append(s).toString());
        }
    }

    static void namesAndValuesToQueryString(StringBuilder stringbuilder, List list)
    {
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            String s = (String)list.get(i);
            String s1 = (String)list.get(i + 1);
            if (i > 0)
            {
                stringbuilder.append('&');
            }
            stringbuilder.append(s);
            if (s1 != null)
            {
                stringbuilder.append('=');
                stringbuilder.append(s1);
            }
            i += 2;
        } while (true);
    }

    public static HttpUrl parse(String s)
    {
        Builder builder = new Builder();
        if (builder.parse(null, s) != Builder.ParseResult.SUCCESS)
        {
            return null;
        } else
        {
            return builder.build();
        }
    }

    static void pathSegmentsToString(StringBuilder stringbuilder, List list)
    {
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            stringbuilder.append('/');
            stringbuilder.append((String)list.get(i));
            i++;
        } while (true);
    }

    static String percentDecode(String s, int i, int j, boolean flag)
    {
        int k = i;
        do
        {
            if (k >= j)
            {
                return s.substring(i, j);
            }
            char c = s.charAt(k);
            while (false) 
            {
                if (c == '%' || c == '+' && flag)
                {
                    Buffer buffer = new Buffer();
                    buffer.writeUtf8(s, i, k);
                    percentDecode(buffer, s, k, j, flag);
                    return buffer.readUtf8();
                }
                k++;
            }
        } while (true);
    }

    static String percentDecode(String s, boolean flag)
    {
        return percentDecode(s, 0, s.length(), flag);
    }

    private List percentDecode(List list, boolean flag)
    {
        int j = list.size();
        ArrayList arraylist = new ArrayList(j);
        int i = 0;
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableList(arraylist);
            }
            String s = (String)list.get(i);
            if (s == null)
            {
                s = null;
            } else
            {
                s = percentDecode(s, flag);
            }
            arraylist.add(s);
            i++;
        } while (true);
    }

    static void percentDecode(Buffer buffer, String s, int i, int j, boolean flag)
    {
_L2:
        int k;
        if (i >= j)
        {
            return;
        }
        k = s.codePointAt(i);
          goto _L1
_L6:
        buffer.writeUtf8CodePoint(k);
_L7:
        i += Character.charCount(k);
          goto _L2
_L1:
        if (k != 37 || i + 2 >= j) goto _L4; else goto _L3
_L3:
        int l;
        int i1;
        l = decodeHexDigit(s.charAt(i + 1));
        i1 = decodeHexDigit(s.charAt(i + 2));
        if (l == -1 || i1 == -1) goto _L6; else goto _L5
_L5:
        buffer.writeByte((l << 4) + i1);
        i += 2;
          goto _L7
_L4:
        if (k != 43 || !flag) goto _L6; else goto _L8
_L8:
        buffer.writeByte(32);
          goto _L7
    }

    static boolean percentEncoded(String s, int i, int j)
    {
        while (i + 2 >= j || s.charAt(i) != '%' || decodeHexDigit(s.charAt(i + 1)) == -1 || decodeHexDigit(s.charAt(i + 2)) == -1) 
        {
            return false;
        }
        return true;
    }

    static List queryStringToNamesAndValues(String s)
    {
        ArrayList arraylist;
        int i;
        arraylist = new ArrayList();
        i = 0;
        break MISSING_BLOCK_LABEL_10;
        i = j + 1;
        if (i > s.length())
        {
            return arraylist;
        }
        int j = s.indexOf('&', i);
        int k;
        if (j == -1)
        {
            j = s.length();
        }
        k = s.indexOf('=', i);
        if (k == -1 || k > j)
        {
            arraylist.add(s.substring(i, j));
            arraylist.add(null);
        } else
        {
            arraylist.add(s.substring(i, k));
            arraylist.add(s.substring(k + 1, j));
        }
        break MISSING_BLOCK_LABEL_69;
    }

    public String encodedFragment()
    {
        if (fragment != null)
        {
            int i = url.indexOf('#');
            return url.substring(i + 1);
        } else
        {
            return null;
        }
    }

    public String encodedPassword()
    {
        if (!password.isEmpty())
        {
            int i = url.indexOf(':', scheme.length() + 3);
            int j = url.indexOf('@');
            return url.substring(i + 1, j);
        } else
        {
            return "";
        }
    }

    public String encodedPath()
    {
        int i = url.indexOf('/', scheme.length() + 3);
        int j = Util.delimiterOffset(url, i, url.length(), "?#");
        return url.substring(i, j);
    }

    public List encodedPathSegments()
    {
        int i = url.indexOf('/', scheme.length() + 3);
        int j = Util.delimiterOffset(url, i, url.length(), "?#");
        ArrayList arraylist = new ArrayList();
        do
        {
            if (i >= j)
            {
                return arraylist;
            }
            int k = i + 1;
            i = Util.delimiterOffset(url, k, j, '/');
            arraylist.add(url.substring(k, i));
        } while (true);
    }

    public String encodedQuery()
    {
        if (queryNamesAndValues != null)
        {
            int i = url.indexOf('?') + 1;
            int j = Util.delimiterOffset(url, i + 1, url.length(), '#');
            return url.substring(i, j);
        } else
        {
            return null;
        }
    }

    public String encodedUsername()
    {
        if (!username.isEmpty())
        {
            int i = scheme.length() + 3;
            int j = Util.delimiterOffset(url, i, url.length(), ":@");
            return url.substring(i, j);
        } else
        {
            return "";
        }
    }

    public boolean equals(Object obj)
    {
        while (!(obj instanceof HttpUrl) || !((HttpUrl)obj).url.equals(url)) 
        {
            return false;
        }
        return true;
    }

    public String fragment()
    {
        return fragment;
    }

    public int hashCode()
    {
        return url.hashCode();
    }

    public String host()
    {
        return host;
    }

    public boolean isHttps()
    {
        return scheme.equals("https");
    }

    public Builder newBuilder()
    {
        Builder builder = new Builder();
        builder.scheme = scheme;
        builder.encodedUsername = encodedUsername();
        builder.encodedPassword = encodedPassword();
        builder.host = host;
        int i;
        if (port == defaultPort(scheme))
        {
            i = -1;
        } else
        {
            i = port;
        }
        builder.port = i;
        builder.encodedPathSegments.clear();
        builder.encodedPathSegments.addAll(encodedPathSegments());
        builder.encodedQuery(encodedQuery());
        builder.encodedFragment = encodedFragment();
        return builder;
    }

    public Builder newBuilder(String s)
    {
        Builder builder1 = new Builder();
        Builder builder = builder1;
        if (builder1.parse(this, s) != Builder.ParseResult.SUCCESS)
        {
            builder = null;
        }
        return builder;
    }

    public String password()
    {
        return password;
    }

    public List pathSegments()
    {
        return pathSegments;
    }

    public int pathSize()
    {
        return pathSegments.size();
    }

    public int port()
    {
        return port;
    }

    public String query()
    {
        if (queryNamesAndValues != null)
        {
            StringBuilder stringbuilder = new StringBuilder();
            namesAndValuesToQueryString(stringbuilder, queryNamesAndValues);
            return stringbuilder.toString();
        } else
        {
            return null;
        }
    }

    public String queryParameter(String s)
    {
        int i;
        i = 0;
        int j;
        if (queryNamesAndValues != null)
        {
            j = queryNamesAndValues.size();
            break MISSING_BLOCK_LABEL_19;
        } else
        {
            return null;
        }
        do
        {
            if (i >= j)
            {
                return null;
            }
            if (!s.equals(queryNamesAndValues.get(i)))
            {
                i += 2;
            } else
            {
                return (String)queryNamesAndValues.get(i + 1);
            }
        } while (true);
    }

    public String queryParameterName(int i)
    {
        if (queryNamesAndValues != null)
        {
            return (String)queryNamesAndValues.get(i * 2);
        } else
        {
            throw new IndexOutOfBoundsException();
        }
    }

    public Set queryParameterNames()
    {
        LinkedHashSet linkedhashset;
        int i;
        int j;
        if (queryNamesAndValues != null)
        {
            linkedhashset = new LinkedHashSet();
            i = 0;
            j = queryNamesAndValues.size();
            break MISSING_BLOCK_LABEL_27;
        } else
        {
            return Collections.emptySet();
        }
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableSet(linkedhashset);
            }
            linkedhashset.add(queryNamesAndValues.get(i));
            i += 2;
        } while (true);
    }

    public String queryParameterValue(int i)
    {
        if (queryNamesAndValues != null)
        {
            return (String)queryNamesAndValues.get(i * 2 + 1);
        } else
        {
            throw new IndexOutOfBoundsException();
        }
    }

    public List queryParameterValues(String s)
    {
        ArrayList arraylist;
        int i;
        i = 0;
        int j;
        if (queryNamesAndValues != null)
        {
            arraylist = new ArrayList();
            j = queryNamesAndValues.size();
            break MISSING_BLOCK_LABEL_28;
        } else
        {
            return Collections.emptyList();
        }
        do
        {
            if (i >= j)
            {
                return Collections.unmodifiableList(arraylist);
            }
            if (s.equals(queryNamesAndValues.get(i)))
            {
                arraylist.add(queryNamesAndValues.get(i + 1));
            }
            i += 2;
        } while (true);
    }

    public int querySize()
    {
        if (queryNamesAndValues == null)
        {
            return 0;
        } else
        {
            return queryNamesAndValues.size() / 2;
        }
    }

    public String redact()
    {
        return newBuilder("/...").username("").password("").build().toString();
    }

    public HttpUrl resolve(String s)
    {
        s = newBuilder(s);
        if (s == null)
        {
            return null;
        } else
        {
            return s.build();
        }
    }

    public String scheme()
    {
        return scheme;
    }

    public String toString()
    {
        return url;
    }

    public URI uri()
    {
        Object obj = newBuilder().reencodeForUri().toString();
        URI uri1;
        try
        {
            uri1 = new URI(((String) (obj)));
        }
        catch (URISyntaxException urisyntaxexception)
        {
            try
            {
                obj = URI.create(((String) (obj)).replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", ""));
            }
            catch (Exception exception)
            {
                throw new RuntimeException(urisyntaxexception);
            }
            return ((URI) (obj));
        }
        return uri1;
    }

    public URL url()
    {
        URL url1;
        try
        {
            url1 = new URL(url);
        }
        catch (MalformedURLException malformedurlexception)
        {
            throw new RuntimeException(malformedurlexception);
        }
        return url1;
    }

    public String username()
    {
        return username;
    }

}
