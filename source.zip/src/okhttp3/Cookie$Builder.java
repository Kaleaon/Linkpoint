// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            Cookie

public static final class path
{

    String domain;
    long expiresAt;
    boolean hostOnly;
    boolean httpOnly;
    String name;
    String path;
    boolean persistent;
    boolean secure;
    String value;

    private path domain(String s, boolean flag)
    {
        if (s != null)
        {
            String s1 = Util.domainToAscii(s);
            if (s1 != null)
            {
                domain = s1;
                hostOnly = flag;
                return this;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected domain: ").append(s).toString());
            }
        } else
        {
            throw new NullPointerException("domain == null");
        }
    }

    public Cookie build()
    {
        return new Cookie(this);
    }

    public ception domain(String s)
    {
        return domain(s, false);
    }

    public domain expiresAt(long l)
    {
        long l1 = 0xe677d21fdbffL;
        boolean flag1 = false;
        boolean flag;
        if (l > 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            l = 0x8000000000000000L;
        }
        flag = flag1;
        if (l <= 0xe677d21fdbffL)
        {
            flag = true;
        }
        if (!flag)
        {
            l = l1;
        }
        expiresAt = l;
        persistent = true;
        return this;
    }

    public persistent hostOnlyDomain(String s)
    {
        return domain(s, true);
    }

    public domain httpOnly()
    {
        httpOnly = true;
        return this;
    }

    public httpOnly name(String s)
    {
        if (s != null)
        {
            if (s.trim().equals(s))
            {
                name = s;
                return this;
            } else
            {
                throw new IllegalArgumentException("name is not trimmed");
            }
        } else
        {
            throw new NullPointerException("name == null");
        }
    }

    public ception path(String s)
    {
        if (s.startsWith("/"))
        {
            path = s;
            return this;
        } else
        {
            throw new IllegalArgumentException("path must start with '/'");
        }
    }

    public ntException secure()
    {
        secure = true;
        return this;
    }

    public secure value(String s)
    {
        if (s != null)
        {
            if (s.trim().equals(s))
            {
                value = s;
                return this;
            } else
            {
                throw new IllegalArgumentException("value is not trimmed");
            }
        } else
        {
            throw new NullPointerException("value == null");
        }
    }

    public ()
    {
        expiresAt = 0xe677d21fdbffL;
        path = "/";
    }
}
