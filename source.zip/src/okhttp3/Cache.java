// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import okhttp3.internal.Util;
import okhttp3.internal.cache.CacheRequest;
import okhttp3.internal.cache.CacheStrategy;
import okhttp3.internal.cache.DiskLruCache;
import okhttp3.internal.cache.InternalCache;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http.HttpMethod;
import okhttp3.internal.http.StatusLine;
import okhttp3.internal.io.FileSystem;
import okhttp3.internal.platform.Platform;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import okio.ForwardingSink;
import okio.ForwardingSource;
import okio.Okio;
import okio.Sink;
import okio.Source;

// Referenced classes of package okhttp3:
//            HttpUrl, Request, Response, ResponseBody, 
//            MediaType, CipherSuite, Handshake, TlsVersion, 
//            Headers, Protocol

public final class Cache
    implements Closeable, Flushable
{
    private final class CacheRequestImpl
        implements CacheRequest
    {

        private Sink body;
        private Sink cacheOut;
        boolean done;
        private final okhttp3.internal.cache.DiskLruCache.Editor editor;
        final Cache this$0;

        public void abort()
        {
label0:
            {
                synchronized (Cache.this)
                {
                    if (done)
                    {
                        break label0;
                    }
                    done = true;
                    Cache cache2 = Cache.this;
                    cache2.writeAbortCount = cache2.writeAbortCount + 1;
                }
                Util.closeQuietly(cacheOut);
                try
                {
                    editor.abort();
                    return;
                }
                catch (IOException ioexception)
                {
                    return;
                }
            }
            cache1;
            JVM INSTR monitorexit ;
            return;
            exception;
            cache1;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public Sink body()
        {
            return body;
        }

        public CacheRequestImpl(okhttp3.internal.cache.DiskLruCache.Editor editor1)
        {
            this$0 = Cache.this;
            super();
            editor = editor1;
            cacheOut = editor1.newSink(1);
            body = new _cls1(editor1);
        }
    }

    private static class CacheResponseBody extends ResponseBody
    {

        private final BufferedSource bodySource;
        private final String contentLength;
        private final String contentType;
        final okhttp3.internal.cache.DiskLruCache.Snapshot snapshot;

        public long contentLength()
        {
            if (contentLength == null)
            {
                return -1L;
            }
            long l;
            try
            {
                l = Long.parseLong(contentLength);
            }
            catch (NumberFormatException numberformatexception)
            {
                return -1L;
            }
            return l;
        }

        public MediaType contentType()
        {
            if (contentType == null)
            {
                return null;
            } else
            {
                return MediaType.parse(contentType);
            }
        }

        public BufferedSource source()
        {
            return bodySource;
        }

        public CacheResponseBody(okhttp3.internal.cache.DiskLruCache.Snapshot snapshot1, String s, String s1)
        {
            snapshot = snapshot1;
            contentType = s;
            contentLength = s1;
            bodySource = Okio.buffer(snapshot1.getSource(1). new _cls1(snapshot1));
        }
    }

    private static final class Entry
    {

        private static final String RECEIVED_MILLIS = (new StringBuilder()).append(Platform.get().getPrefix()).append("-Received-Millis").toString();
        private static final String SENT_MILLIS = (new StringBuilder()).append(Platform.get().getPrefix()).append("-Sent-Millis").toString();
        private final int code;
        private final Handshake handshake;
        private final String message;
        private final Protocol protocol;
        private final long receivedResponseMillis;
        private final String requestMethod;
        private final Headers responseHeaders;
        private final long sentRequestMillis;
        private final String url;
        private final Headers varyHeaders;

        private boolean isHttps()
        {
            return url.startsWith("https://");
        }

        private List readCertificateList(BufferedSource bufferedsource)
            throws IOException
        {
label0:
            {
label1:
                {
                    {
                        int j = Cache.readInt(bufferedsource);
                        if (j == -1)
                        {
                            break label1;
                        }
                        CertificateFactory certificatefactory;
                        ArrayList arraylist;
                        String s;
                        Buffer buffer;
                        int i;
                        try
                        {
                            certificatefactory = CertificateFactory.getInstance("X.509");
                            arraylist = new ArrayList(j);
                        }
                        // Misplaced declaration of an exception variable
                        catch (BufferedSource bufferedsource)
                        {
                            throw new IOException(bufferedsource.getMessage());
                        }
                        i = 0;
                    }
                    if (i >= j)
                    {
                        return arraylist;
                    }
                    break label0;
                }
                return Collections.emptyList();
            }
            s = bufferedsource.readUtf8LineStrict();
            buffer = new Buffer();
            buffer.write(ByteString.decodeBase64(s));
            arraylist.add(certificatefactory.generateCertificate(buffer.inputStream()));
            i++;
            if (false)
            {
            } else
            {
                break MISSING_BLOCK_LABEL_31;
            }
        }

        private void writeCertList(BufferedSink bufferedsink, List list)
            throws IOException
        {
            int i;
            int j;
            try
            {
                bufferedsink.writeDecimalLong(list.size()).writeByte(10);
                j = list.size();
            }
            // Misplaced declaration of an exception variable
            catch (BufferedSink bufferedsink)
            {
                throw new IOException(bufferedsink.getMessage());
            }
            i = 0;
              goto _L1
_L3:
            bufferedsink.writeUtf8(ByteString.of(((Certificate)list.get(i)).getEncoded()).base64()).writeByte(10);
            i++;
_L1:
            if (i < j) goto _L3; else goto _L2
_L2:
        }

        public boolean matches(Request request, Response response1)
        {
            while (!url.equals(request.url().toString()) || !requestMethod.equals(request.method()) || !HttpHeaders.varyMatches(response1, varyHeaders, request)) 
            {
                return false;
            }
            return true;
        }

        public Response response(okhttp3.internal.cache.DiskLruCache.Snapshot snapshot)
        {
            String s = responseHeaders.get("Content-Type");
            String s1 = responseHeaders.get("Content-Length");
            Request request = (new Request.Builder()).url(url).method(requestMethod, null).headers(varyHeaders).build();
            return (new Response.Builder()).request(request).protocol(protocol).code(code).message(message).headers(responseHeaders).body(new CacheResponseBody(snapshot, s, s1)).handshake(handshake).sentRequestAtMillis(sentRequestMillis).receivedResponseAtMillis(receivedResponseMillis).build();
        }

        public void writeTo(okhttp3.internal.cache.DiskLruCache.Editor editor)
            throws IOException
        {
            int i;
            boolean flag;
            int j;
            flag = false;
            editor = Okio.buffer(editor.newSink(0));
            editor.writeUtf8(url).writeByte(10);
            editor.writeUtf8(requestMethod).writeByte(10);
            editor.writeDecimalLong(varyHeaders.size()).writeByte(10);
            j = varyHeaders.size();
            i = 0;
_L3:
            if (i < j) goto _L2; else goto _L1
_L1:
            editor.writeUtf8((new StatusLine(protocol, code, message)).toString()).writeByte(10);
            editor.writeDecimalLong(responseHeaders.size() + 2).writeByte(10);
            j = responseHeaders.size();
            i = ((flag) ? 1 : 0);
_L4:
            if (i >= j)
            {
                editor.writeUtf8(SENT_MILLIS).writeUtf8(": ").writeDecimalLong(sentRequestMillis).writeByte(10);
                editor.writeUtf8(RECEIVED_MILLIS).writeUtf8(": ").writeDecimalLong(receivedResponseMillis).writeByte(10);
                if (isHttps())
                {
                    editor.writeByte(10);
                    editor.writeUtf8(handshake.cipherSuite().javaName()).writeByte(10);
                    writeCertList(editor, handshake.peerCertificates());
                    writeCertList(editor, handshake.localCertificates());
                    if (handshake.tlsVersion() != null)
                    {
                        editor.writeUtf8(handshake.tlsVersion().javaName()).writeByte(10);
                    }
                }
                editor.close();
                return;
            }
            break MISSING_BLOCK_LABEL_295;
_L2:
            editor.writeUtf8(varyHeaders.name(i)).writeUtf8(": ").writeUtf8(varyHeaders.value(i)).writeByte(10);
            i++;
              goto _L3
            editor.writeUtf8(responseHeaders.name(i)).writeUtf8(": ").writeUtf8(responseHeaders.value(i)).writeByte(10);
            i++;
              goto _L4
        }


        public Entry(Response response1)
        {
            url = response1.request().url().toString();
            varyHeaders = HttpHeaders.varyHeaders(response1);
            requestMethod = response1.request().method();
            protocol = response1.protocol();
            code = response1.code();
            message = response1.message();
            responseHeaders = response1.headers();
            handshake = response1.handshake();
            sentRequestMillis = response1.sentRequestAtMillis();
            receivedResponseMillis = response1.receivedResponseAtMillis();
        }

        public Entry(Source source)
            throws IOException
        {
            Object obj;
            boolean flag;
            long l1;
            l1 = 0L;
            obj = null;
            flag = false;
            super();
            BufferedSource bufferedsource;
            Object obj1;
            int j;
            bufferedsource = Okio.buffer(source);
            url = bufferedsource.readUtf8LineStrict();
            requestMethod = bufferedsource.readUtf8LineStrict();
            obj1 = new Headers.Builder();
            j = Cache.readInt(bufferedsource);
            int i = 0;
_L11:
            if (i < j) goto _L2; else goto _L1
_L1:
            varyHeaders = ((Headers.Builder) (obj1)).build();
            obj1 = StatusLine.parse(bufferedsource.readUtf8LineStrict());
            protocol = ((StatusLine) (obj1)).protocol;
            code = ((StatusLine) (obj1)).code;
            message = ((StatusLine) (obj1)).message;
            obj1 = new Headers.Builder();
            j = Cache.readInt(bufferedsource);
            i = ((flag) ? 1 : 0);
_L12:
            if (i < j) goto _L4; else goto _L3
_L3:
            Object obj2;
            Object obj3;
            obj2 = ((Headers.Builder) (obj1)).get(SENT_MILLIS);
            obj3 = ((Headers.Builder) (obj1)).get(RECEIVED_MILLIS);
            ((Headers.Builder) (obj1)).removeAll(SENT_MILLIS);
            ((Headers.Builder) (obj1)).removeAll(RECEIVED_MILLIS);
            if (obj2 != null) goto _L6; else goto _L5
_L5:
            long l = 0L;
_L13:
            sentRequestMillis = l;
            if (obj3 != null) goto _L8; else goto _L7
_L7:
            l = l1;
_L14:
            receivedResponseMillis = l;
            responseHeaders = ((Headers.Builder) (obj1)).build();
            if (isHttps()) goto _L10; else goto _L9
_L9:
            handshake = null;
_L15:
            source.close();
            return;
_L2:
            ((Headers.Builder) (obj1)).addLenient(bufferedsource.readUtf8LineStrict());
            i++;
              goto _L11
_L4:
            ((Headers.Builder) (obj1)).addLenient(bufferedsource.readUtf8LineStrict());
            i++;
              goto _L12
_L6:
            l = Long.parseLong(((String) (obj2)));
              goto _L13
_L8:
            l = Long.parseLong(((String) (obj3)));
              goto _L14
_L10:
            obj1 = bufferedsource.readUtf8LineStrict();
            if (((String) (obj1)).length() > 0)
            {
                break MISSING_BLOCK_LABEL_368;
            }
            obj1 = CipherSuite.forJavaName(bufferedsource.readUtf8LineStrict());
            obj2 = readCertificateList(bufferedsource);
            obj3 = readCertificateList(bufferedsource);
            if (!bufferedsource.exhausted())
            {
                obj = TlsVersion.forJavaName(bufferedsource.readUtf8LineStrict());
            }
            handshake = Handshake.get(((TlsVersion) (obj)), ((CipherSuite) (obj1)), ((List) (obj2)), ((List) (obj3)));
              goto _L15
            obj;
            source.close();
            throw obj;
            throw new IOException((new StringBuilder()).append("expected \"\" but was \"").append(((String) (obj1))).append("\"").toString());
              goto _L11
        }
    }


    private static final int ENTRY_BODY = 1;
    private static final int ENTRY_COUNT = 2;
    private static final int ENTRY_METADATA = 0;
    private static final int VERSION = 0x31191;
    final DiskLruCache cache;
    private int hitCount;
    final InternalCache internalCache;
    private int networkCount;
    private int requestCount;
    int writeAbortCount;
    int writeSuccessCount;

    public Cache(File file, long l)
    {
        this(file, l, FileSystem.SYSTEM);
    }

    Cache(File file, long l, FileSystem filesystem)
    {
        internalCache = new InternalCache() {

            final Cache this$0;

            public Response get(Request request)
                throws IOException
            {
                return Cache.this.get(request);
            }

            public CacheRequest put(Response response)
                throws IOException
            {
                return Cache.this.put(response);
            }

            public void remove(Request request)
                throws IOException
            {
                Cache.this.remove(request);
            }

            public void trackConditionalCacheHit()
            {
                Cache.this.trackConditionalCacheHit();
            }

            public void trackResponse(CacheStrategy cachestrategy)
            {
                Cache.this.trackResponse(cachestrategy);
            }

            public void update(Response response, Response response1)
            {
                Cache.this.update(response, response1);
            }

            
            {
                this$0 = Cache.this;
                super();
            }
        };
        cache = DiskLruCache.create(filesystem, file, 0x31191, 2, l);
    }

    private void abortQuietly(okhttp3.internal.cache.DiskLruCache.Editor editor)
    {
        if (editor == null)
        {
            return;
        }
        try
        {
            editor.abort();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (okhttp3.internal.cache.DiskLruCache.Editor editor)
        {
            return;
        }
    }

    public static String key(HttpUrl httpurl)
    {
        return ByteString.encodeUtf8(httpurl.toString()).md5().hex();
    }

    static int readInt(BufferedSource bufferedsource)
        throws IOException
    {
        boolean flag;
        boolean flag1 = true;
        long l;
        try
        {
            l = bufferedsource.readDecimalLong();
            bufferedsource = bufferedsource.readUtf8LineStrict();
        }
        // Misplaced declaration of an exception variable
        catch (BufferedSource bufferedsource)
        {
            throw new IOException(bufferedsource.getMessage());
        }
        if (l < 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
          goto _L1
_L5:
        if (flag)
        {
            break MISSING_BLOCK_LABEL_41;
        }
        if (bufferedsource.isEmpty())
        {
            return (int)l;
        }
_L3:
        throw new IOException((new StringBuilder()).append("expected an int but was \"").append(l).append(bufferedsource).append("\"").toString());
_L1:
        if (flag) goto _L3; else goto _L2
_L2:
        if (l > 0x7fffffffL)
        {
            flag = flag1;
        } else
        {
            flag = false;
        }
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void close()
        throws IOException
    {
        cache.close();
    }

    public void delete()
        throws IOException
    {
        cache.delete();
    }

    public File directory()
    {
        return cache.getDirectory();
    }

    public void evictAll()
        throws IOException
    {
        cache.evictAll();
    }

    public void flush()
        throws IOException
    {
        cache.flush();
    }

    Response get(Request request)
    {
        Object obj = key(request.url());
        try
        {
            obj = cache.get(((String) (obj)));
        }
        // Misplaced declaration of an exception variable
        catch (Request request)
        {
            return null;
        }
        if (obj != null)
        {
            Entry entry;
            try
            {
                entry = new Entry(((okhttp3.internal.cache.DiskLruCache.Snapshot) (obj)).getSource(0));
            }
            // Misplaced declaration of an exception variable
            catch (Request request)
            {
                Util.closeQuietly(((Closeable) (obj)));
                return null;
            }
            obj = entry.response(((okhttp3.internal.cache.DiskLruCache.Snapshot) (obj)));
            if (entry.matches(request, ((Response) (obj))))
            {
                return ((Response) (obj));
            } else
            {
                Util.closeQuietly(((Response) (obj)).body());
                return null;
            }
        } else
        {
            return null;
        }
    }

    public int hitCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = hitCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public void initialize()
        throws IOException
    {
        cache.initialize();
    }

    public boolean isClosed()
    {
        return cache.isClosed();
    }

    public long maxSize()
    {
        return cache.getMaxSize();
    }

    public int networkCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = networkCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    CacheRequest put(Response response)
    {
        Object obj;
        obj = response.request().method();
        if (HttpMethod.invalidatesCache(response.request().method()))
        {
            break MISSING_BLOCK_LABEL_85;
        }
        if (!((String) (obj)).equals("GET"))
        {
            break MISSING_BLOCK_LABEL_95;
        }
        if (HttpHeaders.hasVaryAll(response))
        {
            break MISSING_BLOCK_LABEL_97;
        }
        obj = new Entry(response);
        response = cache.edit(key(response.request().url()));
        if (response == null)
        {
            break MISSING_BLOCK_LABEL_99;
        }
        ((Entry) (obj)).writeTo(response);
        obj = new CacheRequestImpl(response);
        return ((CacheRequest) (obj));
        IOException ioexception;
        try
        {
            remove(response.request());
        }
        // Misplaced declaration of an exception variable
        catch (Response response)
        {
            return null;
        }
        return null;
        return null;
        return null;
        return null;
        response;
        response = null;
_L2:
        abortQuietly(response);
        return null;
        ioexception;
        if (true) goto _L2; else goto _L1
_L1:
    }

    void remove(Request request)
        throws IOException
    {
        cache.remove(key(request.url()));
    }

    public int requestCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = requestCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public long size()
        throws IOException
    {
        return cache.size();
    }

    void trackConditionalCacheHit()
    {
        this;
        JVM INSTR monitorenter ;
        hitCount = hitCount + 1;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    void trackResponse(CacheStrategy cachestrategy)
    {
        this;
        JVM INSTR monitorenter ;
        requestCount = requestCount + 1;
        if (cachestrategy.networkRequest != null) goto _L2; else goto _L1
_L1:
        cachestrategy = cachestrategy.cacheResponse;
        if (cachestrategy != null)
        {
            break MISSING_BLOCK_LABEL_49;
        }
_L3:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        networkCount = networkCount + 1;
          goto _L3
        cachestrategy;
        throw cachestrategy;
        hitCount = hitCount + 1;
          goto _L3
    }

    void update(Response response, Response response1)
    {
        response1 = new Entry(response1);
        response = ((CacheResponseBody)response.body()).snapshot;
        response = response.edit();
        if (response == null)
        {
            return;
        }
        try
        {
            response1.writeTo(response);
            response.commit();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Response response1) { }
_L2:
        abortQuietly(response);
        return;
        response;
        response = null;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public Iterator urls()
        throws IOException
    {
        return new Iterator() {

            boolean canRemove;
            final Iterator _flddelegate;
            String nextUrl;
            final Cache this$0;

            public boolean hasNext()
            {
                if (nextUrl == null)
                {
                    canRemove = false;
                    break MISSING_BLOCK_LABEL_12;
                } else
                {
                    return true;
                }
_L2:
                okhttp3.internal.cache.DiskLruCache.Snapshot snapshot;
                if (!_flddelegate.hasNext())
                {
                    return false;
                }
                snapshot = (okhttp3.internal.cache.DiskLruCache.Snapshot)_flddelegate.next();
                nextUrl = Okio.buffer(snapshot.getSource(0)).readUtf8LineStrict();
                snapshot.close();
                return true;
                Object obj;
                obj;
                snapshot.close();
                if (true) goto _L2; else goto _L1
_L1:
                obj;
                snapshot.close();
                throw obj;
            }

            public volatile Object next()
            {
                return next();
            }

            public String next()
            {
                if (hasNext())
                {
                    String s = nextUrl;
                    nextUrl = null;
                    canRemove = true;
                    return s;
                } else
                {
                    throw new NoSuchElementException();
                }
            }

            public void remove()
            {
                if (canRemove)
                {
                    _flddelegate.remove();
                    return;
                } else
                {
                    throw new IllegalStateException("remove() before next()");
                }
            }

            
                throws IOException
            {
                this$0 = Cache.this;
                super();
                _flddelegate = cache.snapshots();
            }
        };
    }

    public int writeAbortCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = writeAbortCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public int writeSuccessCount()
    {
        this;
        JVM INSTR monitorenter ;
        int i = writeSuccessCount;
        this;
        JVM INSTR monitorexit ;
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    // Unreferenced inner class okhttp3/Cache$CacheRequestImpl$1

/* anonymous class */
    class CacheRequestImpl._cls1 extends ForwardingSink
    {

        final CacheRequestImpl this$1;
        final okhttp3.internal.cache.DiskLruCache.Editor val$editor;
        final Cache val$this$0;

        public void close()
            throws IOException
        {
label0:
            {
                synchronized (_fld0)
                {
                    if (done)
                    {
                        break label0;
                    }
                    done = true;
                    Cache cache2 = _fld0;
                    cache2.writeSuccessCount = cache2.writeSuccessCount + 1;
                }
                super.close();
                editor.commit();
                return;
            }
            cache1;
            JVM INSTR monitorexit ;
            return;
            exception;
            cache1;
            JVM INSTR monitorexit ;
            throw exception;
        }

            
            {
                this$1 = final_cacherequestimpl;
                this$0 = Cache.this;
                editor = editor1;
                super(final_sink);
            }
    }


    // Unreferenced inner class okhttp3/Cache$CacheResponseBody$1

/* anonymous class */
    class CacheResponseBody._cls1 extends ForwardingSource
    {

        final CacheResponseBody this$0;
        final okhttp3.internal.cache.DiskLruCache.Snapshot val$snapshot;

        public void close()
            throws IOException
        {
            snapshot.close();
            super.close();
        }

            
            {
                this$0 = final_cacheresponsebody;
                snapshot = snapshot1;
                super(Source.this);
            }
    }

}
