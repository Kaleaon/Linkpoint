// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import okhttp3.internal.Util;
import okio.BufferedSource;

// Referenced classes of package okhttp3:
//            ResponseBody

static final class charset extends Reader
{

    private final Charset charset;
    private boolean closed;
    private Reader _flddelegate;
    private final BufferedSource source;

    public void close()
        throws IOException
    {
        closed = true;
        if (_flddelegate == null)
        {
            source.close();
            return;
        } else
        {
            _flddelegate.close();
            return;
        }
    }

    public int read(char ac[], int i, int j)
        throws IOException
    {
        if (!closed)
        {
            Object obj = _flddelegate;
            if (obj == null)
            {
                obj = Util.bomAwareCharset(source, charset);
                obj = new InputStreamReader(source.inputStream(), ((Charset) (obj)));
                _flddelegate = ((Reader) (obj));
            }
            return ((Reader) (obj)).read(ac, i, j);
        } else
        {
            throw new IOException("Stream closed");
        }
    }

    (BufferedSource bufferedsource, Charset charset1)
    {
        source = bufferedsource;
        charset = charset1;
    }
}
