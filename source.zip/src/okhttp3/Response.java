// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.Closeable;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import okhttp3.internal.http.HttpHeaders;
import okio.Buffer;
import okio.BufferedSource;

// Referenced classes of package okhttp3:
//            CacheControl, ResponseBody, Headers, Request, 
//            Handshake, Protocol

public final class Response
    implements Closeable
{
    public static class Builder
    {

        ResponseBody body;
        Response cacheResponse;
        int code;
        Handshake handshake;
        Headers.Builder headers;
        String message;
        Response networkResponse;
        Response priorResponse;
        Protocol protocol;
        long receivedResponseAtMillis;
        Request request;
        long sentRequestAtMillis;

        private void checkPriorResponse(Response response)
        {
            if (response.body == null)
            {
                return;
            } else
            {
                throw new IllegalArgumentException("priorResponse.body != null");
            }
        }

        private void checkSupportResponse(String s, Response response)
        {
            if (response.body == null)
            {
                if (response.networkResponse == null)
                {
                    if (response.cacheResponse == null)
                    {
                        if (response.priorResponse == null)
                        {
                            return;
                        } else
                        {
                            throw new IllegalArgumentException((new StringBuilder()).append(s).append(".priorResponse != null").toString());
                        }
                    } else
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append(s).append(".cacheResponse != null").toString());
                    }
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append(s).append(".networkResponse != null").toString());
                }
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append(s).append(".body != null").toString());
            }
        }

        public Builder addHeader(String s, String s1)
        {
            headers.add(s, s1);
            return this;
        }

        public Builder body(ResponseBody responsebody)
        {
            body = responsebody;
            return this;
        }

        public Response build()
        {
            if (request != null)
            {
                if (protocol != null)
                {
                    if (code >= 0)
                    {
                        return new Response(this);
                    } else
                    {
                        throw new IllegalStateException((new StringBuilder()).append("code < 0: ").append(code).toString());
                    }
                } else
                {
                    throw new IllegalStateException("protocol == null");
                }
            } else
            {
                throw new IllegalStateException("request == null");
            }
        }

        public Builder cacheResponse(Response response)
        {
            if (response != null)
            {
                checkSupportResponse("cacheResponse", response);
            }
            cacheResponse = response;
            return this;
        }

        public Builder code(int i)
        {
            code = i;
            return this;
        }

        public Builder handshake(Handshake handshake1)
        {
            handshake = handshake1;
            return this;
        }

        public Builder header(String s, String s1)
        {
            headers.set(s, s1);
            return this;
        }

        public Builder headers(Headers headers1)
        {
            headers = headers1.newBuilder();
            return this;
        }

        public Builder message(String s)
        {
            message = s;
            return this;
        }

        public Builder networkResponse(Response response)
        {
            if (response != null)
            {
                checkSupportResponse("networkResponse", response);
            }
            networkResponse = response;
            return this;
        }

        public Builder priorResponse(Response response)
        {
            if (response != null)
            {
                checkPriorResponse(response);
            }
            priorResponse = response;
            return this;
        }

        public Builder protocol(Protocol protocol1)
        {
            protocol = protocol1;
            return this;
        }

        public Builder receivedResponseAtMillis(long l)
        {
            receivedResponseAtMillis = l;
            return this;
        }

        public Builder removeHeader(String s)
        {
            headers.removeAll(s);
            return this;
        }

        public Builder request(Request request1)
        {
            request = request1;
            return this;
        }

        public Builder sentRequestAtMillis(long l)
        {
            sentRequestAtMillis = l;
            return this;
        }

        public Builder()
        {
            code = -1;
            headers = new Headers.Builder();
        }

        Builder(Response response)
        {
            code = -1;
            request = response.request;
            protocol = response.protocol;
            code = response.code;
            message = response.message;
            handshake = response.handshake;
            headers = response.headers.newBuilder();
            body = response.body;
            networkResponse = response.networkResponse;
            cacheResponse = response.cacheResponse;
            priorResponse = response.priorResponse;
            sentRequestAtMillis = response.sentRequestAtMillis;
            receivedResponseAtMillis = response.receivedResponseAtMillis;
        }
    }


    final ResponseBody body;
    private volatile CacheControl cacheControl;
    final Response cacheResponse;
    final int code;
    final Handshake handshake;
    final Headers headers;
    final String message;
    final Response networkResponse;
    final Response priorResponse;
    final Protocol protocol;
    final long receivedResponseAtMillis;
    final Request request;
    final long sentRequestAtMillis;

    Response(Builder builder)
    {
        request = builder.request;
        protocol = builder.protocol;
        code = builder.code;
        message = builder.message;
        handshake = builder.handshake;
        headers = builder.headers.build();
        body = builder.body;
        networkResponse = builder.networkResponse;
        cacheResponse = builder.cacheResponse;
        priorResponse = builder.priorResponse;
        sentRequestAtMillis = builder.sentRequestAtMillis;
        receivedResponseAtMillis = builder.receivedResponseAtMillis;
    }

    public ResponseBody body()
    {
        return body;
    }

    public CacheControl cacheControl()
    {
        CacheControl cachecontrol1 = cacheControl;
        CacheControl cachecontrol = cachecontrol1;
        if (cachecontrol1 == null)
        {
            cachecontrol = CacheControl.parse(headers);
            cacheControl = cachecontrol;
        }
        return cachecontrol;
    }

    public Response cacheResponse()
    {
        return cacheResponse;
    }

    public List challenges()
    {
        if (code == 401) goto _L2; else goto _L1
_L1:
        String s;
        if (code != 407)
        {
            return Collections.emptyList();
        }
        s = "Proxy-Authenticate";
          goto _L3
_L2:
        s = "WWW-Authenticate";
_L5:
        return HttpHeaders.parseChallenges(headers(), s);
_L3:
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void close()
    {
        body.close();
    }

    public int code()
    {
        return code;
    }

    public Handshake handshake()
    {
        return handshake;
    }

    public String header(String s)
    {
        return header(s, null);
    }

    public String header(String s, String s1)
    {
        s = headers.get(s);
        if (s == null)
        {
            return s1;
        } else
        {
            return s;
        }
    }

    public List headers(String s)
    {
        return headers.values(s);
    }

    public Headers headers()
    {
        return headers;
    }

    public boolean isRedirect()
    {
        switch (code)
        {
        case 304: 
        case 305: 
        case 306: 
        default:
            return false;

        case 300: 
        case 301: 
        case 302: 
        case 303: 
        case 307: 
        case 308: 
            return true;
        }
    }

    public boolean isSuccessful()
    {
        while (code < 200 || code >= 300) 
        {
            return false;
        }
        return true;
    }

    public String message()
    {
        return message;
    }

    public Response networkResponse()
    {
        return networkResponse;
    }

    public Builder newBuilder()
    {
        return new Builder(this);
    }

    public ResponseBody peekBody(long l)
        throws IOException
    {
        Object obj = body.source();
        ((BufferedSource) (obj)).request(l);
        obj = ((BufferedSource) (obj)).buffer().clone();
        boolean flag;
        if (((Buffer) (obj)).size() <= l)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            Buffer buffer = new Buffer();
            buffer.write(((Buffer) (obj)), l);
            ((Buffer) (obj)).clear();
            obj = buffer;
        }
        return ResponseBody.create(body.contentType(), ((Buffer) (obj)).size(), ((BufferedSource) (obj)));
    }

    public Response priorResponse()
    {
        return priorResponse;
    }

    public Protocol protocol()
    {
        return protocol;
    }

    public long receivedResponseAtMillis()
    {
        return receivedResponseAtMillis;
    }

    public Request request()
    {
        return request;
    }

    public long sentRequestAtMillis()
    {
        return sentRequestAtMillis;
    }

    public String toString()
    {
        return (new StringBuilder()).append("Response{protocol=").append(protocol).append(", code=").append(code).append(", message=").append(message).append(", url=").append(request.url()).append('}').toString();
    }
}
