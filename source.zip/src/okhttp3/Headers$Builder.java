// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.util.ArrayList;
import java.util.List;
import okhttp3.internal.Util;

// Referenced classes of package okhttp3:
//            Headers

public static final class tException
{

    final List namesAndValues = new ArrayList(20);

    private void checkNameAndValue(String s, String s1)
    {
        if (s == null) goto _L2; else goto _L1
_L1:
        if (s.isEmpty()) goto _L4; else goto _L3
_L3:
        int i;
        int j;
        j = s.length();
        i = 0;
_L6:
        if (i >= j)
        {
            if (s1 != null)
            {
                j = s1.length();
                i = 0;
                break MISSING_BLOCK_LABEL_37;
            } else
            {
                throw new NullPointerException("value == null");
            }
        } else
        {
            for (char c = s.charAt(i); c <= '\037' || c >= '\177';)
            {
                throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in header name: %s", new Object[] {
                    Integer.valueOf(c), Integer.valueOf(i), s
                }));
            }

            i++;
            continue; /* Loop/switch isn't completed */
        }
_L2:
        throw new NullPointerException("name == null");
_L4:
        throw new IllegalArgumentException("name is empty");
        char c1;
        do
        {
            if (i >= j)
            {
                return;
            }
            c1 = s1.charAt(i);
            if ((c1 > '\037' || c1 == '\t') && c1 < '\177')
            {
                i++;
            } else
            {
                break;
            }
        } while (true);
        throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in %s value: %s", new Object[] {
            Integer.valueOf(c1), Integer.valueOf(i), s, s1
        }));
        if (true) goto _L6; else goto _L5
_L5:
    }

    public f add(String s)
    {
        int i = s.indexOf(":");
        if (i != -1)
        {
            return add(s.substring(0, i).trim(), s.substring(i + 1));
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Unexpected header: ").append(s).toString());
        }
    }

    public toString add(String s, String s1)
    {
        checkNameAndValue(s, s1);
        return addLenient(s, s1);
    }

    addLenient addLenient(String s)
    {
        int i = s.indexOf(":", 1);
        if (i == -1)
        {
            if (!s.startsWith(":"))
            {
                return addLenient("", s);
            } else
            {
                return addLenient("", s.substring(1));
            }
        } else
        {
            return addLenient(s.substring(0, i), s.substring(i + 1));
        }
    }

    ng addLenient(String s, String s1)
    {
        namesAndValues.add(s);
        namesAndValues.add(s1.trim());
        return this;
    }

    public Headers build()
    {
        return new Headers(this);
    }

    public String get(String s)
    {
        int i = namesAndValues.size() - 2;
        do
        {
            if (i < 0)
            {
                return null;
            }
            if (!s.equalsIgnoreCase((String)namesAndValues.get(i)))
            {
                i -= 2;
            } else
            {
                return (String)namesAndValues.get(i + 1);
            }
        } while (true);
    }

    public namesAndValues removeAll(String s)
    {
        int i = 0;
        do
        {
            if (i >= namesAndValues.size())
            {
                return this;
            }
            if (s.equalsIgnoreCase((String)namesAndValues.get(i)))
            {
                namesAndValues.remove(i);
                namesAndValues.remove(i);
                i -= 2;
            }
            i += 2;
        } while (true);
    }

    public namesAndValues set(String s, String s1)
    {
        checkNameAndValue(s, s1);
        removeAll(s);
        addLenient(s, s1);
        return this;
    }

    public tException()
    {
    }
}
