// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;

// Referenced classes of package okhttp3:
//            Route, Response, Request

public interface Authenticator
{

    public static final Authenticator NONE = new Authenticator() {

        public Request authenticate(Route route, Response response)
        {
            return null;
        }

    };

    public abstract Request authenticate(Route route, Response response)
        throws IOException;

}
