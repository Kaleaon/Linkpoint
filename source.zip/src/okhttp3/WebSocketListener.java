// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import okio.ByteString;

// Referenced classes of package okhttp3:
//            WebSocket, Response

public abstract class WebSocketListener
{

    public WebSocketListener()
    {
    }

    public void onClosed(WebSocket websocket, int i, String s)
    {
    }

    public void onClosing(WebSocket websocket, int i, String s)
    {
    }

    public void onFailure(WebSocket websocket, Throwable throwable, Response response)
    {
    }

    public void onMessage(WebSocket websocket, String s)
    {
    }

    public void onMessage(WebSocket websocket, ByteString bytestring)
    {
    }

    public void onOpen(WebSocket websocket, Response response)
    {
    }
}
