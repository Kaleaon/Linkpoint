// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.net.URL;
import okhttp3.internal.Util;
import okhttp3.internal.http.HttpMethod;

// Referenced classes of package okhttp3:
//            Request, Headers, CacheControl, HttpUrl, 
//            RequestBody

public static class er
{

    RequestBody body;
    eption headers;
    String method;
    Object tag;
    HttpUrl url;

    public er addHeader(String s, String s1)
    {
        headers.add(s, s1);
        return this;
    }

    public Request build()
    {
        if (url != null)
        {
            return new Request(this);
        } else
        {
            throw new IllegalStateException("url == null");
        }
    }

    public ception cacheControl(CacheControl cachecontrol)
    {
        cachecontrol = cachecontrol.toString();
        if (!cachecontrol.isEmpty())
        {
            return header("Cache-Control", cachecontrol);
        } else
        {
            return removeHeader("Cache-Control");
        }
    }

    public removeHeader delete()
    {
        return delete(Util.EMPTY_REQUEST);
    }

    public PTY_REQUEST delete(RequestBody requestbody)
    {
        return method("DELETE", requestbody);
    }

    public method get()
    {
        return method("GET", null);
    }

    public method head()
    {
        return method("HEAD", null);
    }

    public method header(String s, String s1)
    {
        headers.set(s, s1);
        return this;
    }

    public set headers(Headers headers1)
    {
        headers = headers1.newBuilder();
        return this;
    }

    public er method(String s, RequestBody requestbody)
    {
        if (s != null)
        {
            if (s.length() != 0)
            {
                if (requestbody == null || HttpMethod.permitsRequestBody(s))
                {
                    if (requestbody != null || !HttpMethod.requiresRequestBody(s))
                    {
                        method = s;
                        body = requestbody;
                        return this;
                    } else
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("method ").append(s).append(" must have a request body.").toString());
                    }
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("method ").append(s).append(" must not have a request body.").toString());
                }
            } else
            {
                throw new IllegalArgumentException("method.length() == 0");
            }
        } else
        {
            throw new NullPointerException("method == null");
        }
    }

    public eption patch(RequestBody requestbody)
    {
        return method("PATCH", requestbody);
    }

    public method post(RequestBody requestbody)
    {
        return method("POST", requestbody);
    }

    public method put(RequestBody requestbody)
    {
        return method("PUT", requestbody);
    }

    public method removeHeader(String s)
    {
        headers.removeAll(s);
        return this;
    }

    public removeAll tag(Object obj)
    {
        tag = obj;
        return this;
    }

    public tag url(String s)
    {
        if (s != null)
        {
            HttpUrl httpurl;
            if (!s.regionMatches(true, 0, "ws:", 0, 3))
            {
                if (s.regionMatches(true, 0, "wss:", 0, 4))
                {
                    s = (new StringBuilder()).append("https:").append(s.substring(4)).toString();
                }
            } else
            {
                s = (new StringBuilder()).append("http:").append(s.substring(3)).toString();
            }
            httpurl = HttpUrl.parse(s);
            if (httpurl != null)
            {
                return url(httpurl);
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected url: ").append(s).toString());
            }
        } else
        {
            throw new NullPointerException("url == null");
        }
    }

    public eption url(URL url1)
    {
        if (url1 != null)
        {
            HttpUrl httpurl = HttpUrl.get(url1);
            if (httpurl != null)
            {
                return url(httpurl);
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("unexpected url: ").append(url1).toString());
            }
        } else
        {
            throw new NullPointerException("url == null");
        }
    }

    public eption url(HttpUrl httpurl)
    {
        if (httpurl != null)
        {
            url = httpurl;
            return this;
        } else
        {
            throw new NullPointerException("url == null");
        }
    }

    public tpMethod()
    {
        method = "GET";
        headers = new <init>();
    }

    <init>(Request request)
    {
        url = request.url;
        method = request.method;
        body = request.body;
        tag = request.tag;
        headers = request.headers.newBuilder();
    }
}
