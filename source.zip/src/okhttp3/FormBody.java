// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okhttp3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;

// Referenced classes of package okhttp3:
//            RequestBody, MediaType, HttpUrl

public final class FormBody extends RequestBody
{
    public static final class Builder
    {

        private final List names = new ArrayList();
        private final List values = new ArrayList();

        public Builder add(String s, String s1)
        {
            names.add(HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
            values.add(HttpUrl.canonicalize(s1, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
            return this;
        }

        public Builder addEncoded(String s, String s1)
        {
            names.add(HttpUrl.canonicalize(s, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
            values.add(HttpUrl.canonicalize(s1, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
            return this;
        }

        public FormBody build()
        {
            return new FormBody(names, values);
        }

        public Builder()
        {
        }
    }


    private static final MediaType CONTENT_TYPE = MediaType.parse("application/x-www-form-urlencoded");
    private final List encodedNames;
    private final List encodedValues;

    FormBody(List list, List list1)
    {
        encodedNames = Util.immutableList(list);
        encodedValues = Util.immutableList(list1);
    }

    private long writeOrCountBytes(BufferedSink bufferedsink, boolean flag)
    {
        int i = 0;
        int j;
        if (!flag)
        {
            bufferedsink = bufferedsink.buffer();
        } else
        {
            bufferedsink = new Buffer();
        }
        j = encodedNames.size();
        do
        {
            if (i >= j)
            {
                if (!flag)
                {
                    return 0L;
                } else
                {
                    long l = bufferedsink.size();
                    bufferedsink.clear();
                    return l;
                }
            }
            if (i > 0)
            {
                bufferedsink.writeByte(38);
            }
            bufferedsink.writeUtf8((String)encodedNames.get(i));
            bufferedsink.writeByte(61);
            bufferedsink.writeUtf8((String)encodedValues.get(i));
            i++;
        } while (true);
    }

    public long contentLength()
    {
        return writeOrCountBytes(null, true);
    }

    public MediaType contentType()
    {
        return CONTENT_TYPE;
    }

    public String encodedName(int i)
    {
        return (String)encodedNames.get(i);
    }

    public String encodedValue(int i)
    {
        return (String)encodedValues.get(i);
    }

    public String name(int i)
    {
        return HttpUrl.percentDecode(encodedName(i), true);
    }

    public int size()
    {
        return encodedNames.size();
    }

    public String value(int i)
    {
        return HttpUrl.percentDecode(encodedValue(i), true);
    }

    public void writeTo(BufferedSink bufferedsink)
        throws IOException
    {
        writeOrCountBytes(bufferedsink, false);
    }

}
