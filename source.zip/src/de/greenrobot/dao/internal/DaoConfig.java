// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.internal;

import android.database.sqlite.SQLiteDatabase;
import de.greenrobot.dao.DaoException;
import de.greenrobot.dao.Property;
import de.greenrobot.dao.identityscope.IdentityScope;
import de.greenrobot.dao.identityscope.IdentityScopeLong;
import de.greenrobot.dao.identityscope.IdentityScopeObject;
import de.greenrobot.dao.identityscope.IdentityScopeType;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package de.greenrobot.dao.internal:
//            TableStatements

public final class DaoConfig
    implements Cloneable
{

    public final String allColumns[];
    public final SQLiteDatabase db;
    private IdentityScope identityScope;
    public final boolean keyIsNumeric;
    public final String nonPkColumns[];
    public final String pkColumns[];
    public final Property pkProperty;
    public final Property properties[];
    public final TableStatements statements;
    public final String tablename;

    public DaoConfig(SQLiteDatabase sqlitedatabase, Class class1)
    {
        int i;
        db = sqlitedatabase;
        Property property;
        Property aproperty[];
        ArrayList arraylist;
        ArrayList arraylist1;
        String s;
        try
        {
            tablename = (String)class1.getField("TABLENAME").get(null);
            aproperty = reflectProperties(class1);
            properties = aproperty;
            allColumns = new String[aproperty.length];
            arraylist = new ArrayList();
            arraylist1 = new ArrayList();
        }
        // Misplaced declaration of an exception variable
        catch (SQLiteDatabase sqlitedatabase)
        {
            throw new DaoException("Could not init DAOConfig", sqlitedatabase);
        }
        i = 0;
        class1 = null;
_L9:
        if (i < aproperty.length) goto _L2; else goto _L1
_L1:
        nonPkColumns = (String[])arraylist1.toArray(new String[arraylist1.size()]);
        pkColumns = (String[])arraylist.toArray(new String[arraylist.size()]);
        if (pkColumns.length != 1)
        {
            class1 = null;
        }
        pkProperty = class1;
        statements = new TableStatements(sqlitedatabase, tablename, allColumns, pkColumns);
        if (pkProperty == null)
        {
            keyIsNumeric = false;
            return;
        }
          goto _L3
_L2:
        property = aproperty[i];
        s = property.columnName;
        allColumns[i] = s;
        if (property.primaryKey) goto _L5; else goto _L4
_L4:
        arraylist1.add(s);
          goto _L6
_L5:
        arraylist.add(s);
        class1 = property;
          goto _L6
_L3:
        sqlitedatabase = pkProperty.type;
        if (sqlitedatabase.equals(Long.TYPE))
        {
            break MISSING_BLOCK_LABEL_361;
        }
          goto _L7
_L8:
        boolean flag;
        keyIsNumeric = flag;
        return;
_L7:
        if (sqlitedatabase.equals(java/lang/Long) || sqlitedatabase.equals(Integer.TYPE) || sqlitedatabase.equals(java/lang/Integer) || sqlitedatabase.equals(Short.TYPE) || sqlitedatabase.equals(java/lang/Short) || sqlitedatabase.equals(Byte.TYPE))
        {
            break MISSING_BLOCK_LABEL_361;
        }
        flag = sqlitedatabase.equals(java/lang/Byte);
        if (flag)
        {
            break MISSING_BLOCK_LABEL_361;
        }
        flag = false;
          goto _L8
_L6:
        i++;
          goto _L9
        flag = true;
          goto _L8
    }

    public DaoConfig(DaoConfig daoconfig)
    {
        db = daoconfig.db;
        tablename = daoconfig.tablename;
        properties = daoconfig.properties;
        allColumns = daoconfig.allColumns;
        pkColumns = daoconfig.pkColumns;
        nonPkColumns = daoconfig.nonPkColumns;
        pkProperty = daoconfig.pkProperty;
        statements = daoconfig.statements;
        keyIsNumeric = daoconfig.keyIsNumeric;
    }

    private static Property[] reflectProperties(Class class1)
        throws ClassNotFoundException, IllegalArgumentException, IllegalAccessException
    {
        Object aobj[];
        int i;
        int j;
        aobj = Class.forName((new StringBuilder()).append(class1.getName()).append("$Properties").toString()).getDeclaredFields();
        class1 = new ArrayList();
        j = aobj.length;
        i = 0;
_L9:
        if (i < j) goto _L2; else goto _L1
_L1:
        aobj = new Property[class1.size()];
        class1 = class1.iterator();
_L7:
        if (!class1.hasNext())
        {
            return ((Property []) (aobj));
        }
          goto _L3
_L2:
        Object obj = aobj[i];
        if ((((Field) (obj)).getModifiers() & 9) == 9) goto _L5; else goto _L4
_L4:
        i++;
        continue; /* Loop/switch isn't completed */
_L5:
        obj = ((Field) (obj)).get(null);
        if (obj instanceof Property)
        {
            class1.add((Property)obj);
        }
        if (true) goto _L4; else goto _L3
_L3:
        Property property = (Property)class1.next();
        if (aobj[property.ordinal] != null)
        {
            break; /* Loop/switch isn't completed */
        }
        aobj[property.ordinal] = property;
        if (true) goto _L7; else goto _L6
_L6:
        throw new DaoException("Duplicate property ordinals");
        if (true) goto _L9; else goto _L8
_L8:
    }

    public DaoConfig clone()
    {
        return new DaoConfig(this);
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public IdentityScope getIdentityScope()
    {
        return identityScope;
    }

    public void initIdentityScope(IdentityScopeType identityscopetype)
    {
        if (identityscopetype != IdentityScopeType.None)
        {
            if (identityscopetype != IdentityScopeType.Session)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("Unsupported type: ").append(identityscopetype).toString());
            }
        } else
        {
            identityScope = null;
            return;
        }
        if (!keyIsNumeric)
        {
            identityScope = new IdentityScopeObject();
            return;
        } else
        {
            identityScope = new IdentityScopeLong();
            return;
        }
    }

    public void setIdentityScope(IdentityScope identityscope)
    {
        identityScope = identityscope;
    }
}
