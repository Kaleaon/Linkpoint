// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.query;

import android.os.Process;
import android.util.SparseArray;
import de.greenrobot.dao.AbstractDao;
import java.lang.ref.WeakReference;

// Referenced classes of package de.greenrobot.dao.query:
//            AbstractQuery

abstract class AbstractQueryData
{

    final AbstractDao dao;
    final String initialValues[];
    final SparseArray queriesForThreads = new SparseArray();
    final String sql;

    AbstractQueryData(AbstractDao abstractdao, String s, String as[])
    {
        dao = abstractdao;
        sql = s;
        initialValues = as;
    }

    protected abstract AbstractQuery createQuery();

    AbstractQuery forCurrentThread()
    {
        int i = Process.myTid();
        SparseArray sparsearray = queriesForThreads;
        sparsearray;
        JVM INSTR monitorenter ;
        Object obj = (WeakReference)queriesForThreads.get(i);
        if (obj != null) goto _L2; else goto _L1
_L1:
        obj = null;
_L7:
        if (obj == null) goto _L4; else goto _L3
_L3:
        System.arraycopy(initialValues, 0, ((AbstractQuery) (obj)).parameters, 0, initialValues.length);
_L5:
        sparsearray;
        JVM INSTR monitorexit ;
        return ((AbstractQuery) (obj));
_L2:
        obj = (AbstractQuery)((WeakReference) (obj)).get();
        continue; /* Loop/switch isn't completed */
_L4:
        gc();
        obj = createQuery();
        queriesForThreads.put(i, new WeakReference(obj));
          goto _L5
        Exception exception;
        exception;
        sparsearray;
        JVM INSTR monitorexit ;
        throw exception;
        if (true) goto _L7; else goto _L6
_L6:
    }

    AbstractQuery forCurrentThread(AbstractQuery abstractquery)
    {
        if (Thread.currentThread() != abstractquery.ownerThread)
        {
            return forCurrentThread();
        } else
        {
            System.arraycopy(initialValues, 0, abstractquery.parameters, 0, initialValues.length);
            return abstractquery;
        }
    }

    void gc()
    {
        SparseArray sparsearray = queriesForThreads;
        sparsearray;
        JVM INSTR monitorenter ;
        int i = queriesForThreads.size() - 1;
_L2:
        if (i >= 0)
        {
            break MISSING_BLOCK_LABEL_24;
        }
        sparsearray;
        JVM INSTR monitorexit ;
        return;
        if (((WeakReference)queriesForThreads.valueAt(i)).get() != null)
        {
            break MISSING_BLOCK_LABEL_67;
        }
        queriesForThreads.remove(queriesForThreads.keyAt(i));
        break MISSING_BLOCK_LABEL_67;
        Exception exception;
        exception;
        sparsearray;
        JVM INSTR monitorexit ;
        throw exception;
        i--;
        if (true) goto _L2; else goto _L1
_L1:
    }
}
