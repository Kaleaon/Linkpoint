// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.query;

import android.database.sqlite.SQLiteDatabase;
import de.greenrobot.dao.AbstractDao;
import de.greenrobot.dao.DaoException;
import de.greenrobot.dao.InternalQueryDaoAccess;
import java.util.List;

// Referenced classes of package de.greenrobot.dao.query:
//            AbstractQuery, LazyList, CloseableListIterator, AbstractQueryData

public class Query extends AbstractQuery
{
    private static final class QueryData extends AbstractQueryData
    {

        private final int limitPosition;
        private final int offsetPosition;

        protected volatile AbstractQuery createQuery()
        {
            return createQuery();
        }

        protected Query createQuery()
        {
            return new Query(this, dao, sql, (String[])initialValues.clone(), limitPosition, offsetPosition);
        }

        QueryData(AbstractDao abstractdao, String s, String as[], int i, int j)
        {
            super(abstractdao, s, as);
            limitPosition = i;
            offsetPosition = j;
        }
    }


    private final int limitPosition;
    private final int offsetPosition;
    private final QueryData queryData;

    private Query(QueryData querydata, AbstractDao abstractdao, String s, String as[], int i, int j)
    {
        super(abstractdao, s, as);
        queryData = querydata;
        limitPosition = i;
        offsetPosition = j;
    }


    static Query create(AbstractDao abstractdao, String s, Object aobj[], int i, int j)
    {
        return (Query)(new QueryData(abstractdao, s, toStringArray(aobj), i, j)).forCurrentThread();
    }

    public static Query internalCreate(AbstractDao abstractdao, String s, Object aobj[])
    {
        return create(abstractdao, s, aobj, -1, -1);
    }

    public Query forCurrentThread()
    {
        return (Query)queryData.forCurrentThread(this);
    }

    public List list()
    {
        checkThread();
        android.database.Cursor cursor = dao.getDatabase().rawQuery(sql, parameters);
        return daoAccess.loadAllAndCloseCursor(cursor);
    }

    public CloseableListIterator listIterator()
    {
        return listLazyUncached().listIteratorAutoClose();
    }

    public LazyList listLazy()
    {
        checkThread();
        android.database.Cursor cursor = dao.getDatabase().rawQuery(sql, parameters);
        return new LazyList(daoAccess, cursor, true);
    }

    public LazyList listLazyUncached()
    {
        checkThread();
        android.database.Cursor cursor = dao.getDatabase().rawQuery(sql, parameters);
        return new LazyList(daoAccess, cursor, false);
    }

    public void setLimit(int i)
    {
        checkThread();
        if (limitPosition != -1)
        {
            parameters[limitPosition] = Integer.toString(i);
            return;
        } else
        {
            throw new IllegalStateException("Limit must be set with QueryBuilder before it can be used here");
        }
    }

    public void setOffset(int i)
    {
        checkThread();
        if (offsetPosition != -1)
        {
            parameters[offsetPosition] = Integer.toString(i);
            return;
        } else
        {
            throw new IllegalStateException("Offset must be set with QueryBuilder before it can be used here");
        }
    }

    public void setParameter(int i, Object obj)
    {
        while (i >= 0 && (i == limitPosition || i == offsetPosition)) 
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Illegal parameter index: ").append(i).toString());
        }
        super.setParameter(i, obj);
    }

    public Object unique()
    {
        checkThread();
        android.database.Cursor cursor = dao.getDatabase().rawQuery(sql, parameters);
        return daoAccess.loadUniqueAndCloseCursor(cursor);
    }

    public Object uniqueOrThrow()
    {
        Object obj = unique();
        if (obj != null)
        {
            return obj;
        } else
        {
            throw new DaoException("No entity found for query");
        }
    }
}
