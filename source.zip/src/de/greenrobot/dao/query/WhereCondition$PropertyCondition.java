// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.query;

import de.greenrobot.dao.DaoException;
import de.greenrobot.dao.Property;
import java.util.Date;
import java.util.UUID;

// Referenced classes of package de.greenrobot.dao.query:
//            WhereCondition

public static class op extends op
{

    public final String op;
    public final Property property;

    private static Object checkValueForType(Property property1, Object obj)
    {
        while (obj == null || !obj.getClass().isArray()) 
        {
label0:
            {
                Class class1 = property1.type;
                if (class1 != java/util/Date)
                {
                    if (class1 != java/util/UUID)
                    {
                        if (property1.type == Boolean.TYPE || property1.type == java/lang/Boolean)
                        {
                            if (!(obj instanceof Boolean))
                            {
                                int i;
                                if (!(obj instanceof Number))
                                {
                                    if (obj instanceof String)
                                    {
                                        break label0;
                                    }
                                } else
                                {
                                    int j = ((Number)obj).intValue();
                                    if (j != 0 && j != 1)
                                    {
                                        throw new DaoException((new StringBuilder()).append("Illegal boolean value: numbers must be 0 or 1, but was ").append(obj).toString());
                                    }
                                }
                                return obj;
                            } else
                            {
                                if (!((Boolean)obj).booleanValue())
                                {
                                    i = 0;
                                } else
                                {
                                    i = 1;
                                }
                                return Integer.valueOf(i);
                            }
                        } else
                        {
                            return obj;
                        }
                    } else
                    if (!(obj instanceof UUID))
                    {
                        if (!(obj instanceof String))
                        {
                            throw new DaoException((new StringBuilder()).append("Illegal UUID value: expected java.util.UUID or String for value ").append(obj).toString());
                        } else
                        {
                            return obj;
                        }
                    } else
                    {
                        return ((UUID)obj).toString();
                    }
                } else
                if (!(obj instanceof Date))
                {
                    if (!(obj instanceof Long))
                    {
                        throw new DaoException((new StringBuilder()).append("Illegal date value: expected java.util.Date or Long for value ").append(obj).toString());
                    } else
                    {
                        return obj;
                    }
                } else
                {
                    return Long.valueOf(((Date)obj).getTime());
                }
            }
        }
        throw new DaoException("Illegal value: found array, but simple object required");
        property1 = (String)obj;
        if (!"TRUE".equalsIgnoreCase(property1))
        {
            if (!"FALSE".equalsIgnoreCase(property1))
            {
                throw new DaoException((new StringBuilder()).append("Illegal boolean value: Strings must be \"TRUE\" or \"FALSE\" (case insesnsitive), but was ").append(obj).toString());
            } else
            {
                return Integer.valueOf(0);
            }
        } else
        {
            return Integer.valueOf(1);
        }
    }

    private static Object[] checkValuesForType(Property property1, Object aobj[])
    {
        int i = 0;
        do
        {
            if (i >= aobj.length)
            {
                return aobj;
            }
            aobj[i] = checkValueForType(property1, aobj[i]);
            i++;
        } while (true);
    }

    public void appendTo(StringBuilder stringbuilder, String s)
    {
        if (s != null)
        {
            stringbuilder.append(s).append('.');
        }
        stringbuilder.append('\'').append(property.columnName).append('\'').append(op);
    }

    public (Property property1, String s)
    {
        property = property1;
        op = s;
    }

    public op(Property property1, String s, Object obj)
    {
        super(checkValueForType(property1, obj));
        property = property1;
        op = s;
    }

    public op(Property property1, String s, Object aobj[])
    {
        super(checkValuesForType(property1, aobj));
        property = property1;
        op = s;
    }
}
