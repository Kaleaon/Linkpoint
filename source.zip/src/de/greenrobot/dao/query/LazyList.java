// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.query;

import android.database.Cursor;
import de.greenrobot.dao.DaoException;
import de.greenrobot.dao.InternalQueryDaoAccess;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.concurrent.locks.ReentrantLock;

// Referenced classes of package de.greenrobot.dao.query:
//            CloseableListIterator

public class LazyList
    implements List, Closeable
{
    protected class LazyIterator
        implements CloseableListIterator
    {

        private final boolean closeWhenDone;
        private int index;
        final LazyList this$0;

        public void add(Object obj)
        {
            throw new UnsupportedOperationException();
        }

        public void close()
        {
            LazyList.this.close();
        }

        public boolean hasNext()
        {
            return index < size;
        }

        public boolean hasPrevious()
        {
            return index > 0;
        }

        public Object next()
        {
            Object obj;
            if (index < size)
            {
                obj = get(index);
                index = index + 1;
                break MISSING_BLOCK_LABEL_36;
            } else
            {
                throw new NoSuchElementException();
            }
            if (index != size || !closeWhenDone)
            {
                return obj;
            } else
            {
                close();
                return obj;
            }
        }

        public int nextIndex()
        {
            return index;
        }

        public Object previous()
        {
            if (index > 0)
            {
                index = index - 1;
                return get(index);
            } else
            {
                throw new NoSuchElementException();
            }
        }

        public int previousIndex()
        {
            return index - 1;
        }

        public void remove()
        {
            throw new UnsupportedOperationException();
        }

        public void set(Object obj)
        {
            throw new UnsupportedOperationException();
        }

        public LazyIterator(int i, boolean flag)
        {
            this$0 = LazyList.this;
            super();
            index = i;
            closeWhenDone = flag;
        }
    }


    private final Cursor cursor;
    private final InternalQueryDaoAccess daoAccess;
    private final List entities;
    private volatile int loadedCount;
    private final ReentrantLock lock = new ReentrantLock();
    private final int size;

    LazyList(InternalQueryDaoAccess internalquerydaoaccess, Cursor cursor1, boolean flag)
    {
        int i = 0;
        super();
        cursor = cursor1;
        daoAccess = internalquerydaoaccess;
        size = cursor1.getCount();
        if (!flag)
        {
            entities = null;
        } else
        {
            entities = new ArrayList(size);
            while (i < size) 
            {
                entities.add(null);
                i++;
            }
        }
        if (size == 0)
        {
            cursor1.close();
        }
    }

    public void add(int i, Object obj)
    {
        throw new UnsupportedOperationException();
    }

    public boolean add(Object obj)
    {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(int i, Collection collection)
    {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection collection)
    {
        throw new UnsupportedOperationException();
    }

    protected void checkCached()
    {
        if (entities != null)
        {
            return;
        } else
        {
            throw new DaoException("This operation only works with cached lazy lists");
        }
    }

    public void clear()
    {
        throw new UnsupportedOperationException();
    }

    public void close()
    {
        cursor.close();
    }

    public boolean contains(Object obj)
    {
        loadRemaining();
        return entities.contains(obj);
    }

    public boolean containsAll(Collection collection)
    {
        loadRemaining();
        return entities.containsAll(collection);
    }

    public Object get(int i)
    {
        if (entities != null)
        {
            break MISSING_BLOCK_LABEL_29;
        }
        lock.lock();
        Object obj = loadEntity(i);
        lock.unlock();
        return obj;
        obj = entities.get(i);
        if (obj != null)
        {
            return obj;
        }
        lock.lock();
        obj = entities.get(i);
        if (obj == null) goto _L2; else goto _L1
_L1:
        lock.unlock();
        return obj;
_L2:
        Object obj1;
        obj1 = loadEntity(i);
        entities.set(i, obj1);
        loadedCount = loadedCount + 1;
        obj = obj1;
        if (loadedCount != size) goto _L1; else goto _L3
_L3:
        cursor.close();
        obj = obj1;
          goto _L1
        Exception exception;
        exception;
        lock.unlock();
        throw exception;
        exception;
        lock.unlock();
        throw exception;
    }

    public int getLoadedCount()
    {
        return loadedCount;
    }

    public int indexOf(Object obj)
    {
        loadRemaining();
        return entities.indexOf(obj);
    }

    public boolean isClosed()
    {
        return cursor.isClosed();
    }

    public boolean isEmpty()
    {
        return size == 0;
    }

    public boolean isLoadedCompletely()
    {
        return loadedCount == size;
    }

    public Iterator iterator()
    {
        return new LazyIterator(0, false);
    }

    public int lastIndexOf(Object obj)
    {
        loadRemaining();
        return entities.lastIndexOf(obj);
    }

    public CloseableListIterator listIterator()
    {
        return new LazyIterator(0, false);
    }

    public volatile ListIterator listIterator()
    {
        return listIterator();
    }

    public ListIterator listIterator(int i)
    {
        return new LazyIterator(i, false);
    }

    public CloseableListIterator listIteratorAutoClose()
    {
        return new LazyIterator(0, true);
    }

    protected Object loadEntity(int i)
    {
        if (cursor.moveToPosition(i))
        {
            Object obj = daoAccess.loadCurrent(cursor, 0, true);
            if (obj != null)
            {
                return obj;
            } else
            {
                throw new DaoException((new StringBuilder()).append("Loading of entity failed (null) at position ").append(i).toString());
            }
        } else
        {
            throw new DaoException((new StringBuilder()).append("Could not move to cursor location ").append(i).toString());
        }
    }

    public void loadRemaining()
    {
        checkCached();
        int j = entities.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            get(i);
            i++;
        } while (true);
    }

    public Object peak(int i)
    {
        if (entities == null)
        {
            return null;
        } else
        {
            return entities.get(i);
        }
    }

    public Object remove(int i)
    {
        throw new UnsupportedOperationException();
    }

    public boolean remove(Object obj)
    {
        throw new UnsupportedOperationException();
    }

    public boolean removeAll(Collection collection)
    {
        throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection collection)
    {
        throw new UnsupportedOperationException();
    }

    public Object set(int i, Object obj)
    {
        throw new UnsupportedOperationException();
    }

    public int size()
    {
        return size;
    }

    public List subList(int i, int j)
    {
        checkCached();
        int k = i;
        do
        {
            if (k >= j)
            {
                return entities.subList(i, j);
            }
            entities.get(k);
            k++;
        } while (true);
    }

    public Object[] toArray()
    {
        loadRemaining();
        return entities.toArray();
    }

    public Object[] toArray(Object aobj[])
    {
        loadRemaining();
        return entities.toArray(aobj);
    }

}
