// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao.query;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import de.greenrobot.dao.AbstractDao;
import de.greenrobot.dao.DaoException;

// Referenced classes of package de.greenrobot.dao.query:
//            AbstractQuery, AbstractQueryData

public class CountQuery extends AbstractQuery
{
    private static final class QueryData extends AbstractQueryData
    {

        protected volatile AbstractQuery createQuery()
        {
            return createQuery();
        }

        protected CountQuery createQuery()
        {
            return new CountQuery(this, dao, sql, (String[])initialValues.clone());
        }

        private QueryData(AbstractDao abstractdao, String s, String as[])
        {
            super(abstractdao, s, as);
        }

    }


    private final QueryData queryData;

    private CountQuery(QueryData querydata, AbstractDao abstractdao, String s, String as[])
    {
        super(abstractdao, s, as);
        queryData = querydata;
    }


    static CountQuery create(AbstractDao abstractdao, String s, Object aobj[])
    {
        return (CountQuery)(new QueryData(abstractdao, s, toStringArray(aobj))).forCurrentThread();
    }

    public long count()
    {
        Cursor cursor;
        checkThread();
        cursor = dao.getDatabase().rawQuery(sql, parameters);
        long l;
        if (!cursor.moveToNext())
        {
            break MISSING_BLOCK_LABEL_67;
        }
        if (!cursor.isLast())
        {
            break MISSING_BLOCK_LABEL_86;
        }
        if (cursor.getColumnCount() != 1)
        {
            break MISSING_BLOCK_LABEL_118;
        }
        l = cursor.getLong(0);
        cursor.close();
        return l;
        throw new DaoException("No result for count");
        Exception exception;
        exception;
        cursor.close();
        throw exception;
        throw new DaoException((new StringBuilder()).append("Unexpected row count: ").append(cursor.getCount()).toString());
        throw new DaoException((new StringBuilder()).append("Unexpected column count: ").append(cursor.getColumnCount()).toString());
    }

    public CountQuery forCurrentThread()
    {
        return (CountQuery)queryData.forCurrentThread(this);
    }

    public volatile void setParameter(int i, Object obj)
    {
        super.setParameter(i, obj);
    }
}
