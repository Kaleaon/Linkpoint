// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package de.greenrobot.dao;

import android.database.CrossProcessCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import de.greenrobot.dao.identityscope.IdentityScope;
import de.greenrobot.dao.identityscope.IdentityScopeLong;
import de.greenrobot.dao.internal.DaoConfig;
import de.greenrobot.dao.internal.FastCursor;
import de.greenrobot.dao.internal.TableStatements;
import de.greenrobot.dao.query.Query;
import de.greenrobot.dao.query.QueryBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package de.greenrobot.dao:
//            Property, DaoException, DaoLog, AbstractDaoSession

public abstract class AbstractDao
{

    protected final DaoConfig config;
    protected final SQLiteDatabase db;
    protected IdentityScope identityScope;
    protected IdentityScopeLong identityScopeLong;
    protected final int pkOrdinal;
    protected final AbstractDaoSession session;
    protected TableStatements statements;

    public AbstractDao(DaoConfig daoconfig)
    {
        this(daoconfig, null);
    }

    public AbstractDao(DaoConfig daoconfig, AbstractDaoSession abstractdaosession)
    {
        config = daoconfig;
        session = abstractdaosession;
        db = daoconfig.db;
        identityScope = daoconfig.getIdentityScope();
        int i;
        if (identityScope instanceof IdentityScopeLong)
        {
            identityScopeLong = (IdentityScopeLong)identityScope;
        }
        statements = daoconfig.statements;
        if (daoconfig.pkProperty == null)
        {
            i = -1;
        } else
        {
            i = daoconfig.pkProperty.ordinal;
        }
        pkOrdinal = i;
    }

    private void deleteByKeyInsideSynchronized(Object obj, SQLiteStatement sqlitestatement)
    {
        if (obj instanceof Long) goto _L2; else goto _L1
_L1:
        if (obj == null) goto _L4; else goto _L3
_L3:
        sqlitestatement.bindString(1, obj.toString());
_L5:
        sqlitestatement.execute();
        return;
_L2:
        sqlitestatement.bindLong(1, ((Long)obj).longValue());
        if (true) goto _L5; else goto _L4
_L4:
        throw new DaoException("Cannot delete entity, key is null");
    }

    private void deleteInTxInternal(Iterable iterable, Iterable iterable1)
    {
        ArrayList arraylist;
        SQLiteStatement sqlitestatement;
        arraylist = null;
        assertSinglePk();
        sqlitestatement = statements.getDeleteStatement();
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        if (identityScope != null) goto _L2; else goto _L1
_L15:
        if (identityScope != null) goto _L4; else goto _L3
_L3:
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        if (arraylist != null) goto _L6; else goto _L5
_L5:
        db.endTransaction();
        return;
_L2:
        identityScope.lock();
        arraylist = new ArrayList();
          goto _L1
        iterable;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw iterable;
        iterable;
        db.endTransaction();
        throw iterable;
_L14:
        iterable = iterable.iterator();
_L8:
        Object obj;
        do
        {
            if (!iterable.hasNext())
            {
                break; /* Loop/switch isn't completed */
            }
            obj = getKeyVerified(iterable.next());
            deleteByKeyInsideSynchronized(obj, sqlitestatement);
        } while (arraylist == null);
        arraylist.add(obj);
        if (true) goto _L8; else goto _L7
_L7:
        iterable;
        if (identityScope != null) goto _L10; else goto _L9
_L9:
        throw iterable;
_L16:
        iterable = iterable1.iterator();
_L11:
        do
        {
            if (!iterable.hasNext())
            {
                break; /* Loop/switch isn't completed */
            }
            iterable1 = ((Iterable) (iterable.next()));
            deleteByKeyInsideSynchronized(iterable1, sqlitestatement);
        } while (arraylist == null);
        arraylist.add(iterable1);
          goto _L11
_L4:
        identityScope.unlock();
          goto _L3
_L10:
        identityScope.unlock();
          goto _L9
_L6:
        if (identityScope == null) goto _L5; else goto _L12
_L12:
        identityScope.remove(arraylist);
          goto _L5
_L1:
        if (iterable != null) goto _L14; else goto _L13
_L13:
        if (iterable1 != null) goto _L16; else goto _L15
    }

    private long executeInsert(Object obj, SQLiteStatement sqlitestatement)
    {
        if (db.isDbLockedByCurrentThread()) goto _L2; else goto _L1
_L1:
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        long l;
        bindValues(sqlitestatement, obj);
        l = sqlitestatement.executeInsert();
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        db.endTransaction();
_L4:
        updateKeyAfterInsertAndAttach(obj, l, true);
        return l;
_L2:
        sqlitestatement;
        JVM INSTR monitorenter ;
        bindValues(sqlitestatement, obj);
        l = sqlitestatement.executeInsert();
        sqlitestatement;
        JVM INSTR monitorexit ;
        if (true) goto _L4; else goto _L3
_L3:
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        db.endTransaction();
        throw obj;
    }

    private void executeInsertInTx(SQLiteStatement sqlitestatement, Iterable iterable, boolean flag)
    {
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        Object obj = identityScope;
        if (obj != null) goto _L2; else goto _L1
_L1:
        iterable = iterable.iterator();
_L9:
        boolean flag1 = iterable.hasNext();
        if (flag1) goto _L4; else goto _L3
_L3:
        if (identityScope != null) goto _L6; else goto _L5
_L5:
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        db.endTransaction();
        return;
_L2:
        identityScope.lock();
          goto _L1
        iterable;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw iterable;
        sqlitestatement;
        db.endTransaction();
        throw sqlitestatement;
_L4:
        obj = iterable.next();
        bindValues(sqlitestatement, obj);
        if (flag) goto _L8; else goto _L7
_L7:
        sqlitestatement.execute();
          goto _L9
        iterable;
        if (identityScope != null)
        {
            break MISSING_BLOCK_LABEL_153;
        }
_L10:
        throw iterable;
_L8:
        updateKeyAfterInsertAndAttach(obj, sqlitestatement.executeInsert(), false);
          goto _L9
_L6:
        identityScope.unlock();
          goto _L5
        identityScope.unlock();
          goto _L10
    }

    protected void assertSinglePk()
    {
        if (config.pkColumns.length == 1)
        {
            return;
        } else
        {
            throw new DaoException((new StringBuilder()).append(this).append(" (").append(config.tablename).append(") does not have a single-column primary key").toString());
        }
    }

    protected void attachEntity(Object obj)
    {
    }

    protected final void attachEntity(Object obj, Object obj1, boolean flag)
    {
        attachEntity(obj1);
        while (identityScope == null || obj == null) 
        {
            return;
        }
        if (!flag)
        {
            identityScope.putNoLock(obj, obj1);
            return;
        } else
        {
            identityScope.put(obj, obj1);
            return;
        }
    }

    protected abstract void bindValues(SQLiteStatement sqlitestatement, Object obj);

    public long count()
    {
        return DatabaseUtils.queryNumEntries(db, (new StringBuilder()).append('\'').append(config.tablename).append('\'').toString());
    }

    public void delete(Object obj)
    {
        assertSinglePk();
        deleteByKey(getKeyVerified(obj));
    }

    public void deleteAll()
    {
        db.execSQL((new StringBuilder()).append("DELETE FROM '").append(config.tablename).append("'").toString());
        if (identityScope == null)
        {
            return;
        } else
        {
            identityScope.clear();
            return;
        }
    }

    public void deleteByKey(Object obj)
    {
        SQLiteStatement sqlitestatement;
        assertSinglePk();
        sqlitestatement = statements.getDeleteStatement();
        if (db.isDbLockedByCurrentThread()) goto _L2; else goto _L1
_L1:
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        deleteByKeyInsideSynchronized(obj, sqlitestatement);
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        db.endTransaction();
_L3:
        if (identityScope == null)
        {
            return;
        } else
        {
            identityScope.remove(obj);
            return;
        }
_L2:
        sqlitestatement;
        JVM INSTR monitorenter ;
        deleteByKeyInsideSynchronized(obj, sqlitestatement);
        sqlitestatement;
        JVM INSTR monitorexit ;
          goto _L3
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        db.endTransaction();
        throw obj;
    }

    public void deleteByKeyInTx(Iterable iterable)
    {
        deleteInTxInternal(null, iterable);
    }

    public transient void deleteByKeyInTx(Object aobj[])
    {
        deleteInTxInternal(null, Arrays.asList(aobj));
    }

    public void deleteInTx(Iterable iterable)
    {
        deleteInTxInternal(iterable, null);
    }

    public transient void deleteInTx(Object aobj[])
    {
        deleteInTxInternal(Arrays.asList(aobj), null);
    }

    public boolean detach(Object obj)
    {
        if (identityScope == null)
        {
            return false;
        } else
        {
            Object obj1 = getKeyVerified(obj);
            return identityScope.detach(obj1, obj);
        }
    }

    public String[] getAllColumns()
    {
        return config.allColumns;
    }

    public SQLiteDatabase getDatabase()
    {
        return db;
    }

    protected abstract Object getKey(Object obj);

    protected Object getKeyVerified(Object obj)
    {
        Object obj1 = getKey(obj);
        if (obj1 != null)
        {
            return obj1;
        }
        if (obj != null)
        {
            throw new DaoException("Entity has no key");
        } else
        {
            throw new NullPointerException("Entity may not be null");
        }
    }

    public String[] getNonPkColumns()
    {
        return config.nonPkColumns;
    }

    public String[] getPkColumns()
    {
        return config.pkColumns;
    }

    public Property getPkProperty()
    {
        return config.pkProperty;
    }

    public Property[] getProperties()
    {
        return config.properties;
    }

    public AbstractDaoSession getSession()
    {
        return session;
    }

    TableStatements getStatements()
    {
        return config.statements;
    }

    public String getTablename()
    {
        return config.tablename;
    }

    public long insert(Object obj)
    {
        return executeInsert(obj, statements.getInsertStatement());
    }

    public void insertInTx(Iterable iterable)
    {
        insertInTx(iterable, isEntityUpdateable());
    }

    public void insertInTx(Iterable iterable, boolean flag)
    {
        executeInsertInTx(statements.getInsertStatement(), iterable, flag);
    }

    public transient void insertInTx(Object aobj[])
    {
        insertInTx(((Iterable) (Arrays.asList(aobj))), isEntityUpdateable());
    }

    public long insertOrReplace(Object obj)
    {
        return executeInsert(obj, statements.getInsertOrReplaceStatement());
    }

    public void insertOrReplaceInTx(Iterable iterable)
    {
        insertOrReplaceInTx(iterable, isEntityUpdateable());
    }

    public void insertOrReplaceInTx(Iterable iterable, boolean flag)
    {
        executeInsertInTx(statements.getInsertOrReplaceStatement(), iterable, flag);
    }

    public transient void insertOrReplaceInTx(Object aobj[])
    {
        insertOrReplaceInTx(((Iterable) (Arrays.asList(aobj))), isEntityUpdateable());
    }

    public long insertWithoutSettingPk(Object obj)
    {
        SQLiteStatement sqlitestatement;
        sqlitestatement = statements.getInsertStatement();
        if (db.isDbLockedByCurrentThread())
        {
            break MISSING_BLOCK_LABEL_56;
        }
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        long l;
        bindValues(sqlitestatement, obj);
        l = sqlitestatement.executeInsert();
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        db.endTransaction();
        return l;
        sqlitestatement;
        JVM INSTR monitorenter ;
        bindValues(sqlitestatement, obj);
        l = sqlitestatement.executeInsert();
        sqlitestatement;
        JVM INSTR monitorexit ;
        return l;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        db.endTransaction();
        throw obj;
    }

    protected abstract boolean isEntityUpdateable();

    public Object load(Object obj)
    {
        assertSinglePk();
        if (obj != null)
        {
            Object obj1;
            if (identityScope != null)
            {
                if ((obj1 = identityScope.get(obj)) != null)
                {
                    return obj1;
                }
            }
            obj1 = statements.getSelectByKey();
            obj = obj.toString();
            return loadUniqueAndCloseCursor(db.rawQuery(((String) (obj1)), new String[] {
                obj
            }));
        } else
        {
            return null;
        }
    }

    public List loadAll()
    {
        return loadAllAndCloseCursor(db.rawQuery(statements.getSelectAll(), null));
    }

    protected List loadAllAndCloseCursor(Cursor cursor)
    {
        List list = loadAllFromCursor(cursor);
        cursor.close();
        return list;
        Exception exception;
        exception;
        cursor.close();
        throw exception;
    }

    protected List loadAllFromCursor(Cursor cursor)
    {
        ArrayList arraylist;
        int i;
        i = cursor.getCount();
        arraylist = new ArrayList(i);
        if (cursor instanceof CrossProcessCursor) goto _L2; else goto _L1
_L1:
        Object obj = cursor;
_L7:
        if (((Cursor) (obj)).moveToFirst()) goto _L4; else goto _L3
_L3:
        return arraylist;
_L2:
        CursorWindow cursorwindow = ((CrossProcessCursor)cursor).getWindow();
        obj = cursor;
        if (cursorwindow != null)
        {
            if (cursorwindow.getNumRows() != i)
            {
                DaoLog.d((new StringBuilder()).append("Window vs. result size: ").append(cursorwindow.getNumRows()).append("/").append(i).toString());
                obj = cursor;
            } else
            {
                obj = new FastCursor(cursorwindow);
            }
        }
        continue; /* Loop/switch isn't completed */
_L4:
        boolean flag;
        if (identityScope != null)
        {
            identityScope.lock();
            identityScope.reserveRoom(i);
        }
        do
        {
            arraylist.add(loadCurrent(((Cursor) (obj)), 0, false));
            flag = ((Cursor) (obj)).moveToNext();
        } while (flag);
        if (identityScope == null) goto _L3; else goto _L5
_L5:
        identityScope.unlock();
        return arraylist;
        cursor;
        if (identityScope != null)
        {
            identityScope.unlock();
        }
        throw cursor;
        if (true) goto _L7; else goto _L6
_L6:
    }

    public Object loadByRowId(long l)
    {
        String s = Long.toString(l);
        return loadUniqueAndCloseCursor(db.rawQuery(statements.getSelectByRowId(), new String[] {
            s
        }));
    }

    protected final Object loadCurrent(Cursor cursor, int i, boolean flag)
    {
        if (identityScopeLong == null)
        {
            if (identityScope == null)
            {
                if (i == 0 || readKey(cursor, i) != null)
                {
                    cursor = ((Cursor) (readEntity(cursor, i)));
                    attachEntity(cursor);
                    return cursor;
                } else
                {
                    return null;
                }
            } else
            {
                for (Object obj2 = readKey(cursor, i); i == 0 || obj2 != null;)
                {
                    Object obj1;
                    if (!flag)
                    {
                        obj1 = identityScope.getNoLock(obj2);
                    } else
                    {
                        obj1 = identityScope.get(obj2);
                    }
                    if (obj1 == null)
                    {
                        cursor = ((Cursor) (readEntity(cursor, i)));
                        attachEntity(obj2, cursor, flag);
                        return cursor;
                    } else
                    {
                        return obj1;
                    }
                }

                return null;
            }
        } else
        {
            while (i == 0 || !cursor.isNull(pkOrdinal + i)) 
            {
                long l = cursor.getLong(pkOrdinal + i);
                Object obj;
                if (!flag)
                {
                    obj = identityScopeLong.get2NoLock(l);
                } else
                {
                    obj = identityScopeLong.get2(l);
                }
                if (obj == null)
                {
                    cursor = ((Cursor) (readEntity(cursor, i)));
                    attachEntity(cursor);
                    if (!flag)
                    {
                        identityScopeLong.put2NoLock(l, cursor);
                        return cursor;
                    } else
                    {
                        identityScopeLong.put2(l, cursor);
                        return cursor;
                    }
                } else
                {
                    return obj;
                }
            }
            return null;
        }
    }

    protected final Object loadCurrentOther(AbstractDao abstractdao, Cursor cursor, int i)
    {
        return abstractdao.loadCurrent(cursor, i, true);
    }

    protected Object loadUnique(Cursor cursor)
    {
        if (cursor.moveToFirst())
        {
            if (cursor.isLast())
            {
                return loadCurrent(cursor, 0, true);
            } else
            {
                throw new DaoException((new StringBuilder()).append("Expected unique result, but count was ").append(cursor.getCount()).toString());
            }
        } else
        {
            return null;
        }
    }

    protected Object loadUniqueAndCloseCursor(Cursor cursor)
    {
        Object obj = loadUnique(cursor);
        cursor.close();
        return obj;
        Exception exception;
        exception;
        cursor.close();
        throw exception;
    }

    public QueryBuilder queryBuilder()
    {
        return QueryBuilder.internalCreate(this);
    }

    public transient List queryRaw(String s, String as[])
    {
        return loadAllAndCloseCursor(db.rawQuery((new StringBuilder()).append(statements.getSelectAll()).append(s).toString(), as));
    }

    public transient Query queryRawCreate(String s, Object aobj[])
    {
        return queryRawCreateListArgs(s, Arrays.asList(aobj));
    }

    public Query queryRawCreateListArgs(String s, Collection collection)
    {
        return Query.internalCreate(this, (new StringBuilder()).append(statements.getSelectAll()).append(s).toString(), collection.toArray());
    }

    protected abstract Object readEntity(Cursor cursor, int i);

    protected abstract void readEntity(Cursor cursor, Object obj, int i);

    protected abstract Object readKey(Cursor cursor, int i);

    public void refresh(Object obj)
    {
        Object obj1;
        Object obj2;
        assertSinglePk();
        obj1 = getKeyVerified(obj);
        obj2 = statements.getSelectByKey();
        String s = obj1.toString();
        obj2 = db.rawQuery(((String) (obj2)), new String[] {
            s
        });
        if (!((Cursor) (obj2)).moveToFirst())
        {
            break MISSING_BLOCK_LABEL_81;
        }
        if (!((Cursor) (obj2)).isLast())
        {
            break MISSING_BLOCK_LABEL_131;
        }
        readEntity(((Cursor) (obj2)), obj, 0);
        attachEntity(obj1, obj, true);
        ((Cursor) (obj2)).close();
        return;
        throw new DaoException((new StringBuilder()).append("Entity does not exist in the database anymore: ").append(obj.getClass()).append(" with key ").append(obj1).toString());
        obj;
        ((Cursor) (obj2)).close();
        throw obj;
        throw new DaoException((new StringBuilder()).append("Expected unique result, but count was ").append(((Cursor) (obj2)).getCount()).toString());
    }

    public void update(Object obj)
    {
        SQLiteStatement sqlitestatement;
        assertSinglePk();
        sqlitestatement = statements.getUpdateStatement();
        if (db.isDbLockedByCurrentThread())
        {
            break MISSING_BLOCK_LABEL_55;
        }
        db.beginTransaction();
        sqlitestatement;
        JVM INSTR monitorenter ;
        updateInsideSynchronized(obj, sqlitestatement, true);
        sqlitestatement;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        db.endTransaction();
        return;
        sqlitestatement;
        JVM INSTR monitorenter ;
        updateInsideSynchronized(obj, sqlitestatement, true);
        sqlitestatement;
        JVM INSTR monitorexit ;
        return;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        sqlitestatement;
        JVM INSTR monitorexit ;
        throw obj;
        obj;
        db.endTransaction();
        throw obj;
    }

    public void updateInTx(Iterable iterable)
    {
        Object obj;
        obj = statements.getUpdateStatement();
        db.beginTransaction();
        obj;
        JVM INSTR monitorenter ;
        IdentityScope identityscope = identityScope;
        if (identityscope != null) goto _L2; else goto _L1
_L1:
        iterable = iterable.iterator();
_L7:
        boolean flag = iterable.hasNext();
        if (flag) goto _L4; else goto _L3
_L3:
        if (identityScope != null) goto _L6; else goto _L5
_L5:
        obj;
        JVM INSTR monitorexit ;
        db.setTransactionSuccessful();
        break MISSING_BLOCK_LABEL_62;
_L2:
        identityScope.lock();
        continue; /* Loop/switch isn't completed */
        iterable;
        obj;
        JVM INSTR monitorexit ;
        try
        {
            throw iterable;
        }
        // Misplaced declaration of an exception variable
        catch (Iterable iterable) { }
        finally { }
        try
        {
            db.endTransaction();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Object obj) { }
        if (iterable == null)
        {
            throw obj;
        } else
        {
            DaoLog.w("Could not end transaction (rethrowing initial exception)", ((Throwable) (obj)));
            throw iterable;
        }
_L4:
        updateInsideSynchronized(iterable.next(), ((SQLiteStatement) (obj)), false);
          goto _L7
        iterable;
        if (identityScope != null) goto _L9; else goto _L8
_L8:
        throw iterable;
        db.endTransaction();
        throw iterable;
_L6:
        identityScope.unlock();
          goto _L5
_L9:
        identityScope.unlock();
          goto _L8
        try
        {
            db.endTransaction();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Iterable iterable) { }
        if (true)
        {
            throw iterable;
        } else
        {
            DaoLog.w("Could not end transaction (rethrowing initial exception)", iterable);
            throw null;
        }
          goto _L5
        iterable;
        if (true)
        {
            throw iterable;
        }
        DaoLog.w("Could not end transaction (rethrowing initial exception)", iterable);
        throw null;
        if (true) goto _L1; else goto _L10
_L10:
    }

    public transient void updateInTx(Object aobj[])
    {
        updateInTx(((Iterable) (Arrays.asList(aobj))));
    }

    protected void updateInsideSynchronized(Object obj, SQLiteStatement sqlitestatement, boolean flag)
    {
        Object obj1;
        int i;
        bindValues(sqlitestatement, obj);
        i = config.allColumns.length + 1;
        obj1 = getKey(obj);
        if (obj1 instanceof Long) goto _L2; else goto _L1
_L1:
        if (obj1 == null) goto _L4; else goto _L3
_L3:
        sqlitestatement.bindString(i, obj1.toString());
_L5:
        sqlitestatement.execute();
        attachEntity(obj1, obj, flag);
        return;
_L2:
        sqlitestatement.bindLong(i, ((Long)obj1).longValue());
        if (true) goto _L5; else goto _L4
_L4:
        throw new DaoException("Cannot update entity without key - was it inserted before?");
    }

    protected abstract Object updateKeyAfterInsert(Object obj, long l);

    protected void updateKeyAfterInsertAndAttach(Object obj, long l, boolean flag)
    {
        if (l != -1L)
        {
            attachEntity(updateKeyAfterInsert(obj, l), obj, flag);
            return;
        } else
        {
            DaoLog.w("Could not insert row (executeInsert returned -1)");
            return;
        }
    }
}
