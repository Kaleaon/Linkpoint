// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package javax.annotation;

import java.lang.annotation.Annotation;
import javax.annotation.meta.TypeQualifierValidator;
import javax.annotation.meta.When;

public interface Nonnegative
    extends Annotation
{
    public static class Checker
        implements TypeQualifierValidator
    {

        public volatile When forConstantValue(Annotation annotation, Object obj)
        {
            return forConstantValue((Nonnegative)annotation, obj);
        }

        public When forConstantValue(Nonnegative nonnegative, Object obj)
        {
            boolean flag = true;
            boolean flag1 = false;
            if (obj instanceof Number)
            {
                nonnegative = (Number)obj;
                if (!(nonnegative instanceof Long))
                {
                    if (!(nonnegative instanceof Double))
                    {
                        if (!(nonnegative instanceof Float))
                        {
                            if (nonnegative.intValue() >= 0)
                            {
                                flag = flag1;
                            } else
                            {
                                flag = true;
                            }
                        } else
                        if (nonnegative.floatValue() >= 0.0F)
                        {
                            flag = false;
                        }
                    } else
                    if (nonnegative.doubleValue() >= 0.0D)
                    {
                        flag = false;
                    }
                } else
                {
                    boolean flag2;
                    if (nonnegative.longValue() >= 0L)
                    {
                        flag2 = true;
                    } else
                    {
                        flag2 = false;
                    }
                    if (flag2)
                    {
                        flag = false;
                    }
                }
                if (!flag)
                {
                    return When.ALWAYS;
                } else
                {
                    return When.NEVER;
                }
            } else
            {
                return When.NEVER;
            }
        }

        public Checker()
        {
        }
    }


    public abstract When when();
}
