// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package butterknife;

import android.app.Activity;
import android.app.Dialog;
import android.util.Log;
import android.util.Property;
import android.view.View;
import android.view.Window;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Referenced classes of package butterknife:
//            Unbinder

public final class ButterKnife
{
    public static interface Action
    {

        public abstract void apply(View view, int i);
    }

    public static interface Setter
    {

        public abstract void set(View view, Object obj, int i);
    }


    static final Map BINDINGS = new LinkedHashMap();
    private static final String TAG = "ButterKnife";
    private static boolean debug = false;

    private ButterKnife()
    {
        throw new AssertionError("No instances.");
    }

    public static void apply(View view, Property property, Object obj)
    {
        property.set(view, obj);
    }

    public static void apply(View view, Action action)
    {
        action.apply(view, 0);
    }

    public static void apply(View view, Setter setter, Object obj)
    {
        setter.set(view, obj, 0);
    }

    public static transient void apply(View view, Action aaction[])
    {
        int j = aaction.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            aaction[i].apply(view, 0);
            i++;
        } while (true);
    }

    public static void apply(List list, Property property, Object obj)
    {
        int i = 0;
        int j = list.size();
        do
        {
            if (i >= j)
            {
                return;
            }
            property.set(list.get(i), obj);
            i++;
        } while (true);
    }

    public static void apply(List list, Action action)
    {
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            action.apply((View)list.get(i), i);
            i++;
        } while (true);
    }

    public static void apply(List list, Setter setter, Object obj)
    {
        int j = list.size();
        int i = 0;
        do
        {
            if (i >= j)
            {
                return;
            }
            setter.set((View)list.get(i), obj, i);
            i++;
        } while (true);
    }

    public static transient void apply(List list, Action aaction[])
    {
        int i;
        int k;
        k = list.size();
        i = 0;
_L2:
        if (i >= k)
        {
            return;
        }
        int l = aaction.length;
        int j = 0;
        do
        {
label0:
            {
                if (j < l)
                {
                    break label0;
                }
                i++;
            }
            if (true)
            {
                continue;
            }
            aaction[j].apply((View)list.get(i), i);
            j++;
        } while (true);
        if (true) goto _L2; else goto _L1
_L1:
    }

    public static void apply(View aview[], Property property, Object obj)
    {
        int i = 0;
        int j = aview.length;
        do
        {
            if (i >= j)
            {
                return;
            }
            property.set(aview[i], obj);
            i++;
        } while (true);
    }

    public static void apply(View aview[], Action action)
    {
        int i = 0;
        int j = aview.length;
        do
        {
            if (i >= j)
            {
                return;
            }
            action.apply(aview[i], i);
            i++;
        } while (true);
    }

    public static void apply(View aview[], Setter setter, Object obj)
    {
        int i = 0;
        int j = aview.length;
        do
        {
            if (i >= j)
            {
                return;
            }
            setter.set(aview[i], obj, i);
            i++;
        } while (true);
    }

    public static transient void apply(View aview[], Action aaction[])
    {
        int i;
        int k;
        k = aview.length;
        i = 0;
_L2:
        if (i >= k)
        {
            return;
        }
        int l = aaction.length;
        int j = 0;
        do
        {
label0:
            {
                if (j < l)
                {
                    break label0;
                }
                i++;
            }
            if (true)
            {
                continue;
            }
            aaction[j].apply(aview[i], i);
            j++;
        } while (true);
        if (true) goto _L2; else goto _L1
_L1:
    }

    public static Unbinder bind(Activity activity)
    {
        return createBinding(activity, activity.getWindow().getDecorView());
    }

    public static Unbinder bind(Dialog dialog)
    {
        return createBinding(dialog, dialog.getWindow().getDecorView());
    }

    public static Unbinder bind(View view)
    {
        return createBinding(view, view);
    }

    public static Unbinder bind(Object obj, Activity activity)
    {
        return createBinding(obj, activity.getWindow().getDecorView());
    }

    public static Unbinder bind(Object obj, Dialog dialog)
    {
        return createBinding(obj, dialog.getWindow().getDecorView());
    }

    public static Unbinder bind(Object obj, View view)
    {
        return createBinding(obj, view);
    }

    private static Unbinder createBinding(Object obj, View view)
    {
        Object obj1 = obj.getClass();
        if (debug)
        {
            Log.d("ButterKnife", (new StringBuilder()).append("Looking up binding for ").append(((Class) (obj1)).getName()).toString());
        }
        obj1 = findBindingConstructorForClass(((Class) (obj1)));
        if (obj1 != null)
        {
            try
            {
                obj = (Unbinder)((Constructor) (obj1)).newInstance(new Object[] {
                    obj, view
                });
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                throw new RuntimeException((new StringBuilder()).append("Unable to invoke ").append(obj1).toString(), ((Throwable) (obj)));
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                throw new RuntimeException((new StringBuilder()).append("Unable to invoke ").append(obj1).toString(), ((Throwable) (obj)));
            }
            // Misplaced declaration of an exception variable
            catch (Object obj)
            {
                obj = ((InvocationTargetException) (obj)).getCause();
                if (!(obj instanceof RuntimeException))
                {
                    if (!(obj instanceof Error))
                    {
                        throw new RuntimeException("Unable to create binding instance.", ((Throwable) (obj)));
                    } else
                    {
                        throw (Error)obj;
                    }
                } else
                {
                    throw (RuntimeException)obj;
                }
            }
            return ((Unbinder) (obj));
        } else
        {
            return Unbinder.EMPTY;
        }
    }

    private static Constructor findBindingConstructorForClass(Class class1)
    {
        Object obj;
        String s;
label0:
        {
            Constructor constructor = (Constructor)BINDINGS.get(class1);
            if (constructor == null)
            {
                s = class1.getName();
                break label0;
            } else
            if (!debug)
            {
                return constructor;
            } else
            {
                Log.d("ButterKnife", "HIT: Cached in binding map.");
                return constructor;
            }
        }
        boolean flag;
        if (s.startsWith("android.") || s.startsWith("java."))
        {
            if (!debug)
            {
                return null;
            } else
            {
                Log.d("ButterKnife", "MISS: Reached framework class. Abandoning search.");
                return null;
            }
        }
        obj = class1.getClassLoader().loadClass((new StringBuilder()).append(s).append("_ViewBinding").toString()).getConstructor(new Class[] {
            class1, android/view/View
        });
        flag = debug;
        if (flag)
        {
            try
            {
                Log.d("ButterKnife", "HIT: Loaded binding class and constructor.");
            }
            catch (ClassNotFoundException classnotfoundexception)
            {
                if (debug)
                {
                    Log.d("ButterKnife", (new StringBuilder()).append("Not found. Trying superclass ").append(class1.getSuperclass().getName()).toString());
                }
                classnotfoundexception = findBindingConstructorForClass(class1.getSuperclass());
            }
            // Misplaced declaration of an exception variable
            catch (Class class1)
            {
                throw new RuntimeException((new StringBuilder()).append("Unable to find binding constructor for ").append(s).toString(), class1);
            }
        }
        BINDINGS.put(class1, obj);
        return ((Constructor) (obj));
    }

    public static View findById(Activity activity, int i)
    {
        return activity.findViewById(i);
    }

    public static View findById(Dialog dialog, int i)
    {
        return dialog.findViewById(i);
    }

    public static View findById(View view, int i)
    {
        return view.findViewById(i);
    }

    public static void setDebug(boolean flag)
    {
        debug = flag;
    }

}
