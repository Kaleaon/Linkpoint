// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package butterknife.internal;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.util.TypedValue;
import android.view.View;
import java.lang.reflect.Array;
import java.util.List;

// Referenced classes of package butterknife.internal:
//            ImmutableList

public final class Utils
{

    private static final TypedValue VALUE = new TypedValue();

    private Utils()
    {
        throw new AssertionError("No instances.");
    }

    public static transient Object[] arrayOf(Object aobj[])
    {
        return filterNull(aobj);
    }

    public static Object castParam(Object obj, String s, int i, String s1, int j, Class class1)
    {
        try
        {
            obj = class1.cast(obj);
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            throw new IllegalStateException((new StringBuilder()).append("Parameter #").append(i + 1).append(" of method '").append(s).append("' was of the wrong type for parameter #").append(j + 1).append(" of method '").append(s1).append("'. See cause for more info.").toString(), ((Throwable) (obj)));
        }
        return obj;
    }

    public static Object castView(View view, int i, String s, Class class1)
    {
        try
        {
            class1 = ((Class) (class1.cast(view)));
        }
        // Misplaced declaration of an exception variable
        catch (Class class1)
        {
            view = getResourceEntryName(view, i);
            throw new IllegalStateException((new StringBuilder()).append("View '").append(view).append("' with ID ").append(i).append(" for ").append(s).append(" was of the wrong type. See cause for more info.").toString(), class1);
        }
        return class1;
    }

    private static Object[] filterNull(Object aobj[])
    {
        int l = aobj.length;
        int j = 0;
        int i = 0;
        do
        {
            Object obj;
            if (j >= l)
            {
                if (i != l)
                {
                    Object aobj1[] = (Object[])(Object[])Array.newInstance(((Object) (aobj)).getClass().getComponentType(), i);
                    System.arraycopy(((Object) (aobj)), 0, ((Object) (aobj1)), 0, i);
                    return aobj1;
                } else
                {
                    return aobj;
                }
            }
            obj = aobj[j];
            if (obj != null)
            {
                int k = i + 1;
                aobj[i] = obj;
                i = k;
            }
            j++;
        } while (true);
    }

    public static Object findOptionalViewAsType(View view, int i, String s, Class class1)
    {
        return castView(view.findViewById(i), i, s, class1);
    }

    public static View findRequiredView(View view, int i, String s)
    {
        View view1 = view.findViewById(i);
        if (view1 == null)
        {
            view = getResourceEntryName(view, i);
            throw new IllegalStateException((new StringBuilder()).append("Required view '").append(view).append("' with ID ").append(i).append(" for ").append(s).append(" was not found. If this view is optional add '@Nullable' (fields) or '@Optional' (methods) annotation.").toString());
        } else
        {
            return view1;
        }
    }

    public static Object findRequiredViewAsType(View view, int i, String s, Class class1)
    {
        return castView(findRequiredView(view, i, s), i, s, class1);
    }

    public static float getFloat(Context context, int i)
    {
        TypedValue typedvalue = VALUE;
        context.getResources().getValue(i, typedvalue, true);
        if (typedvalue.type != 4)
        {
            throw new android.content.res.Resources.NotFoundException((new StringBuilder()).append("Resource ID #0x").append(Integer.toHexString(i)).append(" type #0x").append(Integer.toHexString(typedvalue.type)).append(" is not valid").toString());
        } else
        {
            return typedvalue.getFloat();
        }
    }

    private static String getResourceEntryName(View view, int i)
    {
        if (!view.isInEditMode())
        {
            return view.getContext().getResources().getResourceEntryName(i);
        } else
        {
            return "<unavailable while editing>";
        }
    }

    public static Drawable getTintedDrawable(Context context, int i, int j)
    {
        if (context.getTheme().resolveAttribute(j, VALUE, true))
        {
            Drawable drawable = DrawableCompat.wrap(ContextCompat.getDrawable(context, i).mutate());
            DrawableCompat.setTint(drawable, ContextCompat.getColor(context, VALUE.resourceId));
            return drawable;
        } else
        {
            throw new android.content.res.Resources.NotFoundException((new StringBuilder()).append("Required tint color attribute with name ").append(context.getResources().getResourceEntryName(j)).append(" and attribute ID ").append(j).append(" was not found.").toString());
        }
    }

    public static transient List listOf(Object aobj[])
    {
        return new ImmutableList(filterNull(aobj));
    }

}
