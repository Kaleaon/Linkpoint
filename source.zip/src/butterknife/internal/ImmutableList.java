// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package butterknife.internal;

import java.util.AbstractList;
import java.util.RandomAccess;

final class ImmutableList extends AbstractList
    implements RandomAccess
{

    private final Object views[];

    ImmutableList(Object aobj[])
    {
        views = aobj;
    }

    public boolean contains(Object obj)
    {
        Object aobj[] = views;
        int j = aobj.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return false;
            }
            if (aobj[i] != obj)
            {
                i++;
            } else
            {
                return true;
            }
        } while (true);
    }

    public Object get(int i)
    {
        return views[i];
    }

    public int size()
    {
        return views.length;
    }
}
