// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package okio:
//            RealBufferedSink, Buffer

class it> extends OutputStream
{

    final RealBufferedSink this$0;

    public void close()
        throws IOException
    {
        RealBufferedSink.this.close();
    }

    public void flush()
        throws IOException
    {
        if (closed)
        {
            return;
        } else
        {
            RealBufferedSink.this.flush();
            return;
        }
    }

    public String toString()
    {
        return (new StringBuilder()).append(RealBufferedSink.this).append(".outputStream()").toString();
    }

    public void write(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeByte((byte)i);
            emitCompleteSegments();
            return;
        } else
        {
            throw new IOException("closed");
        }
    }

    public void write(byte abyte0[], int i, int j)
        throws IOException
    {
        if (!closed)
        {
            buffer.write(abyte0, i, j);
            emitCompleteSegments();
            return;
        } else
        {
            throw new IOException("closed");
        }
    }

    ()
    {
        this$0 = RealBufferedSink.this;
        super();
    }
}
