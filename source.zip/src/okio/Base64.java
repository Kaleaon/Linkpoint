// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.UnsupportedEncodingException;

final class Base64
{

    private static final byte MAP[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 43, 47
    };
    private static final byte URL_MAP[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 45, 95
    };

    private Base64()
    {
    }

    public static byte[] decode(String s)
    {
        int k1 = s.length();
_L4:
        if (k1 > 0) goto _L2; else goto _L1
_L1:
        byte abyte0[];
        int i;
        int l;
        int j1;
        int l1;
        abyte0 = new byte[(int)(((long)k1 * 6L) / 8L)];
        l1 = 0;
        j1 = 0;
        l = 0;
        i = 0;
          goto _L3
_L2:
        i = s.charAt(k1 - 1);
        continue; /* Loop/switch isn't completed */
_L5:
        k1--;
          goto _L4
        if (i != 61 && i != 10 && i != 13 && i != 32 && i != 9) goto _L1; else goto _L5
_L3:
        if (l1 >= k1)
        {
            int j = l % 4;
            if (j != 1)
            {
                int i2;
                if (j != 2)
                {
                    if (j == 3)
                    {
                        int k = j1 << 6;
                        int i1 = i + 1;
                        abyte0[i] = (byte)(k >> 16);
                        i = i1 + 1;
                        abyte0[i1] = (byte)(k >> 8);
                    }
                } else
                {
                    abyte0[i] = (byte)((j1 << 12) >> 16);
                    i++;
                }
                if (i != abyte0.length)
                {
                    s = new byte[i];
                    System.arraycopy(abyte0, 0, s, 0, i);
                    return s;
                } else
                {
                    return abyte0;
                }
            } else
            {
                return null;
            }
        }
        j = s.charAt(l1);
          goto _L6
_L15:
        j = 62;
_L9:
        j = (byte)j | j1 << 6;
        l++;
        if (l % 4 == 0)
        {
            j1 = i + 1;
            abyte0[i] = (byte)(j >> 16);
            i2 = j1 + 1;
            abyte0[j1] = (byte)(j >> 8);
            i = i2 + 1;
            abyte0[i2] = (byte)j;
        }
_L18:
        l1++;
        j1 = j;
          goto _L3
_L6:
        if (j < 65 || j > 90) goto _L8; else goto _L7
_L7:
        j -= 65;
          goto _L9
_L8:
        if (j < 97 || j > 122) goto _L11; else goto _L10
_L10:
        j -= 71;
          goto _L9
_L11:
        if (j < 48 || j > 57) goto _L13; else goto _L12
_L12:
        j += 4;
          goto _L9
_L13:
        if (j == 43 || j == 45) goto _L15; else goto _L14
_L17:
        j = 63;
          goto _L9
_L14:
        if (j == 47 || j == 95) goto _L17; else goto _L16
_L16:
        if (j == 10 || j == 13 || j == 32)
        {
            j = j1;
        } else
        {
            if (j != 9)
            {
                return null;
            }
            j = j1;
        }
          goto _L18
    }

    public static String encode(byte abyte0[])
    {
        return encode(abyte0, MAP);
    }

    private static String encode(byte abyte0[], byte abyte1[])
    {
        byte abyte2[];
        int i;
        int j;
        int k;
        i = 0;
        abyte2 = new byte[((abyte0.length + 2) / 3) * 4];
        k = abyte0.length - abyte0.length % 3;
        j = 0;
_L6:
        if (i < k) goto _L2; else goto _L1
_L1:
        abyte0.length % 3;
        JVM INSTR tableswitch 1 2: default 56
    //                   1 187
    //                   2 245;
           goto _L3 _L4 _L5
_L3:
        break; /* Loop/switch isn't completed */
_L5:
        break MISSING_BLOCK_LABEL_245;
_L7:
        int l;
        try
        {
            abyte0 = new String(abyte2, "US-ASCII");
        }
        // Misplaced declaration of an exception variable
        catch (byte abyte0[])
        {
            throw new AssertionError(abyte0);
        }
        return abyte0;
_L2:
        l = j + 1;
        abyte2[j] = abyte1[(abyte0[i] & 0xff) >> 2];
        j = l + 1;
        abyte2[l] = abyte1[(abyte0[i] & 3) << 4 | (abyte0[i + 1] & 0xff) >> 4];
        l = j + 1;
        abyte2[j] = abyte1[(abyte0[i + 1] & 0xf) << 2 | (abyte0[i + 2] & 0xff) >> 6];
        j = l + 1;
        abyte2[l] = abyte1[abyte0[i + 2] & 0x3f];
        i += 3;
          goto _L6
_L4:
        i = j + 1;
        abyte2[j] = abyte1[(abyte0[k] & 0xff) >> 2];
        j = i + 1;
        abyte2[i] = abyte1[(abyte0[k] & 3) << 4];
        abyte2[j] = 61;
        abyte2[j + 1] = 61;
          goto _L7
        i = j + 1;
        abyte2[j] = abyte1[(abyte0[k] & 0xff) >> 2];
        j = i + 1;
        abyte2[i] = abyte1[(abyte0[k] & 3) << 4 | (abyte0[k + 1] & 0xff) >> 4];
        abyte2[j] = abyte1[(abyte0[k + 1] & 0xf) << 2];
        abyte2[j + 1] = 61;
          goto _L7
    }

    public static String encodeUrl(byte abyte0[])
    {
        return encode(abyte0, URL_MAP);
    }

}
