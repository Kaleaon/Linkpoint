// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;


// Referenced classes of package okio:
//            SegmentPool

final class Segment
{

    static final int SHARE_MINIMUM = 1024;
    static final int SIZE = 8192;
    final byte data[];
    int limit;
    Segment next;
    boolean owner;
    int pos;
    Segment prev;
    boolean shared;

    Segment()
    {
        data = new byte[8192];
        owner = true;
        shared = false;
    }

    Segment(Segment segment)
    {
        this(segment.data, segment.pos, segment.limit);
        segment.shared = true;
    }

    Segment(byte abyte0[], int i, int j)
    {
        data = abyte0;
        pos = i;
        limit = j;
        owner = false;
        shared = true;
    }

    public void compact()
    {
        int i = 0;
        if (prev != this)
        {
            if (prev.owner)
            {
                int j = limit - pos;
                int k = prev.limit;
                if (!prev.shared)
                {
                    i = prev.pos;
                }
                if (j <= i + (8192 - k))
                {
                    writeTo(prev, j);
                    pop();
                    SegmentPool.recycle(this);
                    return;
                } else
                {
                    return;
                }
            } else
            {
                return;
            }
        } else
        {
            throw new IllegalStateException();
        }
    }

    public Segment pop()
    {
        Segment segment;
        if (next == this)
        {
            segment = null;
        } else
        {
            segment = next;
        }
        prev.next = next;
        next.prev = prev;
        next = null;
        prev = null;
        return segment;
    }

    public Segment push(Segment segment)
    {
        segment.prev = this;
        segment.next = next;
        next.prev = segment;
        next = segment;
        return segment;
    }

    public Segment split(int i)
    {
        while (i <= 0 || i > limit - pos) 
        {
            throw new IllegalArgumentException();
        }
        Segment segment;
        if (i < 1024)
        {
            segment = SegmentPool.take();
            System.arraycopy(data, pos, segment.data, 0, i);
        } else
        {
            segment = new Segment(this);
        }
        segment.limit = segment.pos + i;
        pos = pos + i;
        prev.push(segment);
        return segment;
    }

    public void writeTo(Segment segment, int i)
    {
        if (segment.owner)
        {
            if (segment.limit + i > 8192)
            {
                if (!segment.shared)
                {
                    if ((segment.limit + i) - segment.pos <= 8192)
                    {
                        System.arraycopy(segment.data, segment.pos, segment.data, 0, segment.limit - segment.pos);
                        segment.limit = segment.limit - segment.pos;
                        segment.pos = 0;
                    } else
                    {
                        throw new IllegalArgumentException();
                    }
                } else
                {
                    throw new IllegalArgumentException();
                }
            }
            System.arraycopy(data, pos, segment.data, segment.limit, i);
            segment.limit = segment.limit + i;
            pos = pos + i;
            return;
        } else
        {
            throw new IllegalArgumentException();
        }
    }
}
