// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;

// Referenced classes of package okio:
//            ByteString, Buffer, Util, Segment

final class SegmentedByteString extends ByteString
{

    final transient int directory[];
    final transient byte segments[][];

    SegmentedByteString(Buffer buffer, int i)
    {
        Segment segment1;
        int j;
        int k;
        boolean flag;
        flag = false;
        super(null);
        Util.checkOffsetAndCount(buffer.size, 0L, i);
        segment1 = buffer.head;
        j = 0;
        k = 0;
_L3:
        if (k < i) goto _L2; else goto _L1
_L1:
        segments = new byte[j][];
        directory = new int[j * 2];
        buffer = buffer.head;
        k = 0;
        j = ((flag) ? 1 : 0);
_L4:
        if (j >= i)
        {
            return;
        }
        break MISSING_BLOCK_LABEL_122;
_L2:
        if (segment1.limit != segment1.pos)
        {
            k += segment1.limit - segment1.pos;
            j++;
            segment1 = segment1.next;
        } else
        {
            throw new AssertionError("s.limit == s.pos");
        }
          goto _L3
        segments[k] = ((Segment) (buffer)).data;
        j = (((Segment) (buffer)).limit - ((Segment) (buffer)).pos) + j;
        if (j > i)
        {
            j = i;
        }
        directory[k] = j;
        directory[segments.length + k] = ((Segment) (buffer)).pos;
        buffer.shared = true;
        k++;
        buffer = ((Segment) (buffer)).next;
          goto _L4
    }

    private int segment(int i)
    {
        int j = Arrays.binarySearch(directory, 0, segments.length, i + 1);
        i = j;
        if (j < 0)
        {
            i = ~j;
        }
        return i;
    }

    private ByteString toByteString()
    {
        return new ByteString(toByteArray());
    }

    private Object writeReplace()
    {
        return toByteString();
    }

    public ByteBuffer asByteBuffer()
    {
        return ByteBuffer.wrap(toByteArray()).asReadOnlyBuffer();
    }

    public String base64()
    {
        return toByteString().base64();
    }

    public String base64Url()
    {
        return toByteString().base64Url();
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            return (obj instanceof ByteString) && ((ByteString)obj).size() == size() && rangeEquals(0, (ByteString)obj, 0, size());
        } else
        {
            return true;
        }
    }

    public byte getByte(int i)
    {
        Util.checkOffsetAndCount(directory[segments.length - 1], i, 1L);
        int k = segment(i);
        int j;
        int l;
        if (k != 0)
        {
            j = directory[k - 1];
        } else
        {
            j = 0;
        }
        l = directory[segments.length + k];
        return segments[k][(i - j) + l];
    }

    public int hashCode()
    {
        int k;
        int l;
        int i1;
        int l1;
        int i = hashCode;
        if (i == 0)
        {
            i1 = 1;
            l1 = segments.length;
            k = 0;
            l = 0;
            break MISSING_BLOCK_LABEL_24;
        } else
        {
            return i;
        }
_L2:
        if (k >= l1)
        {
            hashCode = i1;
            return i1;
        }
        byte abyte0[] = segments[k];
        int k1 = directory[l1 + k];
        int j1 = directory[k];
        int j = k1;
        do
        {
label0:
            {
                if (j < (j1 - l) + k1)
                {
                    break label0;
                }
                k++;
                l = j1;
            }
            if (true)
            {
                continue;
            }
            i1 = i1 * 31 + abyte0[j];
            j++;
        } while (true);
        if (true) goto _L2; else goto _L1
_L1:
    }

    public String hex()
    {
        return toByteString().hex();
    }

    public ByteString hmacSha1(ByteString bytestring)
    {
        return toByteString().hmacSha1(bytestring);
    }

    public ByteString hmacSha256(ByteString bytestring)
    {
        return toByteString().hmacSha256(bytestring);
    }

    public int indexOf(byte abyte0[], int i)
    {
        return toByteString().indexOf(abyte0, i);
    }

    byte[] internalArray()
    {
        return toByteArray();
    }

    public int lastIndexOf(byte abyte0[], int i)
    {
        return toByteString().lastIndexOf(abyte0, i);
    }

    public ByteString md5()
    {
        return toByteString().md5();
    }

    public boolean rangeEquals(int i, ByteString bytestring, int j, int k)
    {
        while (i < 0 || i > size() - k) 
        {
            return false;
        }
        int i1 = segment(i);
        int l = i;
        i = i1;
        do
        {
            if (k <= 0)
            {
                return true;
            }
            int j1;
            int k1;
            int l1;
            if (i != 0)
            {
                j1 = directory[i - 1];
            } else
            {
                j1 = 0;
            }
            k1 = Math.min(k, ((directory[i] - j1) + j1) - l);
            l1 = directory[segments.length + i];
            if (bytestring.rangeEquals(j, segments[i], (l - j1) + l1, k1))
            {
                l += k1;
                j += k1;
                k -= k1;
                i++;
            } else
            {
                return false;
            }
        } while (true);
    }

    public boolean rangeEquals(int i, byte abyte0[], int j, int k)
    {
        while (i < 0 || i > size() - k || j < 0 || j > abyte0.length - k) 
        {
            return false;
        }
        int i1 = segment(i);
        int l = i;
        i = i1;
        do
        {
            if (k <= 0)
            {
                return true;
            }
            int j1;
            int k1;
            int l1;
            if (i != 0)
            {
                j1 = directory[i - 1];
            } else
            {
                j1 = 0;
            }
            k1 = Math.min(k, ((directory[i] - j1) + j1) - l);
            l1 = directory[segments.length + i];
            if (Util.arrayRangeEquals(segments[i], (l - j1) + l1, abyte0, j, k1))
            {
                l += k1;
                j += k1;
                k -= k1;
                i++;
            } else
            {
                return false;
            }
        } while (true);
    }

    public ByteString sha1()
    {
        return toByteString().sha1();
    }

    public ByteString sha256()
    {
        return toByteString().sha256();
    }

    public int size()
    {
        return directory[segments.length - 1];
    }

    public String string(Charset charset)
    {
        return toByteString().string(charset);
    }

    public ByteString substring(int i)
    {
        return toByteString().substring(i);
    }

    public ByteString substring(int i, int j)
    {
        return toByteString().substring(i, j);
    }

    public ByteString toAsciiLowercase()
    {
        return toByteString().toAsciiLowercase();
    }

    public ByteString toAsciiUppercase()
    {
        return toByteString().toAsciiUppercase();
    }

    public byte[] toByteArray()
    {
        int i = 0;
        byte abyte0[] = new byte[directory[segments.length - 1]];
        int l = segments.length;
        int j = 0;
        do
        {
            if (i >= l)
            {
                return abyte0;
            }
            int i1 = directory[l + i];
            int k = directory[i];
            System.arraycopy(segments[i], i1, abyte0, j, k - j);
            i++;
            j = k;
        } while (true);
    }

    public String toString()
    {
        return toByteString().toString();
    }

    public String utf8()
    {
        return toByteString().utf8();
    }

    public void write(OutputStream outputstream)
        throws IOException
    {
        int i = 0;
        if (outputstream == null) goto _L2; else goto _L1
_L1:
        int j;
        int l;
        l = segments.length;
        j = 0;
_L4:
        if (i >= l)
        {
            return;
        }
        int i1 = directory[l + i];
        int k = directory[i];
        outputstream.write(segments[i], i1, k - j);
        i++;
        j = k;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalArgumentException("out == null");
        if (true) goto _L4; else goto _L3
_L3:
    }

    void write(Buffer buffer)
    {
        int i = 0;
        int l = segments.length;
        int j = 0;
        do
        {
            if (i >= l)
            {
                long l1 = buffer.size;
                buffer.size = (long)j + l1;
                return;
            }
            int i1 = directory[l + i];
            int k = directory[i];
            Segment segment1 = new Segment(segments[i], i1, (i1 + k) - j);
            if (buffer.head != null)
            {
                buffer.head.prev.push(segment1);
            } else
            {
                segment1.prev = segment1;
                segment1.next = segment1;
                buffer.head = segment1;
            }
            i++;
            j = k;
        } while (true);
    }
}
