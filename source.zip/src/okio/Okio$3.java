// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;

// Referenced classes of package okio:
//            Sink, Okio, Timeout, Buffer

static class ception
    implements Sink
{

    public void close()
        throws IOException
    {
    }

    public void flush()
        throws IOException
    {
    }

    public Timeout timeout()
    {
        return Timeout.NONE;
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        buffer.skip(l);
    }

    ception()
    {
    }
}
