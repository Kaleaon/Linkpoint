// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

// Referenced classes of package okio:
//            BufferedSource, Buffer, Source, ByteString, 
//            Util, Sink, Options, Timeout

final class RealBufferedSource
    implements BufferedSource
{

    public final Buffer buffer = new Buffer();
    boolean closed;
    public final Source source;

    RealBufferedSource(Source source1)
    {
        if (source1 != null)
        {
            source = source1;
            return;
        } else
        {
            throw new NullPointerException("source == null");
        }
    }

    public Buffer buffer()
    {
        return buffer;
    }

    public void close()
        throws IOException
    {
        if (!closed)
        {
            closed = true;
            source.close();
            buffer.clear();
            return;
        } else
        {
            return;
        }
    }

    public boolean exhausted()
        throws IOException
    {
        if (!closed)
        {
            return buffer.exhausted() && source.read(buffer, 8192L) == -1L;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public long indexOf(byte byte0)
        throws IOException
    {
        return indexOf(byte0, 0L);
    }

    public long indexOf(byte byte0, long l)
        throws IOException
    {
        if (closed) goto _L2; else goto _L1
_L1:
        long l1 = buffer.indexOf(byte0, l);
        if (l1 != -1L)
        {
            return l1;
        }
        l1 = buffer.size;
        if (source.read(buffer, 8192L) == -1L)
        {
            return -1L;
        }
        l = Math.max(l, l1);
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("closed");
        if (true) goto _L1; else goto _L3
_L3:
    }

    public long indexOf(ByteString bytestring)
        throws IOException
    {
        return indexOf(bytestring, 0L);
    }

    public long indexOf(ByteString bytestring, long l)
        throws IOException
    {
        if (closed) goto _L2; else goto _L1
_L1:
        long l1 = buffer.indexOf(bytestring, l);
        if (l1 != -1L)
        {
            return l1;
        }
        l1 = buffer.size;
        if (source.read(buffer, 8192L) == -1L)
        {
            return -1L;
        }
        l = Math.max(l, (l1 - (long)bytestring.size()) + 1L);
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("closed");
        if (true) goto _L1; else goto _L3
_L3:
    }

    public long indexOfElement(ByteString bytestring)
        throws IOException
    {
        return indexOfElement(bytestring, 0L);
    }

    public long indexOfElement(ByteString bytestring, long l)
        throws IOException
    {
        if (closed) goto _L2; else goto _L1
_L1:
        long l1 = buffer.indexOfElement(bytestring, l);
        if (l1 != -1L)
        {
            return l1;
        }
        l1 = buffer.size;
        if (source.read(buffer, 8192L) == -1L)
        {
            return -1L;
        }
        l = Math.max(l, l1);
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("closed");
        if (true) goto _L1; else goto _L3
_L3:
    }

    public InputStream inputStream()
    {
        return new InputStream() {

            final RealBufferedSource this$0;

            public int available()
                throws IOException
            {
                if (!closed)
                {
                    return (int)Math.min(buffer.size, 0x7fffffffL);
                } else
                {
                    throw new IOException("closed");
                }
            }

            public void close()
                throws IOException
            {
                RealBufferedSource.this.close();
            }

            public int read()
                throws IOException
            {
                if (!closed)
                {
                    if (buffer.size == 0L && source.read(buffer, 8192L) == -1L)
                    {
                        return -1;
                    } else
                    {
                        return buffer.readByte() & 0xff;
                    }
                } else
                {
                    throw new IOException("closed");
                }
            }

            public int read(byte abyte0[], int i, int j)
                throws IOException
            {
                if (!closed)
                {
                    Util.checkOffsetAndCount(abyte0.length, i, j);
                    if (buffer.size == 0L && source.read(buffer, 8192L) == -1L)
                    {
                        return -1;
                    } else
                    {
                        return buffer.read(abyte0, i, j);
                    }
                } else
                {
                    throw new IOException("closed");
                }
            }

            public String toString()
            {
                return (new StringBuilder()).append(RealBufferedSource.this).append(".inputStream()").toString();
            }

            
            {
                this$0 = RealBufferedSource.this;
                super();
            }
        };
    }

    public boolean rangeEquals(long l, ByteString bytestring)
        throws IOException
    {
        return rangeEquals(l, bytestring, 0, bytestring.size());
    }

    public boolean rangeEquals(long l, ByteString bytestring, int i, int j)
        throws IOException
    {
        if (!closed)
        {
            boolean flag;
            if (l < 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            break MISSING_BLOCK_LABEL_16;
        } else
        {
            throw new IllegalStateException("closed");
        }
        if (flag || i < 0 || j < 0 || bytestring.size() - i < j)
        {
            return false;
        }
        int k = 0;
        do
        {
            if (k >= j)
            {
                return true;
            }
            long l1 = (long)k + l;
            if (request(1L + l1))
            {
                if (buffer.getByte(l1) == bytestring.getByte(i + k))
                {
                    k++;
                } else
                {
                    return false;
                }
            } else
            {
                return false;
            }
        } while (true);
    }

    public int read(byte abyte0[])
        throws IOException
    {
        return read(abyte0, 0, abyte0.length);
    }

    public int read(byte abyte0[], int i, int j)
        throws IOException
    {
        Util.checkOffsetAndCount(abyte0.length, i, j);
        if (buffer.size == 0L && source.read(buffer, 8192L) == -1L)
        {
            return -1;
        } else
        {
            j = (int)Math.min(j, buffer.size);
            return buffer.read(abyte0, i, j);
        }
    }

    public long read(Buffer buffer1, long l)
        throws IOException
    {
        boolean flag = false;
        if (buffer1 != null)
        {
            if (l >= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
        } else
        {
            throw new IllegalArgumentException("sink == null");
        }
        if (!closed)
        {
            if (buffer.size == 0L && source.read(buffer, 8192L) == -1L)
            {
                return -1L;
            } else
            {
                l = Math.min(l, buffer.size);
                return buffer.read(buffer1, l);
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public long readAll(Sink sink)
        throws IOException
    {
        long l;
        if (sink != null)
        {
            l = 0L;
            do
            {
                if (source.read(buffer, 8192L) == -1L)
                {
                    break;
                }
                long l1 = buffer.completeSegmentByteCount();
                boolean flag;
                if (l1 <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    l += l1;
                    sink.write(buffer, l1);
                }
            } while (true);
        } else
        {
            throw new IllegalArgumentException("sink == null");
        }
        boolean flag1;
        long l2;
        if (buffer.size() <= 0L)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        l2 = l;
        if (!flag1)
        {
            l2 = l + buffer.size();
            sink.write(buffer, buffer.size());
        }
        return l2;
    }

    public byte readByte()
        throws IOException
    {
        require(1L);
        return buffer.readByte();
    }

    public byte[] readByteArray()
        throws IOException
    {
        buffer.writeAll(source);
        return buffer.readByteArray();
    }

    public byte[] readByteArray(long l)
        throws IOException
    {
        require(l);
        return buffer.readByteArray(l);
    }

    public ByteString readByteString()
        throws IOException
    {
        buffer.writeAll(source);
        return buffer.readByteString();
    }

    public ByteString readByteString(long l)
        throws IOException
    {
        require(l);
        return buffer.readByteString(l);
    }

    public long readDecimalLong()
        throws IOException
    {
        require(1L);
        int i = 0;
        do
        {
            byte byte0;
            if (!request(i + 1))
            {
                do
                {
                    return buffer.readDecimalLong();
                } while (i != 0);
                throw new NumberFormatException(String.format("Expected leading [0-9] or '-' character but was %#x", new Object[] {
                    Byte.valueOf(byte0)
                }));
            }
            byte0 = buffer.getByte(i);
            if (byte0 >= 48 && byte0 <= 57 || i == 0 && byte0 == 45)
            {
                i++;
            } else
            {
                continue;
            }
        } while (true);
    }

    public void readFully(Buffer buffer1, long l)
        throws IOException
    {
        try
        {
            require(l);
        }
        catch (EOFException eofexception)
        {
            buffer1.writeAll(buffer);
            throw eofexception;
        }
        buffer.readFully(buffer1, l);
    }

    public void readFully(byte abyte0[])
        throws IOException
    {
        try
        {
            require(abyte0.length);
        }
        catch (EOFException eofexception)
        {
            int i = 0;
            do
            {
                int j;
                if (buffer.size <= 0L)
                {
                    j = 1;
                } else
                {
                    j = 0;
                }
                if (j == 0)
                {
                    j = buffer.read(abyte0, i, (int)buffer.size);
                    if (j != -1)
                    {
                        i += j;
                    } else
                    {
                        throw new AssertionError();
                    }
                } else
                {
                    throw eofexception;
                }
            } while (true);
        }
        buffer.readFully(abyte0);
    }

    public long readHexadecimalUnsignedLong()
        throws IOException
    {
        require(1L);
        int i = 0;
        do
        {
            byte byte0;
            if (!request(i + 1))
            {
                do
                {
                    return buffer.readHexadecimalUnsignedLong();
                } while (i != 0);
                throw new NumberFormatException(String.format("Expected leading [0-9a-fA-F] character but was %#x", new Object[] {
                    Byte.valueOf(byte0)
                }));
            }
            byte0 = buffer.getByte(i);
            if (byte0 >= 48 && byte0 <= 57 || byte0 >= 97 && byte0 <= 102 || byte0 >= 65 && byte0 <= 70)
            {
                i++;
            } else
            {
                continue;
            }
        } while (true);
    }

    public int readInt()
        throws IOException
    {
        require(4L);
        return buffer.readInt();
    }

    public int readIntLe()
        throws IOException
    {
        require(4L);
        return buffer.readIntLe();
    }

    public long readLong()
        throws IOException
    {
        require(8L);
        return buffer.readLong();
    }

    public long readLongLe()
        throws IOException
    {
        require(8L);
        return buffer.readLongLe();
    }

    public short readShort()
        throws IOException
    {
        require(2L);
        return buffer.readShort();
    }

    public short readShortLe()
        throws IOException
    {
        require(2L);
        return buffer.readShortLe();
    }

    public String readString(long l, Charset charset)
        throws IOException
    {
        require(l);
        if (charset != null)
        {
            return buffer.readString(l, charset);
        } else
        {
            throw new IllegalArgumentException("charset == null");
        }
    }

    public String readString(Charset charset)
        throws IOException
    {
        if (charset != null)
        {
            buffer.writeAll(source);
            return buffer.readString(charset);
        } else
        {
            throw new IllegalArgumentException("charset == null");
        }
    }

    public String readUtf8()
        throws IOException
    {
        buffer.writeAll(source);
        return buffer.readUtf8();
    }

    public String readUtf8(long l)
        throws IOException
    {
        require(l);
        return buffer.readUtf8(l);
    }

    public int readUtf8CodePoint()
        throws IOException
    {
        require(1L);
        byte byte0 = buffer.getByte(0L);
        if ((byte0 & 0xe0) != 192)
        {
            if ((byte0 & 0xf0) != 224)
            {
                if ((byte0 & 0xf8) == 240)
                {
                    require(4L);
                }
            } else
            {
                require(3L);
            }
        } else
        {
            require(2L);
        }
        return buffer.readUtf8CodePoint();
    }

    public String readUtf8Line()
        throws IOException
    {
        long l = indexOf((byte)10);
        if (l == -1L)
        {
            if (buffer.size != 0L)
            {
                return readUtf8(buffer.size);
            } else
            {
                return null;
            }
        } else
        {
            return buffer.readUtf8Line(l);
        }
    }

    public String readUtf8LineStrict()
        throws IOException
    {
        long l = indexOf((byte)10);
        if (l == -1L)
        {
            Buffer buffer1 = new Buffer();
            buffer.copyTo(buffer1, 0L, Math.min(32L, buffer.size()));
            throw new EOFException((new StringBuilder()).append("\\n not found: size=").append(buffer.size()).append(" content=").append(buffer1.readByteString().hex()).append("\u2026").toString());
        } else
        {
            return buffer.readUtf8Line(l);
        }
    }

    public boolean request(long l)
        throws IOException
    {
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (!closed)
        {
            do
            {
                if (buffer.size >= l)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    if (source.read(buffer, 8192L) == -1L)
                    {
                        return false;
                    }
                } else
                {
                    return true;
                }
            } while (true);
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public void require(long l)
        throws IOException
    {
        if (request(l))
        {
            return;
        } else
        {
            throw new EOFException();
        }
    }

    public int select(Options options)
        throws IOException
    {
        if (closed) goto _L2; else goto _L1
_L1:
        int i = buffer.selectPrefix(options);
        if (i != -1)
        {
            int j = options.byteStrings[i].size();
            boolean flag;
            if ((long)j > buffer.size)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                buffer.skip(j);
                return i;
            }
        } else
        {
            return -1;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalStateException("closed");
        if (source.read(buffer, 8192L) != -1L) goto _L1; else goto _L3
_L3:
        return -1;
    }

    public void skip(long l)
        throws IOException
    {
        if (!closed)
        {
            do
            {
                boolean flag;
                if (l <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (flag)
                {
                    break;
                }
                if (buffer.size == 0L && source.read(buffer, 8192L) == -1L)
                {
                    throw new EOFException();
                }
                long l1 = Math.min(l, buffer.size());
                buffer.skip(l1);
                l -= l1;
            } while (true);
            return;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public Timeout timeout()
    {
        return source.timeout();
    }

    public String toString()
    {
        return (new StringBuilder()).append("buffer(").append(source).append(")").toString();
    }
}
