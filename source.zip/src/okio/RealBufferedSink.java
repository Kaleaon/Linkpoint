// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;

// Referenced classes of package okio:
//            BufferedSink, Buffer, Sink, Util, 
//            Source, Timeout, ByteString

final class RealBufferedSink
    implements BufferedSink
{

    public final Buffer buffer = new Buffer();
    boolean closed;
    public final Sink sink;

    RealBufferedSink(Sink sink1)
    {
        if (sink1 != null)
        {
            sink = sink1;
            return;
        } else
        {
            throw new NullPointerException("sink == null");
        }
    }

    public Buffer buffer()
    {
        return buffer;
    }

    public void close()
        throws IOException
    {
        Throwable throwable1;
        boolean flag;
        flag = false;
        throwable1 = null;
        if (closed) goto _L2; else goto _L1
_L1:
        Throwable throwable;
        if (buffer.size <= 0L)
        {
            flag = true;
        }
        throwable = throwable1;
        if (flag)
        {
            break MISSING_BLOCK_LABEL_53;
        }
        sink.write(buffer, buffer.size);
        throwable = throwable1;
_L3:
        sink.close();
        throwable1 = throwable;
_L4:
        closed = true;
        if (throwable1 == null)
        {
            return;
        } else
        {
            Util.sneakyRethrow(throwable1);
            return;
        }
_L2:
        return;
        throwable;
          goto _L3
        throwable1;
        if (throwable != null)
        {
            throwable1 = throwable;
        }
          goto _L4
    }

    public BufferedSink emit()
        throws IOException
    {
        boolean flag = false;
        if (!closed)
        {
            long l = buffer.size();
            if (l <= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                sink.write(buffer, l);
            }
            return this;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink emitCompleteSegments()
        throws IOException
    {
        boolean flag = false;
        if (!closed)
        {
            long l = buffer.completeSegmentByteCount();
            if (l <= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                sink.write(buffer, l);
            }
            return this;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public void flush()
        throws IOException
    {
        boolean flag = false;
        if (!closed)
        {
            if (buffer.size <= 0L)
            {
                flag = true;
            }
            if (!flag)
            {
                sink.write(buffer, buffer.size);
            }
            sink.flush();
            return;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public OutputStream outputStream()
    {
        return new OutputStream() {

            final RealBufferedSink this$0;

            public void close()
                throws IOException
            {
                RealBufferedSink.this.close();
            }

            public void flush()
                throws IOException
            {
                if (closed)
                {
                    return;
                } else
                {
                    RealBufferedSink.this.flush();
                    return;
                }
            }

            public String toString()
            {
                return (new StringBuilder()).append(RealBufferedSink.this).append(".outputStream()").toString();
            }

            public void write(int i)
                throws IOException
            {
                if (!closed)
                {
                    buffer.writeByte((byte)i);
                    emitCompleteSegments();
                    return;
                } else
                {
                    throw new IOException("closed");
                }
            }

            public void write(byte abyte0[], int i, int j)
                throws IOException
            {
                if (!closed)
                {
                    buffer.write(abyte0, i, j);
                    emitCompleteSegments();
                    return;
                } else
                {
                    throw new IOException("closed");
                }
            }

            
            {
                this$0 = RealBufferedSink.this;
                super();
            }
        };
    }

    public Timeout timeout()
    {
        return sink.timeout();
    }

    public String toString()
    {
        return (new StringBuilder()).append("buffer(").append(sink).append(")").toString();
    }

    public BufferedSink write(ByteString bytestring)
        throws IOException
    {
        if (!closed)
        {
            buffer.write(bytestring);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink write(Source source, long l)
        throws IOException
    {
        do
        {
            boolean flag;
            if (l <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                long l1 = source.read(buffer, l);
                if (l1 == -1L)
                {
                    throw new EOFException();
                }
                l -= l1;
                emitCompleteSegments();
            } else
            {
                return this;
            }
        } while (true);
    }

    public BufferedSink write(byte abyte0[])
        throws IOException
    {
        if (!closed)
        {
            buffer.write(abyte0);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink write(byte abyte0[], int i, int j)
        throws IOException
    {
        if (!closed)
        {
            buffer.write(abyte0, i, j);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public void write(Buffer buffer1, long l)
        throws IOException
    {
        if (!closed)
        {
            buffer.write(buffer1, l);
            emitCompleteSegments();
            return;
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public long writeAll(Source source)
        throws IOException
    {
        if (source != null)
        {
            long l = 0L;
            do
            {
                long l1 = source.read(buffer, 8192L);
                if (l1 != -1L)
                {
                    l += l1;
                    emitCompleteSegments();
                } else
                {
                    return l;
                }
            } while (true);
        } else
        {
            throw new IllegalArgumentException("source == null");
        }
    }

    public BufferedSink writeByte(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeByte(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeDecimalLong(long l)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeDecimalLong(l);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeHexadecimalUnsignedLong(long l)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeHexadecimalUnsignedLong(l);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeInt(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeInt(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeIntLe(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeIntLe(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeLong(long l)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeLong(l);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeLongLe(long l)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeLongLe(l);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeShort(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeShort(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeShortLe(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeShortLe(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeString(String s, int i, int j, Charset charset)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeString(s, i, j, charset);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeString(String s, Charset charset)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeString(s, charset);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeUtf8(String s)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeUtf8(s);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeUtf8(String s, int i, int j)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeUtf8(s, i, j);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }

    public BufferedSink writeUtf8CodePoint(int i)
        throws IOException
    {
        if (!closed)
        {
            buffer.writeUtf8CodePoint(i);
            return emitCompleteSegments();
        } else
        {
            throw new IllegalStateException("closed");
        }
    }
}
