// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package okio:
//            Base64, Util, Buffer

public class ByteString
    implements Serializable, Comparable
{

    public static final ByteString EMPTY = of(new byte[0]);
    static final char HEX_DIGITS[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        'a', 'b', 'c', 'd', 'e', 'f'
    };
    private static final long serialVersionUID = 1L;
    final byte data[];
    transient int hashCode;
    transient String utf8;

    ByteString(byte abyte0[])
    {
        data = abyte0;
    }

    static int codePointIndexToCharIndex(String s, int i)
    {
        int k = 0;
        int l = s.length();
        int j = 0;
        do
        {
            if (j >= l)
            {
                return s.length();
            }
            if (k != i)
            {
                int i1 = s.codePointAt(j);
                if ((!Character.isISOControl(i1) || i1 == 10 || i1 == 13) && i1 != 65533)
                {
                    k++;
                    j += Character.charCount(i1);
                } else
                {
                    return -1;
                }
            } else
            {
                return j;
            }
        } while (true);
    }

    public static ByteString decodeBase64(String s)
    {
        if (s != null)
        {
            s = Base64.decode(s);
            if (s == null)
            {
                return null;
            } else
            {
                return new ByteString(s);
            }
        } else
        {
            throw new IllegalArgumentException("base64 == null");
        }
    }

    public static ByteString decodeHex(String s)
    {
        int i = 0;
        if (s == null) goto _L2; else goto _L1
_L1:
        if (s.length() % 2 != 0) goto _L4; else goto _L3
_L3:
        byte abyte0[] = new byte[s.length() / 2];
_L6:
        if (i >= abyte0.length)
        {
            return of(abyte0);
        }
        abyte0[i] = (byte)((decodeHexDigit(s.charAt(i * 2)) << 4) + decodeHexDigit(s.charAt(i * 2 + 1)));
        i++;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalArgumentException("hex == null");
_L4:
        throw new IllegalArgumentException((new StringBuilder()).append("Unexpected hex string: ").append(s).toString());
        if (true) goto _L6; else goto _L5
_L5:
    }

    private static int decodeHexDigit(char c)
    {
        if (c < '0' || c > '9')
        {
            if (c < 'a' || c > 'f')
            {
                if (c < 'A' || c > 'F')
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("Unexpected hex digit: ").append(c).toString());
                } else
                {
                    return (c - 65) + 10;
                }
            } else
            {
                return (c - 97) + 10;
            }
        } else
        {
            return c - 48;
        }
    }

    private ByteString digest(String s)
    {
        try
        {
            s = of(MessageDigest.getInstance(s).digest(data));
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new AssertionError(s);
        }
        return s;
    }

    public static ByteString encodeString(String s, Charset charset)
    {
        if (s != null)
        {
            if (charset != null)
            {
                return new ByteString(s.getBytes(charset));
            } else
            {
                throw new IllegalArgumentException("charset == null");
            }
        } else
        {
            throw new IllegalArgumentException("s == null");
        }
    }

    public static ByteString encodeUtf8(String s)
    {
        if (s != null)
        {
            ByteString bytestring = new ByteString(s.getBytes(Util.UTF_8));
            bytestring.utf8 = s;
            return bytestring;
        } else
        {
            throw new IllegalArgumentException("s == null");
        }
    }

    private ByteString hmac(String s, ByteString bytestring)
    {
        try
        {
            Mac mac = Mac.getInstance(s);
            mac.init(new SecretKeySpec(bytestring.toByteArray(), s));
            s = of(mac.doFinal(data));
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new AssertionError(s);
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new IllegalArgumentException(s);
        }
        return s;
    }

    public static ByteString of(ByteBuffer bytebuffer)
    {
        if (bytebuffer != null)
        {
            byte abyte0[] = new byte[bytebuffer.remaining()];
            bytebuffer.get(abyte0);
            return new ByteString(abyte0);
        } else
        {
            throw new IllegalArgumentException("data == null");
        }
    }

    public static transient ByteString of(byte abyte0[])
    {
        if (abyte0 != null)
        {
            return new ByteString((byte[])abyte0.clone());
        } else
        {
            throw new IllegalArgumentException("data == null");
        }
    }

    public static ByteString of(byte abyte0[], int i, int j)
    {
        if (abyte0 != null)
        {
            Util.checkOffsetAndCount(abyte0.length, i, j);
            byte abyte1[] = new byte[j];
            System.arraycopy(abyte0, i, abyte1, 0, j);
            return new ByteString(abyte1);
        } else
        {
            throw new IllegalArgumentException("data == null");
        }
    }

    public static ByteString read(InputStream inputstream, int i)
        throws IOException
    {
        byte abyte0[];
        int j;
        j = 0;
        if (inputstream != null)
        {
            if (i >= 0)
            {
                abyte0 = new byte[i];
                break MISSING_BLOCK_LABEL_14;
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(i).toString());
            }
        } else
        {
            throw new IllegalArgumentException("in == null");
        }
        do
        {
            if (j >= i)
            {
                return new ByteString(abyte0);
            }
            int k = inputstream.read(abyte0, j, i - j);
            if (k != -1)
            {
                j += k;
            } else
            {
                throw new EOFException();
            }
        } while (true);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException
    {
        objectinputstream = read(objectinputstream, objectinputstream.readInt());
        try
        {
            Field field = okio/ByteString.getDeclaredField("data");
            field.setAccessible(true);
            field.set(this, ((ByteString) (objectinputstream)).data);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (ObjectInputStream objectinputstream)
        {
            throw new AssertionError();
        }
        // Misplaced declaration of an exception variable
        catch (ObjectInputStream objectinputstream)
        {
            throw new AssertionError();
        }
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(data.length);
        objectoutputstream.write(data);
    }

    public ByteBuffer asByteBuffer()
    {
        return ByteBuffer.wrap(data).asReadOnlyBuffer();
    }

    public String base64()
    {
        return Base64.encode(data);
    }

    public String base64Url()
    {
        return Base64.encodeUrl(data);
    }

    public volatile int compareTo(Object obj)
    {
        return compareTo((ByteString)obj);
    }

    public int compareTo(ByteString bytestring)
    {
        int j = size();
        int k = bytestring.size();
        int l = Math.min(j, k);
        int i = 0;
        do
        {
            int i1;
            int j1;
            if (i >= l)
            {
                if (j != k)
                {
                    return j < k ? -1 : 1;
                } else
                {
                    return 0;
                }
            }
            i1 = getByte(i) & 0xff;
            j1 = bytestring.getByte(i) & 0xff;
            if (i1 != j1)
            {
                return i1 < j1 ? -1 : 1;
            }
            i++;
        } while (true);
    }

    public final boolean endsWith(ByteString bytestring)
    {
        return rangeEquals(size() - bytestring.size(), bytestring, 0, bytestring.size());
    }

    public final boolean endsWith(byte abyte0[])
    {
        return rangeEquals(size() - abyte0.length, abyte0, 0, abyte0.length);
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            return (obj instanceof ByteString) && ((ByteString)obj).size() == data.length && ((ByteString)obj).rangeEquals(0, data, 0, data.length);
        } else
        {
            return true;
        }
    }

    public byte getByte(int i)
    {
        return data[i];
    }

    public int hashCode()
    {
        int j = hashCode;
        int i = j;
        if (j == 0)
        {
            i = Arrays.hashCode(data);
            hashCode = i;
        }
        return i;
    }

    public String hex()
    {
        int i = 0;
        char ac[] = new char[data.length * 2];
        byte abyte0[] = data;
        int k = abyte0.length;
        int j = 0;
        do
        {
            if (i >= k)
            {
                return new String(ac);
            }
            byte byte0 = abyte0[i];
            int l = j + 1;
            ac[j] = HEX_DIGITS[byte0 >> 4 & 0xf];
            j = l + 1;
            ac[l] = HEX_DIGITS[byte0 & 0xf];
            i++;
        } while (true);
    }

    public ByteString hmacSha1(ByteString bytestring)
    {
        return hmac("HmacSHA1", bytestring);
    }

    public ByteString hmacSha256(ByteString bytestring)
    {
        return hmac("HmacSHA256", bytestring);
    }

    public final int indexOf(ByteString bytestring)
    {
        return indexOf(bytestring.internalArray(), 0);
    }

    public final int indexOf(ByteString bytestring, int i)
    {
        return indexOf(bytestring.internalArray(), i);
    }

    public final int indexOf(byte abyte0[])
    {
        return indexOf(abyte0, 0);
    }

    public int indexOf(byte abyte0[], int i)
    {
        i = Math.max(i, 0);
        int j = data.length;
        int k = abyte0.length;
        do
        {
            if (i > j - k)
            {
                return -1;
            }
            if (!Util.arrayRangeEquals(data, i, abyte0, 0, abyte0.length))
            {
                i++;
            } else
            {
                return i;
            }
        } while (true);
    }

    byte[] internalArray()
    {
        return data;
    }

    public final int lastIndexOf(ByteString bytestring)
    {
        return lastIndexOf(bytestring.internalArray(), size());
    }

    public final int lastIndexOf(ByteString bytestring, int i)
    {
        return lastIndexOf(bytestring.internalArray(), i);
    }

    public final int lastIndexOf(byte abyte0[])
    {
        return lastIndexOf(abyte0, size());
    }

    public int lastIndexOf(byte abyte0[], int i)
    {
        i = Math.min(i, data.length - abyte0.length);
        do
        {
            if (i < 0)
            {
                return -1;
            }
            if (!Util.arrayRangeEquals(data, i, abyte0, 0, abyte0.length))
            {
                i--;
            } else
            {
                return i;
            }
        } while (true);
    }

    public ByteString md5()
    {
        return digest("MD5");
    }

    public boolean rangeEquals(int i, ByteString bytestring, int j, int k)
    {
        return bytestring.rangeEquals(j, data, i, k);
    }

    public boolean rangeEquals(int i, byte abyte0[], int j, int k)
    {
        while (i < 0 || i > data.length - k || j < 0 || j > abyte0.length - k || !Util.arrayRangeEquals(data, i, abyte0, j, k)) 
        {
            return false;
        }
        return true;
    }

    public ByteString sha1()
    {
        return digest("SHA-1");
    }

    public ByteString sha256()
    {
        return digest("SHA-256");
    }

    public int size()
    {
        return data.length;
    }

    public final boolean startsWith(ByteString bytestring)
    {
        return rangeEquals(0, bytestring, 0, bytestring.size());
    }

    public final boolean startsWith(byte abyte0[])
    {
        return rangeEquals(0, abyte0, 0, abyte0.length);
    }

    public String string(Charset charset)
    {
        if (charset != null)
        {
            return new String(data, charset);
        } else
        {
            throw new IllegalArgumentException("charset == null");
        }
    }

    public ByteString substring(int i)
    {
        return substring(i, data.length);
    }

    public ByteString substring(int i, int j)
    {
        if (i >= 0)
        {
            if (j <= data.length)
            {
                int k = j - i;
                if (k >= 0)
                {
                    if (i != 0 || j != data.length)
                    {
                        byte abyte0[] = new byte[k];
                        System.arraycopy(data, i, abyte0, 0, k);
                        return new ByteString(abyte0);
                    } else
                    {
                        return this;
                    }
                } else
                {
                    throw new IllegalArgumentException("endIndex < beginIndex");
                }
            } else
            {
                throw new IllegalArgumentException((new StringBuilder()).append("endIndex > length(").append(data.length).append(")").toString());
            }
        } else
        {
            throw new IllegalArgumentException("beginIndex < 0");
        }
    }

    public ByteString toAsciiLowercase()
    {
        int i = 0;
_L2:
        byte byte0;
        if (i >= data.length)
        {
            return this;
        }
        byte0 = data[i];
          goto _L1
_L4:
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        if (byte0 < 65 || byte0 > 90) goto _L4; else goto _L3
_L3:
        byte abyte0[] = (byte[])data.clone();
        abyte0[i] = (byte)(byte0 + 32);
        i++;
        do
        {
            if (i >= abyte0.length)
            {
                return new ByteString(abyte0);
            }
            byte byte1 = abyte0[i];
            while (false) 
            {
                if (byte1 >= 65 && byte1 <= 90)
                {
                    abyte0[i] = (byte)(byte1 + 32);
                }
                i++;
            }
        } while (true);
    }

    public ByteString toAsciiUppercase()
    {
        int i = 0;
_L2:
        byte byte0;
        if (i >= data.length)
        {
            return this;
        }
        byte0 = data[i];
          goto _L1
_L4:
        i++;
        if (true) goto _L2; else goto _L1
_L1:
        if (byte0 < 97 || byte0 > 122) goto _L4; else goto _L3
_L3:
        byte abyte0[] = (byte[])data.clone();
        abyte0[i] = (byte)(byte0 - 32);
        i++;
        do
        {
            if (i >= abyte0.length)
            {
                return new ByteString(abyte0);
            }
            byte byte1 = abyte0[i];
            while (false) 
            {
                if (byte1 >= 97 && byte1 <= 122)
                {
                    abyte0[i] = (byte)(byte1 - 32);
                }
                i++;
            }
        } while (true);
    }

    public byte[] toByteArray()
    {
        return (byte[])data.clone();
    }

    public String toString()
    {
        if (data.length != 0)
        {
            String s = utf8();
            int i = codePointIndexToCharIndex(s, 64);
            if (i != -1)
            {
                String s1 = s.substring(0, i).replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
                if (i >= s.length())
                {
                    return (new StringBuilder()).append("[text=").append(s1).append("]").toString();
                } else
                {
                    return (new StringBuilder()).append("[size=").append(data.length).append(" text=").append(s1).append("\u2026]").toString();
                }
            }
        } else
        {
            return "[size=0]";
        }
        if (data.length > 64)
        {
            return (new StringBuilder()).append("[size=").append(data.length).append(" hex=").append(substring(0, 64).hex()).append("\u2026]").toString();
        } else
        {
            return (new StringBuilder()).append("[hex=").append(hex()).append("]").toString();
        }
    }

    public String utf8()
    {
        String s1 = utf8;
        String s = s1;
        if (s1 == null)
        {
            s = new String(data, Util.UTF_8);
            utf8 = s;
        }
        return s;
    }

    public void write(OutputStream outputstream)
        throws IOException
    {
        if (outputstream != null)
        {
            outputstream.write(data);
            return;
        } else
        {
            throw new IllegalArgumentException("out == null");
        }
    }

    void write(Buffer buffer)
    {
        buffer.write(data, 0, data.length);
    }

}
