// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;

// Referenced classes of package okio:
//            Sink, AsyncTimeout, Buffer, Util, 
//            Segment, Timeout

class it>
    implements Sink
{

    final AsyncTimeout this$0;
    final Sink val$sink;

    public void close()
        throws IOException
    {
        enter();
        val$sink.close();
        exit(true);
        return;
        Object obj;
        obj;
        throw exit(((IOException) (obj)));
        obj;
        exit(false);
        throw obj;
    }

    public void flush()
        throws IOException
    {
        enter();
        val$sink.flush();
        exit(true);
        return;
        Object obj;
        obj;
        throw exit(((IOException) (obj)));
        obj;
        exit(false);
        throw obj;
    }

    public Timeout timeout()
    {
        return AsyncTimeout.this;
    }

    public String toString()
    {
        return (new StringBuilder()).append("AsyncTimeout.sink(").append(val$sink).append(")").toString();
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        Util.checkOffsetAndCount(buffer.size, 0L, l);
_L1:
        Segment segment;
        boolean flag;
        long l1;
        long l2;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_176;
        }
        segment = buffer.head;
        l1 = 0L;
_L2:
        if (l1 >= 0x10000L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        l2 = l1;
        if (!flag)
        {
            l1 = (long)(buffer.head.limit - buffer.head.pos) + l1;
            if (l1 < l)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                break MISSING_BLOCK_LABEL_145;
            }
            l2 = l;
        }
        enter();
        val$sink.write(buffer, l2);
        l -= l2;
        exit(true);
          goto _L1
        segment = segment.next;
          goto _L2
        buffer;
        throw exit(buffer);
        buffer;
        exit(false);
        throw buffer;
    }

    der()
    {
        this$0 = final_asynctimeout;
        val$sink = Sink.this;
        super();
    }
}
