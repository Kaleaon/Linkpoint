// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;


// Referenced classes of package okio:
//            AsyncTimeout

private static final class setDaemon extends Thread
{

    public void run()
    {
_L1:
        okio/AsyncTimeout;
        JVM INSTR monitorenter ;
        AsyncTimeout asynctimeout = AsyncTimeout.awaitTimeout();
        if (asynctimeout == null)
        {
            break MISSING_BLOCK_LABEL_32;
        }
        if (asynctimeout == AsyncTimeout.access$000())
        {
            break MISSING_BLOCK_LABEL_44;
        }
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
        try
        {
            asynctimeout.timedOut();
        }
        catch (InterruptedException interruptedexception) { }
          goto _L1
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
          goto _L1
        Exception exception;
        exception;
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
        throw exception;
        AsyncTimeout.access$002(null);
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
    }

    public ion()
    {
        super("Okio Watchdog");
        setDaemon(true);
    }
}
