// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.util.AbstractList;
import java.util.RandomAccess;

// Referenced classes of package okio:
//            ByteString

public final class Options extends AbstractList
    implements RandomAccess
{

    final ByteString byteStrings[];

    private Options(ByteString abytestring[])
    {
        byteStrings = abytestring;
    }

    public static transient Options of(ByteString abytestring[])
    {
        return new Options((ByteString[])abytestring.clone());
    }

    public volatile Object get(int i)
    {
        return get(i);
    }

    public ByteString get(int i)
    {
        return byteStrings[i];
    }

    public int size()
    {
        return byteStrings.length;
    }
}
