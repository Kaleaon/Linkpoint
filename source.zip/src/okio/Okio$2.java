// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.io.InputStream;

// Referenced classes of package okio:
//            Source, Okio, Timeout, Buffer, 
//            Segment

static class ject
    implements Source
{

    final InputStream val$in;
    final Timeout val$timeout;

    public void close()
        throws IOException
    {
        val$in.close();
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag = true;
        if (l < 0L)
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (l == 0L)
        {
            return 0L;
        }
        Segment segment;
        int i;
        try
        {
            val$timeout.throwIfReached();
            segment = buffer.writableSegment(1);
            i = (int)Math.min(l, 8192 - segment.limit);
            i = val$in.read(segment.data, segment.limit, i);
        }
        // Misplaced declaration of an exception variable
        catch (Buffer buffer)
        {
            if (!Okio.isAndroidGetsocknameError(buffer))
            {
                throw buffer;
            } else
            {
                throw new IOException(buffer);
            }
        }
        if (i == -1)
        {
            break MISSING_BLOCK_LABEL_142;
        }
        segment.limit = segment.limit + i;
        buffer.size = buffer.size + (long)i;
        return (long)i;
        return -1L;
    }

    public Timeout timeout()
    {
        return val$timeout;
    }

    public String toString()
    {
        return (new StringBuilder()).append("source(").append(val$in).append(")").toString();
    }

    tStream(Timeout timeout1, InputStream inputstream)
    {
        val$timeout = timeout1;
        val$in = inputstream;
        super();
    }
}
