// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

// Referenced classes of package okio:
//            Timeout, Sink, Source, Buffer, 
//            Util, Segment

public class AsyncTimeout extends Timeout
{
    private static final class Watchdog extends Thread
    {

        public void run()
        {
_L1:
            okio/AsyncTimeout;
            JVM INSTR monitorenter ;
            AsyncTimeout asynctimeout = AsyncTimeout.awaitTimeout();
            if (asynctimeout == null)
            {
                break MISSING_BLOCK_LABEL_32;
            }
            if (asynctimeout == AsyncTimeout.head)
            {
                break MISSING_BLOCK_LABEL_44;
            }
            okio/AsyncTimeout;
            JVM INSTR monitorexit ;
            try
            {
                asynctimeout.timedOut();
            }
            catch (InterruptedException interruptedexception) { }
              goto _L1
            okio/AsyncTimeout;
            JVM INSTR monitorexit ;
              goto _L1
            Exception exception;
            exception;
            okio/AsyncTimeout;
            JVM INSTR monitorexit ;
            throw exception;
            AsyncTimeout.head = null;
            okio/AsyncTimeout;
            JVM INSTR monitorexit ;
        }

        public Watchdog()
        {
            super("Okio Watchdog");
            setDaemon(true);
        }
    }


    private static final long IDLE_TIMEOUT_MILLIS;
    private static final long IDLE_TIMEOUT_NANOS;
    private static final int TIMEOUT_WRITE_SIZE = 0x10000;
    private static AsyncTimeout head;
    private boolean inQueue;
    private AsyncTimeout next;
    private long timeoutAt;

    public AsyncTimeout()
    {
    }

    static AsyncTimeout awaitTimeout()
        throws InterruptedException
    {
        boolean flag1 = true;
        boolean flag = true;
        AsyncTimeout asynctimeout = head.next;
        if (asynctimeout != null)
        {
            long l = asynctimeout.remainingNanos(System.nanoTime());
            if (l > 0L)
            {
                flag = false;
            }
            if (!flag)
            {
                long l1 = l / 0xf4240L;
                okio/AsyncTimeout.wait(l1, (int)(l - l1 * 0xf4240L));
                return null;
            } else
            {
                head.next = asynctimeout.next;
                asynctimeout.next = null;
                return asynctimeout;
            }
        }
        l = System.nanoTime();
        okio/AsyncTimeout.wait(IDLE_TIMEOUT_MILLIS);
        if (head.next == null)
        {
            if (System.nanoTime() - l < IDLE_TIMEOUT_NANOS)
            {
                flag = flag1;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                return head;
            }
        }
        return null;
    }

    private static boolean cancelScheduledTimeout(AsyncTimeout asynctimeout)
    {
        okio/AsyncTimeout;
        JVM INSTR monitorenter ;
        AsyncTimeout asynctimeout1 = head;
_L1:
        if (asynctimeout1 != null)
        {
            break MISSING_BLOCK_LABEL_16;
        }
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
        return true;
label0:
        {
            if (asynctimeout1.next == asynctimeout)
            {
                break label0;
            }
            asynctimeout1 = asynctimeout1.next;
        }
          goto _L1
        asynctimeout1.next = asynctimeout.next;
        asynctimeout.next = null;
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
        return false;
        asynctimeout;
        throw asynctimeout;
    }

    private long remainingNanos(long l)
    {
        return timeoutAt - l;
    }

    private static void scheduleTimeout(AsyncTimeout asynctimeout, long l, boolean flag)
    {
        okio/AsyncTimeout;
        JVM INSTR monitorenter ;
        if (head == null) goto _L2; else goto _L1
_L1:
        long l1 = System.nanoTime();
        if (l != 0L && flag) goto _L4; else goto _L3
_L3:
        if (l == 0L) goto _L6; else goto _L5
_L5:
        asynctimeout.timeoutAt = l1 + l;
_L9:
        AsyncTimeout asynctimeout1;
        l = asynctimeout.remainingNanos(l1);
        asynctimeout1 = head;
_L11:
        if (asynctimeout1.next != null) goto _L8; else goto _L7
_L7:
        asynctimeout.next = asynctimeout1.next;
        asynctimeout1.next = asynctimeout;
        asynctimeout = head;
        if (asynctimeout1 == asynctimeout)
        {
            break MISSING_BLOCK_LABEL_193;
        }
_L12:
        okio/AsyncTimeout;
        JVM INSTR monitorexit ;
        return;
_L2:
        head = new AsyncTimeout();
        (new Watchdog()).start();
          goto _L1
        asynctimeout;
        throw asynctimeout;
_L4:
        asynctimeout.timeoutAt = Math.min(l, asynctimeout.deadlineNanoTime() - l1) + l1;
          goto _L9
_L6:
        if (flag)
        {
            break MISSING_BLOCK_LABEL_149;
        }
        throw new AssertionError();
        asynctimeout.timeoutAt = asynctimeout.deadlineNanoTime();
          goto _L9
_L8:
        boolean flag1;
        if (l >= asynctimeout1.next.remainingNanos(l1))
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (!flag1) goto _L7; else goto _L10
_L10:
        asynctimeout1 = asynctimeout1.next;
          goto _L11
        okio/AsyncTimeout.notify();
          goto _L12
    }

    public final void enter()
    {
        if (!inQueue)
        {
            long l = timeoutNanos();
            boolean flag = hasDeadline();
            if (l != 0L || flag)
            {
                inQueue = true;
                scheduleTimeout(this, l, flag);
                return;
            } else
            {
                return;
            }
        } else
        {
            throw new IllegalStateException("Unbalanced enter/exit");
        }
    }

    final IOException exit(IOException ioexception)
        throws IOException
    {
        if (exit())
        {
            return newTimeoutException(ioexception);
        } else
        {
            return ioexception;
        }
    }

    final void exit(boolean flag)
        throws IOException
    {
        while (!exit() || !flag) 
        {
            return;
        }
        throw newTimeoutException(null);
    }

    public final boolean exit()
    {
        if (inQueue)
        {
            inQueue = false;
            return cancelScheduledTimeout(this);
        } else
        {
            return false;
        }
    }

    protected IOException newTimeoutException(IOException ioexception)
    {
        InterruptedIOException interruptedioexception = new InterruptedIOException("timeout");
        if (ioexception == null)
        {
            return interruptedioexception;
        } else
        {
            interruptedioexception.initCause(ioexception);
            return interruptedioexception;
        }
    }

    public final Sink sink(final Sink sink)
    {
        return new Sink() {

            final AsyncTimeout this$0;
            final Sink val$sink;

            public void close()
                throws IOException
            {
                enter();
                sink.close();
                exit(true);
                return;
                Object obj;
                obj;
                throw exit(((IOException) (obj)));
                obj;
                exit(false);
                throw obj;
            }

            public void flush()
                throws IOException
            {
                enter();
                sink.flush();
                exit(true);
                return;
                Object obj;
                obj;
                throw exit(((IOException) (obj)));
                obj;
                exit(false);
                throw obj;
            }

            public Timeout timeout()
            {
                return AsyncTimeout.this;
            }

            public String toString()
            {
                return (new StringBuilder()).append("AsyncTimeout.sink(").append(sink).append(")").toString();
            }

            public void write(Buffer buffer, long l)
                throws IOException
            {
                Util.checkOffsetAndCount(buffer.size, 0L, l);
_L1:
                Segment segment;
                boolean flag;
                long l1;
                long l2;
                if (l <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (flag)
                {
                    break MISSING_BLOCK_LABEL_176;
                }
                segment = buffer.head;
                l1 = 0L;
_L2:
                if (l1 >= 0x10000L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                l2 = l1;
                if (!flag)
                {
                    l1 = (long)(buffer.head.limit - buffer.head.pos) + l1;
                    if (l1 < l)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (flag)
                    {
                        break MISSING_BLOCK_LABEL_145;
                    }
                    l2 = l;
                }
                enter();
                sink.write(buffer, l2);
                l -= l2;
                exit(true);
                  goto _L1
                segment = segment.next;
                  goto _L2
                buffer;
                throw exit(buffer);
                buffer;
                exit(false);
                throw buffer;
            }

            
            {
                this$0 = AsyncTimeout.this;
                sink = sink1;
                super();
            }
        };
    }

    public final Source source(final Source source)
    {
        return new Source() {

            final AsyncTimeout this$0;
            final Source val$source;

            public void close()
                throws IOException
            {
                source.close();
                exit(true);
                return;
                Object obj;
                obj;
                throw exit(((IOException) (obj)));
                obj;
                exit(false);
                throw obj;
            }

            public long read(Buffer buffer, long l)
                throws IOException
            {
                enter();
                l = source.read(buffer, l);
                exit(true);
                return l;
                buffer;
                throw exit(buffer);
                buffer;
                exit(false);
                throw buffer;
            }

            public Timeout timeout()
            {
                return AsyncTimeout.this;
            }

            public String toString()
            {
                return (new StringBuilder()).append("AsyncTimeout.source(").append(source).append(")").toString();
            }

            
            {
                this$0 = AsyncTimeout.this;
                source = source1;
                super();
            }
        };
    }

    protected void timedOut()
    {
    }

    static 
    {
        IDLE_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(60L);
        IDLE_TIMEOUT_NANOS = TimeUnit.MILLISECONDS.toNanos(IDLE_TIMEOUT_MILLIS);
    }



/*
    static AsyncTimeout access$002(AsyncTimeout asynctimeout)
    {
        head = asynctimeout;
        return asynctimeout;
    }

*/
}
