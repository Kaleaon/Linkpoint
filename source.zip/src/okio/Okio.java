// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package okio:
//            RealBufferedSink, RealBufferedSource, Timeout, AsyncTimeout, 
//            Sink, BufferedSink, Source, BufferedSource, 
//            Buffer, Util, Segment, SegmentPool

public final class Okio
{

    static final Logger logger = Logger.getLogger(okio/Okio.getName());

    private Okio()
    {
    }

    public static Sink appendingSink(File file)
        throws FileNotFoundException
    {
        if (file != null)
        {
            return sink(new FileOutputStream(file, true));
        } else
        {
            throw new IllegalArgumentException("file == null");
        }
    }

    public static Sink blackhole()
    {
        return new Sink() {

            public void close()
                throws IOException
            {
            }

            public void flush()
                throws IOException
            {
            }

            public Timeout timeout()
            {
                return Timeout.NONE;
            }

            public void write(Buffer buffer1, long l)
                throws IOException
            {
                buffer1.skip(l);
            }

        };
    }

    public static BufferedSink buffer(Sink sink1)
    {
        return new RealBufferedSink(sink1);
    }

    public static BufferedSource buffer(Source source1)
    {
        return new RealBufferedSource(source1);
    }

    static boolean isAndroidGetsocknameError(AssertionError assertionerror)
    {
        while (assertionerror.getCause() == null || assertionerror.getMessage() == null || !assertionerror.getMessage().contains("getsockname failed")) 
        {
            return false;
        }
        return true;
    }

    public static Sink sink(File file)
        throws FileNotFoundException
    {
        if (file != null)
        {
            return sink(((OutputStream) (new FileOutputStream(file))));
        } else
        {
            throw new IllegalArgumentException("file == null");
        }
    }

    public static Sink sink(OutputStream outputstream)
    {
        return sink(outputstream, new Timeout());
    }

    private static Sink sink(OutputStream outputstream, Timeout timeout1)
    {
        if (outputstream != null)
        {
            if (timeout1 != null)
            {
                return new Sink(timeout1, outputstream) {

                    final OutputStream val$out;
                    final Timeout val$timeout;

                    public void close()
                        throws IOException
                    {
                        out.close();
                    }

                    public void flush()
                        throws IOException
                    {
                        out.flush();
                    }

                    public Timeout timeout()
                    {
                        return timeout;
                    }

                    public String toString()
                    {
                        return (new StringBuilder()).append("sink(").append(out).append(")").toString();
                    }

                    public void write(Buffer buffer1, long l)
                        throws IOException
                    {
                        Util.checkOffsetAndCount(buffer1.size, 0L, l);
                        do
                        {
                            int i;
                            if (l <= 0L)
                            {
                                i = 1;
                            } else
                            {
                                i = 0;
                            }
                            if (i == 0)
                            {
                                timeout.throwIfReached();
                                Segment segment = buffer1.head;
                                i = (int)Math.min(l, segment.limit - segment.pos);
                                out.write(segment.data, segment.pos, i);
                                segment.pos = segment.pos + i;
                                long l1 = l - (long)i;
                                buffer1.size = buffer1.size - (long)i;
                                l = l1;
                                if (segment.pos == segment.limit)
                                {
                                    buffer1.head = segment.pop();
                                    SegmentPool.recycle(segment);
                                    l = l1;
                                }
                            } else
                            {
                                return;
                            }
                        } while (true);
                    }

            
            {
                timeout = timeout1;
                out = outputstream;
                super();
            }
                };
            } else
            {
                throw new IllegalArgumentException("timeout == null");
            }
        } else
        {
            throw new IllegalArgumentException("out == null");
        }
    }

    public static Sink sink(Socket socket)
        throws IOException
    {
        if (socket != null)
        {
            AsyncTimeout asynctimeout = timeout(socket);
            return asynctimeout.sink(sink(socket.getOutputStream(), ((Timeout) (asynctimeout))));
        } else
        {
            throw new IllegalArgumentException("socket == null");
        }
    }

    public static transient Sink sink(Path path, OpenOption aopenoption[])
        throws IOException
    {
        if (path != null)
        {
            return sink(Files.newOutputStream(path, aopenoption));
        } else
        {
            throw new IllegalArgumentException("path == null");
        }
    }

    public static Source source(File file)
        throws FileNotFoundException
    {
        if (file != null)
        {
            return source(((InputStream) (new FileInputStream(file))));
        } else
        {
            throw new IllegalArgumentException("file == null");
        }
    }

    public static Source source(InputStream inputstream)
    {
        return source(inputstream, new Timeout());
    }

    private static Source source(InputStream inputstream, Timeout timeout1)
    {
        if (inputstream != null)
        {
            if (timeout1 != null)
            {
                return new Source(timeout1, inputstream) {

                    final InputStream val$in;
                    final Timeout val$timeout;

                    public void close()
                        throws IOException
                    {
                        in.close();
                    }

                    public long read(Buffer buffer1, long l)
                        throws IOException
                    {
                        boolean flag = true;
                        if (l < 0L)
                        {
                            flag = false;
                        }
                        if (!flag)
                        {
                            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
                        }
                        if (l == 0L)
                        {
                            return 0L;
                        }
                        Segment segment;
                        int i;
                        try
                        {
                            timeout.throwIfReached();
                            segment = buffer1.writableSegment(1);
                            i = (int)Math.min(l, 8192 - segment.limit);
                            i = in.read(segment.data, segment.limit, i);
                        }
                        // Misplaced declaration of an exception variable
                        catch (Buffer buffer1)
                        {
                            if (!Okio.isAndroidGetsocknameError(buffer1))
                            {
                                throw buffer1;
                            } else
                            {
                                throw new IOException(buffer1);
                            }
                        }
                        if (i == -1)
                        {
                            break MISSING_BLOCK_LABEL_142;
                        }
                        segment.limit = segment.limit + i;
                        buffer1.size = buffer1.size + (long)i;
                        return (long)i;
                        return -1L;
                    }

                    public Timeout timeout()
                    {
                        return timeout;
                    }

                    public String toString()
                    {
                        return (new StringBuilder()).append("source(").append(in).append(")").toString();
                    }

            
            {
                timeout = timeout1;
                in = inputstream;
                super();
            }
                };
            } else
            {
                throw new IllegalArgumentException("timeout == null");
            }
        } else
        {
            throw new IllegalArgumentException("in == null");
        }
    }

    public static Source source(Socket socket)
        throws IOException
    {
        if (socket != null)
        {
            AsyncTimeout asynctimeout = timeout(socket);
            return asynctimeout.source(source(socket.getInputStream(), ((Timeout) (asynctimeout))));
        } else
        {
            throw new IllegalArgumentException("socket == null");
        }
    }

    public static transient Source source(Path path, OpenOption aopenoption[])
        throws IOException
    {
        if (path != null)
        {
            return source(Files.newInputStream(path, aopenoption));
        } else
        {
            throw new IllegalArgumentException("path == null");
        }
    }

    private static AsyncTimeout timeout(Socket socket)
    {
        return new AsyncTimeout(socket) {

            final Socket val$socket;

            protected IOException newTimeoutException(IOException ioexception)
            {
                SocketTimeoutException sockettimeoutexception = new SocketTimeoutException("timeout");
                if (ioexception == null)
                {
                    return sockettimeoutexception;
                } else
                {
                    sockettimeoutexception.initCause(ioexception);
                    return sockettimeoutexception;
                }
            }

            protected void timedOut()
            {
                try
                {
                    socket.close();
                    return;
                }
                catch (Exception exception)
                {
                    Okio.logger.log(Level.WARNING, (new StringBuilder()).append("Failed to close timed out socket ").append(socket).toString(), exception);
                    return;
                }
                catch (AssertionError assertionerror)
                {
                    if (!Okio.isAndroidGetsocknameError(assertionerror))
                    {
                        throw assertionerror;
                    } else
                    {
                        Okio.logger.log(Level.WARNING, (new StringBuilder()).append("Failed to close timed out socket ").append(socket).toString(), assertionerror);
                        return;
                    }
                }
            }

            
            {
                socket = socket1;
                super();
            }
        };
    }

}
