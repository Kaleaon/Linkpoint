// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

// Referenced classes of package okio:
//            Source, Okio, BufferedSource, Buffer, 
//            Segment, SegmentPool, Timeout

public final class InflaterSource
    implements Source
{

    private int bufferBytesHeldByInflater;
    private boolean closed;
    private final Inflater inflater;
    private final BufferedSource source;

    InflaterSource(BufferedSource bufferedsource, Inflater inflater1)
    {
        if (bufferedsource != null)
        {
            if (inflater1 != null)
            {
                source = bufferedsource;
                inflater = inflater1;
                return;
            } else
            {
                throw new IllegalArgumentException("inflater == null");
            }
        } else
        {
            throw new IllegalArgumentException("source == null");
        }
    }

    public InflaterSource(Source source1, Inflater inflater1)
    {
        this(Okio.buffer(source1), inflater1);
    }

    private void releaseInflatedBytes()
        throws IOException
    {
        if (bufferBytesHeldByInflater != 0)
        {
            int i = bufferBytesHeldByInflater - inflater.getRemaining();
            bufferBytesHeldByInflater = bufferBytesHeldByInflater - i;
            source.skip(i);
            return;
        } else
        {
            return;
        }
    }

    public void close()
        throws IOException
    {
        if (!closed)
        {
            inflater.end();
            closed = true;
            source.close();
            return;
        } else
        {
            return;
        }
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        boolean flag = true;
        if (l < 0L)
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        }
        if (!closed)
        {
            if (l == 0L)
            {
                return 0L;
            }
        } else
        {
            throw new IllegalStateException("closed");
        }
          goto _L1
_L3:
        Segment segment;
        int i;
        boolean flag1;
        boolean flag2;
        try
        {
            flag1 = inflater.needsDictionary();
        }
        // Misplaced declaration of an exception variable
        catch (Buffer buffer)
        {
            throw new IOException(buffer);
        }
        if (flag1)
        {
            break; /* Loop/switch isn't completed */
        }
        if (flag2)
        {
            break MISSING_BLOCK_LABEL_223;
        }
_L1:
        flag2 = refill();
        segment = buffer.writableSegment(1);
        i = inflater.inflate(segment.data, segment.limit, 8192 - segment.limit);
        if (i > 0)
        {
            break MISSING_BLOCK_LABEL_167;
        }
        if (!inflater.finished()) goto _L3; else goto _L2
_L2:
        releaseInflatedBytes();
        if (segment.pos != segment.limit)
        {
            break MISSING_BLOCK_LABEL_233;
        }
        break MISSING_BLOCK_LABEL_196;
        segment.limit = segment.limit + i;
        buffer.size = buffer.size + (long)i;
        return (long)i;
        buffer.head = segment.pop();
        SegmentPool.recycle(segment);
        break MISSING_BLOCK_LABEL_233;
        throw new EOFException("source exhausted prematurely");
        return -1L;
    }

    public boolean refill()
        throws IOException
    {
        if (inflater.needsInput())
        {
            releaseInflatedBytes();
            if (inflater.getRemaining() == 0)
            {
                if (!source.exhausted())
                {
                    Segment segment = source.buffer().head;
                    bufferBytesHeldByInflater = segment.limit - segment.pos;
                    inflater.setInput(segment.data, segment.pos, bufferBytesHeldByInflater);
                    return false;
                } else
                {
                    return true;
                }
            } else
            {
                throw new IllegalStateException("?");
            }
        } else
        {
            return false;
        }
    }

    public Timeout timeout()
    {
        return source.timeout();
    }
}
