// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package okio:
//            BufferedSource, BufferedSink, ByteString, Segment, 
//            Util, SegmentPool, Sink, Options, 
//            SegmentedByteString, Timeout, Source

public final class Buffer
    implements BufferedSource, BufferedSink, Cloneable
{

    private static final byte DIGITS[] = {
        48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 
        97, 98, 99, 100, 101, 102
    };
    static final int REPLACEMENT_CHARACTER = 65533;
    Segment head;
    long size;

    public Buffer()
    {
    }

    private ByteString digest(String s)
    {
        try
        {
            MessageDigest messagedigest = MessageDigest.getInstance(s);
            if (head != null)
            {
                messagedigest.update(head.data, head.pos, head.limit - head.pos);
                s = head.next;
                while (s != head) 
                {
                    messagedigest.update(((Segment) (s)).data, ((Segment) (s)).pos, ((Segment) (s)).limit - ((Segment) (s)).pos);
                    s = ((Segment) (s)).next;
                }
            }
            return ByteString.of(messagedigest.digest());
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new AssertionError();
        }
    }

    private ByteString hmac(String s, ByteString bytestring)
    {
        try
        {
            Mac mac = Mac.getInstance(s);
            mac.init(new SecretKeySpec(bytestring.toByteArray(), s));
            if (head != null)
            {
                mac.update(head.data, head.pos, head.limit - head.pos);
                s = head.next;
                while (s != head) 
                {
                    mac.update(((Segment) (s)).data, ((Segment) (s)).pos, ((Segment) (s)).limit - ((Segment) (s)).pos);
                    s = ((Segment) (s)).next;
                }
            }
            return ByteString.of(mac.doFinal());
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new AssertionError();
        }
        // Misplaced declaration of an exception variable
        catch (String s)
        {
            throw new IllegalArgumentException(s);
        }
    }

    private boolean rangeEquals(Segment segment, int i, ByteString bytestring, int j, int k)
    {
        int l = segment.limit;
        byte abyte0[] = segment.data;
        Segment segment1 = segment;
        segment = abyte0;
        do
        {
            if (j >= k)
            {
                return true;
            }
            if (i == l)
            {
                segment1 = segment1.next;
                segment = segment1.data;
                i = segment1.pos;
                l = segment1.limit;
            }
            if (segment[i] == bytestring.getByte(j))
            {
                i++;
                j++;
            } else
            {
                return false;
            }
        } while (true);
    }

    private void readFrom(InputStream inputstream, long l, boolean flag)
        throws IOException
    {
        if (inputstream != null)
        {
            do
            {
                boolean flag1;
                if (l > 0L)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                if (!flag1 && !flag)
                {
                    return;
                }
                Segment segment = writableSegment(1);
                int i = (int)Math.min(l, 8192 - segment.limit);
                i = inputstream.read(segment.data, segment.limit, i);
                if (i == -1)
                {
                    break;
                }
                segment.limit = segment.limit + i;
                size = size + (long)i;
                l -= i;
            } while (true);
            if (!flag)
            {
                throw new EOFException();
            } else
            {
                return;
            }
        } else
        {
            throw new IllegalArgumentException("in == null");
        }
    }

    public Buffer buffer()
    {
        return this;
    }

    public void clear()
    {
        try
        {
            skip(size);
            return;
        }
        catch (EOFException eofexception)
        {
            throw new AssertionError(eofexception);
        }
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public Buffer clone()
    {
        Buffer buffer1 = new Buffer();
        if (size == 0L)
        {
            return buffer1;
        }
        buffer1.head = new Segment(head);
        Segment segment = buffer1.head;
        Segment segment1 = buffer1.head;
        Segment segment2 = buffer1.head;
        segment1.prev = segment2;
        segment.next = segment2;
        segment = head.next;
        do
        {
            if (segment == head)
            {
                buffer1.size = size;
                return buffer1;
            }
            buffer1.head.prev.push(new Segment(segment));
            segment = segment.next;
        } while (true);
    }

    public void close()
    {
    }

    public long completeSegmentByteCount()
    {
        long l = size;
        if (l == 0L)
        {
            return 0L;
        }
        Segment segment;
        for (segment = head.prev; segment.limit >= 8192 || !segment.owner;)
        {
            return l;
        }

        return l - (long)(segment.limit - segment.pos);
    }

    public Buffer copyTo(OutputStream outputstream)
        throws IOException
    {
        return copyTo(outputstream, 0L, size);
    }

    public Buffer copyTo(OutputStream outputstream, long l, long l1)
        throws IOException
    {
        if (outputstream != null)
        {
            Util.checkOffsetAndCount(size, l, l1);
            if (l1 == 0L)
            {
                return this;
            }
        } else
        {
            throw new IllegalArgumentException("out == null");
        }
        Segment segment = head;
        do
        {
            boolean flag;
            if (l < (long)(segment.limit - segment.pos))
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                l -= segment.limit - segment.pos;
                segment = segment.next;
            } else
            {
                do
                {
                    int i;
                    if (l1 <= 0L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = (int)((long)segment.pos + l);
                        int j = (int)Math.min(segment.limit - i, l1);
                        outputstream.write(segment.data, i, j);
                        l1 -= j;
                        segment = segment.next;
                        l = 0L;
                    } else
                    {
                        return this;
                    }
                } while (true);
            }
        } while (true);
    }

    public Buffer copyTo(Buffer buffer1, long l, long l1)
    {
        if (buffer1 != null)
        {
            Util.checkOffsetAndCount(size, l, l1);
            if (l1 == 0L)
            {
                return this;
            }
        } else
        {
            throw new IllegalArgumentException("out == null");
        }
        buffer1.size = buffer1.size + l1;
        Segment segment = head;
        do
        {
            boolean flag;
            if (l < (long)(segment.limit - segment.pos))
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                l -= segment.limit - segment.pos;
                segment = segment.next;
            } else
            {
                do
                {
                    boolean flag1;
                    if (l1 <= 0L)
                    {
                        flag1 = true;
                    } else
                    {
                        flag1 = false;
                    }
                    if (!flag1)
                    {
                        Segment segment1 = new Segment(segment);
                        segment1.pos = (int)((long)segment1.pos + l);
                        segment1.limit = Math.min(segment1.pos + (int)l1, segment1.limit);
                        if (buffer1.head != null)
                        {
                            buffer1.head.prev.push(segment1);
                        } else
                        {
                            segment1.prev = segment1;
                            segment1.next = segment1;
                            buffer1.head = segment1;
                        }
                        l1 -= segment1.limit - segment1.pos;
                        segment = segment.next;
                        l = 0L;
                    } else
                    {
                        return this;
                    }
                } while (true);
            }
        } while (true);
    }

    public BufferedSink emit()
    {
        return this;
    }

    public Buffer emitCompleteSegments()
    {
        return this;
    }

    public volatile BufferedSink emitCompleteSegments()
        throws IOException
    {
        return emitCompleteSegments();
    }

    public boolean equals(Object obj)
    {
        long l = 0L;
        if (this != obj)
        {
            if (obj instanceof Buffer)
            {
                obj = (Buffer)obj;
                if (size != ((Buffer) (obj)).size)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        } else
        {
            return true;
        }
        if (size == 0L)
        {
            return true;
        }
        Segment segment = head;
        obj = ((Buffer) (obj)).head;
        int j = segment.pos;
        int i = ((Segment) (obj)).pos;
        do
        {
            int k;
            if (l >= size)
            {
                k = 1;
            } else
            {
                k = 0;
            }
            if (k == 0)
            {
                long l1 = Math.min(segment.limit - j, ((Segment) (obj)).limit - i);
                k = 0;
                do
                {
                    boolean flag;
                    if ((long)k >= l1)
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                    }
                    if (flag)
                    {
                        break;
                    }
                    if (segment.data[j] == ((Segment) (obj)).data[i])
                    {
                        k++;
                        i++;
                        j++;
                    } else
                    {
                        return false;
                    }
                } while (true);
                if (j == segment.limit)
                {
                    segment = segment.next;
                    j = segment.pos;
                }
                if (i == ((Segment) (obj)).limit)
                {
                    obj = ((Segment) (obj)).next;
                    i = ((Segment) (obj)).pos;
                }
                l += l1;
            } else
            {
                return true;
            }
        } while (true);
    }

    public boolean exhausted()
    {
        return size == 0L;
    }

    public void flush()
    {
    }

    public byte getByte(long l)
    {
        Util.checkOffsetAndCount(size, l, 1L);
        Segment segment = head;
        do
        {
            int i = segment.limit - segment.pos;
            boolean flag;
            if (l >= (long)i)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                return segment.data[segment.pos + (int)l];
            }
            l -= i;
            segment = segment.next;
        } while (true);
    }

    public int hashCode()
    {
        Segment segment = head;
        if (segment == null) goto _L2; else goto _L1
_L1:
        int j = 1;
_L4:
        int i;
        int k;
        int l;
        k = segment.pos;
        l = segment.limit;
        i = j;
_L5:
        Segment segment1;
        if (k < l)
        {
            break MISSING_BLOCK_LABEL_56;
        }
        segment1 = segment.next;
        j = i;
        segment = segment1;
        if (segment1 != head) goto _L4; else goto _L3
_L3:
        return i;
_L2:
        return 0;
        byte byte0 = segment.data[k];
        k++;
        i = byte0 + i * 31;
          goto _L5
    }

    public ByteString hmacSha1(ByteString bytestring)
    {
        return hmac("HmacSHA1", bytestring);
    }

    public ByteString hmacSha256(ByteString bytestring)
    {
        return hmac("HmacSHA256", bytestring);
    }

    public long indexOf(byte byte0)
    {
        return indexOf(byte0, 0L);
    }

    public long indexOf(byte byte0, long l)
    {
        Segment segment;
        long l1;
        l1 = 0L;
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException("fromIndex < 0");
        }
        segment = head;
        if (segment == null) goto _L2; else goto _L1
_L1:
        Segment segment1;
        boolean flag1;
        long l2;
        long l4;
        if (size - l >= l)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (flag1) goto _L4; else goto _L3
_L3:
        l2 = size;
        segment1 = segment;
_L7:
        if (l2 <= l)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        l1 = l2;
        segment = segment1;
        l4 = l;
        if (flag1) goto _L6; else goto _L5
_L5:
        segment1 = segment1.prev;
        l2 -= segment1.limit - segment1.pos;
          goto _L7
_L2:
        return -1L;
_L4:
        segment1 = segment;
_L9:
        long l3 = (long)(segment1.limit - segment1.pos) + l1;
        boolean flag2;
        if (l3 >= l)
        {
            flag2 = true;
        } else
        {
            flag2 = false;
        }
        segment = segment1;
        l4 = l;
        if (flag2) goto _L6; else goto _L8
_L8:
        segment1 = segment1.next;
        l1 = l3;
          goto _L9
_L13:
        byte abyte0[];
        int i;
        if (abyte0[i] == byte0)
        {
            break MISSING_BLOCK_LABEL_311;
        }
        i++;
_L11:
        int j;
        if (i < j)
        {
            continue; /* Loop/switch isn't completed */
        }
        l1 += segment.limit - segment.pos;
        segment = segment.next;
        l4 = l1;
_L6:
        if (l1 >= size)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            abyte0 = segment.data;
            i = (int)(((long)segment.pos + l4) - l1);
            j = segment.limit;
        } else
        {
            return -1L;
        }
        if (true) goto _L11; else goto _L10
_L10:
        if (true) goto _L13; else goto _L12
_L12:
        return l1 + (long)(i - segment.pos);
    }

    public long indexOf(ByteString bytestring)
        throws IOException
    {
        return indexOf(bytestring, 0L);
    }

    public long indexOf(ByteString bytestring, long l)
        throws IOException
    {
        Segment segment;
        long l1;
        if (bytestring.size() != 0)
        {
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException("fromIndex < 0");
            }
        } else
        {
            throw new IllegalArgumentException("bytes is empty");
        }
        segment = head;
        if (segment != null)
        {
            boolean flag1;
            if (size - l >= l)
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (!flag1)
            {
                long l2 = size;
                Segment segment1 = segment;
                do
                {
                    if (l2 <= l)
                    {
                        flag1 = true;
                    } else
                    {
                        flag1 = false;
                    }
                    l1 = l2;
                    segment = segment1;
                    if (flag1)
                    {
                        break MISSING_BLOCK_LABEL_216;
                    }
                    segment1 = segment1.prev;
                    l2 -= segment1.limit - segment1.pos;
                } while (true);
            }
        } else
        {
            return -1L;
        }
        l1 = 0L;
        Segment segment2 = segment;
        do
        {
            long l3 = (long)(segment2.limit - segment2.pos) + l1;
            boolean flag2;
            if (l3 >= l)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
            segment = segment2;
            if (flag2)
            {
                break MISSING_BLOCK_LABEL_216;
            }
            segment2 = segment2.next;
            l1 = l3;
        } while (true);
        byte byte0 = bytestring.getByte(0);
        int j = bytestring.size();
        long l4 = (size - (long)j) + 1L;
label0:
        do
        {
            int i;
            if (l1 >= l4)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                byte abyte0[] = segment.data;
                int k = (int)Math.min(segment.limit, ((long)segment.pos + l4) - l1);
                i = (int)(((long)segment.pos + l) - l1);
                do
                {
                    if (i >= k)
                    {
                        l = (long)(segment.limit - segment.pos) + l1;
                        segment = segment.next;
                        l1 = l;
                        continue label0;
                    }
                    if (abyte0[i] != byte0 || !rangeEquals(segment, i + 1, bytestring, 1, j))
                    {
                        i++;
                    } else
                    {
                        return (long)(i - segment.pos) + l1;
                    }
                } while (true);
            }
            return -1L;
        } while (true);
    }

    public long indexOfElement(ByteString bytestring)
    {
        return indexOfElement(bytestring, 0L);
    }

    public long indexOfElement(ByteString bytestring, long l)
    {
        Segment segment;
        long l1;
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException("fromIndex < 0");
        }
        segment = head;
        if (segment != null)
        {
            boolean flag1;
            if (size - l >= l)
            {
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (!flag1)
            {
                long l2 = size;
                Segment segment1 = segment;
                do
                {
                    if (l2 <= l)
                    {
                        flag1 = true;
                    } else
                    {
                        flag1 = false;
                    }
                    l1 = l2;
                    segment = segment1;
                    if (flag1)
                    {
                        break MISSING_BLOCK_LABEL_199;
                    }
                    segment1 = segment1.prev;
                    l2 -= segment1.limit - segment1.pos;
                } while (true);
            }
        } else
        {
            return -1L;
        }
        l1 = 0L;
        Segment segment2 = segment;
        do
        {
            long l3 = (long)(segment2.limit - segment2.pos) + l1;
            boolean flag2;
            if (l3 >= l)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
            segment = segment2;
            if (flag2)
            {
                break MISSING_BLOCK_LABEL_199;
            }
            segment2 = segment2.next;
            l1 = l3;
        } while (true);
        if (bytestring.size() == 2) goto _L2; else goto _L1
_L1:
        bytestring = bytestring.internalArray();
_L5:
        byte abyte0[];
        int i;
        byte byte0;
        int k;
        int i1;
        byte byte2;
        if (l1 >= size)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_506;
        }
        abyte0 = segment.data;
        i = (int)(((long)segment.pos + l) - l1);
        k = segment.limit;
_L8:
        if (i < k) goto _L4; else goto _L3
_L3:
        l1 += segment.limit - segment.pos;
        segment = segment.next;
        l = l1;
          goto _L5
_L2:
        byte0 = bytestring.getByte(0);
        k = bytestring.getByte(1);
_L6:
        if (l1 >= size)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_506;
        }
        bytestring = segment.data;
        i = (int)(((long)segment.pos + l) - l1);
        i1 = segment.limit;
_L7:
label0:
        {
            if (i < i1)
            {
                break label0;
            }
            l1 += segment.limit - segment.pos;
            segment = segment.next;
            l = l1;
        }
          goto _L6
        for (byte2 = bytestring[i]; byte2 == byte0 || byte2 == k;)
        {
            return l1 + (long)(i - segment.pos);
        }

        i++;
          goto _L7
_L4:
        int j;
        byte byte1;
        int j1;
        byte1 = abyte0[i];
        j1 = bytestring.length;
        j = 0;
_L9:
label1:
        {
            if (j < j1)
            {
                break label1;
            }
            i++;
        }
          goto _L8
        if (byte1 != bytestring[j])
        {
            j++;
        } else
        {
            return l1 + (long)(i - segment.pos);
        }
          goto _L9
        return -1L;
          goto _L8
    }

    public InputStream inputStream()
    {
        return new InputStream() {

            final Buffer this$0;

            public int available()
            {
                return (int)Math.min(size, 0x7fffffffL);
            }

            public void close()
            {
            }

            public int read()
            {
                boolean flag;
                if (size <= 0L)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (!flag)
                {
                    return readByte() & 0xff;
                } else
                {
                    return -1;
                }
            }

            public int read(byte abyte0[], int i, int j)
            {
                return Buffer.this.read(abyte0, i, j);
            }

            public String toString()
            {
                return (new StringBuilder()).append(Buffer.this).append(".inputStream()").toString();
            }

            
            {
                this$0 = Buffer.this;
                super();
            }
        };
    }

    public ByteString md5()
    {
        return digest("MD5");
    }

    public OutputStream outputStream()
    {
        return new OutputStream() {

            final Buffer this$0;

            public void close()
            {
            }

            public void flush()
            {
            }

            public String toString()
            {
                return (new StringBuilder()).append(Buffer.this).append(".outputStream()").toString();
            }

            public void write(int i)
            {
                writeByte((byte)i);
            }

            public void write(byte abyte0[], int i, int j)
            {
                Buffer.this.write(abyte0, i, j);
            }

            
            {
                this$0 = Buffer.this;
                super();
            }
        };
    }

    public boolean rangeEquals(long l, ByteString bytestring)
    {
        return rangeEquals(l, bytestring, 0, bytestring.size());
    }

    public boolean rangeEquals(long l, ByteString bytestring, int i, int j)
    {
        boolean flag;
        if (l < 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        break MISSING_BLOCK_LABEL_9;
        if (!flag && i >= 0 && j >= 0)
        {
            int k;
            if (size - l < (long)j)
            {
                k = 1;
            } else
            {
                k = 0;
            }
            if (k == 0 && bytestring.size() - i >= j)
            {
                k = 0;
                do
                {
                    if (k >= j)
                    {
                        return true;
                    }
                    if (getByte((long)k + l) == bytestring.getByte(i + k))
                    {
                        k++;
                    } else
                    {
                        return false;
                    }
                } while (true);
            }
        }
        return false;
    }

    public int read(byte abyte0[])
    {
        return read(abyte0, 0, abyte0.length);
    }

    public int read(byte abyte0[], int i, int j)
    {
        Util.checkOffsetAndCount(abyte0.length, i, j);
        Segment segment = head;
        if (segment != null)
        {
            j = Math.min(j, segment.limit - segment.pos);
            System.arraycopy(segment.data, segment.pos, abyte0, i, j);
            segment.pos = segment.pos + j;
            size = size - (long)j;
            if (segment.pos != segment.limit)
            {
                return j;
            } else
            {
                head = segment.pop();
                SegmentPool.recycle(segment);
                return j;
            }
        } else
        {
            return -1;
        }
    }

    public long read(Buffer buffer1, long l)
    {
        boolean flag2 = true;
        if (buffer1 != null)
        {
            boolean flag;
            if (l >= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
            }
        } else
        {
            throw new IllegalArgumentException("sink == null");
        }
        if (size == 0L)
        {
            return -1L;
        }
        boolean flag1;
        if (l <= size)
        {
            flag1 = flag2;
        } else
        {
            flag1 = false;
        }
        if (!flag1)
        {
            l = size;
        }
        buffer1.write(this, l);
        return l;
    }

    public long readAll(Sink sink)
        throws IOException
    {
        long l = size;
        boolean flag;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            sink.write(this, l);
        }
        return l;
    }

    public byte readByte()
    {
        if (size == 0L)
        {
            throw new IllegalStateException("size == 0");
        }
        Segment segment = head;
        int i = segment.pos;
        int j = segment.limit;
        byte abyte0[] = segment.data;
        int k = i + 1;
        byte byte0 = abyte0[i];
        size = size - 1L;
        if (k != j)
        {
            segment.pos = k;
            return byte0;
        } else
        {
            head = segment.pop();
            SegmentPool.recycle(segment);
            return byte0;
        }
    }

    public byte[] readByteArray()
    {
        byte abyte0[];
        try
        {
            abyte0 = readByteArray(size);
        }
        catch (EOFException eofexception)
        {
            throw new AssertionError(eofexception);
        }
        return abyte0;
    }

    public byte[] readByteArray(long l)
        throws EOFException
    {
        Util.checkOffsetAndCount(size, 0L, l);
        boolean flag;
        if (l <= 0x7fffffffL)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount > Integer.MAX_VALUE: ").append(l).toString());
        } else
        {
            byte abyte0[] = new byte[(int)l];
            readFully(abyte0);
            return abyte0;
        }
    }

    public ByteString readByteString()
    {
        return new ByteString(readByteArray());
    }

    public ByteString readByteString(long l)
        throws EOFException
    {
        return new ByteString(readByteArray(l));
    }

    public long readDecimalLong()
    {
        boolean flag;
        int j;
        boolean flag1;
        long l1;
        long l2;
        if (size == 0L)
        {
            throw new IllegalStateException("size == 0");
        }
        l1 = 0L;
        j = 0;
        flag1 = false;
        flag = false;
        l2 = -7L;
_L11:
        Object obj;
        byte abyte0[];
        int i;
        int k;
        obj = head;
        abyte0 = ((Segment) (obj)).data;
        i = ((Segment) (obj)).pos;
        k = ((Segment) (obj)).limit;
_L7:
        if (i < k) goto _L2; else goto _L1
_L1:
        byte byte0;
        if (i != k)
        {
            obj.pos = i;
        } else
        {
            head = ((Segment) (obj)).pop();
            SegmentPool.recycle(((Segment) (obj)));
        }
          goto _L3
_L12:
        size = size - (long)j;
        l2 = l1;
        if (!flag1)
        {
            l2 = -l1;
        }
        return l2;
_L2:
        byte0 = abyte0[i];
          goto _L4
_L9:
        if (j != 0)
        {
            flag = true;
        } else
        {
            throw new NumberFormatException((new StringBuilder()).append("Expected leading [0-9] or '-' character but was 0x").append(Integer.toHexString(byte0)).toString());
        }
          goto _L1
_L4:
        if (byte0 < 48 || byte0 > 57) goto _L6; else goto _L5
_L5:
        int l;
label0:
        {
            l = 48 - byte0;
            boolean flag2;
            if (l1 < 0xf333333333333334L)
            {
                flag2 = true;
            } else
            {
                flag2 = false;
            }
            if (!flag2)
            {
                if (l1 != 0xf333333333333334L)
                {
                    break label0;
                }
                if ((long)l >= l2)
                {
                    flag2 = true;
                } else
                {
                    flag2 = false;
                }
                if (flag2)
                {
                    break label0;
                }
            }
            obj = (new Buffer()).writeDecimalLong(l1).writeByte(byte0);
            if (!flag1)
            {
                ((Buffer) (obj)).readByte();
            }
            throw new NumberFormatException((new StringBuilder()).append("Number too large: ").append(((Buffer) (obj)).readUtf8()).toString());
        }
        l1 = l1 * 10L + (long)l;
_L10:
        j++;
        i++;
          goto _L7
_L6:
        if (byte0 != 45 || j != 0) goto _L9; else goto _L8
_L8:
        flag1 = true;
        l2--;
          goto _L10
_L3:
        if (flag || head == null) goto _L12; else goto _L11
    }

    public Buffer readFrom(InputStream inputstream)
        throws IOException
    {
        readFrom(inputstream, 0x7fffffffffffffffL, true);
        return this;
    }

    public Buffer readFrom(InputStream inputstream, long l)
        throws IOException
    {
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("byteCount < 0: ").append(l).toString());
        } else
        {
            readFrom(inputstream, l, false);
            return this;
        }
    }

    public void readFully(Buffer buffer1, long l)
        throws EOFException
    {
        boolean flag;
        if (size >= l)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            buffer1.write(this, size);
            throw new EOFException();
        } else
        {
            buffer1.write(this, l);
            return;
        }
    }

    public void readFully(byte abyte0[])
        throws EOFException
    {
        int i = 0;
        do
        {
            if (i >= abyte0.length)
            {
                return;
            }
            int j = read(abyte0, i, abyte0.length - i);
            if (j != -1)
            {
                i += j;
            } else
            {
                throw new EOFException();
            }
        } while (true);
    }

    public long readHexadecimalUnsignedLong()
    {
        boolean flag;
        int k;
        long l1;
        if (size == 0L)
        {
            throw new IllegalStateException("size == 0");
        }
        l1 = 0L;
        k = 0;
        flag = false;
_L12:
        Object obj;
        byte abyte0[];
        int j;
        int l;
        obj = head;
        abyte0 = ((Segment) (obj)).data;
        j = ((Segment) (obj)).pos;
        l = ((Segment) (obj)).limit;
_L11:
        if (j < l) goto _L2; else goto _L1
_L1:
        int i;
        byte byte0;
        long l2;
        if (j != l)
        {
            obj.pos = j;
        } else
        {
            head = ((Segment) (obj)).pop();
            SegmentPool.recycle(((Segment) (obj)));
        }
        continue; /* Loop/switch isn't completed */
_L13:
        size = size - (long)k;
        return l1;
_L2:
        byte0 = abyte0[j];
          goto _L3
_L10:
        if (k != 0)
        {
            flag = true;
        } else
        {
            throw new NumberFormatException((new StringBuilder()).append("Expected leading [0-9a-fA-F] character but was 0x").append(Integer.toHexString(byte0)).toString());
        }
          goto _L1
_L3:
        if (byte0 < 48 || byte0 > 57) goto _L5; else goto _L4
_L4:
        i = byte0 - 48;
_L8:
        if ((0xf000000000000000L & l1) != 0L)
        {
            obj = (new Buffer()).writeHexadecimalUnsignedLong(l1).writeByte(byte0);
            throw new NumberFormatException((new StringBuilder()).append("Number too large: ").append(((Buffer) (obj)).readUtf8()).toString());
        }
        break MISSING_BLOCK_LABEL_272;
_L5:
        if (byte0 < 97 || byte0 > 102) goto _L7; else goto _L6
_L6:
        i = (byte0 - 97) + 10;
          goto _L8
_L7:
        if (byte0 < 65 || byte0 > 70) goto _L10; else goto _L9
_L9:
        i = (byte0 - 65) + 10;
          goto _L8
        l2 = i;
        k++;
        j++;
        l1 = l2 | l1 << 4;
          goto _L11
        if (flag || head == null) goto _L13; else goto _L12
    }

    public int readInt()
    {
        boolean flag;
        if (size >= 4L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalStateException((new StringBuilder()).append("size < 4: ").append(size).toString());
        }
        Segment segment = head;
        int j = segment.pos;
        int i = segment.limit;
        if (i - j >= 4)
        {
            byte abyte0[] = segment.data;
            int k = j + 1;
            j = abyte0[j];
            int i1 = k + 1;
            k = abyte0[k];
            int l = i1 + 1;
            byte byte0 = abyte0[i1];
            i1 = l + 1;
            j = (j & 0xff) << 24 | (k & 0xff) << 16 | (byte0 & 0xff) << 8 | abyte0[l] & 0xff;
            size = size - 4L;
            if (i1 != i)
            {
                segment.pos = i1;
                return j;
            } else
            {
                head = segment.pop();
                SegmentPool.recycle(segment);
                return j;
            }
        } else
        {
            return (readByte() & 0xff) << 24 | (readByte() & 0xff) << 16 | (readByte() & 0xff) << 8 | readByte() & 0xff;
        }
    }

    public int readIntLe()
    {
        return Util.reverseBytesInt(readInt());
    }

    public long readLong()
    {
        boolean flag;
        if (size >= 8L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalStateException((new StringBuilder()).append("size < 8: ").append(size).toString());
        }
        Segment segment = head;
        int k = segment.pos;
        int i = segment.limit;
        if (i - k >= 8)
        {
            byte abyte0[] = segment.data;
            int j = k + 1;
            long l = abyte0[k];
            k = j + 1;
            long l1 = abyte0[j];
            j = k + 1;
            long l2 = abyte0[k];
            k = j + 1;
            long l3 = abyte0[j];
            j = k + 1;
            long l4 = abyte0[k];
            k = j + 1;
            long l5 = abyte0[j];
            j = k + 1;
            long l6 = abyte0[k];
            k = j + 1;
            l = (l1 & 255L) << 48 | (l & 255L) << 56 | (l2 & 255L) << 40 | (l3 & 255L) << 32 | (l4 & 255L) << 24 | (l5 & 255L) << 16 | (l6 & 255L) << 8 | (long)abyte0[j] & 255L;
            size = size - 8L;
            if (k != i)
            {
                segment.pos = k;
                return l;
            } else
            {
                head = segment.pop();
                SegmentPool.recycle(segment);
                return l;
            }
        } else
        {
            return ((long)readInt() & 0xffffffffL) << 32 | (long)readInt() & 0xffffffffL;
        }
    }

    public long readLongLe()
    {
        return Util.reverseBytesLong(readLong());
    }

    public short readShort()
    {
        boolean flag;
        if (size >= 2L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalStateException((new StringBuilder()).append("size < 2: ").append(size).toString());
        }
        Segment segment = head;
        int k = segment.pos;
        int i = segment.limit;
        if (i - k >= 2)
        {
            byte abyte0[] = segment.data;
            int j = k + 1;
            k = abyte0[k];
            int l = j + 1;
            j = abyte0[j];
            size = size - 2L;
            if (l != i)
            {
                segment.pos = l;
            } else
            {
                head = segment.pop();
                SegmentPool.recycle(segment);
            }
            return (short)((k & 0xff) << 8 | j & 0xff);
        } else
        {
            return (short)((readByte() & 0xff) << 8 | readByte() & 0xff);
        }
    }

    public short readShortLe()
    {
        return Util.reverseBytesShort(readShort());
    }

    public String readString(long l, Charset charset)
        throws EOFException
    {
        Util.checkOffsetAndCount(size, 0L, l);
        if (charset != null)
        {
            boolean flag;
            if (l <= 0x7fffffffL)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                throw new IllegalArgumentException((new StringBuilder()).append("byteCount > Integer.MAX_VALUE: ").append(l).toString());
            }
        } else
        {
            throw new IllegalArgumentException("charset == null");
        }
        if (l == 0L)
        {
            return "";
        }
        Segment segment = head;
        boolean flag1;
        if ((long)segment.pos + l <= (long)segment.limit)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (!flag1)
        {
            return new String(readByteArray(l), charset);
        }
        charset = new String(segment.data, segment.pos, (int)l, charset);
        segment.pos = (int)((long)segment.pos + l);
        size = size - l;
        if (segment.pos != segment.limit)
        {
            return charset;
        } else
        {
            head = segment.pop();
            SegmentPool.recycle(segment);
            return charset;
        }
    }

    public String readString(Charset charset)
    {
        try
        {
            charset = readString(size, charset);
        }
        // Misplaced declaration of an exception variable
        catch (Charset charset)
        {
            throw new AssertionError(charset);
        }
        return charset;
    }

    public String readUtf8()
    {
        String s;
        try
        {
            s = readString(size, Util.UTF_8);
        }
        catch (EOFException eofexception)
        {
            throw new AssertionError(eofexception);
        }
        return s;
    }

    public String readUtf8(long l)
        throws EOFException
    {
        return readString(l, Util.UTF_8);
    }

    public int readUtf8CodePoint()
        throws EOFException
    {
        int l;
        boolean flag;
        byte byte1;
        l = 1;
        flag = false;
        if (size == 0L)
        {
            throw new EOFException();
        }
        byte1 = getByte(0L);
        if ((byte1 & 0x80) == 0) goto _L2; else goto _L1
_L2:
        int i;
        int j;
        int k;
        k = 1;
        i = byte1 & 0x7f;
        j = 0;
_L4:
        if (size >= (long)k)
        {
            flag = true;
        }
        if (!flag)
        {
            throw new EOFException((new StringBuilder()).append("size < ").append(k).append(": ").append(size).append(" (to read code point prefixed 0x").append(Integer.toHexString(byte1)).append(")").toString());
        }
        break; /* Loop/switch isn't completed */
_L1:
        if ((byte1 & 0xe0) != 192)
        {
            if ((byte1 & 0xf0) != 224)
            {
                if ((byte1 & 0xf8) != 240)
                {
                    skip(1L);
                    return 65533;
                }
            } else
            {
                i = byte1 & 0xf;
                k = 3;
                j = 2048;
                continue; /* Loop/switch isn't completed */
            }
        } else
        {
            i = byte1 & 0x1f;
            k = 2;
            j = 128;
            continue; /* Loop/switch isn't completed */
        }
        i = byte1 & 7;
        k = 4;
        j = 0x10000;
        if (true) goto _L4; else goto _L3
_L6:
        byte byte0;
        i = i << 6 | byte0 & 0x3f;
        l++;
_L3:
        if (l >= k)
        {
            skip(k);
            if (i <= 0x10ffff)
            {
                if (i < 55296 || i > 57343)
                {
                    if (i >= j)
                    {
                        return i;
                    } else
                    {
                        return 65533;
                    }
                } else
                {
                    return 65533;
                }
            } else
            {
                return 65533;
            }
        }
        byte0 = getByte(l);
        if ((byte0 & 0xc0) != 128)
        {
            skip(l);
            return 65533;
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public String readUtf8Line()
        throws EOFException
    {
        long l = indexOf((byte)10);
        if (l == -1L)
        {
            if (size != 0L)
            {
                return readUtf8(size);
            } else
            {
                return null;
            }
        } else
        {
            return readUtf8Line(l);
        }
    }

    String readUtf8Line(long l)
        throws EOFException
    {
        boolean flag;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag || getByte(l - 1L) != 13)
        {
            String s = readUtf8(l);
            skip(1L);
            return s;
        } else
        {
            String s1 = readUtf8(l - 1L);
            skip(2L);
            return s1;
        }
    }

    public String readUtf8LineStrict()
        throws EOFException
    {
        long l = indexOf((byte)10);
        if (l == -1L)
        {
            Buffer buffer1 = new Buffer();
            copyTo(buffer1, 0L, Math.min(32L, size));
            throw new EOFException((new StringBuilder()).append("\\n not found: size=").append(size()).append(" content=").append(buffer1.readByteString().hex()).append("\u2026").toString());
        } else
        {
            return readUtf8Line(l);
        }
    }

    public boolean request(long l)
    {
        boolean flag;
        if (size < l)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        return !flag;
    }

    public void require(long l)
        throws EOFException
    {
        boolean flag;
        if (size >= l)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new EOFException();
        } else
        {
            return;
        }
    }

    List segmentSizes()
    {
        Segment segment;
        ArrayList arraylist;
        if (head != null)
        {
            arraylist = new ArrayList();
            arraylist.add(Integer.valueOf(head.limit - head.pos));
            segment = head.next;
            break MISSING_BLOCK_LABEL_48;
        } else
        {
            return Collections.emptyList();
        }
        do
        {
            if (segment == head)
            {
                return arraylist;
            }
            arraylist.add(Integer.valueOf(segment.limit - segment.pos));
            segment = segment.next;
        } while (true);
    }

    public int select(Options options)
    {
        Segment segment;
        int i;
        segment = head;
        int j;
        if (segment != null)
        {
            options = options.byteStrings;
            j = options.length;
            i = 0;
            break MISSING_BLOCK_LABEL_21;
        } else
        {
            return options.indexOf(ByteString.EMPTY);
        }
        ByteString bytestring;
        do
        {
            if (i >= j)
            {
                return -1;
            }
            bytestring = options[i];
            boolean flag;
            if (size < (long)bytestring.size())
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag && rangeEquals(segment, segment.pos, bytestring, 0, bytestring.size()))
            {
                break;
            }
            i++;
        } while (true);
        try
        {
            skip(bytestring.size());
        }
        // Misplaced declaration of an exception variable
        catch (Options options)
        {
            throw new AssertionError(options);
        }
        return i;
    }

    int selectPrefix(Options options)
    {
        Segment segment = head;
        options = options.byteStrings;
        int j = options.length;
        int i = 0;
        do
        {
            if (i >= j)
            {
                return -1;
            }
            ByteString bytestring = options[i];
            for (int k = (int)Math.min(size, bytestring.size()); k == 0 || rangeEquals(segment, segment.pos, bytestring, 0, k);)
            {
                return i;
            }

            i++;
        } while (true);
    }

    public ByteString sha1()
    {
        return digest("SHA-1");
    }

    public ByteString sha256()
    {
        return digest("SHA-256");
    }

    public long size()
    {
        return size;
    }

    public void skip(long l)
        throws EOFException
    {
        do
        {
            int i;
            if (l <= 0L)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                if (head != null)
                {
                    i = (int)Math.min(l, head.limit - head.pos);
                    size = size - (long)i;
                    long l1 = l - (long)i;
                    Segment segment = head;
                    segment.pos = i + segment.pos;
                    l = l1;
                    if (head.pos == head.limit)
                    {
                        Segment segment1 = head;
                        head = segment1.pop();
                        SegmentPool.recycle(segment1);
                        l = l1;
                    }
                } else
                {
                    throw new EOFException();
                }
            } else
            {
                return;
            }
        } while (true);
    }

    public ByteString snapshot()
    {
        boolean flag;
        if (size <= 0x7fffffffL)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("size > Integer.MAX_VALUE: ").append(size).toString());
        } else
        {
            return snapshot((int)size);
        }
    }

    public ByteString snapshot(int i)
    {
        if (i != 0)
        {
            return new SegmentedByteString(this, i);
        } else
        {
            return ByteString.EMPTY;
        }
    }

    public Timeout timeout()
    {
        return Timeout.NONE;
    }

    public String toString()
    {
        return snapshot().toString();
    }

    Segment writableSegment(int i)
    {
        Segment segment;
label0:
        {
            while (i < 1 || i > 8192) 
            {
                throw new IllegalArgumentException();
            }
            if (head != null)
            {
                segment = head.prev;
                break label0;
            } else
            {
                head = SegmentPool.take();
                segment = head;
                Segment segment1 = head;
                Segment segment2 = head;
                segment1.prev = segment2;
                segment.next = segment2;
                return segment2;
            }
        }
        if (segment.limit + i > 8192 || !segment.owner)
        {
            return segment.push(SegmentPool.take());
        } else
        {
            return segment;
        }
    }

    public Buffer write(ByteString bytestring)
    {
        if (bytestring != null)
        {
            bytestring.write(this);
            return this;
        } else
        {
            throw new IllegalArgumentException("byteString == null");
        }
    }

    public Buffer write(byte abyte0[])
    {
        if (abyte0 != null)
        {
            return write(abyte0, 0, abyte0.length);
        } else
        {
            throw new IllegalArgumentException("source == null");
        }
    }

    public Buffer write(byte abyte0[], int i, int j)
    {
        if (abyte0 == null) goto _L2; else goto _L1
_L1:
        int k;
        Util.checkOffsetAndCount(abyte0.length, i, j);
        k = i + j;
_L4:
        if (i >= k)
        {
            size = size + (long)j;
            return this;
        }
        Segment segment = writableSegment(1);
        int l = Math.min(k - i, 8192 - segment.limit);
        System.arraycopy(abyte0, i, segment.data, segment.limit, l);
        i += l;
        segment.limit = l + segment.limit;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalArgumentException("source == null");
        if (true) goto _L4; else goto _L3
_L3:
    }

    public volatile BufferedSink write(ByteString bytestring)
        throws IOException
    {
        return write(bytestring);
    }

    public BufferedSink write(Source source, long l)
        throws IOException
    {
        do
        {
            boolean flag;
            if (l <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (!flag)
            {
                long l1 = source.read(this, l);
                if (l1 == -1L)
                {
                    throw new EOFException();
                }
                l -= l1;
            } else
            {
                return this;
            }
        } while (true);
    }

    public volatile BufferedSink write(byte abyte0[])
        throws IOException
    {
        return write(abyte0);
    }

    public volatile BufferedSink write(byte abyte0[], int i, int j)
        throws IOException
    {
        return write(abyte0, i, j);
    }

    public void write(Buffer buffer1, long l)
    {
        if (buffer1 == null) goto _L2; else goto _L1
_L1:
        if (buffer1 == this) goto _L4; else goto _L3
_L3:
        Util.checkOffsetAndCount(buffer1.size, 0L, l);
_L12:
        Segment segment;
        boolean flag;
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L6; else goto _L5
_L5:
        if (l >= (long)(buffer1.head.limit - buffer1.head.pos))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L8; else goto _L7
_L10:
        buffer1.head = buffer1.head.split((int)l);
_L8:
        segment = buffer1.head;
        long l1 = segment.limit - segment.pos;
        buffer1.head = segment.pop();
        int i;
        if (head != null)
        {
            head.prev.push(segment).compact();
        } else
        {
            head = segment;
            segment = head;
            Segment segment1 = head;
            Segment segment2 = head;
            segment1.prev = segment2;
            segment.next = segment2;
        }
        buffer1.size = buffer1.size - l1;
        size = size + l1;
        l -= l1;
        continue; /* Loop/switch isn't completed */
_L2:
        throw new IllegalArgumentException("source == null");
_L4:
        throw new IllegalArgumentException("source == this");
_L7:
        if (head == null)
        {
            segment = null;
        } else
        {
            segment = head.prev;
        }
        if (segment == null || !segment.owner)
        {
            break MISSING_BLOCK_LABEL_76;
        }
        l1 = segment.limit;
        if (!segment.shared)
        {
            i = segment.pos;
        } else
        {
            i = 0;
        }
        if ((l1 + l) - (long)i > 8192L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0) goto _L10; else goto _L9
_L9:
        buffer1.head.writeTo(segment, (int)l);
        buffer1.size = buffer1.size - l;
        size = size + l;
        return;
_L6:
        return;
        if (true) goto _L12; else goto _L11
_L11:
    }

    public long writeAll(Source source)
        throws IOException
    {
        if (source != null)
        {
            long l = 0L;
            do
            {
                long l1 = source.read(this, 8192L);
                if (l1 != -1L)
                {
                    l += l1;
                } else
                {
                    return l;
                }
            } while (true);
        } else
        {
            throw new IllegalArgumentException("source == null");
        }
    }

    public Buffer writeByte(int i)
    {
        Segment segment = writableSegment(1);
        byte abyte0[] = segment.data;
        int j = segment.limit;
        segment.limit = j + 1;
        abyte0[j] = (byte)i;
        size = size + 1L;
        return this;
    }

    public volatile BufferedSink writeByte(int i)
        throws IOException
    {
        return writeByte(i);
    }

    public Buffer writeDecimalLong(long l)
    {
        Segment segment;
        byte abyte0[];
        int i;
        boolean flag;
        int j;
        if (l == 0L)
        {
            return writeByte(48);
        }
        if (l >= 0L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            l = -l;
            int k;
            if (l >= 0L)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                return writeUtf8("-9223372036854775808");
            }
            break MISSING_BLOCK_LABEL_202;
        }
        flag = false;
_L1:
        if (l >= 0x5f5e100L)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i == 0)
        {
            if (l >= 10000L)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                if (l >= 100L)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    if (l >= 10L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 1;
                    } else
                    {
                        i = 2;
                    }
                } else
                {
                    if (l >= 1000L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 3;
                    } else
                    {
                        i = 4;
                    }
                }
            } else
            {
                if (l >= 0xf4240L)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    if (l >= 0x186a0L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 5;
                    } else
                    {
                        i = 6;
                    }
                } else
                {
                    if (l >= 0x989680L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 7;
                    } else
                    {
                        i = 8;
                    }
                }
            }
        } else
        {
            if (l >= 0xe8d4a51000L)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                if (l >= 0x2540be400L)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    if (l >= 0x3b9aca00L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 9;
                    } else
                    {
                        i = 10;
                    }
                } else
                {
                    if (l >= 0x174876e800L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 11;
                    } else
                    {
                        i = 12;
                    }
                }
            } else
            {
                if (l >= 0x38d7ea4c68000L)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    if (l >= 0x9184e72a000L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        i = 13;
                    } else
                    {
                        if (l >= 0x5af3107a4000L)
                        {
                            i = 1;
                        } else
                        {
                            i = 0;
                        }
                        if (i == 0)
                        {
                            i = 14;
                        } else
                        {
                            i = 15;
                        }
                    }
                } else
                {
                    if (l >= 0x16345785d8a0000L)
                    {
                        i = 1;
                    } else
                    {
                        i = 0;
                    }
                    if (i == 0)
                    {
                        if (l >= 0x2386f26fc10000L)
                        {
                            i = 1;
                        } else
                        {
                            i = 0;
                        }
                        if (i == 0)
                        {
                            i = 16;
                        } else
                        {
                            i = 17;
                        }
                    } else
                    {
                        if (l >= 0xde0b6b3a7640000L)
                        {
                            i = 1;
                        } else
                        {
                            i = 0;
                        }
                        if (i == 0)
                        {
                            i = 18;
                        } else
                        {
                            i = 19;
                        }
                    }
                }
            }
        }
        if (flag)
        {
            i++;
        }
        segment = writableSegment(i);
        abyte0 = segment.data;
        j = segment.limit + i;
        for (; l != 0L; l /= 10L)
        {
            k = (int)(l % 10L);
            j--;
            abyte0[j] = DIGITS[k];
        }

        break MISSING_BLOCK_LABEL_671;
        flag = true;
          goto _L1
        if (flag)
        {
            abyte0[j - 1] = 45;
        }
        segment.limit = segment.limit + i;
        l = size;
        size = (long)i + l;
        return this;
    }

    public volatile BufferedSink writeDecimalLong(long l)
        throws IOException
    {
        return writeDecimalLong(l);
    }

    public Buffer writeHexadecimalUnsignedLong(long l)
    {
        if (l == 0L)
        {
            return writeByte(48);
        }
        int j = Long.numberOfTrailingZeros(Long.highestOneBit(l)) / 4 + 1;
        Segment segment = writableSegment(j);
        byte abyte0[] = segment.data;
        int i = (segment.limit + j) - 1;
        int k = segment.limit;
        do
        {
            if (i < k)
            {
                segment.limit = segment.limit + j;
                l = size;
                size = (long)j + l;
                return this;
            }
            abyte0[i] = DIGITS[(int)(15L & l)];
            l >>>= 4;
            i--;
        } while (true);
    }

    public volatile BufferedSink writeHexadecimalUnsignedLong(long l)
        throws IOException
    {
        return writeHexadecimalUnsignedLong(l);
    }

    public Buffer writeInt(int i)
    {
        Segment segment = writableSegment(4);
        byte abyte0[] = segment.data;
        int k = segment.limit;
        int j = k + 1;
        abyte0[k] = (byte)(i >>> 24 & 0xff);
        k = j + 1;
        abyte0[j] = (byte)(i >>> 16 & 0xff);
        j = k + 1;
        abyte0[k] = (byte)(i >>> 8 & 0xff);
        abyte0[j] = (byte)(i & 0xff);
        segment.limit = j + 1;
        size = size + 4L;
        return this;
    }

    public volatile BufferedSink writeInt(int i)
        throws IOException
    {
        return writeInt(i);
    }

    public Buffer writeIntLe(int i)
    {
        return writeInt(Util.reverseBytesInt(i));
    }

    public volatile BufferedSink writeIntLe(int i)
        throws IOException
    {
        return writeIntLe(i);
    }

    public Buffer writeLong(long l)
    {
        Segment segment = writableSegment(8);
        byte abyte0[] = segment.data;
        int j = segment.limit;
        int i = j + 1;
        abyte0[j] = (byte)(int)(l >>> 56 & 255L);
        j = i + 1;
        abyte0[i] = (byte)(int)(l >>> 48 & 255L);
        i = j + 1;
        abyte0[j] = (byte)(int)(l >>> 40 & 255L);
        j = i + 1;
        abyte0[i] = (byte)(int)(l >>> 32 & 255L);
        i = j + 1;
        abyte0[j] = (byte)(int)(l >>> 24 & 255L);
        j = i + 1;
        abyte0[i] = (byte)(int)(l >>> 16 & 255L);
        i = j + 1;
        abyte0[j] = (byte)(int)(l >>> 8 & 255L);
        abyte0[i] = (byte)(int)(l & 255L);
        segment.limit = i + 1;
        size = size + 8L;
        return this;
    }

    public volatile BufferedSink writeLong(long l)
        throws IOException
    {
        return writeLong(l);
    }

    public Buffer writeLongLe(long l)
    {
        return writeLong(Util.reverseBytesLong(l));
    }

    public volatile BufferedSink writeLongLe(long l)
        throws IOException
    {
        return writeLongLe(l);
    }

    public Buffer writeShort(int i)
    {
        Segment segment = writableSegment(2);
        byte abyte0[] = segment.data;
        int j = segment.limit;
        int k = j + 1;
        abyte0[j] = (byte)(i >>> 8 & 0xff);
        abyte0[k] = (byte)(i & 0xff);
        segment.limit = k + 1;
        size = size + 2L;
        return this;
    }

    public volatile BufferedSink writeShort(int i)
        throws IOException
    {
        return writeShort(i);
    }

    public Buffer writeShortLe(int i)
    {
        return writeShort(Util.reverseBytesShort((short)i));
    }

    public volatile BufferedSink writeShortLe(int i)
        throws IOException
    {
        return writeShortLe(i);
    }

    public Buffer writeString(String s, int i, int j, Charset charset)
    {
        if (s != null)
        {
            if (i >= 0)
            {
                if (j >= i)
                {
                    if (j <= s.length())
                    {
                        if (charset != null)
                        {
                            if (!charset.equals(Util.UTF_8))
                            {
                                s = s.substring(i, j).getBytes(charset);
                                return write(s, 0, s.length);
                            } else
                            {
                                return writeUtf8(s, i, j);
                            }
                        } else
                        {
                            throw new IllegalArgumentException("charset == null");
                        }
                    } else
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("endIndex > string.length: ").append(j).append(" > ").append(s.length()).toString());
                    }
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("endIndex < beginIndex: ").append(j).append(" < ").append(i).toString());
                }
            } else
            {
                throw new IllegalAccessError((new StringBuilder()).append("beginIndex < 0: ").append(i).toString());
            }
        } else
        {
            throw new IllegalArgumentException("string == null");
        }
    }

    public Buffer writeString(String s, Charset charset)
    {
        return writeString(s, 0, s.length(), charset);
    }

    public volatile BufferedSink writeString(String s, int i, int j, Charset charset)
        throws IOException
    {
        return writeString(s, i, j, charset);
    }

    public volatile BufferedSink writeString(String s, Charset charset)
        throws IOException
    {
        return writeString(s, charset);
    }

    public Buffer writeTo(OutputStream outputstream)
        throws IOException
    {
        return writeTo(outputstream, size);
    }

    public Buffer writeTo(OutputStream outputstream, long l)
        throws IOException
    {
        if (outputstream != null)
        {
            Util.checkOffsetAndCount(size, 0L, l);
            Segment segment = head;
            do
            {
                int i;
                if (l <= 0L)
                {
                    i = 1;
                } else
                {
                    i = 0;
                }
                if (i == 0)
                {
                    i = (int)Math.min(l, segment.limit - segment.pos);
                    outputstream.write(segment.data, segment.pos, i);
                    segment.pos = segment.pos + i;
                    size = size - (long)i;
                    long l1 = l - (long)i;
                    l = l1;
                    if (segment.pos == segment.limit)
                    {
                        Segment segment1 = segment.pop();
                        head = segment1;
                        SegmentPool.recycle(segment);
                        segment = segment1;
                        l = l1;
                    }
                } else
                {
                    return this;
                }
            } while (true);
        } else
        {
            throw new IllegalArgumentException("out == null");
        }
    }

    public Buffer writeUtf8(String s)
    {
        return writeUtf8(s, 0, s.length());
    }

    public Buffer writeUtf8(String s, int i, int j)
    {
        if (s != null)
        {
            if (i >= 0)
            {
                if (j >= i)
                {
                    if (j <= s.length())
                    {
                        break MISSING_BLOCK_LABEL_21;
                    } else
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("endIndex > string.length: ").append(j).append(" > ").append(s.length()).toString());
                    }
                } else
                {
                    throw new IllegalArgumentException((new StringBuilder()).append("endIndex < beginIndex: ").append(j).append(" < ").append(i).toString());
                }
            } else
            {
                throw new IllegalAccessError((new StringBuilder()).append("beginIndex < 0: ").append(i).toString());
            }
        } else
        {
            throw new IllegalArgumentException("string == null");
        }
_L3:
        do
        {
            if (i >= j)
            {
                return this;
            }
label0:
            {
                char c = s.charAt(i);
                if (c < '\200')
                {
                    break label0;
                }
                Segment segment;
                byte abyte0[];
                int k;
                int i1;
                int j1;
                long l1;
                if (c >= '\u0800')
                {
                    if (c < '\uD800' || c > '\uDFFF')
                    {
                        writeByte(c >> 12 | 0xe0);
                        writeByte(c >> 6 & 0x3f | 0x80);
                        writeByte(c & 0x3f | 0x80);
                        i++;
                    } else
                    {
                        int l;
                        if (i + 1 >= j)
                        {
                            l = 0;
                        } else
                        {
                            l = s.charAt(i + 1);
                        }
                        if (c > '\uDBFF' || l < '\uDC00' || l > '\uDFFF')
                        {
                            writeByte(63);
                            i++;
                        } else
                        {
                            l = (l & 0xffff23ff | (c & 0xffff27ff) << 10) + 0x10000;
                            writeByte(l >> 18 | 0xf0);
                            writeByte(l >> 12 & 0x3f | 0x80);
                            writeByte(l >> 6 & 0x3f | 0x80);
                            writeByte(l & 0x3f | 0x80);
                            i += 2;
                        }
                    }
                } else
                {
                    writeByte(c >> 6 | 0xc0);
                    writeByte(c & 0x3f | 0x80);
                    i++;
                }
            }
        } while (true);
        segment = writableSegment(1);
        abyte0 = segment.data;
        i1 = segment.limit - i;
        j1 = Math.min(j, 8192 - i1);
        k = i + 1;
        abyte0[i1 + i] = (byte)c;
        i = k;
_L5:
        if (i < j1) goto _L2; else goto _L1
_L1:
        k = (i + i1) - segment.limit;
        segment.limit = segment.limit + k;
        l1 = size;
        size = (long)k + l1;
          goto _L3
_L2:
        if ((k = s.charAt(i)) >= '\200') goto _L1; else goto _L4
_L4:
        abyte0[i + i1] = (byte)k;
        i++;
          goto _L5
    }

    public volatile BufferedSink writeUtf8(String s)
        throws IOException
    {
        return writeUtf8(s);
    }

    public volatile BufferedSink writeUtf8(String s, int i, int j)
        throws IOException
    {
        return writeUtf8(s, i, j);
    }

    public Buffer writeUtf8CodePoint(int i)
    {
        if (i >= 128)
        {
            if (i >= 2048)
            {
                if (i >= 0x10000)
                {
                    if (i > 0x10ffff)
                    {
                        throw new IllegalArgumentException((new StringBuilder()).append("Unexpected code point: ").append(Integer.toHexString(i)).toString());
                    } else
                    {
                        writeByte(i >> 18 | 0xf0);
                        writeByte(i >> 12 & 0x3f | 0x80);
                        writeByte(i >> 6 & 0x3f | 0x80);
                        writeByte(i & 0x3f | 0x80);
                        return this;
                    }
                }
            } else
            {
                writeByte(i >> 6 | 0xc0);
                writeByte(i & 0x3f | 0x80);
                return this;
            }
        } else
        {
            writeByte(i);
            return this;
        }
        while (i < 55296 || i > 57343) 
        {
            writeByte(i >> 12 | 0xe0);
            writeByte(i >> 6 & 0x3f | 0x80);
            writeByte(i & 0x3f | 0x80);
            return this;
        }
        throw new IllegalArgumentException((new StringBuilder()).append("Unexpected code point: ").append(Integer.toHexString(i)).toString());
    }

    public volatile BufferedSink writeUtf8CodePoint(int i)
        throws IOException
    {
        return writeUtf8CodePoint(i);
    }

}
