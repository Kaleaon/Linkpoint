// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

public class Timeout
{

    public static final Timeout NONE = new Timeout() {

        public Timeout deadlineNanoTime(long l)
        {
            return this;
        }

        public void throwIfReached()
            throws IOException
        {
        }

        public Timeout timeout(long l, TimeUnit timeunit)
        {
            return this;
        }

    };
    private long deadlineNanoTime;
    private boolean hasDeadline;
    private long timeoutNanos;

    public Timeout()
    {
    }

    public Timeout clearDeadline()
    {
        hasDeadline = false;
        return this;
    }

    public Timeout clearTimeout()
    {
        timeoutNanos = 0L;
        return this;
    }

    public final Timeout deadline(long l, TimeUnit timeunit)
    {
        boolean flag;
        if (l > 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("duration <= 0: ").append(l).toString());
        }
        if (timeunit != null)
        {
            return deadlineNanoTime(System.nanoTime() + timeunit.toNanos(l));
        } else
        {
            throw new IllegalArgumentException("unit == null");
        }
    }

    public long deadlineNanoTime()
    {
        if (hasDeadline)
        {
            return deadlineNanoTime;
        } else
        {
            throw new IllegalStateException("No deadline");
        }
    }

    public Timeout deadlineNanoTime(long l)
    {
        hasDeadline = true;
        deadlineNanoTime = l;
        return this;
    }

    public boolean hasDeadline()
    {
        return hasDeadline;
    }

    public void throwIfReached()
        throws IOException
    {
        boolean flag = false;
        if (!Thread.interrupted())
        {
            if (hasDeadline)
            {
                if (deadlineNanoTime - System.nanoTime() > 0L)
                {
                    flag = true;
                }
                if (!flag)
                {
                    throw new InterruptedIOException("deadline reached");
                }
            }
            return;
        } else
        {
            throw new InterruptedIOException("thread interrupted");
        }
    }

    public Timeout timeout(long l, TimeUnit timeunit)
    {
        boolean flag;
        if (l >= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("timeout < 0: ").append(l).toString());
        }
        if (timeunit != null)
        {
            timeoutNanos = timeunit.toNanos(l);
            return this;
        } else
        {
            throw new IllegalArgumentException("unit == null");
        }
    }

    public long timeoutNanos()
    {
        return timeoutNanos;
    }

    public final void waitUntilNotified(Object obj)
        throws InterruptedIOException
    {
        long l2 = System.nanoTime();
          goto _L1
_L9:
        boolean flag;
        if (flag) goto _L3; else goto _L2
_L2:
        l1 = l / 0xf4240L;
        obj.wait(l1, (int)(l - l1 * 0xf4240L));
        l1 = System.nanoTime() - l2;
          goto _L3
_L10:
        if (flag) goto _L5; else goto _L4
_L4:
        throw new InterruptedIOException("timeout");
        l1 = 0L;
        try
        {
            flag1 = hasDeadline();
            l = timeoutNanos();
        }
        // Misplaced declaration of an exception variable
        catch (Object obj)
        {
            throw new InterruptedIOException("interrupted");
        }
        if (flag1 || l != 0L)
        {
            break MISSING_BLOCK_LABEL_19;
        }
        obj.wait();
        return;
_L1:
        if (!flag1 || l == 0L) goto _L7; else goto _L6
_L6:
        l = Math.min(l, deadlineNanoTime() - l2);
          goto _L8
_L11:
        l = deadlineNanoTime();
        l -= l2;
        break; /* Loop/switch isn't completed */
_L13:
        flag = false;
          goto _L9
_L15:
        flag = false;
          goto _L10
_L5:
        return;
_L7:
        if (flag1) goto _L11; else goto _L8
_L8:
        if (l > 0L) goto _L13; else goto _L12
_L12:
        flag = true;
          goto _L9
_L3:
        if (l1 >= l) goto _L15; else goto _L14
_L14:
        flag = true;
          goto _L10
    }

}
