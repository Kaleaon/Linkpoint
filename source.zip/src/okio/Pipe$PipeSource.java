// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;

// Referenced classes of package okio:
//            Source, Pipe, Timeout, Buffer

final class t>
    implements Source
{

    final Pipe this$0;
    final Timeout timeout = new Timeout();

    public void close()
        throws IOException
    {
        synchronized (Pipe.this.buffer)
        {
            sourceClosed = true;
            Pipe.this.buffer.notifyAll();
        }
        return;
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        Buffer buffer1 = Pipe.this.buffer;
        buffer1;
        JVM INSTR monitorenter ;
        if (sourceClosed) goto _L2; else goto _L1
_L1:
        do
        {
            if (Pipe.this.buffer.size() != 0L)
            {
                break MISSING_BLOCK_LABEL_87;
            }
            if (sinkClosed)
            {
                break;
            }
            timeout.waitUntilNotified(Pipe.this.buffer);
        } while (true);
          goto _L3
        buffer;
        buffer1;
        JVM INSTR monitorexit ;
        throw buffer;
_L2:
        throw new IllegalStateException("closed");
_L3:
        buffer1;
        JVM INSTR monitorexit ;
        return -1L;
        l = Pipe.this.buffer.read(buffer, l);
        Pipe.this.buffer.notifyAll();
        buffer1;
        JVM INSTR monitorexit ;
        return l;
    }

    public Timeout timeout()
    {
        return timeout;
    }

    eException()
    {
        this$0 = Pipe.this;
        super();
    }
}
