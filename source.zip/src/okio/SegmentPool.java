// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;


// Referenced classes of package okio:
//            Segment

final class SegmentPool
{

    static final long MAX_SIZE = 0x10000L;
    static long byteCount;
    static Segment next;

    private SegmentPool()
    {
    }

    static void recycle(Segment segment)
    {
        boolean flag;
        for (flag = false; segment.next != null || segment.prev != null;)
        {
            throw new IllegalArgumentException();
        }

        if (segment.shared)
        {
            break MISSING_BLOCK_LABEL_99;
        }
        okio/SegmentPool;
        JVM INSTR monitorenter ;
        if (byteCount + 8192L <= 0x10000L)
        {
            flag = true;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_58;
        }
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        return;
        byteCount += 8192L;
        segment.next = next;
        segment.limit = 0;
        segment.pos = 0;
        next = segment;
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        return;
        segment;
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        throw segment;
    }

    static Segment take()
    {
        okio/SegmentPool;
        JVM INSTR monitorenter ;
        if (next != null)
        {
            break MISSING_BLOCK_LABEL_20;
        }
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        return new Segment();
        Segment segment;
        segment = next;
        next = segment.next;
        segment.next = null;
        byteCount -= 8192L;
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        return segment;
        Exception exception;
        exception;
        okio/SegmentPool;
        JVM INSTR monitorexit ;
        throw exception;
    }
}
