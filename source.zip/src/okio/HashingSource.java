// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package okio:
//            ForwardingSource, ByteString, Buffer, Segment, 
//            Source

public final class HashingSource extends ForwardingSource
{

    private final Mac mac;
    private final MessageDigest messageDigest;

    private HashingSource(Source source, String s)
    {
        super(source);
        try
        {
            messageDigest = MessageDigest.getInstance(s);
            mac = null;
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Source source)
        {
            throw new AssertionError();
        }
    }

    private HashingSource(Source source, ByteString bytestring, String s)
    {
        super(source);
        try
        {
            mac = Mac.getInstance(s);
            mac.init(new SecretKeySpec(bytestring.toByteArray(), s));
            messageDigest = null;
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Source source)
        {
            throw new AssertionError();
        }
        // Misplaced declaration of an exception variable
        catch (Source source)
        {
            throw new IllegalArgumentException(source);
        }
    }

    public static HashingSource hmacSha1(Source source, ByteString bytestring)
    {
        return new HashingSource(source, bytestring, "HmacSHA1");
    }

    public static HashingSource hmacSha256(Source source, ByteString bytestring)
    {
        return new HashingSource(source, bytestring, "HmacSHA256");
    }

    public static HashingSource md5(Source source)
    {
        return new HashingSource(source, "MD5");
    }

    public static HashingSource sha1(Source source)
    {
        return new HashingSource(source, "SHA-1");
    }

    public static HashingSource sha256(Source source)
    {
        return new HashingSource(source, "SHA-256");
    }

    public ByteString hash()
    {
        byte abyte0[];
        if (messageDigest == null)
        {
            abyte0 = mac.doFinal();
        } else
        {
            abyte0 = messageDigest.digest();
        }
        return ByteString.of(abyte0);
    }

    public long read(Buffer buffer, long l)
        throws IOException
    {
        Segment segment;
        long l3;
        long l4;
        l4 = super.read(buffer, l);
        if (l4 == -1L)
        {
            break MISSING_BLOCK_LABEL_215;
        }
        l3 = buffer.size - l4;
        l = buffer.size;
        segment = buffer.head;
_L3:
        Segment segment1;
        long l1;
        long l2;
        boolean flag;
        if (l <= l3)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        segment1 = segment;
        l2 = l;
        l1 = l3;
        if (flag) goto _L2; else goto _L1
_L1:
        segment = segment.prev;
        l -= segment.limit - segment.pos;
          goto _L3
_L7:
        int i;
        messageDigest.update(segment1.data, i, segment1.limit - i);
_L5:
        l2 += segment1.limit - segment1.pos;
        segment1 = segment1.next;
        l1 = l2;
_L2:
        if (l2 >= buffer.size)
        {
            i = 1;
        } else
        {
            i = 0;
        }
        if (i != 0)
        {
            break MISSING_BLOCK_LABEL_215;
        }
        i = (int)((l1 + (long)segment1.pos) - l2);
        if (messageDigest != null)
        {
            break; /* Loop/switch isn't completed */
        }
        mac.update(segment1.data, i, segment1.limit - i);
        if (true) goto _L5; else goto _L4
_L4:
        if (true) goto _L7; else goto _L6
_L6:
        return l4;
    }
}
