// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;

// Referenced classes of package okio:
//            Buffer, Sink, Source, Timeout

public final class Pipe
{
    final class PipeSink
        implements Sink
    {

        final Pipe this$0;
        final Timeout timeout = new Timeout();

        public void close()
            throws IOException
        {
            Buffer buffer1 = buffer;
            buffer1;
            JVM INSTR monitorenter ;
            boolean flag = sinkClosed;
            if (flag)
            {
                break MISSING_BLOCK_LABEL_47;
            }
            flush();
            sinkClosed = true;
            buffer.notifyAll();
            buffer1;
            JVM INSTR monitorexit ;
            return;
            buffer1;
            JVM INSTR monitorexit ;
            return;
            Exception exception;
            exception;
            sinkClosed = true;
            buffer.notifyAll();
            throw exception;
            exception;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public void flush()
            throws IOException
        {
            Buffer buffer1 = buffer;
            buffer1;
            JVM INSTR monitorenter ;
            if (sinkClosed)
            {
                break MISSING_BLOCK_LABEL_73;
            }
_L1:
            Exception exception;
            boolean flag;
            if (buffer.size() <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag)
            {
                break MISSING_BLOCK_LABEL_94;
            }
            if (sourceClosed)
            {
                break MISSING_BLOCK_LABEL_83;
            }
            timeout.waitUntilNotified(buffer);
              goto _L1
            exception;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception;
            throw new IllegalStateException("closed");
            throw new IOException("source is closed");
        }

        public Timeout timeout()
        {
            return timeout;
        }

        public void write(Buffer buffer1, long l)
            throws IOException
        {
            Buffer buffer2 = buffer;
            buffer2;
            JVM INSTR monitorenter ;
            if (sinkClosed) goto _L2; else goto _L1
_L10:
            boolean flag;
            if (flag) goto _L4; else goto _L3
_L3:
            if (sourceClosed) goto _L6; else goto _L5
_L5:
            long l1 = maxBufferSize - buffer.size();
            if (l1 != 0L) goto _L8; else goto _L7
_L7:
            timeout.waitUntilNotified(buffer);
              goto _L1
            buffer1;
            buffer2;
            JVM INSTR monitorexit ;
            throw buffer1;
_L2:
            throw new IllegalStateException("closed");
_L6:
            throw new IOException("source is closed");
_L8:
            l1 = Math.min(l1, l);
            buffer.write(buffer1, l1);
            l -= l1;
            buffer.notifyAll();
              goto _L1
_L4:
            buffer2;
            JVM INSTR monitorexit ;
            return;
_L1:
            if (l <= 0L)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (true) goto _L10; else goto _L9
_L9:
        }

        PipeSink()
        {
            this$0 = Pipe.this;
            super();
        }
    }

    final class PipeSource
        implements Source
    {

        final Pipe this$0;
        final Timeout timeout = new Timeout();

        public void close()
            throws IOException
        {
            synchronized (buffer)
            {
                sourceClosed = true;
                buffer.notifyAll();
            }
            return;
            exception;
            buffer1;
            JVM INSTR monitorexit ;
            throw exception;
        }

        public long read(Buffer buffer1, long l)
            throws IOException
        {
            Buffer buffer2 = buffer;
            buffer2;
            JVM INSTR monitorenter ;
            if (sourceClosed) goto _L2; else goto _L1
_L1:
            do
            {
                if (buffer.size() != 0L)
                {
                    break MISSING_BLOCK_LABEL_87;
                }
                if (sinkClosed)
                {
                    break;
                }
                timeout.waitUntilNotified(buffer);
            } while (true);
              goto _L3
            buffer1;
            buffer2;
            JVM INSTR monitorexit ;
            throw buffer1;
_L2:
            throw new IllegalStateException("closed");
_L3:
            buffer2;
            JVM INSTR monitorexit ;
            return -1L;
            l = buffer.read(buffer1, l);
            buffer.notifyAll();
            buffer2;
            JVM INSTR monitorexit ;
            return l;
        }

        public Timeout timeout()
        {
            return timeout;
        }

        PipeSource()
        {
            this$0 = Pipe.this;
            super();
        }
    }


    final Buffer buffer = new Buffer();
    final long maxBufferSize;
    private final Sink sink = new PipeSink();
    boolean sinkClosed;
    private final Source source = new PipeSource();
    boolean sourceClosed;

    public Pipe(long l)
    {
        boolean flag;
        if (l >= 1L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("maxBufferSize < 1: ").append(l).toString());
        } else
        {
            maxBufferSize = l;
            return;
        }
    }

    public Sink sink()
    {
        return sink;
    }

    public Source source()
    {
        return source;
    }
}
