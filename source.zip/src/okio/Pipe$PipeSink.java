// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;

// Referenced classes of package okio:
//            Sink, Pipe, Timeout, Buffer

final class nit>
    implements Sink
{

    final Pipe this$0;
    final Timeout timeout = new Timeout();

    public void close()
        throws IOException
    {
        Buffer buffer = Pipe.this.buffer;
        buffer;
        JVM INSTR monitorenter ;
        boolean flag = sinkClosed;
        if (flag)
        {
            break MISSING_BLOCK_LABEL_47;
        }
        flush();
        sinkClosed = true;
        Pipe.this.buffer.notifyAll();
        buffer;
        JVM INSTR monitorexit ;
        return;
        buffer;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        sinkClosed = true;
        Pipe.this.buffer.notifyAll();
        throw exception;
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void flush()
        throws IOException
    {
        Buffer buffer = Pipe.this.buffer;
        buffer;
        JVM INSTR monitorenter ;
        if (sinkClosed)
        {
            break MISSING_BLOCK_LABEL_73;
        }
_L1:
        Exception exception;
        boolean flag;
        if (Pipe.this.buffer.size() <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            break MISSING_BLOCK_LABEL_94;
        }
        if (sourceClosed)
        {
            break MISSING_BLOCK_LABEL_83;
        }
        timeout.waitUntilNotified(Pipe.this.buffer);
          goto _L1
        exception;
        buffer;
        JVM INSTR monitorexit ;
        throw exception;
        throw new IllegalStateException("closed");
        throw new IOException("source is closed");
    }

    public Timeout timeout()
    {
        return timeout;
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        Buffer buffer1 = Pipe.this.buffer;
        buffer1;
        JVM INSTR monitorenter ;
        if (sinkClosed) goto _L2; else goto _L1
_L10:
        boolean flag;
        if (flag) goto _L4; else goto _L3
_L3:
        if (sourceClosed) goto _L6; else goto _L5
_L5:
        long l1 = maxBufferSize - Pipe.this.buffer.size();
        if (l1 != 0L) goto _L8; else goto _L7
_L7:
        timeout.waitUntilNotified(Pipe.this.buffer);
          goto _L1
        buffer;
        buffer1;
        JVM INSTR monitorexit ;
        throw buffer;
_L2:
        throw new IllegalStateException("closed");
_L6:
        throw new IOException("source is closed");
_L8:
        l1 = Math.min(l1, l);
        Pipe.this.buffer.write(buffer, l1);
        l -= l1;
        Pipe.this.buffer.notifyAll();
          goto _L1
_L4:
        buffer1;
        JVM INSTR monitorexit ;
        return;
_L1:
        if (l <= 0L)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (true) goto _L10; else goto _L9
_L9:
    }

    ()
    {
        this$0 = Pipe.this;
        super();
    }
}
