// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package okio;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package okio:
//            ForwardingSink, ByteString, Buffer, Util, 
//            Segment, Sink

public final class HashingSink extends ForwardingSink
{

    private final Mac mac;
    private final MessageDigest messageDigest;

    private HashingSink(Sink sink, String s)
    {
        super(sink);
        try
        {
            messageDigest = MessageDigest.getInstance(s);
            mac = null;
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Sink sink)
        {
            throw new AssertionError();
        }
    }

    private HashingSink(Sink sink, ByteString bytestring, String s)
    {
        super(sink);
        try
        {
            mac = Mac.getInstance(s);
            mac.init(new SecretKeySpec(bytestring.toByteArray(), s));
            messageDigest = null;
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Sink sink)
        {
            throw new AssertionError();
        }
        // Misplaced declaration of an exception variable
        catch (Sink sink)
        {
            throw new IllegalArgumentException(sink);
        }
    }

    public static HashingSink hmacSha1(Sink sink, ByteString bytestring)
    {
        return new HashingSink(sink, bytestring, "HmacSHA1");
    }

    public static HashingSink hmacSha256(Sink sink, ByteString bytestring)
    {
        return new HashingSink(sink, bytestring, "HmacSHA256");
    }

    public static HashingSink md5(Sink sink)
    {
        return new HashingSink(sink, "MD5");
    }

    public static HashingSink sha1(Sink sink)
    {
        return new HashingSink(sink, "SHA-1");
    }

    public static HashingSink sha256(Sink sink)
    {
        return new HashingSink(sink, "SHA-256");
    }

    public ByteString hash()
    {
        byte abyte0[];
        if (messageDigest == null)
        {
            abyte0 = mac.doFinal();
        } else
        {
            abyte0 = messageDigest.digest();
        }
        return ByteString.of(abyte0);
    }

    public void write(Buffer buffer, long l)
        throws IOException
    {
        long l1 = 0L;
        Util.checkOffsetAndCount(buffer.size, 0L, l);
        Segment segment = buffer.head;
        do
        {
            int i;
            if (l1 >= l)
            {
                i = 1;
            } else
            {
                i = 0;
            }
            if (i == 0)
            {
                i = (int)Math.min(l - l1, segment.limit - segment.pos);
                if (messageDigest == null)
                {
                    mac.update(segment.data, segment.pos, i);
                } else
                {
                    messageDigest.update(segment.data, segment.pos, i);
                }
                l1 += i;
                segment = segment.next;
            } else
            {
                super.write(buffer, l);
                return;
            }
        } while (true);
    }
}
