// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya;

import com.lumiyaviewer.lumiya.slproto.users.ChatterNameRetriever;

// Referenced classes of package com.lumiyaviewer.lumiya:
//            GridConnectionService

final class _2D_.f0
    implements com.lumiyaviewer.lumiya.slproto.users.ed
{

    private final Object _2D_$f0;

    private final void $m$0(ChatterNameRetriever chatternameretriever)
    {
        ((GridConnectionService)_2D_$f0).lambda$_2D_com_lumiyaviewer_lumiya_GridConnectionService_20777(chatternameretriever);
    }

    public final void onChatterNameUpdated(ChatterNameRetriever chatternameretriever)
    {
        $m$0(chatternameretriever);
    }

    public atterNameUpdated(Object obj)
    {
        _2D_$f0 = obj;
    }
}
