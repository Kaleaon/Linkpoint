// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.slproto.chat;

import com.lumiyaviewer.lumiya.slproto.users.manager.UserManager;

// Referenced classes of package com.lumiyaviewer.lumiya.slproto.chat:
//            SLChatTextBoxDialog

final class _2D_.f1
    implements com.lumiyaviewer.lumiya.ui.common.tener
{

    private final Object _2D_$f0;
    private final Object _2D_$f1;

    private final void $m$0(String s)
    {
        ((SLChatTextBoxDialog)_2D_$f0).lambda$_2D_com_lumiyaviewer_lumiya_slproto_chat_SLChatTextBoxDialog_4223((UserManager)_2D_$f1, s);
    }

    public final void onTextEntered(String s)
    {
        $m$0(s);
    }

    public er(Object obj, Object obj1)
    {
        _2D_$f0 = obj;
        _2D_$f1 = obj1;
    }
}
