// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.slproto.chat.generic;

import android.content.Context;
import android.view.MenuItem;

// Referenced classes of package com.lumiyaviewer.lumiya.slproto.chat.generic:
//            SLChatEvent

final class _2D_.f1
    implements android.support.v7.widget._cls9bCTwS1nc4b06kls._cls6
{

    private final Object _2D_$f0;
    private final Object _2D_$f1;

    private final boolean $m$0(MenuItem menuitem)
    {
        return ((SLChatEvent)_2D_$f0).lambda$_2D_com_lumiyaviewer_lumiya_slproto_chat_generic_SLChatEvent_21084((Context)_2D_$f1, menuitem);
    }

    public final boolean onMenuItemClick(MenuItem menuitem)
    {
        return $m$0(menuitem);
    }

    public Y(Object obj, Object obj1)
    {
        _2D_$f0 = obj;
        _2D_$f1 = obj1;
    }
}
