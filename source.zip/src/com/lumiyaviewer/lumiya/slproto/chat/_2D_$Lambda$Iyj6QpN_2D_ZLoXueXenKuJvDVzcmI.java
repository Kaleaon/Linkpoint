// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.slproto.chat;

import com.lumiyaviewer.lumiya.slproto.users.manager.UserManager;

// Referenced classes of package com.lumiyaviewer.lumiya.slproto.chat:
//            SLChatTextBoxDialog

final class _2D_.f1
    implements com.lumiyaviewer.lumiya.ui.common.dListener
{

    private final Object _2D_$f0;
    private final Object _2D_$f1;

    private final void $m$0()
    {
        ((SLChatTextBoxDialog)_2D_$f0).lambda$_2D_com_lumiyaviewer_lumiya_slproto_chat_SLChatTextBoxDialog_4314((UserManager)_2D_$f1);
    }

    public final void onTextCancelled()
    {
        $m$0();
    }

    public stener(Object obj, Object obj1)
    {
        _2D_$f0 = obj;
        _2D_$f1 = obj1;
    }
}
