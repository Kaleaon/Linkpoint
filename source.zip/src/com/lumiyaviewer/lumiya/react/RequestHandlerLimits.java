// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.react;


public interface RequestHandlerLimits
{

    public abstract int getMaxRequestsInFlight();

    public abstract long getRequestTimeout();

    public abstract boolean isRequestCancellable();
}
