// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.react;


final class _2D_.f1
    implements Runnable
{

    private final Object _2D_$f0;
    private final Object _2D_$f1;

    private final void $m$0()
    {
        ((on)_2D_$f0).DownstreamSubscription_827(_2D_$f1);
    }

    public final void run()
    {
        $m$0();
    }

    public on(Object obj, Object obj1)
    {
        _2D_$f0 = obj;
        _2D_$f1 = obj1;
    }
}
