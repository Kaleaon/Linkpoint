// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.lumiyaviewer.lumiya.react;


// Referenced classes of package com.lumiyaviewer.lumiya.react:
//            SubscriptionPool

final class _2D_.f1
    implements Runnable
{

    private final Object _2D_$f0;
    private final Object _2D_$f1;

    private final void $m$0()
    {
        ((SubscriptionPool)_2D_$f0).lambda$_2D_com_lumiyaviewer_lumiya_react_SubscriptionPool_8106(_2D_$f1);
    }

    public final void run()
    {
        $m$0();
    }

    public (Object obj, Object obj1)
    {
        _2D_$f0 = obj;
        _2D_$f1 = obj1;
    }
}
