// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package uk.co.senab.photoview.gestures;

import android.content.Context;
import android.view.MotionEvent;
import uk.co.senab.photoview.Compat;

// Referenced classes of package uk.co.senab.photoview.gestures:
//            CupcakeGestureDetector

public class EclairGestureDetector extends CupcakeGestureDetector
{

    private static final int INVALID_POINTER_ID = -1;
    private int mActivePointerId;
    private int mActivePointerIndex;

    public EclairGestureDetector(Context context)
    {
        super(context);
        mActivePointerId = -1;
        mActivePointerIndex = 0;
    }

    float getActiveX(MotionEvent motionevent)
    {
        float f;
        try
        {
            f = motionevent.getX(mActivePointerIndex);
        }
        catch (Exception exception)
        {
            return motionevent.getX();
        }
        return f;
    }

    float getActiveY(MotionEvent motionevent)
    {
        float f;
        try
        {
            f = motionevent.getY(mActivePointerIndex);
        }
        catch (Exception exception)
        {
            return motionevent.getY();
        }
        return f;
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        boolean flag = false;
        motionevent.getAction() & 0xff;
        JVM INSTR tableswitch 0 6: default 52
    //                   0 81
    //                   1 93
    //                   2 52
    //                   3 93
    //                   4 52
    //                   5 52
    //                   6 101;
           goto _L1 _L2 _L3 _L1 _L3 _L1 _L1 _L4
_L1:
        break; /* Loop/switch isn't completed */
_L4:
        break MISSING_BLOCK_LABEL_101;
_L5:
        int i;
        boolean flag1;
        if (mActivePointerId == -1)
        {
            i = ((flag) ? 1 : 0);
        } else
        {
            i = mActivePointerId;
        }
        mActivePointerIndex = motionevent.findPointerIndex(i);
        try
        {
            flag1 = super.onTouchEvent(motionevent);
        }
        // Misplaced declaration of an exception variable
        catch (MotionEvent motionevent)
        {
            return true;
        }
        return flag1;
_L2:
        mActivePointerId = motionevent.getPointerId(0);
          goto _L5
_L3:
        mActivePointerId = -1;
          goto _L5
        i = Compat.getPointerIndex(motionevent.getAction());
        if (motionevent.getPointerId(i) == mActivePointerId)
        {
            if (i != 0)
            {
                i = 0;
            } else
            {
                i = 1;
            }
            mActivePointerId = motionevent.getPointerId(i);
            mLastTouchX = motionevent.getX(i);
            mLastTouchY = motionevent.getY(i);
        }
          goto _L5
    }
}
