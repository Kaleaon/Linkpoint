// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package uk.co.senab.photoview;

import android.view.View;

public class Compat
{

    private static final int SIXTY_FPS_INTERVAL = 16;

    public Compat()
    {
    }

    public static int getPointerIndex(int i)
    {
        if (android.os.Build.VERSION.SDK_INT < 11)
        {
            return getPointerIndexEclair(i);
        } else
        {
            return getPointerIndexHoneyComb(i);
        }
    }

    private static int getPointerIndexEclair(int i)
    {
        return (0xff00 & i) >> 8;
    }

    private static int getPointerIndexHoneyComb(int i)
    {
        return (0xff00 & i) >> 8;
    }

    public static void postOnAnimation(View view, Runnable runnable)
    {
        if (android.os.Build.VERSION.SDK_INT < 16)
        {
            view.postDelayed(runnable, 16L);
            return;
        } else
        {
            postOnAnimationJellyBean(view, runnable);
            return;
        }
    }

    private static void postOnAnimationJellyBean(View view, Runnable runnable)
    {
        view.postOnAnimation(runnable);
    }
}
