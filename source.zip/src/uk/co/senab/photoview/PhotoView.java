// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package uk.co.senab.photoview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

// Referenced classes of package uk.co.senab.photoview:
//            IPhotoView, PhotoViewAttacher

public class PhotoView extends ImageView
    implements IPhotoView
{

    private PhotoViewAttacher mAttacher;
    private android.widget.ImageView.ScaleType mPendingScaleType;

    public PhotoView(Context context)
    {
        this(context, null);
    }

    public PhotoView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public PhotoView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        super.setScaleType(android.widget.ImageView.ScaleType.MATRIX);
        init();
    }

    public boolean canZoom()
    {
        return mAttacher.canZoom();
    }

    public void getDisplayMatrix(Matrix matrix)
    {
        mAttacher.getDisplayMatrix(matrix);
    }

    public RectF getDisplayRect()
    {
        return mAttacher.getDisplayRect();
    }

    public IPhotoView getIPhotoViewImplementation()
    {
        return mAttacher;
    }

    public Matrix getImageMatrix()
    {
        return mAttacher.getImageMatrix();
    }

    public float getMaximumScale()
    {
        return mAttacher.getMaximumScale();
    }

    public float getMediumScale()
    {
        return mAttacher.getMediumScale();
    }

    public float getMinimumScale()
    {
        return mAttacher.getMinimumScale();
    }

    public float getScale()
    {
        return mAttacher.getScale();
    }

    public android.widget.ImageView.ScaleType getScaleType()
    {
        return mAttacher.getScaleType();
    }

    public Bitmap getVisibleRectangleBitmap()
    {
        return mAttacher.getVisibleRectangleBitmap();
    }

    protected void init()
    {
        if (mAttacher == null || mAttacher.getImageView() == null)
        {
            mAttacher = new PhotoViewAttacher(this);
        }
        if (mPendingScaleType == null)
        {
            return;
        } else
        {
            setScaleType(mPendingScaleType);
            mPendingScaleType = null;
            return;
        }
    }

    protected void onAttachedToWindow()
    {
        init();
        super.onAttachedToWindow();
    }

    protected void onDetachedFromWindow()
    {
        mAttacher.cleanup();
        mAttacher = null;
        super.onDetachedFromWindow();
    }

    public void setAllowParentInterceptOnEdge(boolean flag)
    {
        mAttacher.setAllowParentInterceptOnEdge(flag);
    }

    public boolean setDisplayMatrix(Matrix matrix)
    {
        return mAttacher.setDisplayMatrix(matrix);
    }

    protected boolean setFrame(int i, int j, int k, int l)
    {
        boolean flag = super.setFrame(i, j, k, l);
        if (mAttacher == null)
        {
            return flag;
        } else
        {
            mAttacher.update();
            return flag;
        }
    }

    public void setImageDrawable(Drawable drawable)
    {
        super.setImageDrawable(drawable);
        if (mAttacher == null)
        {
            return;
        } else
        {
            mAttacher.update();
            return;
        }
    }

    public void setImageResource(int i)
    {
        super.setImageResource(i);
        if (mAttacher == null)
        {
            return;
        } else
        {
            mAttacher.update();
            return;
        }
    }

    public void setImageURI(Uri uri)
    {
        super.setImageURI(uri);
        if (mAttacher == null)
        {
            return;
        } else
        {
            mAttacher.update();
            return;
        }
    }

    public void setMaximumScale(float f)
    {
        mAttacher.setMaximumScale(f);
    }

    public void setMediumScale(float f)
    {
        mAttacher.setMediumScale(f);
    }

    public void setMinimumScale(float f)
    {
        mAttacher.setMinimumScale(f);
    }

    public void setOnDoubleTapListener(android.view.GestureDetector.OnDoubleTapListener ondoubletaplistener)
    {
        mAttacher.setOnDoubleTapListener(ondoubletaplistener);
    }

    public void setOnLongClickListener(android.view.View.OnLongClickListener onlongclicklistener)
    {
        mAttacher.setOnLongClickListener(onlongclicklistener);
    }

    public void setOnMatrixChangeListener(PhotoViewAttacher.OnMatrixChangedListener onmatrixchangedlistener)
    {
        mAttacher.setOnMatrixChangeListener(onmatrixchangedlistener);
    }

    public void setOnPhotoTapListener(PhotoViewAttacher.OnPhotoTapListener onphototaplistener)
    {
        mAttacher.setOnPhotoTapListener(onphototaplistener);
    }

    public void setOnScaleChangeListener(PhotoViewAttacher.OnScaleChangeListener onscalechangelistener)
    {
        mAttacher.setOnScaleChangeListener(onscalechangelistener);
    }

    public void setOnSingleFlingListener(PhotoViewAttacher.OnSingleFlingListener onsingleflinglistener)
    {
        mAttacher.setOnSingleFlingListener(onsingleflinglistener);
    }

    public void setOnViewTapListener(PhotoViewAttacher.OnViewTapListener onviewtaplistener)
    {
        mAttacher.setOnViewTapListener(onviewtaplistener);
    }

    public void setRotationBy(float f)
    {
        mAttacher.setRotationBy(f);
    }

    public void setRotationTo(float f)
    {
        mAttacher.setRotationTo(f);
    }

    public void setScale(float f)
    {
        mAttacher.setScale(f);
    }

    public void setScale(float f, float f1, float f2, boolean flag)
    {
        mAttacher.setScale(f, f1, f2, flag);
    }

    public void setScale(float f, boolean flag)
    {
        mAttacher.setScale(f, flag);
    }

    public void setScaleLevels(float f, float f1, float f2)
    {
        mAttacher.setScaleLevels(f, f1, f2);
    }

    public void setScaleType(android.widget.ImageView.ScaleType scaletype)
    {
        if (mAttacher == null)
        {
            mPendingScaleType = scaletype;
            return;
        } else
        {
            mAttacher.setScaleType(scaletype);
            return;
        }
    }

    public void setZoomTransitionDuration(int i)
    {
        mAttacher.setZoomTransitionDuration(i);
    }

    public void setZoomable(boolean flag)
    {
        mAttacher.setZoomable(flag);
    }
}
