// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package uk.co.senab.photoview;

import android.view.animation.Interpolator;

// Referenced classes of package uk.co.senab.photoview:
//            PhotoViewAttacher, Compat

private class mZoomEnd
    implements Runnable
{

    private final float mFocalX;
    private final float mFocalY;
    private final long mStartTime = System.currentTimeMillis();
    private final float mZoomEnd;
    private final float mZoomStart;
    final PhotoViewAttacher this$0;

    private float interpolate()
    {
        float f = Math.min(1.0F, ((float)(System.currentTimeMillis() - mStartTime) * 1.0F) / (float)ZOOM_DURATION);
        return PhotoViewAttacher.access$200(PhotoViewAttacher.this).getInterpolation(f);
    }

    public void run()
    {
        android.widget.ImageView imageview = getImageView();
        if (imageview != null)
        {
            float f = interpolate();
            float f1 = (mZoomStart + (mZoomEnd - mZoomStart) * f) / getScale();
            onScale(f1, mFocalX, mFocalY);
            if (f < 1.0F)
            {
                Compat.postOnAnimation(imageview, this);
            }
            return;
        } else
        {
            return;
        }
    }

    public (float f, float f1, float f2, float f3)
    {
        this$0 = PhotoViewAttacher.this;
        super();
        mFocalX = f2;
        mFocalY = f3;
        mZoomStart = f;
        mZoomEnd = f1;
    }
}
