// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package uk.co.senab.photoview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.support.v4.view.MotionEventCompat;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import java.lang.ref.WeakReference;
import uk.co.senab.photoview.gestures.OnGestureListener;
import uk.co.senab.photoview.gestures.VersionedGestureDetector;
import uk.co.senab.photoview.log.LogManager;
import uk.co.senab.photoview.log.Logger;
import uk.co.senab.photoview.scrollerproxy.ScrollerProxy;

// Referenced classes of package uk.co.senab.photoview:
//            IPhotoView, DefaultOnDoubleTapListener, Compat

public class PhotoViewAttacher
    implements IPhotoView, android.view.View.OnTouchListener, OnGestureListener, android.view.ViewTreeObserver.OnGlobalLayoutListener
{
    private class AnimatedZoomRunnable
        implements Runnable
    {

        private final float mFocalX;
        private final float mFocalY;
        private final long mStartTime = System.currentTimeMillis();
        private final float mZoomEnd;
        private final float mZoomStart;
        final PhotoViewAttacher this$0;

        private float interpolate()
        {
            float f = Math.min(1.0F, ((float)(System.currentTimeMillis() - mStartTime) * 1.0F) / (float)ZOOM_DURATION);
            return mInterpolator.getInterpolation(f);
        }

        public void run()
        {
            ImageView imageview = getImageView();
            if (imageview != null)
            {
                float f = interpolate();
                float f1 = (mZoomStart + (mZoomEnd - mZoomStart) * f) / getScale();
                onScale(f1, mFocalX, mFocalY);
                if (f < 1.0F)
                {
                    Compat.postOnAnimation(imageview, this);
                }
                return;
            } else
            {
                return;
            }
        }

        public AnimatedZoomRunnable(float f, float f1, float f2, float f3)
        {
            this$0 = PhotoViewAttacher.this;
            super();
            mFocalX = f2;
            mFocalY = f3;
            mZoomStart = f;
            mZoomEnd = f1;
        }
    }

    private class FlingRunnable
        implements Runnable
    {

        private int mCurrentX;
        private int mCurrentY;
        private final ScrollerProxy mScroller;
        final PhotoViewAttacher this$0;

        public void cancelFling()
        {
            if (PhotoViewAttacher.DEBUG)
            {
                LogManager.getLogger().d("PhotoViewAttacher", "Cancel Fling");
            }
            mScroller.forceFinished(true);
        }

        public void fling(int i, int j, int k, int l)
        {
            int k1;
            int l1;
            RectF rectf = getDisplayRect();
            if (rectf != null)
            {
                int i1 = Math.round(-rectf.left);
                int j1;
                if ((float)i < rectf.width())
                {
                    j1 = Math.round(rectf.width() - (float)i);
                    i = 0;
                } else
                {
                    j1 = i1;
                    i = i1;
                }
                k1 = Math.round(-rectf.top);
                if ((float)j < rectf.height())
                {
                    l1 = Math.round(rectf.height() - (float)j);
                    j = 0;
                } else
                {
                    l1 = k1;
                    j = k1;
                }
                mCurrentX = i1;
                mCurrentY = k1;
                if (PhotoViewAttacher.DEBUG)
                {
                    LogManager.getLogger().d("PhotoViewAttacher", (new StringBuilder()).append("fling. StartX:").append(i1).append(" StartY:").append(k1).append(" MaxX:").append(j1).append(" MaxY:").append(l1).toString());
                }
                break MISSING_BLOCK_LABEL_106;
            } else
            {
                return;
            }
            if (i1 != j1 || k1 != l1)
            {
                mScroller.fling(i1, k1, k, l, i, j1, j, l1, 0, 0);
                return;
            } else
            {
                return;
            }
        }

        public void run()
        {
            ImageView imageview;
            if (!mScroller.isFinished())
            {
                imageview = getImageView();
                break MISSING_BLOCK_LABEL_18;
            } else
            {
                return;
            }
            if (imageview == null || !mScroller.computeScrollOffset())
            {
                return;
            }
            int i = mScroller.getCurrX();
            int j = mScroller.getCurrY();
            if (PhotoViewAttacher.DEBUG)
            {
                LogManager.getLogger().d("PhotoViewAttacher", (new StringBuilder()).append("fling run(). CurrentX:").append(mCurrentX).append(" CurrentY:").append(mCurrentY).append(" NewX:").append(i).append(" NewY:").append(j).toString());
            }
            mSuppMatrix.postTranslate(mCurrentX - i, mCurrentY - j);
            setImageViewMatrix(getDrawMatrix());
            mCurrentX = i;
            mCurrentY = j;
            Compat.postOnAnimation(imageview, this);
            return;
        }

        public FlingRunnable(Context context)
        {
            this$0 = PhotoViewAttacher.this;
            super();
            mScroller = ScrollerProxy.getScroller(context);
        }
    }

    public static interface OnMatrixChangedListener
    {

        public abstract void onMatrixChanged(RectF rectf);
    }

    public static interface OnPhotoTapListener
    {

        public abstract void onOutsidePhotoTap();

        public abstract void onPhotoTap(View view, float f, float f1);
    }

    public static interface OnScaleChangeListener
    {

        public abstract void onScaleChange(float f, float f1, float f2);
    }

    public static interface OnSingleFlingListener
    {

        public abstract boolean onFling(MotionEvent motionevent, MotionEvent motionevent1, float f, float f1);
    }

    public static interface OnViewTapListener
    {

        public abstract void onViewTap(View view, float f, float f1);
    }


    private static final boolean DEBUG = Log.isLoggable("PhotoViewAttacher", 3);
    static final int EDGE_BOTH = 2;
    static final int EDGE_LEFT = 0;
    static final int EDGE_NONE = -1;
    static final int EDGE_RIGHT = 1;
    private static final String LOG_TAG = "PhotoViewAttacher";
    static int SINGLE_TOUCH = 1;
    int ZOOM_DURATION;
    private boolean mAllowParentInterceptOnEdge;
    private final Matrix mBaseMatrix;
    private float mBaseRotation;
    private boolean mBlockParentIntercept;
    private FlingRunnable mCurrentFlingRunnable;
    private final RectF mDisplayRect;
    private final Matrix mDrawMatrix;
    private GestureDetector mGestureDetector;
    private WeakReference mImageView;
    private Interpolator mInterpolator;
    private int mIvBottom;
    private int mIvLeft;
    private int mIvRight;
    private int mIvTop;
    private android.view.View.OnLongClickListener mLongClickListener;
    private OnMatrixChangedListener mMatrixChangeListener;
    private final float mMatrixValues[];
    private float mMaxScale;
    private float mMidScale;
    private float mMinScale;
    private OnPhotoTapListener mPhotoTapListener;
    private OnScaleChangeListener mScaleChangeListener;
    private uk.co.senab.photoview.gestures.GestureDetector mScaleDragDetector;
    private android.widget.ImageView.ScaleType mScaleType;
    private int mScrollEdge;
    private OnSingleFlingListener mSingleFlingListener;
    private final Matrix mSuppMatrix;
    private OnViewTapListener mViewTapListener;
    private boolean mZoomEnabled;

    public PhotoViewAttacher(ImageView imageview)
    {
        this(imageview, true);
    }

    public PhotoViewAttacher(ImageView imageview, boolean flag)
    {
        mInterpolator = new AccelerateDecelerateInterpolator();
        ZOOM_DURATION = 200;
        mMinScale = 1.0F;
        mMidScale = 1.75F;
        mMaxScale = 3F;
        mAllowParentInterceptOnEdge = true;
        mBlockParentIntercept = false;
        mBaseMatrix = new Matrix();
        mDrawMatrix = new Matrix();
        mSuppMatrix = new Matrix();
        mDisplayRect = new RectF();
        mMatrixValues = new float[9];
        mScrollEdge = 2;
        mScaleType = android.widget.ImageView.ScaleType.FIT_CENTER;
        mImageView = new WeakReference(imageview);
        imageview.setDrawingCacheEnabled(true);
        imageview.setOnTouchListener(this);
        ViewTreeObserver viewtreeobserver = imageview.getViewTreeObserver();
        if (viewtreeobserver != null)
        {
            viewtreeobserver.addOnGlobalLayoutListener(this);
        }
        setImageViewScaleTypeMatrix(imageview);
        if (!imageview.isInEditMode())
        {
            mScaleDragDetector = VersionedGestureDetector.newInstance(imageview.getContext(), this);
            mGestureDetector = new GestureDetector(imageview.getContext(), new android.view.GestureDetector.SimpleOnGestureListener() {

                final PhotoViewAttacher this$0;

                public boolean onFling(MotionEvent motionevent, MotionEvent motionevent1, float f, float f1)
                {
                    if (mSingleFlingListener == null)
                    {
                        return false;
                    }
                    if (getScale() > 1.0F)
                    {
                        return false;
                    }
                    while (MotionEventCompat.getPointerCount(motionevent) > PhotoViewAttacher.SINGLE_TOUCH || MotionEventCompat.getPointerCount(motionevent1) > PhotoViewAttacher.SINGLE_TOUCH) 
                    {
                        return false;
                    }
                    return mSingleFlingListener.onFling(motionevent, motionevent1, f, f1);
                }

                public void onLongPress(MotionEvent motionevent)
                {
                    if (mLongClickListener == null)
                    {
                        return;
                    } else
                    {
                        mLongClickListener.onLongClick(getImageView());
                        return;
                    }
                }

            
            {
                this$0 = PhotoViewAttacher.this;
                super();
            }
            });
            mGestureDetector.setOnDoubleTapListener(new DefaultOnDoubleTapListener(this));
            mBaseRotation = 0.0F;
            setZoomable(flag);
            return;
        } else
        {
            return;
        }
    }

    private void cancelFling()
    {
        if (mCurrentFlingRunnable == null)
        {
            return;
        } else
        {
            mCurrentFlingRunnable.cancelFling();
            mCurrentFlingRunnable = null;
            return;
        }
    }

    private void checkAndDisplayMatrix()
    {
        if (!checkMatrixBounds())
        {
            return;
        } else
        {
            setImageViewMatrix(getDrawMatrix());
            return;
        }
    }

    private void checkImageViewScaleType()
    {
        for (ImageView imageview = getImageView(); imageview == null || (imageview instanceof IPhotoView) || android.widget.ImageView.ScaleType.MATRIX.equals(imageview.getScaleType());)
        {
            return;
        }

        throw new IllegalStateException("The ImageView's ScaleType has been changed since attaching a PhotoViewAttacher. You should call setScaleType on the PhotoViewAttacher instead of on the ImageView");
    }

    private boolean checkMatrixBounds()
    {
        float f1;
        ImageView imageview;
        f1 = 0.0F;
        imageview = getImageView();
        if (imageview == null) goto _L2; else goto _L1
_L1:
        RectF rectf = getDisplayRect(getDrawMatrix());
        if (rectf == null) goto _L4; else goto _L3
_L3:
        float f;
        float f2;
        int i;
        f = rectf.height();
        f2 = rectf.width();
        i = getImageViewHeight(imageview);
        if (f > (float)i) goto _L6; else goto _L5
_L5:
        static class _cls2
        {

            static final int $SwitchMap$android$widget$ImageView$ScaleType[];

            static 
            {
                $SwitchMap$android$widget$ImageView$ScaleType = new int[android.widget.ImageView.ScaleType.values().length];
                try
                {
                    $SwitchMap$android$widget$ImageView$ScaleType[android.widget.ImageView.ScaleType.MATRIX.ordinal()] = 1;
                }
                catch (NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$android$widget$ImageView$ScaleType[android.widget.ImageView.ScaleType.FIT_START.ordinal()] = 2;
                }
                catch (NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$android$widget$ImageView$ScaleType[android.widget.ImageView.ScaleType.FIT_END.ordinal()] = 3;
                }
                catch (NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$android$widget$ImageView$ScaleType[android.widget.ImageView.ScaleType.FIT_CENTER.ordinal()] = 4;
                }
                catch (NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$android$widget$ImageView$ScaleType[android.widget.ImageView.ScaleType.FIT_XY.ordinal()] = 5;
                }
                catch (NoSuchFieldError nosuchfielderror)
                {
                    return;
                }
            }
        }

        _cls2..SwitchMap.android.widget.ImageView.ScaleType[mScaleType.ordinal()];
        JVM INSTR tableswitch 2 3: default 88
    //                   2 187
    //                   3 197;
           goto _L7 _L8 _L9
_L7:
        f = ((float)i - f) / 2.0F - rectf.top;
_L13:
        i = getImageViewWidth(imageview);
        if (f2 > (float)i)
        {
            break MISSING_BLOCK_LABEL_287;
        }
        _cls2..SwitchMap.android.widget.ImageView.ScaleType[mScaleType.ordinal()];
        JVM INSTR tableswitch 2 3: default 152
    //                   2 262
    //                   3 272;
           goto _L10 _L11 _L12
_L10:
        f1 = ((float)i - f2) / 2.0F - rectf.left;
_L14:
        mScrollEdge = 2;
_L15:
        mSuppMatrix.postTranslate(f1, f);
        return true;
_L2:
        return false;
_L4:
        return false;
_L8:
        f = -rectf.top;
          goto _L13
_L9:
        f = (float)i - f - rectf.top;
          goto _L13
_L6:
        if (rectf.top > 0.0F)
        {
            f = -rectf.top;
        } else
        if (rectf.bottom < (float)i)
        {
            f = (float)i - rectf.bottom;
        } else
        {
            f = 0.0F;
        }
          goto _L13
_L11:
        f1 = -rectf.left;
          goto _L14
_L12:
        f1 = (float)i - f2 - rectf.left;
          goto _L14
        if (rectf.left > 0.0F)
        {
            mScrollEdge = 0;
            f1 = -rectf.left;
        } else
        if (rectf.right < (float)i)
        {
            f1 = (float)i - rectf.right;
            mScrollEdge = 1;
        } else
        {
            mScrollEdge = -1;
        }
          goto _L15
    }

    private static void checkZoomLevels(float f, float f1, float f2)
    {
        if (f >= f1)
        {
            throw new IllegalArgumentException("Minimum zoom has to be less than Medium zoom. Call setMinimumZoom() with a more appropriate value");
        }
        if (f1 >= f2)
        {
            throw new IllegalArgumentException("Medium zoom has to be less than Maximum zoom. Call setMaximumZoom() with a more appropriate value");
        } else
        {
            return;
        }
    }

    private RectF getDisplayRect(Matrix matrix)
    {
        Object obj = getImageView();
        if (obj != null)
        {
            if ((obj = ((ImageView) (obj)).getDrawable()) != null)
            {
                mDisplayRect.set(0.0F, 0.0F, ((Drawable) (obj)).getIntrinsicWidth(), ((Drawable) (obj)).getIntrinsicHeight());
                matrix.mapRect(mDisplayRect);
                return mDisplayRect;
            }
        }
        return null;
    }

    private Matrix getDrawMatrix()
    {
        mDrawMatrix.set(mBaseMatrix);
        mDrawMatrix.postConcat(mSuppMatrix);
        return mDrawMatrix;
    }

    private int getImageViewHeight(ImageView imageview)
    {
        if (imageview != null)
        {
            return imageview.getHeight() - imageview.getPaddingTop() - imageview.getPaddingBottom();
        } else
        {
            return 0;
        }
    }

    private int getImageViewWidth(ImageView imageview)
    {
        if (imageview != null)
        {
            return imageview.getWidth() - imageview.getPaddingLeft() - imageview.getPaddingRight();
        } else
        {
            return 0;
        }
    }

    private float getValue(Matrix matrix, int i)
    {
        matrix.getValues(mMatrixValues);
        return mMatrixValues[i];
    }

    private static boolean hasDrawable(ImageView imageview)
    {
        while (imageview == null || imageview.getDrawable() == null) 
        {
            return false;
        }
        return true;
    }

    private static boolean isSupportedScaleType(android.widget.ImageView.ScaleType scaletype)
    {
        if (scaletype != null)
        {
            switch (_cls2..SwitchMap.android.widget.ImageView.ScaleType[scaletype.ordinal()])
            {
            default:
                return true;

            case 1: // '\001'
                throw new IllegalArgumentException((new StringBuilder()).append(scaletype.name()).append(" is not supported in PhotoView").toString());
            }
        } else
        {
            return false;
        }
    }

    private void resetMatrix()
    {
        mSuppMatrix.reset();
        setRotationBy(mBaseRotation);
        setImageViewMatrix(getDrawMatrix());
        checkMatrixBounds();
    }

    private void setImageViewMatrix(Matrix matrix)
    {
        ImageView imageview = getImageView();
        if (imageview != null)
        {
            checkImageViewScaleType();
            imageview.setImageMatrix(matrix);
            if (mMatrixChangeListener != null)
            {
                matrix = getDisplayRect(matrix);
                if (matrix != null)
                {
                    mMatrixChangeListener.onMatrixChanged(matrix);
                    return;
                }
            }
        }
    }

    private static void setImageViewScaleTypeMatrix(ImageView imageview)
    {
        while (imageview == null || (imageview instanceof IPhotoView) || android.widget.ImageView.ScaleType.MATRIX.equals(imageview.getScaleType())) 
        {
            return;
        }
        imageview.setScaleType(android.widget.ImageView.ScaleType.MATRIX);
    }

    private void updateBaseMatrix(Drawable drawable)
    {
        float f;
        float f1;
        float f2;
        float f3;
        int i;
        int j;
        ImageView imageview;
        for (imageview = getImageView(); imageview == null || drawable == null;)
        {
            return;
        }

        f = getImageViewWidth(imageview);
        f1 = getImageViewHeight(imageview);
        i = drawable.getIntrinsicWidth();
        j = drawable.getIntrinsicHeight();
        mBaseMatrix.reset();
        f2 = f / (float)i;
        f3 = f1 / (float)j;
        if (mScaleType == android.widget.ImageView.ScaleType.CENTER) goto _L2; else goto _L1
_L1:
        if (mScaleType == android.widget.ImageView.ScaleType.CENTER_CROP) goto _L4; else goto _L3
_L3:
        if (mScaleType == android.widget.ImageView.ScaleType.CENTER_INSIDE) goto _L6; else goto _L5
_L5:
        RectF rectf;
        drawable = new RectF(0.0F, 0.0F, i, j);
        rectf = new RectF(0.0F, 0.0F, f, f1);
        if ((int)mBaseRotation % 180 != 0)
        {
            drawable = new RectF(0.0F, 0.0F, j, i);
        }
        _cls2..SwitchMap.android.widget.ImageView.ScaleType[mScaleType.ordinal()];
        JVM INSTR tableswitch 2 5: default 176
    //                   2 350
    //                   3 367
    //                   4 333
    //                   5 384;
           goto _L7 _L8 _L9 _L10 _L11
_L7:
        resetMatrix();
        return;
_L2:
        mBaseMatrix.postTranslate((f - (float)i) / 2.0F, (f1 - (float)j) / 2.0F);
        continue; /* Loop/switch isn't completed */
_L4:
        f2 = Math.max(f2, f3);
        mBaseMatrix.postScale(f2, f2);
        mBaseMatrix.postTranslate((f - (float)i * f2) / 2.0F, (f1 - f2 * (float)j) / 2.0F);
        continue; /* Loop/switch isn't completed */
_L6:
        f2 = Math.min(1.0F, Math.min(f2, f3));
        mBaseMatrix.postScale(f2, f2);
        mBaseMatrix.postTranslate((f - (float)i * f2) / 2.0F, (f1 - f2 * (float)j) / 2.0F);
        continue; /* Loop/switch isn't completed */
_L10:
        mBaseMatrix.setRectToRect(drawable, rectf, android.graphics.Matrix.ScaleToFit.CENTER);
        continue; /* Loop/switch isn't completed */
_L8:
        mBaseMatrix.setRectToRect(drawable, rectf, android.graphics.Matrix.ScaleToFit.START);
        continue; /* Loop/switch isn't completed */
_L9:
        mBaseMatrix.setRectToRect(drawable, rectf, android.graphics.Matrix.ScaleToFit.END);
        continue; /* Loop/switch isn't completed */
_L11:
        mBaseMatrix.setRectToRect(drawable, rectf, android.graphics.Matrix.ScaleToFit.FILL);
        if (true) goto _L7; else goto _L12
_L12:
    }

    public boolean canZoom()
    {
        return mZoomEnabled;
    }

    public void cleanup()
    {
        if (mImageView != null)
        {
            ImageView imageview = (ImageView)mImageView.get();
            if (imageview != null)
            {
                ViewTreeObserver viewtreeobserver = imageview.getViewTreeObserver();
                if (viewtreeobserver != null && viewtreeobserver.isAlive())
                {
                    viewtreeobserver.removeGlobalOnLayoutListener(this);
                }
                imageview.setOnTouchListener(null);
                cancelFling();
            }
            if (mGestureDetector != null)
            {
                mGestureDetector.setOnDoubleTapListener(null);
            }
            mMatrixChangeListener = null;
            mPhotoTapListener = null;
            mViewTapListener = null;
            mImageView = null;
            return;
        } else
        {
            return;
        }
    }

    public void getDisplayMatrix(Matrix matrix)
    {
        matrix.set(getDrawMatrix());
    }

    public RectF getDisplayRect()
    {
        checkMatrixBounds();
        return getDisplayRect(getDrawMatrix());
    }

    public IPhotoView getIPhotoViewImplementation()
    {
        return this;
    }

    public Matrix getImageMatrix()
    {
        return mDrawMatrix;
    }

    public ImageView getImageView()
    {
        ImageView imageview = null;
        if (mImageView != null)
        {
            imageview = (ImageView)mImageView.get();
        }
        if (imageview != null)
        {
            return imageview;
        } else
        {
            cleanup();
            LogManager.getLogger().i("PhotoViewAttacher", "ImageView no longer exists. You should not use this PhotoViewAttacher any more.");
            return imageview;
        }
    }

    public float getMaximumScale()
    {
        return mMaxScale;
    }

    public float getMediumScale()
    {
        return mMidScale;
    }

    public float getMinimumScale()
    {
        return mMinScale;
    }

    OnPhotoTapListener getOnPhotoTapListener()
    {
        return mPhotoTapListener;
    }

    OnViewTapListener getOnViewTapListener()
    {
        return mViewTapListener;
    }

    public float getScale()
    {
        return (float)Math.sqrt((float)Math.pow(getValue(mSuppMatrix, 0), 2D) + (float)Math.pow(getValue(mSuppMatrix, 3), 2D));
    }

    public android.widget.ImageView.ScaleType getScaleType()
    {
        return mScaleType;
    }

    public void getSuppMatrix(Matrix matrix)
    {
        matrix.set(mSuppMatrix);
    }

    public Bitmap getVisibleRectangleBitmap()
    {
        Bitmap bitmap = null;
        ImageView imageview = getImageView();
        if (imageview != null)
        {
            bitmap = imageview.getDrawingCache();
        }
        return bitmap;
    }

    public void onDrag(float f, float f1)
    {
        Object obj;
        if (!mScaleDragDetector.isScaling())
        {
            if (DEBUG)
            {
                LogManager.getLogger().d("PhotoViewAttacher", String.format("onDrag: dx: %.2f. dy: %.2f", new Object[] {
                    Float.valueOf(f), Float.valueOf(f1)
                }));
            }
            obj = getImageView();
            mSuppMatrix.postTranslate(f, f1);
            checkAndDisplayMatrix();
            obj = ((ImageView) (obj)).getParent();
            if (!mAllowParentInterceptOnEdge || mScaleDragDetector.isScaling() || mBlockParentIntercept)
            {
                break MISSING_BLOCK_LABEL_49;
            }
        } else
        {
            return;
        }
          goto _L1
        if (obj != null) goto _L3; else goto _L2
_L2:
        return;
_L1:
        if (mScrollEdge != 2) goto _L5; else goto _L4
_L4:
        if (obj != null)
        {
            ((ViewParent) (obj)).requestDisallowInterceptTouchEvent(false);
            return;
        } else
        {
            break; /* Loop/switch isn't completed */
        }
_L5:
        if (mScrollEdge == 0) goto _L7; else goto _L6
_L6:
        if (mScrollEdge != 1 || f > -1F) goto _L2; else goto _L8
_L8:
        break; /* Loop/switch isn't completed */
_L7:
        boolean flag;
        if (f >= 1.0F)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag) goto _L4; else goto _L6
_L3:
        ((ViewParent) (obj)).requestDisallowInterceptTouchEvent(true);
        return;
    }

    public void onFling(float f, float f1, float f2, float f3)
    {
        ImageView imageview;
        if (DEBUG)
        {
            LogManager.getLogger().d("PhotoViewAttacher", (new StringBuilder()).append("onFling. sX: ").append(f).append(" sY: ").append(f1).append(" Vx: ").append(f2).append(" Vy: ").append(f3).toString());
        }
        imageview = getImageView();
        mCurrentFlingRunnable = new FlingRunnable(imageview.getContext());
        mCurrentFlingRunnable.fling(getImageViewWidth(imageview), getImageViewHeight(imageview), (int)f2, (int)f3);
        imageview.post(mCurrentFlingRunnable);
    }

    public void onGlobalLayout()
    {
        ImageView imageview = getImageView();
        if (imageview == null)
        {
            return;
        }
        if (!mZoomEnabled)
        {
            updateBaseMatrix(imageview.getDrawable());
            return;
        }
        int i = imageview.getTop();
        int j = imageview.getRight();
        int k = imageview.getBottom();
        for (int l = imageview.getLeft(); i != mIvTop || k != mIvBottom || l != mIvLeft || j != mIvRight;)
        {
            updateBaseMatrix(imageview.getDrawable());
            mIvTop = i;
            mIvRight = j;
            mIvBottom = k;
            mIvLeft = l;
            return;
        }

    }

    public void onScale(float f, float f1, float f2)
    {
        boolean flag1 = true;
        boolean flag;
        if (DEBUG)
        {
            LogManager.getLogger().d("PhotoViewAttacher", String.format("onScale: scale: %.2f. fX: %.2f. fY: %.2f", new Object[] {
                Float.valueOf(f), Float.valueOf(f1), Float.valueOf(f2)
            }));
        }
        if (getScale() < mMaxScale)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag || f < 1.0F)
        {
            if (getScale() > mMinScale)
            {
                flag = flag1;
            } else
            {
                flag = false;
            }
            if (flag || f > 1.0F)
            {
                if (mScaleChangeListener != null)
                {
                    mScaleChangeListener.onScaleChange(f, f1, f2);
                }
                mSuppMatrix.postScale(f, f, f1, f2);
                checkAndDisplayMatrix();
            }
        }
    }

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        ViewParent viewparent;
        boolean flag3;
        for (flag3 = false; !mZoomEnabled || !hasDrawable((ImageView)view);)
        {
            return false;
        }

        viewparent = view.getParent();
        motionevent.getAction();
        JVM INSTR tableswitch 0 3: default 60
    //                   0 80
    //                   1 118
    //                   2 60
    //                   3 118;
           goto _L1 _L2 _L3 _L1 _L3
_L1:
        boolean flag2 = false;
_L7:
        if (mScaleDragDetector != null) goto _L5; else goto _L4
_L2:
        if (viewparent == null)
        {
            LogManager.getLogger().i("PhotoViewAttacher", "onTouch getParent() returned null");
        } else
        {
            viewparent.requestDisallowInterceptTouchEvent(true);
        }
        cancelFling();
        flag2 = false;
          goto _L6
_L3:
        if (getScale() < mMinScale)
        {
            RectF rectf = getDisplayRect();
            if (rectf == null)
            {
                flag2 = false;
            } else
            {
                view.post(new AnimatedZoomRunnable(getScale(), mMinScale, rectf.centerX(), rectf.centerY()));
                flag2 = true;
            }
        } else
        {
            flag2 = false;
        }
          goto _L6
_L5:
        flag2 = mScaleDragDetector.isScaling();
        boolean flag5 = mScaleDragDetector.isDragging();
        boolean flag4 = mScaleDragDetector.onTouchEvent(motionevent);
        boolean flag;
        boolean flag1;
        if (flag2 || mScaleDragDetector.isScaling())
        {
            flag = false;
        } else
        {
            flag = true;
        }
        if (flag5 || mScaleDragDetector.isDragging())
        {
            flag1 = false;
        } else
        {
            flag1 = true;
        }
        if (!flag)
        {
            flag2 = flag3;
        } else
        {
            flag2 = flag3;
            if (flag1)
            {
                flag2 = true;
            }
        }
        mBlockParentIntercept = flag2;
        flag2 = flag4;
_L4:
        if (mGestureDetector == null || !mGestureDetector.onTouchEvent(motionevent))
        {
            return flag2;
        }
        return true;
_L6:
        if (true) goto _L7; else goto _L5
    }

    public void setAllowParentInterceptOnEdge(boolean flag)
    {
        mAllowParentInterceptOnEdge = flag;
    }

    public void setBaseRotation(float f)
    {
        mBaseRotation = f % 360F;
        update();
        setRotationBy(mBaseRotation);
        checkAndDisplayMatrix();
    }

    public boolean setDisplayMatrix(Matrix matrix)
    {
        if (matrix != null)
        {
            ImageView imageview = getImageView();
            if (imageview != null)
            {
                if (imageview.getDrawable() != null)
                {
                    mSuppMatrix.set(matrix);
                    setImageViewMatrix(getDrawMatrix());
                    checkMatrixBounds();
                    return true;
                } else
                {
                    return false;
                }
            } else
            {
                return false;
            }
        } else
        {
            throw new IllegalArgumentException("Matrix cannot be null");
        }
    }

    public void setMaximumScale(float f)
    {
        checkZoomLevels(mMinScale, mMidScale, f);
        mMaxScale = f;
    }

    public void setMediumScale(float f)
    {
        checkZoomLevels(mMinScale, f, mMaxScale);
        mMidScale = f;
    }

    public void setMinimumScale(float f)
    {
        checkZoomLevels(f, mMidScale, mMaxScale);
        mMinScale = f;
    }

    public void setOnDoubleTapListener(android.view.GestureDetector.OnDoubleTapListener ondoubletaplistener)
    {
        if (ondoubletaplistener == null)
        {
            mGestureDetector.setOnDoubleTapListener(new DefaultOnDoubleTapListener(this));
            return;
        } else
        {
            mGestureDetector.setOnDoubleTapListener(ondoubletaplistener);
            return;
        }
    }

    public void setOnLongClickListener(android.view.View.OnLongClickListener onlongclicklistener)
    {
        mLongClickListener = onlongclicklistener;
    }

    public void setOnMatrixChangeListener(OnMatrixChangedListener onmatrixchangedlistener)
    {
        mMatrixChangeListener = onmatrixchangedlistener;
    }

    public void setOnPhotoTapListener(OnPhotoTapListener onphototaplistener)
    {
        mPhotoTapListener = onphototaplistener;
    }

    public void setOnScaleChangeListener(OnScaleChangeListener onscalechangelistener)
    {
        mScaleChangeListener = onscalechangelistener;
    }

    public void setOnSingleFlingListener(OnSingleFlingListener onsingleflinglistener)
    {
        mSingleFlingListener = onsingleflinglistener;
    }

    public void setOnViewTapListener(OnViewTapListener onviewtaplistener)
    {
        mViewTapListener = onviewtaplistener;
    }

    public void setRotationBy(float f)
    {
        mSuppMatrix.postRotate(f % 360F);
        checkAndDisplayMatrix();
    }

    public void setRotationTo(float f)
    {
        mSuppMatrix.setRotate(f % 360F);
        checkAndDisplayMatrix();
    }

    public void setScale(float f)
    {
        setScale(f, false);
    }

    public void setScale(float f, float f1, float f2, boolean flag)
    {
        boolean flag1 = false;
        ImageView imageview = getImageView();
        if (imageview == null)
        {
            return;
        }
        if (f < mMinScale)
        {
            flag1 = true;
        }
        if (flag1 || f > mMaxScale)
        {
            LogManager.getLogger().i("PhotoViewAttacher", "Scale must be within the range of minScale and maxScale");
            return;
        }
        if (!flag)
        {
            mSuppMatrix.setScale(f, f, f1, f2);
            checkAndDisplayMatrix();
            return;
        } else
        {
            imageview.post(new AnimatedZoomRunnable(getScale(), f, f1, f2));
            return;
        }
    }

    public void setScale(float f, boolean flag)
    {
        ImageView imageview = getImageView();
        if (imageview == null)
        {
            return;
        } else
        {
            setScale(f, imageview.getRight() / 2, imageview.getBottom() / 2, flag);
            return;
        }
    }

    public void setScaleLevels(float f, float f1, float f2)
    {
        checkZoomLevels(f, f1, f2);
        mMinScale = f;
        mMidScale = f1;
        mMaxScale = f2;
    }

    public void setScaleType(android.widget.ImageView.ScaleType scaletype)
    {
        while (!isSupportedScaleType(scaletype) || scaletype == mScaleType) 
        {
            return;
        }
        mScaleType = scaletype;
        update();
    }

    public void setZoomInterpolator(Interpolator interpolator)
    {
        mInterpolator = interpolator;
    }

    public void setZoomTransitionDuration(int i)
    {
        if (i < 0)
        {
            i = 200;
        }
        ZOOM_DURATION = i;
    }

    public void setZoomable(boolean flag)
    {
        mZoomEnabled = flag;
        update();
    }

    public void update()
    {
        ImageView imageview = getImageView();
        if (imageview == null)
        {
            return;
        }
        if (!mZoomEnabled)
        {
            resetMatrix();
            return;
        } else
        {
            setImageViewScaleTypeMatrix(imageview);
            updateBaseMatrix(imageview.getDrawable());
            return;
        }
    }








}
